package com.service.feedback.Impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fegin.client.ArchiveClient;
import com.common.ApiException;
import com.common.Result;
import com.dto.FeedbackDTO;
import com.mapper.feedback.FeedbackManagerMapper;
import com.mapper.tenant.TenantMapper;
import com.mapper.user.UserMapper;
import com.pojo.Feedback;
import com.pojo.Tenant;
import com.pojo.User;
import com.service.feedback.FeedbackManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2023/10/18 
 */
@Service
public class FeedbackManagerServiceImpl implements FeedbackManagerService {

    @Autowired
    private FeedbackManagerMapper feedbackManagerMapper;

    @Autowired
    private ArchiveClient  archiveClient;

    @Autowired
    private TenantMapper tenantMapper;

    @Autowired
    private UserMapper userMapper;


    /***
       * 反馈管理-首页面查询
       * @author liuwei
       * @date  2023/10/23
       * @params [id]
       * @return com.common.Result
     */
    @Override
    public Result getFeedbackByUser(String id) {
        String roleCode = archiveClient.getRole().getRoleCode();
        String orgId = archiveClient.getOrg().getOrgId();
        List<Feedback> feedbackList =  new ArrayList<>();
        if(roleCode.equals("admin")){
            //管理员角色查看所有反馈
            feedbackList = feedbackManagerMapper.selectList(new QueryWrapper<Feedback>().orderByDesc("create_time","type"));
        }else {
            //非管理员角色查看当前组织下的
            User curentUser = userMapper.selectById(id);
            List<String> ids = new ArrayList<>();
            List<Tenant> tenants = new ArrayList<>();
            if("".equals(curentUser.getTgBuildDoorplate()) || null == curentUser.getTgBuildDoorplate()){
                String areaId = curentUser.getAreaId();
                tenants = tenantMapper.selectList(new QueryWrapper<Tenant>().in("area_id",areaId));
            }else{
                String tgId = curentUser.getTgBuildDoorplate();
                List<String> bgList = archiveClient.reGetChildBDGradeId(tgId,orgId);
                tenants = tenantMapper.selectList(new QueryWrapper<Tenant>().in("tg_build_doorplate",bgList));
            }
            tenants.forEach(val->{
                String tenantId = val.getId()+"";
                ids.add(tenantId);
            });
            if(tenants.size() > 0  ){
                feedbackList = feedbackManagerMapper.selectList(new QueryWrapper<Feedback>().in("create_user",ids));
            }
        }
        return Result.OK(feedbackList);
    }

    /**
       * 反馈管理-查询反馈
       * @author liuwei
       * @date  2023/10/20
       * @params [feedback]
       * @return com.common.Result
     */
    @Override
    public Result getFeedback(FeedbackDTO feedback) {
        String roleCode = archiveClient.getRole().getRoleCode();
        String tgId = archiveClient.getTgId();
        String areaId = archiveClient.getAreaId();
        Page<Feedback> page = new Page<>(feedback.getPage(),feedback.getLimit());
        QueryWrapper<Feedback> qw = new QueryWrapper<>();
        if(!"".equals(feedback.getType()) && null != feedback.getType()){
            qw.eq("type",feedback.getType());
        }
        if(!"".equals(feedback.getStatus()) && null != feedback.getStatus()){
            qw.eq("status",feedback.getStatus());
        }
        if(!"".equals(feedback.getTitle()) && null != feedback.getTitle()){
            qw.like("title","%" + feedback.getTitle() + "%");
        }


        if(roleCode.equals("admin")){
            qw.orderByDesc("level","create_time","status");
            //管理员角色查找所有反馈
            page = feedbackManagerMapper.selectPage(page,qw);
        }else{
            List<String> ids = new ArrayList<>();
            List<Tenant> tenantList;
            if("".equals(tgId)||null == tgId){
                //组织区域人员
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().eq("area_id",areaId));
            }else{
                //门栋单元人员
                List<String> bdList = archiveClient.reGetChildBDGradeId(tgId,archiveClient.getOrg().getOrgId());
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("tg_build_doorplate",bdList));
            }
            tenantList.forEach(val->ids.add(val.getId()+""));
            qw.in("create_user",ids);
            qw.orderByDesc("level","create_time","status");
            page = feedbackManagerMapper.selectPage(page,qw);
        }
        return Result.OK(page);
    }

    /***
       * 反馈管理-处理回复反馈
       * @author liuwei
       * @date  2023/10/23
       * @params [dto]
       * @return com.common.Result
     */
    @Override
    public Result replay(FeedbackDTO dto) {
        int count = feedbackManagerMapper.replay(dto);
        if(count >0){
            return Result.OK();
        }else{
            return Result.ERROR(new ApiException(500,"批量回复出现异常！"));
        }
    }

    /***
       * 反馈管理-获得反馈的一些数据
       * @author liuwei
       * @date  2023/10/23
       * @params []
       * @return com.common.Result
     */
    @Override
    public Result getFeedbackAnalysisData() {
        String roleCode = archiveClient.getRole().getRoleCode();
        String tgId = archiveClient.getTgId();
        String areaId = archiveClient.getAreaId();
        FeedbackDTO dto = new FeedbackDTO();
        DecimalFormat df = new DecimalFormat("######0.00");
        List<Tenant> tenantList = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        int functionalNum = 0;
        int performanceNum = 0;
        int noDealNum = 0;
        int replayNum = 0;
        int goodNum = 0;
        int badNum = 0;
        double badRate = 0;
        double replayRate = 0;
        if(roleCode.equals("admin")){
            //管理员
            functionalNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("type","0"));
            performanceNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("type","1"));
            noDealNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("status","0"));
            replayNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("status","1"));
            goodNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().ge("level",3));
            badNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().lt("level",3));
        }else{
            if(!"".equals(tgId) && null != tgId){
                //门栋单元人员
                List<String> bdList = archiveClient.reGetChildBDGradeId(tgId,archiveClient.getOrg().getOrgId());
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("tg_build_doorplate",bdList));
            }else{
                //组织区域人员
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().eq("area_id",areaId));
            }
            tenantList.forEach(val->ids.add(val.getId()+""));
            functionalNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("type","0").in("create_user",ids));
            performanceNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("type","1").in("create_user",ids));
            noDealNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("status","0").in("create_user",ids));
            replayNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().eq("status","1").in("create_user",ids));
            goodNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().ge("level",3).in("create_user",ids));
            badNum = feedbackManagerMapper.selectCount(new QueryWrapper<Feedback>().lt("level",3).in("create_user",ids));
        }
        badRate = ((double) badNum / (double) (goodNum+badNum)) * 100;
        badRate = Double.parseDouble(df.format(badRate));
        replayRate = ((double) replayNum / (double) (replayNum+noDealNum)) * 100;
        replayRate = Double.parseDouble(df.format(replayRate));

        dto.setFunctionalNum(functionalNum);
        dto.setPerformanceNum(performanceNum);
        dto.setNoDealNum(noDealNum);
        dto.setReplayNum(replayNum);
        dto.setGoodNum(goodNum);
        dto.setBadNum(badNum);
        dto.setBadRate(badRate);
        dto.setReplayRate(replayRate);
        return Result.OK(dto);
    }
}
