package com.config;

import com.fegin.client.CollectService;
import org.springframework.stereotype.Component;

@Component
public class CollectHysitx implements CollectService {
    @Override
    public Object startListenOrgin() {
        return "服务异常，触发熔断";
    }
}
