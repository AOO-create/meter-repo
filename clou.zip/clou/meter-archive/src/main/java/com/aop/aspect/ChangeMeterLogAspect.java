package com.aop.aspect;

import com.aop.annotation.ChangeMeterAopAnnotation;
import com.common.Const;
import com.dto.equipment.MeterDTO;
import com.entity.log.ChangeMeterLog;
import com.entity.Org;
import com.entity.equipment.WNB;
import com.entity.equipment.WiredMeter;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.mapper.systemLog.ChangeMeterLogMapper;
import com.util.ShiroConstUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.*;

@Aspect
@Component
@EnableAsync
public class ChangeMeterLogAspect {
    @Autowired
    private ChangeMeterLogMapper logMapper;//日志 mapper

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    private long startTimeMillis = 0; // 开始时间
    private long endTimeMillis = 0; // 结束时间

    /**
     * 注解的位置
     */
    @Pointcut("@annotation(com.aop.annotation.ChangeMeterAopAnnotation)")
    public void logPointCut() {
    }

    /**
     * @param joinPoint
     * @Description 前置通知  方法调用前触发   记录开始时间,从session中获取操作人
     */
    @Before(value = "logPointCut()")
    public void before(JoinPoint joinPoint) {
        startTimeMillis = System.currentTimeMillis();
        //删除操作在切点前面执行
        String targetName = joinPoint.getTarget().getClass().getName();
        String methodName = joinPoint.getSignature().getName();
        Object[] arguments = joinPoint.getArgs();
        Class<?> targetClass = null;
        try {
            targetClass = Class.forName(targetName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Method[] methods = targetClass.getMethods();
        Class<?>[] clazzs;
        for (Method method : methods) {
            if (method.getName().equals(methodName)) {
                clazzs = method.getParameterTypes();
                if (clazzs != null && clazzs.length == arguments.length && method.getAnnotation(ChangeMeterAopAnnotation.class) != null) {
                    int opType = method.getAnnotation(ChangeMeterAopAnnotation.class).changeType();
                    operate(joinPoint, opType);
                }
            }
        }
    }

    /**
     * @param joinPoint
     * @return
     * @Description 获取入参方法参数
     */
    public Map<String, Object> getNameAndValue(JoinPoint joinPoint, int type) {
        Map<String, Object> param = new HashMap<>();
        MeterDTO dto = (MeterDTO) joinPoint.getArgs()[0];
        param.put("oldId",dto.getId());
        param.put("meterAddress", dto.getMeterAddress());
        param.put("name", dto.getName());
        param.put("areaId", dto.getAreaId());
        param.put("meterType",dto.getMeterType());
        return param;
    }


    /**
     * 功能描述
     * @param joinPoint
     * @return void
     * @author liuwei
     * @date 2022/6/24
     */
    private void operate(JoinPoint joinPoint, int opType) {
        //业务操作
        ChangeMeterLog log = new ChangeMeterLog();
        Map<String, Object> map = getNameAndValue(joinPoint, opType);
        String oldMeterAddress = null;
        String oldMeterName = null;
        String meterType = "";
        //获取到表地址；表名称；组织区域；
        if(opType == Const.unbind_meter){
            if(map.get("meterType").equals("0")){
                log.setOpType(Const.unbind_nb_meter);
            }else{
                WiredMeter wiredMeter = wiredMeterMapper.selectById((String)map.get("oldId"));
                meterType = wiredMeter.getMeterType();
                log.setOpType(Const.unbind_wired_meter);
            }
        }else{
            if(map.get("meterType").equals("0")){
                log.setOpType(Const.change_nb_meter);
                WNB wnb  = nBmeterMapper.selectById((String)map.get("oldId"));
                oldMeterAddress = wnb.getMeterAddress();
                oldMeterName = wnb.getName();
            }else{
                log.setOpType(Const.change_wired_meter);
                WiredMeter wiredMeter = wiredMeterMapper.selectById((String)map.get("oldId"));
                oldMeterAddress = wiredMeter.getMeterAddress();
                oldMeterName = wiredMeter.getName();
                meterType = wiredMeter.getMeterType();
            }
        }
        log.setMeterAddress((String) map.get("meterAddress"));
        log.setMeterName((String) map.get("name"));
        log.setAreaId((String) map.get("areaId"));
        log.setOpUser(String.valueOf(Const.userId));

        Org org = shiroConstUtils.getOrg();
        log.setOrgId(org.getOrgId());
        log.setOldMeterAddress(oldMeterAddress);
        log.setOldMeterName(oldMeterName);
        log.setMeterType(meterType);
        endTimeMillis = System.currentTimeMillis();
        log.setOpUseTime(endTimeMillis - startTimeMillis);
        log.setOpTime(new Date());
        logMapper.insert(log);
    }

    /**
     * @param joinPoint
     * @Description 后置通知    方法调用后触发   记录结束时间 ,操作人 ,入参等
     */
    @After(value = "logPointCut()")
    public void after(JoinPoint joinPoint) {}

    /**
     * @Description: 获取request
     */
    public HttpServletRequest getHttpServletRequest() {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();
        return request;
    }

    /**
     * @param joinPoint
     * @return 环绕通知
     * @throws Throwable
     */
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        return null;
    }

    /**
     * @param joinPoint
     * @Description 异常通知
     */
    public void throwing(JoinPoint joinPoint) {
        System.out.println("异常通知");
    }
}
