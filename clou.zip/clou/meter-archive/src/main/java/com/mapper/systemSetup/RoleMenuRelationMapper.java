package com.mapper.systemSetup;

import com.entity.systemSetup.RoleMenuRelation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

public interface RoleMenuRelationMapper extends BaseMapper<RoleMenuRelation> {


    int updateFlag(@Param("relation") RoleMenuRelation relation);
}
