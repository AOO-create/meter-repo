package com.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Data
@TableName("wired_meter")
public class WiredMeter {

    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    private String meterAddress;

    private String name;

    private String instLoc;

    private Date instTime;

    private String meterType;

    private String channel;

    private String protocol;

    private String uartbps;

    private String termId;

    private String orgId;

    private String areaId;

    private String tgBuildDoorplate;
}
