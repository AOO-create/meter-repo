package com.szclou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 说明：水表
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-1-26
 */
public class Wmtr {
    private String wmtrId;//水表标识
    private String wmtrNo;//水表编号
    private double baseValue;//水表低度
    private int belongTo;//水表归属
    private String caliberId;
    private String consId;
    private String orgId;//供能单位ID
    private String areaId;//组织单位ID
    private int buildingUnit;//楼栋单元
    private int doorplate;//门牌
    private int wmtrType;//表具类型
    private int wmtrUsage;//水表用途
    private int assessType;//考核类型
    private double rate;//倍率
    private double dayAlrUp;//日报警水量下限
    private double dayAlrLow;//日报警水量上限
    private String instLoc;//安装位置
    private String gpsLongitude;//gps经度
    private String gpsLatitude;//gps纬度
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date instDate;//安装日期
    private String mtrParaId;
    private Date updTime;

    private String tgBuildDoorplate;

    private int isTap;

    public int getIsTap() {
        return isTap;
    }

    public void setIsTap(int isTap) {
        this.isTap = isTap;
    }

    public String getWmtrId() {
        return wmtrId;
    }

    public void setWmtrId(String wmtrId) {
        this.wmtrId = wmtrId;
    }

    public String getWmtrNo() {
        return wmtrNo;
    }

    public void setWmtrNo(String wmtrNo) {
        this.wmtrNo = wmtrNo;
    }

    public double getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(double baseValue) {
        this.baseValue = baseValue;
    }

    public int getBelongTo() {
        return belongTo;
    }

    public void setBelongTo(int belongTo) {
        this.belongTo = belongTo;
    }

    public String getCaliberId() {
        return caliberId;
    }

    public void setCaliberId(String caliberId) {
        this.caliberId = caliberId;
    }

    public String getConsId() {
        return consId;
    }

    public void setConsId(String consId) {
        this.consId = consId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public int getBuildingUnit() {
        return buildingUnit;
    }

    public void setBuildingUnit(int buildingUnit) {
        this.buildingUnit = buildingUnit;
    }

    public int getDoorplate() {
        return doorplate;
    }

    public void setDoorplate(int doorplate) {
        this.doorplate = doorplate;
    }

    public int getWmtrType() {
        return wmtrType;
    }

    public void setWmtrType(int wmtrType) {
        this.wmtrType = wmtrType;
    }

    public int getWmtrUsage() {
        return wmtrUsage;
    }

    public void setWmtrUsage(int wmtrUsage) {
        this.wmtrUsage = wmtrUsage;
    }

    public int getAssessType() {
        return assessType;
    }

    public void setAssessType(int assessType) {
        this.assessType = assessType;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getDayAlrUp() {
        return dayAlrUp;
    }

    public void setDayAlrUp(double dayAlrUp) {
        this.dayAlrUp = dayAlrUp;
    }

    public double getDayAlrLow() {
        return dayAlrLow;
    }

    public void setDayAlrLow(double dayAlrLow) {
        this.dayAlrLow = dayAlrLow;
    }

    public Date getInstDate() {
        return instDate;
    }

    public void setInstDate(Date instDate) {
        this.instDate = instDate;
    }

    public String getMtrParaId() {
        return mtrParaId;
    }

    public void setMtrParaId(String mtrParaId) {
        this.mtrParaId = mtrParaId;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getTgBuildDoorplate() {
        return tgBuildDoorplate;
    }

    public void setTgBuildDoorplate(String tgBuildDoorplate) {
        this.tgBuildDoorplate = tgBuildDoorplate;
    }

    public String getGpsLatitude() {
        return gpsLatitude;
    }

    public void setGpsLatitude(String gpsLatitude) {
        this.gpsLatitude = gpsLatitude;
    }


    public String getInstLoc() {
        return instLoc;
    }

    public void setInstLoc(String instLoc) {
        this.instLoc = instLoc == null ? null : instLoc.trim();
    }

    public String getGpsLongitude() {
        return gpsLongitude;
    }

    public void setGpsLongitude(String gpsLongitude) {
        this.gpsLongitude = gpsLongitude == null ? null : gpsLongitude.trim();
    }



}