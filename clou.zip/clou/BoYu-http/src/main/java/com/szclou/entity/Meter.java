package com.szclou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 说明：电表
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-8-8
 */
public class Meter {

    private String meterId;
    private String assetNo;//资产编号
    private String madeNo;//出厂编号
    private String barCode;//条形码
    private String wiringMode;//接线方式
    private String measMode;//计量方式
    private String voltCode;//电压等级
    private String tFactor;//综合倍率
    private String currentRatioCode;//电流变比
    private String voltRatioCode;//电压变比
    private String consId;//用户ID
    private String orgId;//供能单位ID
    private String areaId;//组织单位ID
    private int buildingUnit;//楼栋单元
    private int doorPlate;//门牌
    private double papR;//费率总
    private double papR1;//费率1
    private double papR2;//费率2
    private double papR3;//费率3
    private double papR4;//费率4
    private int refMeterFlag;//是否参考表
    private String refMeterId;//参考表标识
    private String curStatusCode;//当前状态
    private String instLoc;//安装位置
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date instDate;//安装日期
    private String gpsLongitude;//GPRS精度
    private String gpsLatitude;//GPRS维度
    private String mtrParaId;//表计参数标识
    private Date updTime;


    private double baseValue; //低度

    private String tgBuildDoorplate;

    private int isTap;

    private int meterUsage;

    public int getMeterUsage() {
        return meterUsage;
    }

    public void setMeterUsage(int meterUsage) {
        this.meterUsage = meterUsage;
    }

    public int getIsTap() {
        return isTap;
    }

    public void setIsTap(int isTap) {
        this.isTap = isTap;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public String getAssetNo() {
        return assetNo;
    }

    public void setAssetNo(String assetNo) {
        this.assetNo = assetNo;
    }

    public String getMadeNo() {
        return madeNo;
    }

    public void setMadeNo(String madeNo) {
        this.madeNo = madeNo;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getWiringMode() {
        return wiringMode;
    }

    public void setWiringMode(String wiringMode) {
        this.wiringMode = wiringMode;
    }

    public String getMeasMode() {
        return measMode;
    }

    public void setMeasMode(String measMode) {
        this.measMode = measMode;
    }

    public String getVoltCode() {
        return voltCode;
    }

    public void setVoltCode(String voltCode) {
        this.voltCode = voltCode;
    }

    public String gettFactor() {
        return tFactor;
    }

    public void settFactor(String tFactor) {
        this.tFactor = tFactor;
    }

    public String getCurrentRatioCode() {
        return currentRatioCode;
    }

    public void setCurrentRatioCode(String currentRatioCode) {
        this.currentRatioCode = currentRatioCode;
    }

    public String getVoltRatioCode() {
        return voltRatioCode;
    }

    public void setVoltRatioCode(String voltRatioCode) {
        this.voltRatioCode = voltRatioCode;
    }

    public String getConsId() {
        return consId;
    }

    public void setConsId(String consId) {
        this.consId = consId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public int getBuildingUnit() {
        return buildingUnit;
    }

    public void setBuildingUnit(int buildingUnit) {
        this.buildingUnit = buildingUnit;
    }

    public int getDoorPlate() {
        return doorPlate;
    }

    public void setDoorPlate(int doorPlate) {
        this.doorPlate = doorPlate;
    }

    public double getPapR() {
        return papR;
    }

    public void setPapR(double papR) {
        this.papR = papR;
    }

    public double getPapR1() {
        return papR1;
    }

    public void setPapR1(double papR1) {
        this.papR1 = papR1;
    }

    public double getPapR2() {
        return papR2;
    }

    public void setPapR2(double papR2) {
        this.papR2 = papR2;
    }

    public double getPapR3() {
        return papR3;
    }

    public void setPapR3(double papR3) {
        this.papR3 = papR3;
    }

    public double getPapR4() {
        return papR4;
    }

    public void setPapR4(double papR4) {
        this.papR4 = papR4;
    }

    public int getRefMeterFlag() {
        return refMeterFlag;
    }

    public void setRefMeterFlag(int refMeterFlag) {
        this.refMeterFlag = refMeterFlag;
    }

    public String getRefMeterId() {
        return refMeterId;
    }

    public void setRefMeterId(String refMeterId) {
        this.refMeterId = refMeterId;
    }

    public String getCurStatusCode() {
        return curStatusCode;
    }

    public void setCurStatusCode(String curStatusCode) {
        this.curStatusCode = curStatusCode;
    }

    public String getInstLoc() {
        return instLoc;
    }

    public void setInstLoc(String instLoc) {
        this.instLoc = instLoc;
    }

    public Date getInstDate() {
        return instDate;
    }

    public void setInstDate(Date instDate) {
        this.instDate = instDate;
    }

    public String getGpsLongitude() {
        return gpsLongitude;
    }

    public void setGpsLongitude(String gpsLongitude) {
        this.gpsLongitude = gpsLongitude;
    }

    public String getGpsLatitude() {
        return gpsLatitude;
    }

    public void setGpsLatitude(String gpsLatitude) {
        this.gpsLatitude = gpsLatitude;
    }

    public String getMtrParaId() {
        return mtrParaId;
    }

    public void setMtrParaId(String mtrParaId) {
        this.mtrParaId = mtrParaId;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public double getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(double baseValue) {
        this.baseValue = baseValue;
    }

    public String getTgBuildDoorplate() {
        return tgBuildDoorplate;
    }

    public void setTgBuildDoorplate(String tgBuildDoorplate) {
        this.tgBuildDoorplate = tgBuildDoorplate;
    }
}
