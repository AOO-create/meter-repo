package com.sso.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @program: springboot-security-sso
 * @description:
 * @author: 吴方豪
 * @create: 2022-11-02 11:29
 **/
@Data
public class SysRole implements GrantedAuthority {
    private String id;
    private String name;
    private String descr;

    private String createName;

    private String roleCode;

    private String orgId;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date updTime;

    @JsonIgnore
    @Override
    public String getAuthority() {
        return name;
    }
}
