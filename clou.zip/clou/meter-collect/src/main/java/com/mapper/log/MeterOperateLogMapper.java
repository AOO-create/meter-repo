package com.mapper.log;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.log.OperateMeterLog;
import com.vo.SystemLogVo.OperateMeterLogVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface MeterOperateLogMapper extends BaseMapper<OperateMeterLog> {

    List<OperateMeterLogVO> getLog(@Param("dto") OperateMeterLogVO dto);

    int getLogCount(@Param("dto") OperateMeterLogVO dto);
}
