package com.mapper.tenant;

import com.entity.tenant.TenantBuildRela;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author liuwei
 * @description
 * @date 2022/7/26
 */
public interface TenantBuildRelaMapper extends BaseMapper<TenantBuildRela> {
}
