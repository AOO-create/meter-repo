package com.service.equipment.impl;

import com.aop.annotation.AopAnnotation;
import com.config.DynamicDataSource;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.equipment.Term;
import com.entity.organization.BDGrade;
import com.entity.organization.Grade;
import com.mapper.dataView.DataViewMapper;
import com.mapper.equipment.TermManagerMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.organization.OrgMapper;
import com.entity.equipment.WiredMeter;
import com.entity.Org;
import com.service.equipment.WiredMeterService;
import com.service.organization.impl.GradeServiceImpl;
import com.util.ShiroConstUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.ApiException;
import com.common.Const;
import com.common.Result;
import com.common.ResultCodeEnum;
import com.vo.exportExcelVo.ExportExcelParamsVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
@Service
@Slf4j //开启Log4j日志
public class WiredMeterServiceImpl implements WiredMeterService {

    @Autowired
    private NBmeterServiceImpl service;

    @Autowired
    private WiredMeterMapper mapper;

    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private TermManagerMapper termManagerMapper;

    @Autowired
    private DataViewMapper dataViewMapper;

    @Autowired
    private GradeServiceImpl gradeService;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public Page<WiredMeterDTO> getMeter(WiredMeterDTO dto) {
        Org org = shiroConstUtils.getOrg();

        dto.setOrgId(org.getOrgId());

        String areaId = dto.getAreaId();
        List<String> idList = new ArrayList<>();
        List<String> bdIdList = new ArrayList<>();

        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }


        List<WiredMeterDTO> nblist = new ArrayList<>();


        //查找出所有的区域ID
        List<String> tempList = new ArrayList<>();
        if(null == areaId || areaId.equals("")){
            bdIdList = gradeService.reGetChildBDGradeId(dto.getTgBuildDoorplate(),dto.getOrgId(),tempList);
        }

        nblist = mapper.getMeter(dto,areaId,bdIdList);
        int count = mapper.getCount(dto,areaId,bdIdList);
        Page<WiredMeterDTO> page = new Page<>();
        if(nblist.size() !=0 && nblist !=null){
            page.setRecords(nblist);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Transactional
    @AopAnnotation(opType = Const.operate_wired_insert)
    @Override
    public Result save(WiredMeterDTO dto){
        System.out.println(dto.getPn());
        WiredMeter wiredMeter = new WiredMeter();
        String termId = dto.getTermId();
        String areaId = termManagerMapper.getByAddress(termId).getAreaId();
        dto.setAreaId(areaId);
        //安装位置需要根据areaId和tgId去给添加上
        String instLoc = gradeMapper.getInstLocById(dto.getAreaId(),dto.getTgBuildDoorplate());
        dto.setInstLoc(instLoc);
        dto.setInstTime(new Date());

        Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());

        BeanUtils.copyProperties(dto,wiredMeter);

        int num = mapper.selectCount(new QueryWrapper<WiredMeter>()
                .eq("meter_address",dto.getMeterAddress())
                .eq("term_id",dto.getTermId()));

        if(num >= 1){
            return Result.ERROR(new ApiException(500,"新增档案失败，集中器下已存在该表地址的有线表"));
        }

        int result = mapper.insert(wiredMeter);
//                addWiredMeter(wiredMeter);
        if(result <0){
            return Result.ERROR(new ApiException(500,"新增表档案失败，请查找原因"));
        }
        return Result.OK("新增表档案成功！");
    }

    @Override
    public Boolean validMeterAddress(String meterAddress) {
        return mapper.selectCount(new QueryWrapper<WiredMeter>().eq("meter_address",meterAddress)) <= 0;
    }

    @Transactional
    @AopAnnotation(opType = Const.operate_wired_update)
    @Override
    public Result update(WiredMeterDTO dto){
        String instLoc = gradeMapper.getInstLocById(dto.getAreaId(),dto.getTgBuildDoorplate());
        dto.setInstLoc(instLoc);
        dto.setInstTime(new Date());

        WiredMeter wiredMeter = new WiredMeter();
        BeanUtils.copyProperties(dto,wiredMeter);
        wiredMeter.setId(Long.valueOf(dto.getId()));

//        int num = mapper.selectCount(new QueryWrapper<WiredMeter>()
//                .eq("meter_address",dto.getMeterAddress())
//                .eq("term_id",dto.getTermId()));
//        if(num >= 1){
//            return Result.ERROR(new ApiException(500,"新增档案失败，集中器下已存在该表地址的有线表"));
//        }

        int result = mapper.updateById(wiredMeter);
//                updateWiredMeter(dto);
        if(result <0){
            return Result.ERROR(new ApiException(500,"修改表档案失败，请查找原因"));
        }
        return Result.OK("修改表档案成功！");
    }

    @Override
    public Page<MeterDayDataDTO> getWiredDayData(MeterDayDataDTO dto, String date) {
        Org org = shiroConstUtils.getOrg();
        String tgId = dto.getTgBuildDoorplate();
        String areaId = dto.getAreaId();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dto.setOrgId(org.getOrgId());
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        List<MeterDayDataDTO> nbList = new ArrayList<>();
        List<MeterDayDataDTO> meterList = new ArrayList<>();
        int count = 0;
        if(null == areaId || areaId.equals("")){
            areaId = bdGradeMapper.selectById(tgId).getAreaId();
            List<String> bdIds = gradeService.reGetChildBDGradeId(tgId,org.getOrgId(),new ArrayList<>());
            meterList = mapper.get818Meter(areaId,bdIds);
            nbList = mapper.getDataByTgIdAndOrgId(dto,bdIds,date);
            count = mapper.getDateDayCountByTgId(dto,bdIds,date);
        }else{
            meterList = mapper.get818Meter(areaId,null);
            nbList = mapper.getDateByAreaIdAndOrgId(dto,date);
            count = mapper.getDateDayCount(dto,date);
        }
        //kl2022库查询所有关联ID
        DynamicDataSource.name.set("r");
        List<MeterDayDataDTO> temp = meterList;
        //查询CL6904库数据
        DynamicDataSource.name.set("w");
        List<MeterDayDataDTO> finalMeterList = new ArrayList<>();
        finalMeterList.addAll(meterList);
        temp.forEach(val -> {
            String pap_r = dataViewMapper.getCL6904Data(val.getMeterId(), date);
            if(null == pap_r || pap_r.equals("")){
                finalMeterList.remove(val);
            }else{
                val.setRealSumFlow(pap_r);
                try {
                    val.setDataDate(simpleDateFormat.parse(date));
                    val.setCollTime(simpleDateFormat.parse(date));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
        meterList = finalMeterList;
        DynamicDataSource.name.set("r");
        nbList.addAll(meterList);
        count = count + meterList.size();

        Page<MeterDayDataDTO> page = new Page<>();
        if(nbList.size() !=0 && nbList !=null){
            page.setRecords(nbList);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Transactional
    @Override
    public Result  ExcelWiredIn(List<WiredMeterDTO> list) throws Exception {
        List<WiredMeterDTO> wiredMeterDTOS = list;
        String errorAddress = "";
        String orgId = shiroConstUtils.getOrg().getOrgId();
        Result result = new Result();

        for(WiredMeterDTO dto : wiredMeterDTOS){
            String bdName = dto.getInstLoc();
            String termId = dto.getTermId();
            Term termDTO = termManagerMapper.selectOne(new QueryWrapper<Term>().eq("address",termId));

            if( null == termDTO ){
                list.remove(dto);
                errorAddress = errorAddress + dto.getMeterAddress()+"无此集中器；";
                continue;
            }else {
                dto.setAreaId(termDTO.getAreaId());
            }
            Grade grade = gradeMapper.selectById(dto.getAreaId());

            BDGrade bdGrade = bdGradeMapper.selectOne(new QueryWrapper<BDGrade>().eq("bd_name",bdName));
            if(null == bdGrade){
                BDGrade inBdGrade = new BDGrade();
                inBdGrade.setUpdTime(new Date());
                inBdGrade.setBdName(dto.getBdName());
                inBdGrade.setBdNo(dto.getBdName());
                inBdGrade.setOrgId(orgId);
                inBdGrade.setAreaId(dto.getAreaId());
                String bdId = bdGradeMapper.selectOne(new QueryWrapper<BDGrade>().eq("bd_name",dto.getBdName())).getId() + "";
                dto.setTgBuildDoorplate(bdId);
            } else{
                dto.setTgBuildDoorplate(bdGrade.getId()+"");
            }

            dto.setInstLoc(grade.getAreaName() + "-" + dto.getBdName());
            dto.setInstTime(new Date());
            dto.setOrgId(orgId);

            if(dto.getChannel().equals("RS485")){
                dto.setChannel("0");
            }else if(dto.getChannel().equals("MBUS1")){
                dto.setChannel("1");
            }else if(dto.getChannel().equals("MBUS2")){
                dto.setChannel("2");
            }

            if(dto.getMeterType().equals("冷水水表")){
                dto.setMeterType("0");
            }else if(dto.getMeterType().equals("生活热水水表")){
                dto.setMeterType("1");
            }else if(dto.getMeterType().equals("直饮水水表")){
                dto.setMeterType("2");
            }else if(dto.getMeterType().equals("中水水表")){
                dto.setMeterType("3");
            }else if(dto.getMeterType().equals("电表")){
                dto.setMeterType("4");
            }

            if(dto.getProtocol().equals("CJ/T188")){
                dto.setProtocol("0");
            }else if(dto.getProtocol().equals("DL/T645-1997")){
                dto.setProtocol("1");
            }else if(dto.getProtocol().equals("DL/T645-2007")){
                dto.setProtocol("2");
            }

            if(dto.getUartbps().equals("2400bps")){
                dto.setUartbps("1");
            }else if(dto.getUartbps().equals("9600bps")){
                dto.setUartbps("2");
            }else if(dto.getUartbps().equals("1200bps")){
                dto.setUartbps("3");
            }else if(dto.getUartbps().equals("4800bps")){
                dto.setUartbps("4");
            }

            dto.setId(Math.abs(UUID.randomUUID().getLeastSignificantBits()));
            int num = mapper.selectCount(new QueryWrapper<WiredMeter>()
                    .eq("meter_address",dto.getMeterAddress())
                    .eq("term_id",dto.getTermId()));
//            int termIsExit = termManagerMapper.selectCount(new QueryWrapper<Term>().eq("address",dto.getTermId()));
            if(num >= 1){
                list.remove(dto);
                errorAddress = errorAddress + dto.getMeterAddress() + "该表具已存在;";
            }
        }
        for(WiredMeterDTO dto : list){
            save(dto);
        }

        if(!errorAddress.equals("")){
            log.info("导入集中器水电表档案，其中失败的有：" + errorAddress);
            result.setMsg("导入集中器水电表档案，其中失败的有：" + errorAddress);
            result.setCode(500);
        }else{
            return Result.OK();
        }
        return result;
    }


    @Override
    public List<MeterDayDataDTO> getExportData(ExportExcelParamsVo dto) {
        Org org = shiroConstUtils.getOrg();

        dto.setOrgId(org.getOrgId());

        List<String> idList = new ArrayList<>();
        //获得所有选择的组织区域下的areaId
        List<String> tempList = new ArrayList<>();
        String date = dto.getDataDate();
        MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
        meterDayDataDTO.setMeterAddress(dto.getMeterAddress());
        meterDayDataDTO.setMeterType(Integer.parseInt(dto.getMeterType()));
        meterDayDataDTO.setOrgId(dto.getOrgId());
        meterDayDataDTO.setAreaId(dto.getAreaId());

        if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
            //管理员或者建立在areaId时查组织区域下所有
            return mapper.getDateByAreaIdAndOrgId(meterDayDataDTO,date);
        }else if(shiroConstUtils.getTgBuildDoorplate().equals("") || shiroConstUtils.getTgBuildDoorplate() == null){
            return mapper.getDateByAreaIdAndOrgId(meterDayDataDTO,date);
        }else {
            //查本房间或者本房间下的区域
            idList = gradeService.reGetChildBDGradeId(shiroConstUtils.getTgBuildDoorplate(),org.getOrgId(),tempList);
            return mapper.getDataByTgIdAndOrgId(meterDayDataDTO,idList,date);
        }
    }

    @Transactional
    @Override
    @AopAnnotation(opType = Const.operate_wired_delete)
    public Result deleteMeter(String id) {

        int count = mapper.deleteById(id);
        if(count < 0){
            return Result.ERROR(new ApiException(ResultCodeEnum.DELETE_WIRED_ERROR));
        }
        return Result.OK();
    }


    @Transactional
    @Override
    @AopAnnotation(opType = Const.operate_wired_batch_delete)
    public Result batchDeleteWired(List<String> ids) {
        int count = mapper.deleteBatchIds(ids);
        if(count < 0){
            return Result.ERROR(new ApiException(ResultCodeEnum.DELETE_WIRED_ERROR));
        }

        return Result.OK();
    }


}
