package com.vo.tenant;

import com.common.PageConstant;
import com.dto.equipment.MeterDayDataDTO;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/8/4
 */
@Data
public class TenantUseWaterVo extends PageConstant {

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tenantId;//住户ID

    private String name;//住户姓名

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tgBuildDoorplate;//房门号ID

    private String bdName;//房门号

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long areaId;//所属组织区域ID

    private String areaName;//组织区域名称

    private Double waterConsumption;//用水量 截至当前日期所查询的

    private List<MeterDayDataDTO> meterDataList ;//表数据集合

    private String mobile;//手机号

    private String wxNumber;//微信号

    private String adminId;//管理员ID

    private String adminName;//管理员名称

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date monthDate;//选择月份

    private String sex;//性别

    private Double balance;//余额

    private String status;//缴费状态

    private String waterFee;//用水费用

    private String calculate;//计算公式，带入用水量值

    private String method;//计算方式：统一水价 阶梯计费

    private String formula;//计算公式，未带入值

    private String type;//用量类型 0：用水；1：用电;
}
