package com.dto.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.common.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Data
public class WiredMeterDTO extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;
    private String meterAddress;
    private String name;
    private String instLoc;
    private String meterType;
    private String termId;
    private Date instTime;
    private String address;

    private String collTime;
    private String dataDate;
    private String realSumFlow;
    private String channel;
    private String protocol;
    private String uartbps;

    private String orgId;
    private String areaId;
    private String tgBuildDoorplate ;
    private String modelType;//集中器型号
    private String areaName;
    private String bdName;
    private Integer pn;



    private String isRelation;//是否关联 0：已关联 1：未关联
}
