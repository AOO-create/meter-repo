package com.entity.log;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.common.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2023/4/20
 */
@Data
@TableName("change_term_log")
public class ChangeTermLog extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;//主键ID

    private String address;//操作表地址

    private String name;//操作表名

    private String oldAddress;//被替换表具表地址

    private String oldName;//被替换表具表名称

    private String areaId;//操作表所属组织区域

    private Date opTime;// 操作日期

    private String opUser;//操作人

    private Long opUseTime;//操作耗时时间

    private String orgId;

    private String areaName;//组织区域名称

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd" , timezone = "GMT+8")
    private Date startDate;//开始时间
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;//结束时间

    private String userName;//操作用户姓名
}
