package com.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.log.ChangeMeterLog;
import com.service.ChangeMeterLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/collect/changeMeterLog")
public class ChangeMeterLogController {
    @Autowired
    private ChangeMeterLogService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getChangeLog")
    @ResponseBody
    public Page<ChangeMeterLog> getChangeLog(@RequestBody ChangeMeterLog dto) {
        return service.getChangeLog(dto);
    }

}
