package com.vo.systemSetUpVo;

import com.common.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.*;

@Data
public class RoleVo  extends PageConstant implements Serializable {

    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;

    private String name;

    private String createName;

    private String roleCode;

    private String orgId;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date updTime;

    private String descr;

    private List<MenuVo> list = new ArrayList<MenuVo>() ;

    private Map<String, Object> where = new HashMap<String, Object>();
}
