package com.mapper.equipment;



import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.equipment.WNB;
import com.entity.equipment.WiredMeter;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
public interface DayDataManagerMapper{

    List<MeterDayDataDTO> oldWaterDayData(@Param("dto") MeterDayDataDTO dto, @Param("ids") List<String> idList, @Param("date") String date);

    int getOldDataCount(@Param("dto") MeterDayDataDTO dto,@Param("ids") List<String> idList,@Param("date") String date);

    void BatchInsertNB(@Param("list") List<MeterDayDataDTO> list);

    void BatchInsertWired(@Param("list") List<MeterDayDataDTO> list);

    List<NBDTO> getDataByDay(@Param("dto") NBDTO nbdto);

    int getDataByDayCount(@Param("dto") NBDTO nbdto);

    List<NBDTO> getDataByMonth(@Param("dto") NBDTO nbdto);

    int getDataByMonthCount(@Param("dto") NBDTO nbdto);

    int getDayReportCount(@Param("str") String str,@Param("id") String id);

    Integer getAllByAreaId(@Param("id") String id);

    Integer getNbByAreaId(@Param("id") String id);

    int getCountByDateAndAreaId(@Param("date") String date,@Param("id") String id);

    int getCountByDateAndTgId(@Param("date") String date,@Param("ids") List<String> id);

    int getCountWiredMeterByAreaId(@Param("id") String id,@Param("type")String type);

    int getReportWiredByDateAndAreaId(@Param("date") String date,@Param("id") String s,@Param("type") String type);

    int getCountWiredMeterByTgId(@Param("ids") List<String> id,@Param("type") String type);

    int getReportWiredByDateAndTgId(@Param("date") String date,@Param("ids") List<String> s,@Param("type")String type);

    MeterDayDataDTO getDataDayByNb(@Param("nb")WNB nb,@Param("date") String date);

    List<WiredMeter> getWiredMeterByAreaId(@Param("id") String areaId,@Param("type") String s);

    MeterDayDataDTO getDataDayByWired(@Param("dto") WiredMeter wiredMeter,@Param("date") String date,@Param("type") String s);

    List<WiredMeter> getWiredMeterByTgId(@Param("ids") List<String> bdList,@Param("type") String s);

    Integer getAllByTgId(@Param("ids") List<String> id);

    Integer getNbByTgId(@Param("ids") List<String> id);

    int getDayReportCountByTgId(@Param("str") String str,@Param("ids") List<String> id);

    int getWiredMouthDataCount(@Param("dto") WiredMeterDTO wiredMeterDTO);

    List<WiredMeterDTO> getWiredMouthData(@Param("dto") WiredMeterDTO wiredMeterDTO);


}
