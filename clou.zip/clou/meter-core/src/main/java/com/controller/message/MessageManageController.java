package com.controller.message;

import com.common.Result;
import com.service.message.MessageManagerService;
import com.dto.MessageDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuwei
 * @description
 * @date 2022/9/30
 */
@RestController
@RequestMapping("/core/messageManager")
public class MessageManageController {

    @Autowired
    private MessageManagerService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getIdentity")
    public Result getIdentity(){
        return Result.OK(service.userIdentity());
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/findMessage")
    public Result findMessage(@RequestBody MessageDTO vo){
        return Result.OK(service.findMessage(vo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/addMessage")
    public Result addMessage(@RequestBody MessageDTO vo){
        return Result.OK(service.addMessage(vo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getMsCountBelongSelf")
    public Result getMsCountBelongSelf(){
        return Result.OK(service.getMsCountBelongSelf());
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getMessageReadNo")
    public Result getMessageReadNo(){
        return Result.OK(service.getMessageReadNo());
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/readMessage")
    public Result readMessage(String id){
        return Result.OK(service.readMessage(id));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getMessageByUser")
    public Result getMessageByUser(@RequestParam("userId")String id){
        return Result.OK(service.getMessageByUser(id));
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getUserAndTenant")
    public Result getUserAndTenant(String id){
        return Result.OK(service.getUserAndTenant(id));
    }

}
