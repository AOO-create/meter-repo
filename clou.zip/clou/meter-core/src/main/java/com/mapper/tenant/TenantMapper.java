package com.mapper.tenant;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pojo.Tenant;

/**
 * @author liuwei
 * @description
 * @date 2022/7/26
 */
public interface TenantMapper extends BaseMapper<Tenant> {
}
