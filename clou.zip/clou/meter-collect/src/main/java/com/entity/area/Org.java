package com.entity.area;

import lombok.Data;

import java.util.Date;


@Data
public class Org {
    private String orgId;//单位标识
    private String orgNo;//单位编号
    private String orgName;//单位名称
    private String account;//账号
    private String taxNo;//税号
    private String remark;//备注
    private String bankAccount;//账号
    private int chargeType;
    private String chargeId;
    private Date updTime;//更新时间
    private int isWater;
    private int isElectricity;
    private int isHot;
    private int isGas;
    private int isPrepay;
    private int isUpreport;
    private int isManagerConsArch;

}
