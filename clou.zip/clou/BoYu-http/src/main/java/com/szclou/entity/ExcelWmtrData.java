package com.szclou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2023/8/17
 */
@Data
public class ExcelWmtrData {
    private String wmtrNo;//水表编号
    private String mtrCaliber;//水表口径
    private String buildingUnit;//楼栋单元
    private String doorplate;//门牌
    private String wmtrType;//表具类型
    private String wmtrUsage;//水表用途
    private String assessType;//考核类型
    private double rate;//倍率
    private double dayAlrUp;//日报警水量下限
    private double dayAlrLow;//日报警水量上限
    private String instLoc;//安装位置
    private String gpsLongitude;//gps经度
    private String gpsLatitude;//gps纬度
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date instDate;//安装日期

    private String bdNo;//门派编号

    private String isTap;
    private Integer meterIndex;//电能表序号
    private Integer mpedIndex;//所属测量点号
    private Integer commRate;//通信速率
    private Integer commPort;//端口号
    private Integer protocolType;//通信规约类型
    private String commAddr;//通信地址
    private String commPwd;//通信密码
    private Integer tariffNum;//电能费率个数
    private Integer integerNum;//有功电能示值的整数位个数
    private Integer decimalNum;//有功电能示值的小数位个数
    private String collectorAddr;//所属采集器通信地址
    private Integer consMainType;//用户大类号
    private Integer consSubType;//用户小类号

}
