package com.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.equipment.MeterHourVo;
import com.dto.equipment.MeterDayVo;
import com.dto.equipment.MeterMonthVo;
import com.entity.equipment.WiredMeterDayRead;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface DayMapper extends BaseMapper<WiredMeterDayRead> {

    @Select("select g.BD_NAME,d.real_sum_flow ,d.data_date, d.fee1,d.fee2,d.fee3,d.fee4,d.real_sum_flow,m.* from wired_meter_day_read d join wired_meter m \n" +
            "\ton d.meter_address = m.meter_address\n" +
            "\tjoin o_tg_build_doorplate g  on m.tg_build_doorplate =  g.id"+
            "\twhere d.data_date = #{dataDate} and d.meter_address =#{meterAddress}")
    Page<MeterDayVo> selectPageByMeterAdder(@Param("dataDate") String dataDate, @Param("meterAddress") String meterAddress,IPage<MeterDayVo> page);

    @Select({
            "<script>",
            "SELECT\n" +
                    "\tg.BD_NAME,\n" +
                    "SUM(d.real_sum_flow) real_sum_flow,\n" +
                    "\td.data_date,\n" +
                    "\td.fee1,\n" +
                    "\td.fee2,\n" +
                    "\td.fee3,\n" +
                    "\td.fee4,\n" +
                    "\td.real_sum_flow,\n" +
                    "\tm.* \n" +
                    "FROM\n" +
                    "\twired_meter_day_read d\n" +
                    "\tJOIN wired_meter m on d.meter_address = m.meter_address\n" +
                    "\tJOIN o_tg_build_doorplate g ON m.tg_build_doorplate = g.id \n" +
                    "WHERE\n" +
                    "\td.data_date =#{dataDate} and d.meter_address in " +
                    "<foreach collection='meterList' item='id' open='(' separator=',' close=')'>",
            "#{id}",
            "</foreach>",
            "</script>"
    })
    MeterDayVo selectSumDataByMeter(@Param("dataDate") String dataDate, @Param("meterList") List<String> conList);


    @Select("select g.BD_NAME,d.real_sum_flow ,d.data_date, d.fee1,d.fee2,d.fee3,d.fee4,d.real_sum_flow,m.* from wired_meter_day_read d join wired_meter m \n" +
            "\ton d.meter_address = m.meter_address\n" +
            "\tjoin o_tg_build_doorplate g  on m.tg_build_doorplate =  g.id"+
            "\twhere d.data_date = #{dataDate} and d.meter_address =#{meterAddress}")
    Page<MeterDayVo> selectOneByMeterAdder(@Param("dataDate") String dataDate, @Param("meterAddress") String meterAddress,IPage<MeterDayVo> page);

@Select({
        "<script>",
        "SELECT\n" +
                "        g.BD_NAME,\n" +
                "        h.COLL_TIME,h.data_date,\n" +
                "        SUM(h.real_sum_flow) real_sum_flow,\n" +
                "        h.`hour`,\n" +
                "        m.meter_address,\n" +
                "        m.`name`,\n" +
                "        m.inst_loc,\n" +
                "         h.term_address,\n" +
                "        m.channel,\n" +
                "        m.uartbps,\n" +
                "        m.protocol\n" +
                "        FROM\n" +
                "        wired_read_hour_data h\n" +
                "        JOIN wired_meter m ON h.meter_address = m.meter_address\n" +
                "        JOIN o_tg_build_doorplate g ON m.tg_build_doorplate = g.id  ",
        "where h.coll_time = #{dataDate}  and m.meter_address in",
        "<foreach collection='meterList' item='id' open='(' separator=',' close=')'>",
        "#{id}",
        "</foreach>",
        "GROUP BY hour</script>"
        })
    Page<MeterDayVo> selectSumHourByAreaId(@Param("dataDate") String dataDate, @Param("meterList") List<String> tgList, IPage<MeterDayVo> page);

    @Select({
            "<script>",
            "SELECT\n" +
                    "        g.BD_NAME,\n" +
                    "        h.COLL_TIME,h.data_date,\n" +
                    "        SUM(h.real_sum_flow) real_sum_flow,\n" +
                    "        h.`hour`,\n" +
                    "        m.meter_address,\n" +
                    "        m.`name`,\n" +
                    "        m.inst_loc,\n" +
                    "         h.term_address,\n" +
                    "        m.channel,\n" +
                    "        m.uartbps,\n" +
                    "        m.protocol\n" +
                    "        FROM\n" +
                    "        wired_read_hour_data h\n" +
                    "        JOIN wired_meter m ON h.meter_address = m.meter_address\n" +
                    "        JOIN o_tg_build_doorplate g ON m.tg_build_doorplate = g.id  ",
            "where h.coll_time = #{dataDate}  and m.meter_address in",
            "<foreach collection='meterList' item='id' open='(' separator=',' close=')'>",
            "#{id}",
            "</foreach>"+ "and h.hour in",
            "<foreach collection='conList' item='con' open='(' separator=',' close=')'>",
            "#{con}",
            "</foreach>",
            "GROUP BY hour</script>"
    })
    Page<MeterDayVo> selectSumHourByAreaIdTu(@Param("dataDate") String dataDate, @Param("meterList") List<String> tgList,@Param("conList") List<String> conList, IPage<MeterDayVo> page);

    @Select({
            "<script>",
            "select g.BD_NAME,d.real_sum_flow,d.data_date, d.fee1,d.fee2,d.fee3,d.fee4, m.* from wired_meter_day_read d join wired_meter m \n" +
                    "\ton d.meter_address = m.meter_address\n" +
                    "\tjoin o_tg_build_doorplate g on m.tg_build_doorplate =  g.id",
            "where d.coll_time = #{dataDate}  and d.meter_address in",
            "<foreach collection='meterList' item='id' open='(' separator=',' close=')'>",
            "#{id}",
            "</foreach>",
            "</script>"
    })
    Page<MeterDayVo> selectPageByAreaId(@Param("dataDate") String dataDate, @Param("meterList") List<String> tgList, IPage<MeterDayVo> page);

    @Select("SELECT\n" +
            "\tg.BD_NAME,\n" +
            "\th.COLL_TIME,h.data_date,\n" +
            "\th.real_sum_flow,\n" +
            "\th.`hour`,\n" +
            "\tm.meter_address,\n" +
            "\tm.`name`,\n" +
            "\tm.inst_loc,\n" +
            "  h.term_address,\n" +
            "\tm.channel,\n" +
            "\tm.uartbps,\n" +
            "\tm.protocol\n" +
            "FROM\n" +
            "\twired_read_hour_data h\n" +
            "\tJOIN wired_meter m ON h.meter_address = m.meter_address\n" +
            "\tJOIN o_tg_build_doorplate g ON m.tg_build_doorplate = g.id "+
            "\tWHERE m.meter_address =#{meterAddress} and data_date =#{dataDate} ")
    Page<MeterHourVo> selectPageByHour(@Param("meterAddress") String meterAddress, @Param("dataDate") String dataDate, IPage<MeterHourVo> page);


    @Select({
            "<script>",
            "select g.BD_NAME,d.real_sum_flow,d.data_date, d.fee1,d.fee2,d.fee3,d.fee4,d.real_sum_flow, m.* from wired_meter_month_read d join wired_meter m \n" +
                    "\ton d.meter_address = m.meter_address\n" +
                    "\tjoin o_tg_build_doorplate g on m.tg_build_doorplate =  g.id",
            "where d.coll_time BETWEEN #{startDate} AND #{endDate} " +
                    " and d.meter_address in",
            "<foreach collection='meterList' item='id' open='(' separator=',' close=')'>",
            "#{id}",
            "</foreach>",
            "</script>"
    })
    Page<MeterMonthVo> selectMonthByAreaId(@Param("startDate") String startDate, @Param("endDate") String endDate, @Param("meterList") List<String> tgList, IPage<MeterMonthVo> page);

    @Select("select g.BD_NAME,d.coll_time,d.real_sum_flow ,d.data_date, d.fee1,d.fee2,d.fee3,d.fee4,d.real_sum_flow,m.* from wired_meter_month_read d join wired_meter m \n" +
            "\ton d.meter_address = m.meter_address\n" +
            "\tjoin o_tg_build_doorplate g  on m.tg_build_doorplate =  g.id"+
            "\twhere d.coll_time BETWEEN #{startDate} AND #{endDate} " +
            "and d.meter_address =#{meterAddress}")
    Page<MeterMonthVo> selectMonthByMeterAdder(@Param("startDate") String startDate, @Param("endDate") String endDate,@Param("meterAddress") String meterAddress,IPage<MeterMonthVo> page);
}