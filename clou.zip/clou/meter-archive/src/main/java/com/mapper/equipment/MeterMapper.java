package com.mapper.equipment;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface MeterMapper {


    int findCountByBDGradeId(String id);
}
