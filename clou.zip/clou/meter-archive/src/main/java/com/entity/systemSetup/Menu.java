package com.entity.systemSetup;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/6/21
 */
@Data
@TableName("menu")
public class Menu {
    private Long id; //主键

    private String menuId;//菜单Id

    private String parentMenuId;//父级菜单ID

    private String icon;//菜单图标

    private String menuName;//菜单名称

    private String url;//菜单路径

    private int hasThird;//菜单是否具有子节点 1 -- 有 0 -- 无

    private int menuIndex;//菜单索引

    @TableField(fill = FieldFill.INSERT)
    private int deleted;//逻辑删除
}
