package aep.nbiot.command;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AEP 设备管理命令定义
 * 对应官网 https://www.ctwing.cn/channel-help-api.htm?api=99
 * @date 2021/11/17 8:33
 */
public enum AepDeviceManagementEnum implements AepCommandEnum {

    CreateDevice("CreateDevice","增加设备"),
    DeleteDevice("DeleteDevice","删除设备"),
    DeleteDeviceByPost("DeleteDeviceByPost","批量删除设备Post方法"),
    ListDeviceActiveStatus("ListDeviceActiveStatus","批量查询设备激活状态"),
    ListDeviceInfo("ListDeviceInfo","根据设备ID列表查询设备信息"),
    QueryDevice("QueryDevice","获取单个设备详情"),
    QueryDeviceList("QueryDeviceList","批量获取设备信息"),
    UpdateDevice("UpdateDevice","更新设备"),

    ;

    /**
     * 命令KEY
     */
    private String commandKey;

    /**
     * 命令名称
     */
    private String commandName;

    AepDeviceManagementEnum(String commandKey, String commandName) {
        this.commandKey = commandKey;
        this.commandName = commandName;
    }
}
