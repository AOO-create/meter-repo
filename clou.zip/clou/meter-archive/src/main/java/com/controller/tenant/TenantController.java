package com.controller.tenant;

import com.service.tenant.TenantService;
import com.vo.tenant.TenantVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/tenant")
public class TenantController {

    @Autowired
    private TenantService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getTenantByAreaId")
    @ResponseBody
    public Page<TenantVo> getTenantByAreaId(@RequestBody TenantVo vo){
        return service.getTenantByAreaId(vo);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getTenantBybdId")
    @ResponseBody
    public Page<TenantVo> getTenantBybdId(@RequestBody TenantVo vo){
        return service.getTenantBybdId(vo);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getAllTenant")
    @ResponseBody
    public Page<TenantVo> getAllTenant(@RequestBody TenantVo vo){
        return service.getAllTenant(vo);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("tenantSave")
    @ResponseBody
    public Result tenantSave(@RequestBody TenantVo vo){
        return Result.OK(service.tenantSave(vo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @GetMapping("deleteTenant")
    @ResponseBody
    public Result deleteTenant(@RequestParam("id") String id){
        return Result.OK(service.deleteTenant(id));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @GetMapping("batchDeleteTenant")
    @ResponseBody
    public Result batchDeleteTenant(@RequestBody List<String> ids){
        return Result.OK(service.batchDeleteTenant(ids));
    }
}
