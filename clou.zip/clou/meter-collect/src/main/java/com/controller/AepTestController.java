package com.controller;

import aep.nbiot.callback.AepMqDecodeCallback;
import aep.nbiot.callback.AepMqOrginCallback;
import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.command.AepDeviceManagementEnum;
import aep.nbiot.mq.MqReport;
import aep.nbiot.service.AepApiService;
import aep.nbiot.service.AepMqService;
import aep.nbiot.util.ResultUtil;

import com.AepResolve.ProtoResolveService;
import com.alibaba.fastjson.JSONObject;

import com.config.ProductProperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 测试控制器
 * @date 2021/11/17 10:19
 */
@RestController
@RequestMapping("/collect/nbMeter")
public class AepTestController {

    public static Logger logger = LoggerFactory.getLogger(AepTestController.class);
    @Autowired
    private AepApiService aepApiService;
    @Autowired
    private AepMqService aepMqService;
    @Autowired
    private ProtoResolveService protoResolveService;
    @Autowired
    private ProductProperties productProperties;


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping(value = "/receive",method = {RequestMethod.POST, RequestMethod.GET})
    public StringBuffer receive(HttpServletRequest request, HttpServletResponse response){

        StringBuffer resultStr = new StringBuffer("");
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"utf-8"));
            StringBuffer sb = new StringBuffer("");
            String temp;
            while ((temp = br.readLine()) != null){
                sb.append(temp);
            }
            br.close();
            //真正接收到的数据
            String result = sb.toString();
            //测试的数据
           // String result = "{\"deviceId\":\"xxx\",\"deviceInfo\":{\"swVersion\":\"xxx\",\"name\":\"xxx\",\"description\":\"xxx\",\"model\":\"90\",\"fwVersion\":\"xxx\",\"protocolType\":\"xxx\",\"type\":90,\"mac\":\"xxx\",\"manufacturer\":\"xxx\",\"hwVersion\":\"xxx\"},\"notifyType\":\"deviceInfoChanged\",\"gatewayId\":\"xxx\"}\n";
            JSONObject json = JSONObject.parseObject(result);
            //类型
            String notifyType = json.getString("notifyType");
            //设备id
            String deviceId = json.getString("deviceId");
            //网关id
            String payload = json.getString("payload");
            //deviceInfo信息
            String deviceInfo = json.getString("deviceInfo");
            JSONObject deviceInfoJson = JSONObject.parseObject(result);
            //设备的状态
            String status  = deviceInfoJson.getString("status");
            resultStr.append("订阅类型 notifyType >>" + notifyType+"订阅类型 notifyType >>" + notifyType+" 设备id    deviceId >>" + deviceId+" 网关id   gatewayId >>" +"设备信息 deviceInfo >>" + deviceInfo+"设备状态     status >>"+status);
            int i = 0;
            int m=(i+1);
            logger.info("接收消息的次数"+m+"次");
            logger.info("订阅类型 notifyType >>" + notifyType);
            logger.info(" 数据>>" + payload);
            logger.info("设备信息 deviceInfo >>" + deviceInfo);
        }catch (Exception e){
            e.printStackTrace();
        }
        return resultStr;
    }

    @GetMapping("/deviceList")
    public Object deviceList(){
        HashMap<String,Object> params = new HashMap<>();
        System.out.println( "MasterKey的值为：" + productProperties.getMasterKey());
        params.put("MasterKey",productProperties.getMasterKey());
        params.put("productId",productProperties.getProductId());
        return aepApiService.invockApi(AepDeviceManagementEnum.QueryDeviceList, params);
    }

    @GetMapping("/commandList")
    public Object commandList(){
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        params.put("productId",productProperties.getProductId());
        return aepApiService.invockApi(AepDeviceCommandEnum.QueryCommandList, params);
    }

    @GetMapping("/commandListError")
    public Object commandListError(){
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        params.put("productId",productProperties.getProductId());
        
        return aepApiService.invockApi(AepDeviceCommandEnum.QueryCommand, params);
    }

    @GetMapping("/listen")//所以只要在这里传一个topic就可以了
    public Object startListenOrgin(){
        aepMqService.listenerOrign(null,new AepMqOrginCallback() {
            @Override
            public void listener(String msg) {
                String result =protoResolveService.handleFrame(msg);
                System.out.println("原始msg打印消息：" +msg);
                System.out.println("处理结果为:"+ result);
            }
        });
        return ResultUtil.defaultSuccess();
    }

    @GetMapping("/listenDecode")
    public Object startListenDecode(){
        List<String> topic =new ArrayList<>();
        aepMqService.listenerDecode(topic,new AepMqDecodeCallback() {
            @Override
            public void listener(MqReport msg) {
            }
        });
        return ResultUtil.defaultSuccess();
    }

    @GetMapping("/command/create")
    public Object commandCreate(){
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        params.put("productId",productProperties.getProductId());
        HashMap<String,Object> body = new HashMap<>();
        body.put("operator","cl6904");
        body.put("ttl",864000);
        //body.put("deviceGroupId",)
        //body.put("level",)
        HashMap<String,Object> content = new HashMap<>();
        content.put("dataType","2");
        content.put("payload","6810030000092050200107009023a8070000017e16");
        body.put("content",content);

        return aepApiService.invockApi(AepDeviceCommandEnum.CreateCommand,params,body);
    }


    @GetMapping("/command/create2")
    public Object commandCreate2(){
        HashMap<String,Object> params = new HashMap<>();

        params.put("masterKey","c3a8adbb4d4a43f1911143cb957ff488");
        HashMap<String,Object> body = new HashMap<>();
        body.put("deviceId","4dda216b31254302b68a72793064f331");
        body.put("operator","lanccj");
        body.put("productProperties.getProductId()","15108878");
        body.put("ttl",864000);
        //body.put("deviceGroupId",)
        //body.put("level",3);
        HashMap<String,Object> content = new HashMap<>();
        HashMap<String,Object> content_params = new HashMap<>();
        content_params.put("device_id","123");
        content_params.put("message_type",10);
        content_params.put("device_type","SZWL-SF-1@");
        content_params.put("device_work_mode","0");
        content.put("params",content_params);
        content.put("serviceIdentifier","device_work_mode_inquire_ack");
        body.put("content",content);
        return aepApiService.invockApi(AepDeviceCommandEnum.CreateCommand,params,body);
    }


    @GetMapping("/commandCreateDevice")
    public Object createDevice(){
        //TODO调用CTWING接口
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        HashMap<String,Object> body = new HashMap<>();
        body.put("deviceName","测试有阀设备");
        body.put("productId",productProperties.getProductId());
        body.put("deviceSn","'22502111000029");
        body.put("imei","867590066466535");
        body.put("operator","test");
        HashMap<String,Object> other = new HashMap<String,Object>();
        other.put("autoObserver",0);
        body.put("other",other);
        body.put("productProperties.getProductId()",productProperties.getProductId());

        return aepApiService.invockApi(AepDeviceManagementEnum.CreateDevice,params,body);
    }



    @GetMapping("/receiveCtHttp")
    public void receiveCtHttp() throws Exception {
        //TODO 调用第三方接口测试;

    }

    @GetMapping("/receiveCtHttp2")
    public void receiveCtHttp2() throws Exception {
        //TODO 调用第三方接口测试;
//        iBatchDataService.getMeterPowerList2();
    }

}
