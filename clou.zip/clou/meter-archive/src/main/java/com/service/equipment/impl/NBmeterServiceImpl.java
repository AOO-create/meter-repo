package com.service.equipment.impl;

import aep.nbiot.command.AepDeviceManagementEnum;
import aep.nbiot.service.AepApiService;
import com.aop.annotation.AopAnnotation;
import com.common.Result;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.entity.organization.BDGrade;
import com.entity.organization.Grade;
import com.mapper.equipment.DayDataManagerMapper;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.entity.equipment.Protocol;
import com.entity.equipment.WNB;
import com.entity.Org;
import com.service.equipment.NBmeterService;
import com.service.organization.impl.GradeServiceImpl;
import com.util.ShiroConstUtils;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Const;
import com.common.ProductProperties;
import com.vo.exportExcelVo.ExportExcelParamsVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

//import org.apache.commons.lang3.StringUtils;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Service
public class NBmeterServiceImpl implements NBmeterService {

    @Autowired
    private NBmeterMapper mapper;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private DayDataManagerMapper dayDataManagerMapper;

    private ProductProperties productProperties = new ProductProperties();

    @Autowired
    private AepApiService aepApiService;

    @Autowired
    private GradeServiceImpl gradeService;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public Page<NBDTO> findMeterToConsIsnull(NBDTO dto) {
        Org org = shiroConstUtils.getOrg();

        dto.setOrgId(org.getOrgId());

        String areaId = dto.getAreaId();
        List<String> bdIdList = new ArrayList<>();
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }

        if(areaId.equals("") || null == areaId){
            bdIdList = gradeService.reGetChildBDGradeId(dto.getTgBuildDoorplate(),dto.getOrgId(),new ArrayList<>());
        }


        List<NBDTO> nblist = mapper.selectNBToConsIsnullByArea(dto,areaId,bdIdList);
        int count = mapper.getCount(dto,areaId,bdIdList);
        Page<NBDTO> page = new Page<>();
        if(nblist.size() !=0 && nblist !=null){
            page.setRecords(nblist);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }



    @Transactional
    @AopAnnotation(opType = Const.operate_nb_update)
    @Override
    public String updateNB(NBDTO nBdto) {
//        if(mapper.findMeterInMtrRela(String.valueOf(nBdto.getWmtrId())) > 0)
//        {
//            return "修改表档案失败,请先解除该表在表计终端的绑定";
//        }
        WNB wnb = new WNB();
        BeanUtils.copyProperties(nBdto,wnb);
        wnb.setWmtrId(Long.valueOf(nBdto.getWmtrId()));
        wnb.setInstDate(nBdto.getDataDate());
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = formatter.format(new Date());
        wnb.setUpdTime(dateString);
        String instLoc = gradeMapper.getInstLocById(nBdto.getAreaId(),nBdto.getTgBuildDoorplate());
        wnb.setInstLoc(instLoc);
        //修改本地
        int result = mapper.updateById(wnb);
//                updateNB(nBdto);
        if(result <0){
            return "修改表档案失败，请查找原因" ;
        }
        //修改远程电信平台相关信息调用接口
        ////如果deviceId没有的话就是新增，如果deviceId有的话就是修改
        return "修改表档案成功！";
    }

    @Transactional
    @AopAnnotation(opType = Const.operate_nb_insert)
    @Override
    public String addNB(NBDTO nBdto) throws Exception {
        WNB wnb = new WNB();
        String areaId = bdGradeMapper.selectById(nBdto.getTgBuildDoorplate()).getAreaId();
        nBdto.setAreaId(areaId);
        BeanUtils.copyProperties(nBdto,wnb);
        wnb.setInstDate(nBdto.getDataDate());
        wnb.setUpdTime(nBdto.getDataDate());

        //安装位置需要根据areaId和tgId去给添加上
        String instLoc = gradeMapper.getInstLocById(nBdto.getAreaId(),nBdto.getTgBuildDoorplate());
        wnb.setInstLoc(instLoc);

        Org org = shiroConstUtils.getOrg();
        wnb.setOrgId(org.getOrgId());

        //调用电信接口插入
        JSONObject  jsonObject = JSONObject.parseObject(telecomInsertNB(nBdto).toString());
        String code =jsonObject.get("code") + "";
        if(!code.equals("0")){
            throw new Exception();
        }
        JSONObject resultStr = JSONObject.parseObject(jsonObject.getString("result"));
        String deviceId = (String) resultStr.get("deviceId");
        wnb.setDeviceId(deviceId);

        //Object返回deviceId 自己需要填写协议是哪一种
        int result = mapper.insert(wnb);
        if(result <0){
            return "新增表档案失败，请查找原因" ;
        }
        return "新增表档案成功！";
    }

    @Transactional
    @AopAnnotation(opType = Const.operate_nb_delete)
    @Override
    public boolean deleteNB(String wmtrId) throws Exception {
        if(mapper.findMeterInMtrRela(wmtrId) > 0) {
            return false ;
        }
        WNB wnb = mapper.selectById(wmtrId);
        JSONObject  jsonObject = JSONObject.parseObject(telecomDeletedNB(wnb).toString());
        String code =jsonObject.get("code") + "";
        if(!code.equals("0")){
            throw new Exception();
        }
        int result = mapper.deleteById(wmtrId);

        return result > 0;
    }

    @Transactional
    @AopAnnotation(opType = Const.operate_nb_batch_delete)
    @Override
    public boolean batchDeleteNB(List<String> ids) throws Exception {
        String str = "";
        for(String id : ids){
            if(mapper.findMeterInMtrRela(id) > 0){
                return false ;
            }
        }
        List<WNB> wnbList = mapper.selectList(new QueryWrapper<WNB>().in("id",ids));
        for(WNB wnb : wnbList){
            str = str + wnb.getDeviceId() + ",";
        }
        int length = str.length();
        str = str.substring(0,length - 1);

        JSONObject  jsonObject = JSONObject.parseObject(telecomBatchDeletedNB(str).toString());
        String code =jsonObject.get("code") + "";
        if(!code.equals("0")){
            throw new Exception();
        }

        int result = mapper.deleteBatchIds(ids);
        return result > 0;
    }

    @Override
    public boolean validWmtrNo(String meterAddress) {
        int count = mapper.selectCount(new QueryWrapper<WNB>().eq("meter_address",meterAddress));
        return  count <=0;
    }

    @Override
    public boolean validImei(String imei) {
        int count = mapper.selectCount(new QueryWrapper<WNB>().eq("imei",imei));
        return  count <=0;
    }

    @Override
    public List<Protocol> getProtocol() {
        return mapper.getProtocol();
    }

    @Override
    public List<WNB> findNewProtoMeter() {
        return mapper.selectList(new QueryWrapper<WNB>().eq("proto_code","NEWPROTO"));
    }

    @Override
    public Result ExcelNBProductIn(List<NBDTO> list) throws Exception {
        Org org = shiroConstUtils.getOrg();
        List<NBDTO> temp = new ArrayList<>(list);
        List<NBDTO> tempTwo = new ArrayList<>(list);

        //校验是否可以插入
        for(NBDTO nbdto : temp){
            //添加上组织区域ID，门东单元ID，安装时间（），传输协议
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            nbdto.setOrgId(org.getOrgId());
            nbdto.setAreaId("1568067501611581442");
            nbdto.setTgBuildDoorplate("1568067941656985601");
            nbdto.setDataDate(dateFormat.format(new Date()));
            nbdto.setProtoCode("NEWPROTO");
            if(!validWmtrNo(nbdto.getMeterAddress()) || !validImei(nbdto.getImei())){
                //没有该资产编号或者imei
                list.remove(nbdto);
            }

            for(NBDTO  dto : tempTwo){
                //情形二：插入列表中存在
                if(!dto.getName().equals(nbdto.getName())){
                    if(dto.getImei().equals(nbdto.getImei())||dto.getMeterAddress().equals(nbdto.getMeterAddress())){
                        list.remove(nbdto);
                    }
                }
            }
        }

        for(NBDTO nbdto : list){
            addNB(nbdto);
        }
        return Result.OK();
    }

    @Override
    public Map<String,Object> warningDayData() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String endTime = simpleDateFormat.format(new Date());

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DATE,calendar.get(Calendar.DATE)-7);
        String startTime = simpleDateFormat.format(calendar.getTime());
        List<MeterDayDataDTO> list = dayDataManagerMapper.warningDayData(startTime,endTime);
        Map<String,Object> map = new HashMap<>();
        for(MeterDayDataDTO dto : list){
            int count = 0;
            for(MeterDayDataDTO dtoTwo : list){
                if(dto.getMeterAddress().equals(dtoTwo.getMeterAddress())){
                    count ++ ;
                }
            }
            dto.setCount(count);
        }
        map.put("warningTable",list);
        map.put("warningCount",list.size());
        return map;
    }

    @Override
    public List<MeterDayDataDTO> getExportData(ExportExcelParamsVo exportExcelParams) {
        List<String> idList = new ArrayList<>();
        List<String> tempList = new ArrayList<>();

        MeterDayDataDTO dto  = new MeterDayDataDTO();
        dto.setAreaId(exportExcelParams.getAreaId());
        dto.setOrgId(exportExcelParams.getOrgId());
        dto.setMeterAddress(exportExcelParams.getMeterAddress());
        String dateString = exportExcelParams.getDataDate();

        idList = gradeService.reGetChildGradeId(dto.getAreaId(),dto.getOrgId(),tempList);
        return  dayDataManagerMapper.oldWaterDayData(dto,idList,dateString);
    }

    @Override
    public Page<NBDTO> getDataDay(NBDTO dto) {
        //获得改组织区域下所有的NB表ID和资产编号（主要靠资产编号查询得到）
        Org org = shiroConstUtils.getOrg();
        String areaId = dto.getAreaId();
        String tgId = dto.getTgBuildDoorplate();

        dto.setOrgId(org.getOrgId());
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }

        //获得所有选择的组织区域下的areaId
        List<NBDTO> nbList = new ArrayList<>();
        int count = 0;
        if(areaId.equals("") || areaId == null){
            //查本房间或者本房间下的区域
            List<String> bdIds = gradeService.reGetChildBDGradeId(tgId,org.getOrgId(),new ArrayList<>());
            nbList = mapper.getDataByTgIdAndOrgId(dto,bdIds);
            count = mapper.getDateDayCountByTgId(dto,bdIds);
        }else {
            nbList = mapper.getNBDateByAreaIdAndOrgId(dto,areaId);
            count = mapper.getDateDayCount(dto,areaId);
        }

        Page<NBDTO> page = new Page<>();
        if(nbList.size() !=0 && nbList !=null){
            page.setRecords(nbList);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Transactional
    @Override
    public Result ExcelNBIn(List<NBDTO> list) throws Exception {
        Org org = shiroConstUtils.getOrg();
        Result result = new Result();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<NBDTO> temp = new ArrayList<>(list);
        List<NBDTO> tempTwo = new ArrayList<>(list);
        String errorAddress = "";
        //校验是否可以插入
        for(NBDTO nbdto : temp){
            nbdto.setOrgId(org.getOrgId());
            if(!validWmtrNo(nbdto.getMeterAddress()) || !validImei(nbdto.getImei())){
                //情形一：数据库中存在该资产编号或者imei
                list.remove(nbdto);
                errorAddress = errorAddress + nbdto.getMeterAddress() + "已存在该地址、IMEI；";
                continue;
            }
            for(NBDTO  dto : tempTwo){
                //情形二：插入列表中存在
                if(!dto.getName().equals(nbdto.getName())){
                    if(dto.getImei().equals(nbdto.getImei())||dto.getMeterAddress().equals(nbdto.getMeterAddress())){
                        errorAddress = errorAddress + nbdto.getMeterAddress() + "导入表格存在重复表具；";
                        list.remove(nbdto);
                    }
                }
            }
        }

        //Nb表开始正式导入
        for(NBDTO nbdto : list){
            nbdto.setDataDate(simpleDateFormat.format(new Date()));
            //根据areaName 和bdName 添加areaId和tgBuildDoorplate
            Grade grade = gradeMapper.selectOne(new QueryWrapper<Grade>().eq("area_name",nbdto.getAreaName()));
            if(grade == null ){
                //无该组织区域,新增该组织区域
                Grade insertGrade = new Grade();
                insertGrade.setUpdTime(new Date());
                insertGrade.setAreaName(nbdto.getAreaName());
                insertGrade.setOrgId(org.getOrgId());
                insertGrade.setAreaNo(nbdto.getAreaName());
                gradeMapper.insert(insertGrade);
                String areaId = gradeMapper.selectOne(new QueryWrapper<Grade>().eq("area_name",nbdto.getAreaName())).getId() +"";
                nbdto.setAreaId(areaId);
            }else{
                nbdto.setAreaId(grade.getId()+"");
            }

            BDGrade bdGrade = bdGradeMapper.selectOne(new QueryWrapper<BDGrade>().eq("bd_name",nbdto.getBdName()));
            if(null == bdGrade){
                BDGrade inBdGrade = new BDGrade();
                inBdGrade.setUpdTime(new Date());
                inBdGrade.setBdName(nbdto.getBdName());
                inBdGrade.setBdNo(nbdto.getBdName());
                inBdGrade.setOrgId(org.getOrgId());
                inBdGrade.setAreaId(nbdto.getAreaId());
                String bdId = bdGradeMapper.selectOne(new QueryWrapper<BDGrade>().eq("bd_name",nbdto.getBdName())).getId() + "";
                nbdto.setTgBuildDoorplate(bdId);
            } else{
                nbdto.setTgBuildDoorplate(bdGrade.getId()+"");
            }
            addNB(nbdto);
        }
        if(!errorAddress.equals("")){
            result.setMsg("导入失败NB表具为：" + errorAddress);
            result.setCode(500);
        }else{
            return Result.OK();
        }
        return result;
    }

    //调用电信接口插入
    public Object telecomInsertNB(NBDTO nbdto){
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        HashMap<String,Object> body = new HashMap<>();
        body.put("deviceName",nbdto.getName());
        body.put("productId",productProperties.getProductId());
        body.put("deviceSn",nbdto.getImei());
        body.put("imei",nbdto.getImei());
        body.put("operator","insert");
        HashMap<String,Object> other = new HashMap<String,Object>();
        other.put("autoObserver",0);
        body.put("other",other);
        body.put("productProperties.getProductId()",productProperties.getProductId());

        return aepApiService.invockApi(AepDeviceManagementEnum.CreateDevice,params,body);
    }

    //调用电信接口删除
    public Object telecomDeletedNB(WNB wnb){
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        HashMap<String,Object> body = new HashMap<>();
        params.put("productId",Integer.parseInt(productProperties.getProductId()));
        params.put("deviceIds",wnb.getDeviceId());
//        body.put("productProperties.getProductId()",productProperties.getProductId());
        return aepApiService.invockApi(AepDeviceManagementEnum.DeleteDevice,params,body);
    }

    public Object telecomBatchDeletedNB(String deviceIds){
        HashMap<String,Object> params = new HashMap<>();
        params.put("MasterKey",productProperties.getMasterKey());
        HashMap<String,Object> body = new HashMap<>();
        params.put("productId",Integer.parseInt(productProperties.getProductId()));
        params.put("deviceIds",deviceIds);
//        body.put("productProperties.getProductId()",productProperties.getProductId());
        return aepApiService.invockApi(AepDeviceManagementEnum.DeleteDevice,params,body);
    }

}
