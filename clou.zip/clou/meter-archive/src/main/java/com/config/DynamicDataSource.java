package com.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;


@Component
@Primary    // 将该Bean设置为主要注入Bean
public class DynamicDataSource implements DataSource, InitializingBean {

    // 用于存储数据源的标识
    public static ThreadLocal<String> name = new ThreadLocal<>();

    // 写
    private final DataSource writeDataSource;

    // 读
    private final DataSource readDataSource;

    @Autowired
    public DynamicDataSource(@Qualifier("readDatasource") DataSource readDataSource,
                             @Qualifier("writeDatasource") DataSource writeDataSource) {
        this.readDataSource = readDataSource;
        this.writeDataSource = writeDataSource;
    }

    @Override
    public Connection getConnection() throws SQLException {
        if(name.get() == null ){
            return  readDataSource.getConnection();
        }else{
            return name.get().equals("w") ? writeDataSource.getConnection() : readDataSource.getConnection();
        }
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return null;
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return false;
    }

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        return null;
    }

    @Override
    public void setLogWriter(PrintWriter out) throws SQLException {

    }

    @Override
    public int getLoginTimeout() throws SQLException {
        return 0;
    }

    @Override
    public void setLoginTimeout(int seconds) throws SQLException {

    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        return null;
    }

    /**
     * 初始化bean的initialization接口
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // TODO 初始化
        name.set("r");
    }
}
