package com.service.tenant;

import com.vo.tenant.TenantUseWaterVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.text.ParseException;

/**
 * @author liuwei
 * @description
 * @date 2022/8/4
 */
public interface TenantUseWaterService {
    Page<TenantUseWaterVo> getUseWaterRecord(TenantUseWaterVo vo);

    Page<TenantUseWaterVo> getTenantStatistics(TenantUseWaterVo vo) throws ParseException;

    Page<TenantUseWaterVo> getUseElecRecord(TenantUseWaterVo vo);
}
