package aep.nbiot.callback;

import aep.nbiot.mq.MqReport;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AER MQ回调函数(解密base64并且封装后的,存在十六进制或者字符串情况加密)
 * @date 2021/11/19 8:26
 */
public interface AepMqDecodeCallback {

    /***
     * 监听MQ消息回调方法
     * @param msg
     */
    public  <T extends MqReport> void listener(T msg);

}
