package aep.nbiot.strategy.aepdevicemanage;

import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.util.ParamsUtil;
import com.ctg.ag.sdk.biz.AepNbDeviceManagementClient;
import com.ctg.ag.sdk.biz.aep_nb_device_management.BatchCreateNBDeviceRequest;
import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 批量增加NB设备
 * @date 2021/11/17 8:03
 */
public class BatchCreateNBDeviceStrategy implements IAepStrategy {

    @Override
    public BaseApiResponse invockApi(BaseApiClient _client, HashMap<String,Object> params, HashMap<String,Object> body) {
        try {
            ParamsUtil paramsUtil = new ParamsUtil(new BatchCreateNBDeviceRequest());
            BatchCreateNBDeviceRequest request = (BatchCreateNBDeviceRequest) paramsUtil.addParams(params,body);
             AepNbDeviceManagementClient client = (AepNbDeviceManagementClient)_client;
//            AepNbDeviceManagementClient client = AepNbDeviceManagementClient.newClient()
//                    .appKey("vNRFeVsRtI6").appSecret("h1Kmx4Gui0")
//                    .build();

            System.out.println(client.BatchCreateNBDevice(request));
            return client.BatchCreateNBDevice(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
