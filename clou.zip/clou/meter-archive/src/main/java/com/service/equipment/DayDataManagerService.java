package com.service.equipment;

import com.dto.equipment.MeterDayDataDTO;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
public interface DayDataManagerService {
    Map<String, Page<MeterDayDataDTO>> getAllDayData(MeterDayDataDTO dto) throws ParseException;

    void ExcelDayDataIn(List<MeterDayDataDTO> list,String meterType);

    Page<MeterDayDataDTO> getDataByDay(MeterDayDataDTO dto);
}
