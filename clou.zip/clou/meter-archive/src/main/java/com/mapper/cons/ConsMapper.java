package com.mapper.cons;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface ConsMapper {


    int findCountByBDGradeId(String id);
}
