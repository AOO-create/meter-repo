package com.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.nbFrame.nbSendCommand;
import com.vo.nbSendCommandVo;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
public interface CommandManagerService {
    Page<nbSendCommand> findAll(nbSendCommandVo command);

    boolean saveCommand(nbSendCommandVo command);

    boolean updateCommand(nbSendCommandVo command);

    boolean deleteCommand(String id);

    boolean batchDeleteCommand(List<String> ids);

    nbSendCommandVo getParam(nbSendCommand command);
}
