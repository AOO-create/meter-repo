package aep.nbiot.util;

import com.alibaba.fastjson.JSON;
import com.ctg.ag.sdk.core.model.BaseApiRequest;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 填充参数处理类
 * @date 2021/11/17 8:12
 */
public class ParamsUtil<T extends BaseApiRequest> {

    private T request;

    public ParamsUtil(T request) {
        this.request = request;
    }

    /**
     *向某个继承自BaseApiRequest的request对象添加查询参数
     * @param params 传入的参数
     * @return
     */
    public T addParams(HashMap<String, String> params,HashMap<String, Object> body) {
        if (params!=null) {
            params.entrySet().iterator().forEachRemaining(param ->
                    request.addParam(param.getKey(),param.getValue())
            );
        }
        if (body!=null) {

            //request.setBody(JSONUtil.toJsonStr(body).getBytes());
            request.setBody(JSON.toJSONString(body).getBytes());
        }
        return request;
    }

}
