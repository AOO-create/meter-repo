package com.mapper.feedback;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dto.FeedbackDTO;
import com.pojo.Feedback;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/10/18 
 */
public interface FeedbackManagerMapper extends BaseMapper<Feedback> {
    int replay(@Param("dto")FeedbackDTO dto);

}
