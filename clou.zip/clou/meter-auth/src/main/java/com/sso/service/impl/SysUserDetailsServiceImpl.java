package com.sso.service.impl;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.entity.Org;
import com.sso.domain.*;
import com.sso.mapper.*;
import com.sso.service.SysUserDetailsService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: springboot-security-sso
 * @description:
 * @author: 吴方豪
 * @create: 2022-11-02 11:32
 **/
@Service
@Transactional
public class SysUserDetailsServiceImpl implements SysUserDetailsService {
    @Autowired(required = false)
    private SysUserMapper sysUserMapper;

    @Autowired(required = false)
    private SysRoleMapper sysRoleMapper;

    @Autowired(required = false)
    private MenuMangerMapper mangerMapper;

    @Autowired(required = false)
    private OrgMapper orgMapper;

    @Autowired(required = false)
    private RoleMenuRelationMapper roleMenuRelationMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //根据用户名去数据库中查询指定用户，这就要保证数据库中的用户的名称必须唯一，否则将会报错
        SysUser sysUser = sysUserMapper.findByUsername(username);
        //如果没有查询到这个用户，说明数据库中不存在此用户，认证失败，此时需要抛出用户账户不存在
        if (sysUser == null) {
            throw new UsernameNotFoundException("user not exist.");
        }
        List<SysRole> list = sysUser.getSysRoles();
        SysRole sysRole = list.get(0);
        MenuVo menuVo = getAllMenu(sysRole);
        sysUser.setMenuVoString(menuVo);
        Org org = orgMapper.findByUid(sysUser.getOrgId());
        sysUser.setOrg(org);
        return sysUser;
    }


    public MenuVo getAllMenu(SysRole role) {
        MenuVo rootVo = new MenuVo();
        //获取所有上方菜单
        List<Menu> list = getParentMenu(role);
        //每一个上方菜单去对照一个MenuVo
        List<MenuVo> menuVos = new ArrayList<>();

        if(role.getRoleCode().equals("admin")){
            for(Menu menu : list) {
                MenuVo vo = getSubMenuByIndex(String.valueOf(menu.getMenuIndex()));
                menuVos.add(vo);
            }
        }else{
            //非管理员角色通过查询确定
            menuVos = new ArrayList<>();
            List<String> list1 = getCurrentUserMenu(role);
            for(String menuId : list1){
                Menu menu = mangerMapper.selectOne(new QueryWrapper<Menu>().eq("menu_id",menuId).eq("deleted",0));
                MenuVo menuVo = new MenuVo();
                BeanUtils.copyProperties(menu,menuVo);
                menuVos.add(menuVo);
            }
            //拼接成树状的菜单
            List<MenuVo> finalMenuVos = new ArrayList<>(menuVos);
            for (MenuVo menu : menuVos) {
                for(MenuVo m : menuVos){
                    if(m.getParentMenuId()!=null && m.getParentMenuId().equals(menu.getMenuId())){
                        menu.getChildList().add(m);
                    }
                }
            }
            //删除构造树中多余的元素
            for(MenuVo menuVo : finalMenuVos){
                if(menuVo.getParentMenuId()!=null){
                    menuVos.remove(menuVo);
                }
            }
        }
        //为子节点赋值上标志
        for(MenuVo menuVo : menuVos){
            List<MenuVo> childs = menuVo.getChildList();
            menuVo.setChildList(reGetFlag(childs,role));
        }
        rootVo.setChildList(menuVos);
        return rootVo;
    }

    public MenuVo getSubMenuByIndex(String index) {
        QueryWrapper<Menu> qw = new QueryWrapper<>();
        qw.eq("has_third",1).isNull("parent_menu_id").eq("menu_index",index).eq("deleted",0);
        Menu menu = mangerMapper.selectOne(qw);
        MenuVo vo = menuToMenuVo(menu);

        List<MenuVo> childList = reGetChildList(vo.getMenuId());
        vo.setChildList(childList);
        return vo;
    }

    public MenuVo menuToMenuVo(Menu menu){
        MenuVo vo = new MenuVo();
        vo.setHasThird(menu.getHasThird());
        vo.setIcon(menu.getIcon());
        vo.setId(menu.getId());
        vo.setMenuId(menu.getMenuId());
        vo.setMenuName(menu.getMenuName());
        vo.setMenuIndex(menu.getMenuIndex());
        vo.setUrl(menu.getUrl());
        vo.setParentMenuId(menu.getParentMenuId());
        vo.setChildList(null);
        return vo;
    }

    //递归遍历
    public List<MenuVo> reGetChildList(String parentId){
        List<Menu> menus = mangerMapper.selectList(new QueryWrapper<Menu>().eq("parent_menu_id",parentId).eq("deleted",0)
                .orderByAsc("menu_index"));
        List<MenuVo> menuVos = new ArrayList<>();
        for(Menu menu : menus){
            MenuVo vo = menuToMenuVo(menu);
            menuVos.add(vo);
        }
        //查询所有该menuId下面的子节点
        for (MenuVo menu1 : menuVos) {
            parentId = menu1.getMenuId();
            //自己调用自己
            List<MenuVo> childMenus = reGetChildList(parentId);
            //跳出递归
            if (childMenus.isEmpty()) {
                continue;
            }
            menu1.setChildList(childMenus);
        }
        return menuVos;
    }
    //递归遍历为叶子节点赋值标志
    public List<MenuVo> reGetFlag(List<MenuVo> childs,SysRole role){
        for(MenuVo vo : childs){
            if(vo.getHasThird() == 1){
                reGetFlag(vo.getChildList(),role);
            }else{
                RoleMenuRelation relation = roleMenuRelationMapper.selectOne(new QueryWrapper<RoleMenuRelation>()
                        .eq("menu_id",vo.getMenuId())
                        .eq("role_id",role.getId()));
                if(null != relation){
                    vo.setAddFlag(relation.getAddFlag());
                    vo.setDeleteFlag(relation.getDeleteFlag());
                    vo.setUpdateFlag(relation.getUpdateFlag());
                }else{
                    vo.setAddFlag(false);
                    vo.setUpdateFlag(false);
                    vo.setDeleteFlag(false);
                }

            }
        }

        return childs;
    }

    public List<String> getCurrentUserMenu(SysRole role) {
        List<String> list = new ArrayList<>();
        List<RoleMenuRelation>  roleMenuRelationList = new ArrayList<>();
        if(role.getRoleCode().equals("admin")){
            roleMenuRelationList = roleMenuRelationMapper.selectList(null);

        }else{
            roleMenuRelationList  = roleMenuRelationMapper.selectList(new QueryWrapper<RoleMenuRelation>()
                    .eq("role_id",role.getId()));
        }
        roleMenuRelationList.forEach(roleMenuRelation -> {
            list.add(""+roleMenuRelation.getMenuId());
        });
        return list;
    }

    public List<Menu> getParentMenu(SysRole role) {
        QueryWrapper<Menu> qw = new QueryWrapper<>();
        qw.eq("has_third",1).eq("deleted",0).isNull("parent_menu_id").orderByAsc("menu_index");

        if(role.getRoleCode().equals("admin")){
            return mangerMapper.selectList(qw);
        }else{
            List<RoleMenuRelation> list = roleMenuRelationMapper.selectList(new QueryWrapper<RoleMenuRelation>().eq("role_id",role.getId()));
            List<Menu> menuList = new ArrayList<>();
            for (RoleMenuRelation relation : list) {
                Menu menu = mangerMapper.selectOne(new QueryWrapper<Menu>()
                        .eq("menu_id",relation.getMenuId())
                        .eq("has_third",1)
                        .isNull("parent_menu_id")
                        .orderByAsc("menu_index"));
                if(menu != null){
                    menuList.add(menu);
                }
            }
            return menuList;
        }
    }
}
