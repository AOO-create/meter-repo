package com.config;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

/**
 * Copyright © 2021 FL All rights reserved.
 */
@Slf4j
@Configuration
public class FeignRequestInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate template) {
//      log.info("-----增强配置Feign请求头，开始------->");
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (null != attributes) {
            HttpServletRequest request = attributes.getRequest();
            //获取到请求头名字
            Enumeration<String> headerNames = request.getHeaderNames();
            while (headerNames.hasMoreElements()) {
                String name = headerNames.nextElement();
                if(!name.equals("authorization") && !name.equals("userid")){
                    continue;
                }
                //获取到请求头
                String value = request.getHeader(name);
                //经过处理逻辑后
                //使用进入的request对象来设置Feign请求对象的请求头
                template.header(name, value);
            }
        }
//        log.info("-----增强配置Feign请求头，结束------->");

    }

}
