package aep.nbiot.command;

/**
 * @author wufanghao
 * @version 1.0
 * @description: MQ消息订阅
 * @date 2021/11/17 8:05
 */
public enum AepMqSubEnum implements AepCommandEnum{

    ChangeSubRules("ChangeSubRules","增加或修改产品订阅规则"),
    ChangeTopicInfo("ChangeTopicInfo","更新topic基本信息，可更新topic名称、描述、启用状态、数据源类型、删除状态"),
    ClosePushService("ClosePushService","关闭租户MQ消息提送服务"),
    CreateTopic("CreateTopic","创建topic，同一租户最多能创建10个主题，不能出现同名topic"),
    OpenMqService("OpenMqService","开通租户MQ消息推送服务"),
    QueryServiceState("QueryServiceState","根据tenantId查询开通状态、开通时间、token等信息"),
    QuerySubRules("QuerySubRules","根据产品ID获取指定topic下的订阅规则列表，支持多产品ID"),
    QueryTopicCacheInfo("QueryTopicCacheInfo","根据topicId查询topic缓存空间使用信息"),
    QueryTopicInfo("QueryTopicInfo","根据topicId查询topic基本信息"),
    QueryTopics("QueryTopics","查询某个租户的所有topic列表"),
    ;
    /**
     * 命令KEY
     */
    private String commandKey;

    /**
     * 命令名称
     */
    private String commandName;

    AepMqSubEnum(String commandKey, String commandName) {
        this.commandKey = commandKey;
        this.commandName = commandName;
    }

}
