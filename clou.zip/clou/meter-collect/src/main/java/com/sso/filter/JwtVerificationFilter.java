package com.sso.filter;

import com.common.Const;
import com.entity.Role;
import com.entity.User;
import com.sso.domain.Payload;
import com.sso.domain.SysRole;
import com.sso.domain.SysUser;
import com.sso.domain.UserDto;
import com.sso.prop.RsaKeyProperties;
import com.sso.utils.JwtUtils;
import com.sso.utils.ResponseUtils;
import com.utils.RedisUtils;
import com.utils.UserInfo;
import io.jsonwebtoken.ExpiredJwtException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.stereotype.Component;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 验证过滤器
 *
 * @author sso
 */
public class JwtVerificationFilter extends BasicAuthenticationFilter {
    private RsaKeyProperties prop;
    private AuthenticationManager authenticationManager;

    public JwtVerificationFilter(AuthenticationManager authenticationManager, RsaKeyProperties prop) {
        super(authenticationManager);
        this.authenticationManager = authenticationManager;
        this.prop = prop;
    }

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            String header = request.getHeader("Authorization");
            String userId = request.getHeader("userId");
            if (header == null || !header.startsWith("Bearer ")) {
                //如果token的格式错误，则提示用户非法登录
                chain.doFilter(request, response);
                ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户非法登录！");
            } else {
                //如果token的格式正确，则先要获取到token
                String token = header.replace("Bearer ", "");
                //使用公钥进行解密然后来验证token是否正确
                Payload<SysUser> payload = JwtUtils.getInfoFromToken(token, prop.getPublicKey(), SysUser.class);
                SysUser sysUser = payload.getUserInfo();
//                RedisUtils redisUtils = RedisUtils.getBean(RedisUtils.class,request);
//                UserInfo userInfo = UserDto.sysUserToInfo(sysUser);
                Const.userId = userId;
                if (sysUser != null) {
                    UsernamePasswordAuthenticationToken authResult = new UsernamePasswordAuthenticationToken(sysUser.getUsername(), null, sysUser.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(authResult);
                    chain.doFilter(request, response);
                } else {
                    ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户验证失败！");
                }
            }
        } catch (ExpiredJwtException e) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "请您重新登录！");
        }
    }
}
