package aep.nbiot.client;

import aep.nbiot.command.AepCommandEnum;
import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.command.AepDeviceManagementEnum;
import aep.nbiot.command.AepNbDeviceManagementEnum;
import aep.nbiot.propertie.AepIotProperties;
import com.ctg.ag.sdk.biz.*;
import com.ctg.ag.sdk.core.BaseApiClient;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AEP Client工厂类
 * @date 2021/11/17 8:33
 */
public class ClientFactory {

    /**
     * 设备管理Client
     */
    private static AepDeviceManagementClient aepDeviceManagementClient = null;


    /**
     * 批量设备管理Client
     */
    private static AepNbDeviceManagementClient aepNbDeviceManagementClient = null;

    /**
     * 指令下发Client
     */
    private static AepDeviceCommandClient aepDeviceCommandClient = null;

    //以下暂未集成实现
    private static AepCommandModbusClient aepCommandModbusClient = null;
    private static AepDeviceCommandLwmProfileClient aepDeviceCommandLwmProfileClient = null;
    private static AepDeviceControlClient aepDeviceControlClient = null;
    private static AepDeviceEventClient aepDeviceEventClient = null;
    private static AepDeviceGroupManagementClient aepDeviceGroupManagementClient = null;
    private static AepDeviceModelClient aepDeviceModelClient = null;
    private static AepDeviceStatusClient aepDeviceStatusClient = null;
    private static AepEdgeGatewayClient aepEdgeGatewayClient = null;
    private static AepFirmwareManagementClient aepFirmwareManagementClient = null;
    private static AepModbusDeviceManagementClient                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  aepModbusDeviceManagementClient = null;
    private static AepMqSubClient aepMqSubClient = null;
    private static AepProductManagementClient aepProductManagementClient = null;
    private static AepPublicProductManagementClient aepPublicProductManagementClient = null;
    private static AepRuleEngineClient aepRuleEngineClient = null;
    private static AepSoftwareManagementClient aepSoftwareManagementClient = null;
    private static AepSoftwareUpgradeManagementClient aepSoftwareUpgradeManagementClient = null;
    private static AepStandardManagementClient aepStandardManagementClient = null;
    private static AepSubscribeNorthClient aepSubscribeNorthClient = null;
    private static AepUpgradeManagementClient aepUpgradeManagementClient = null;
    private static TenantAppStatisticsClient tenantAppStatisticsClient = null;
    private static TenantDeviceStatisticsClient  tenantDeviceStatisticsClient= null;
    private static UsrClient  usrClient= null;



    /**
     * 构造返回相应命令的Client对象
     * @param command AEP 命令
     * @return 相应的客户端Client
     */
    public static BaseApiClient getClient(AepCommandEnum command, AepIotProperties aepIotProperties){
        if(command instanceof AepDeviceManagementEnum){
            if(aepDeviceManagementClient == null){
                aepDeviceManagementClient = AepDeviceManagementClient.newClient().appKey(aepIotProperties.getAppKey()).appSecret(aepIotProperties.getAppSecret()).build();
            }
            return aepDeviceManagementClient;
        }

        if(command instanceof AepDeviceCommandEnum){
            if(aepDeviceCommandClient == null){
                aepDeviceCommandClient = AepDeviceCommandClient.newClient().appKey(aepIotProperties.getAppKey()).appSecret(aepIotProperties.getAppSecret()).build();
            }
            return aepDeviceCommandClient;
        }

        if(command instanceof AepNbDeviceManagementEnum){
            if(aepDeviceManagementClient == null){
                aepNbDeviceManagementClient = AepNbDeviceManagementClient.newClient().appKey(aepIotProperties.getAppKey()).appSecret(aepIotProperties.getAppSecret()).build();
            }
            return aepNbDeviceManagementClient;
        }

        return null;
    }

}
