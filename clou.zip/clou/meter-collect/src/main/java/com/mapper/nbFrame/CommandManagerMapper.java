package com.mapper.nbFrame;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.nbFrame.nbSendCommand;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
public interface CommandManagerMapper extends BaseMapper<nbSendCommand> {
}
