package com.sso.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.Org;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 说明：单位mapper
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-12-30
 */
public interface OrgMapper extends BaseMapper<Org> {

    @Select("select * from `o_org` where org_id = #{orgId}")
    Org findByUid(@Param("orgId") String orgId);
}
