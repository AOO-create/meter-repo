package com.advice;

import com.sso.utils.ResponseUtils;
import com.sso.utils.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalControllerAdvice {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @InitBinder
    public void initBinder(WebDataBinder binder) {

    }

    @ModelAttribute
    public void addAttributes(HttpServletRequest request, Model model) {
        model.addAttribute("request", request);
        model.addAttribute("base", request.getContextPath());
        model.addAttribute("today", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy年MM月dd E")));
    }

    @ExceptionHandler(value = { Exception.class })
    public Result handleException(HttpServletRequest request, Exception authException) {
        if (authException instanceof InternalAuthenticationServiceException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "认证服务不正常", null);
        } else if (authException instanceof UsernameNotFoundException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "用户账户不存在", null);
        } else if (authException instanceof BadCredentialsException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "用户密码错误", null);
        } else if (authException instanceof AccountExpiredException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "用户账户已过期", null);
        } else if (authException instanceof LockedException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "用户账户已被锁", null);
        } else if (authException instanceof CredentialsExpiredException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "用户密码已失效", null);
        } else if (authException instanceof DisabledException) {
            return new Result(HttpServletResponse.SC_FORBIDDEN, "用户账户已被锁", null);
        }
//        7967e8e5a68656425665276fb03cf7c44fe7ce75
        return new Result(HttpServletResponse.SC_FORBIDDEN, authException.getMessage(), null);
    }

}
