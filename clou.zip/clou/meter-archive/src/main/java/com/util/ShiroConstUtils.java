package com.util;

import com.alibaba.fastjson.JSONObject;
import com.common.Const;
import com.entity.Org;
import com.entity.Role;
import com.entity.User;
import com.utils.RedisUtils;
import com.utils.SpringUtils;
import com.utils.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author liuwei
 * @从redis缓存中获取登录用户信息
 * @date 2022/5/31
 */
@Component
public class ShiroConstUtils {


    @Resource
    private RedisUtils redisUtils = SpringUtils.getBean(RedisUtils.class);

    public  Org getOrg(){
        String key = "userInfo:" + Const.userId;
        String str = redisUtils.getCacheObject(key);
        JSONObject json = JSONObject.parseObject(str);
        JSONObject json1 =  json.getJSONObject("userInfo");
        UserInfo userInfo =  json1.toJavaObject(UserInfo.class);
        return userInfo.getOrg();
    }

    public  User getUser(){
        String key = "userInfo:" + Const.userId;
        String str = redisUtils.getCacheObject(key);
        JSONObject json = JSONObject.parseObject(str);
        JSONObject json1 =  json.getJSONObject("userInfo");
        UserInfo userInfo =  json1.toJavaObject(UserInfo.class);
        return userInfo.getUser();
    }

    public  Role getRole() {
        String key = "userInfo:" + Const.userId;
        String str = redisUtils.getCacheObject(key);
        JSONObject json = JSONObject.parseObject(str);
        JSONObject json1 =  json.getJSONObject("userInfo");
        UserInfo userInfo =  json1.toJavaObject(UserInfo.class);
        return userInfo.getRole();
    }

    public String getTgBuildDoorplate(){
        String key = "userInfo:" + Const.userId;
        String str = redisUtils.getCacheObject(key);
        JSONObject json = JSONObject.parseObject(str);
        JSONObject json1 =  json.getJSONObject("userInfo");
        UserInfo userInfo =  json1.toJavaObject(UserInfo.class);
        return userInfo.getTgBuildDoorplate();
    }

    public String getAreaId(){
        String key = "userInfo:" + Const.userId;
        String str = redisUtils.getCacheObject(key);
        JSONObject json = JSONObject.parseObject(str);
        JSONObject json1 =  json.getJSONObject("userInfo");
        UserInfo userInfo =  json1.toJavaObject(UserInfo.class);
        return userInfo.getAreaId();
    }


}
