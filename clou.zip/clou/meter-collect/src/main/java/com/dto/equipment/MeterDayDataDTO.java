package com.dto.equipment;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.constant.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
@Data
public class MeterDayDataDTO extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private String id;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date collTime;
    private String realSumFlow;//冻结
    private String actualSumFlow;//冻结
    private String waterFee;//水费

    private String orgId;
    private String tgBuildDoorplate;
    private String areaId;//组织地址
    private String name;//表名称
    private String termName;//集中器名称
    private String instLoc;//安装地址
    private String bdNo;  //门牌地址
    private Integer meterType;//查询日数据的表类型

    private String imei;
    private String meterAddress;
    private String wmtrNo;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date dataDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updTime;
    private String version;

    private String status;//开关阀状态

    //新协议NB表特有属性
    private String csq;
    private String rsrp;
    private String snr;
    private String ecl;
    private String waterCurrentDate;
    private String runStatus;

    private String collId;
    private String type;
    //集中器地址
    private String termAddress;
    //公式
    private String calculate;//公式

    private String protoCode;//协议类型

    private String channel;
    private String protocol;
    private String uartbps;
    private String meterId;//cl6904库中ID

    private String modelType;//集中器类型
    private List<String> tgIds;
    private String date;

}
