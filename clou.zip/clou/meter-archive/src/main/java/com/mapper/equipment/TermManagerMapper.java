package com.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.log.ChangeTermLog;
import com.entity.equipment.Term;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Mapper
public interface TermManagerMapper extends BaseMapper<Term> {

    int getCount(@Param("dto") TermDTO dto);

    List<TermDTO> getTerm(@Param("dto") TermDTO dto);

    List<WiredMeterDTO> getMeterOnTerm(@Param("dto") WiredMeterDTO dto);

    int getReadCount(@Param("dto") WiredMeterDTO dto);

    List<TermDTO> validAddress(@Param("address") String address);

    List<TermDTO> getTermByAreaId(@Param("orgId") String orgId, @Param("ids") List<String> idList);

    void batchInsert(@Param("list") List<TermDTO> list);

    Integer getMeterByTermId(@Param("termId") String termId);

    void deleteTerm(@Param("terminalId")String terminalId);

    TermDTO getByAddress(@Param("address") String termId);

    void setTermAddress(@Param("oldAddress") String oldAddress,@Param("newAddress") String newAddress);

    int updateWiredTermAddress(@Param("dto") TermDTO dto);

    List<ChangeTermLog> getChangeTermLog(@Param("dto") ChangeTermLog log);

    int getChangeTermLogCount(@Param("dto") ChangeTermLog log);

    int getMeterByTermIdList(@Param("ids") List<String> idList);

    void batchDeleteTerm(@Param("ids") List<String> idList);
}
