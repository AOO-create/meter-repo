package com.AepResolve;


import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.service.AepApiService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.config.ProductProperties;
import com.constant.ProtoConstant;
import com.constant.Seroalid;
import com.entity.aotemanCommand.AotemanSendCommand;
import com.entity.equipment.WaterMeterDayRead;
import com.mapper.aotemanCommand.AotemanCommandMapper;
import com.service.WaterMeterDayReadService;
import com.utils.AepUtils;
import com.utils.BCDCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class AepCompanyAoteman  {

    @Autowired
    private ProductProperties productProperties;

    @Autowired
    private AepApiService aepApiService;

    @Autowired
    private WaterMeterDayReadService waterMeterDayReadService;

    @Autowired
    private AotemanCommandMapper aotemanCommandMapper;

    /***
     * 组装数据同步帧
     */
    public static String makeSyncFrame(MeterFrameDataAoteman data, String currentIntegreFlow) {
        String length;
        String logo;
        if (ProtoConstant.FarmeLogo.OffineLogoA.equals(data.getDataLogo())) {
            length = ProtoConstant.FarmeCode.SyncLengthA;
            logo = ProtoConstant.FarmeLogo.SyncLogoA;
        } else {
            length = ProtoConstant.FarmeCode.SyncLengthB;
            logo = ProtoConstant.FarmeLogo.SyncLogoB;
        }

        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(ProtoConstant.FarmeCode.SyncContol)
                .append(length).append(logo)
                .append(Seroalid.createSerialId())
                .append(currentIntegreFlow)
                .append(ProtoConstant.FarmeType.Unit);
        String checkCode = AepUtils.makeChecksum(stringBuilder.toString());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    public static StringBuilder makeFrame(MeterFrameDataAoteman data) {
        StringBuilder stringBuilder = new StringBuilder(30);
        stringBuilder.append(ProtoConstant.FarmeCode.StartCode)
                .append(data.getType())
                .append(data.getAddress());
        return stringBuilder;
    }

    /***
     * 开关阀操作
     * @param data
     * @param status
     * @return
     */
    public static String makeValveFrame(MeterFrameDataAoteman data, String status) {
        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(ProtoConstant.FarmeCode.ValveContol)
                .append(ProtoConstant.FarmeCode.ValveLength)
                .append(ProtoConstant.FarmeLogo.ValveLogo)
                .append(Seroalid.createSerialId())
                .append(status);
        String checkCode = AepUtils.makeChecksum(stringBuilder.toString());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    /***
     * 组装离线应答帧
     */
    public static String makeOfflineFrame(MeterFrameDataAoteman data, String isRespon) {

        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(isRespon)
                .append(ProtoConstant.FarmeCode.OffineLength)
                .append(data.getDataLogo())
                .append(data.getSerialId()).append(data.getTotalNmbel())
                .append(data.getCurrentFrmId());
        String checkCode = AepUtils.makeChecksum(stringBuilder.toString());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    public String handleFrame(String deviceId,String frame) {
        MeterFrameDataAoteman dataAoteman = resolveWtm(frame,deviceId);
        if(dataAoteman.getCurrentIntegreFlow()!=null){
            WaterMeterDayRead waterMeterDayRead = new WaterMeterDayRead();
            //插入数据库
            SimpleDateFormat format = new SimpleDateFormat("yyMMddHHmmss");
            try {
                waterMeterDayRead.setCollTime(format.parse(dataAoteman.getReportTime()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            waterMeterDayRead.setCollTime(new Date());
            waterMeterDayRead.setDeviceId(dataAoteman.getImei());
            waterMeterDayRead.setRealSumFlow(BigDecimal.valueOf(dataAoteman.getCurrentIntegreFlow()));
            waterMeterDayRead.setDataDate(new Date());
            waterMeterDayReadService.add(waterMeterDayRead);
        }
        //下达指令回复
        String onlineFrame = makeOfflineFrame(dataAoteman, ProtoConstant.ResponStatus.Online);
//        String valveFrame = null;
//        if(ProtoConstant.ValveStatus.Close.equals(dataAoteman.getContolCode())){
//             valveFrame = makeValveFrame(dataAoteman, ProtoConstant.ValveStatus.Open);//关闭阀门
//        }

//        createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), valveFrame);
        String responseString = createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), onlineFrame);

        //加个判断表具开关阀
        List<String> frameArray = AepUtils.stringToArray(frame);
        MeterFrameDataAoteman frameWaterData = new MeterFrameDataAoteman();
        frameWaterData.setStartcode(Integer.parseInt(frameArray.get(0)));
        frameWaterData.setType(Integer.parseInt(frameArray.get(1)));
        frameWaterData.setAddress(AepUtils.join(frameArray.subList(2, 9)));
        frameWaterData.setContolCode((frameArray.get(9)));
        frameWaterData.setByteLength(AepUtils.bigEndian(frameArray.subList(10, 12)));
        frameWaterData.setDataLogo(AepUtils.join(frameArray.subList(12, 14)));
        frameWaterData.setSerialId((frameArray.get(14)));
        frameWaterData.setReportTime((BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(frameArray.size() - 18,frameArray.size() - 12)))));
        frameWaterData.setCheckCode((frameArray.get(frameArray.size() - 2)));
        frameWaterData.setDeviceId(deviceId);
        String meterAddress = BCDCode.StringBcdToInt(frameWaterData.getAddress());
        if(meterAddress.length() < 16){
            for(int i=16;i>=meterAddress.length();i--){
                meterAddress = "0" + meterAddress;
            }
        }
        AotemanSendCommand command = aotemanCommandMapper.selectOne(new QueryWrapper<AotemanSendCommand>()
                .eq("meter_address",meterAddress)
                .eq("flag","0"));
        if(command != null){
            String flag = command.getParam();
            //55开。 99 关
            String valveFrame = makeValveFrame(frameWaterData,flag);//关闭阀门
//            String valveFrame = makeValveFrame(frameWaterData, ProtoConstant.ValveStatus.Close);//关闭阀门
            if(flag.equals("55")){
                System.out.println("沃特曼开阀命令:" + valveFrame);
            }else{
                System.out.println("沃特曼关阀命令:" + valveFrame);
            }
            //发送确认帧 ,下达指令
            createCommand(productProperties.getMasterKey(), frameWaterData.getDeviceId(), productProperties.getProductId(), productProperties.getOperator(), valveFrame);
            command.setFlag("1");
            command.setResultData("已下发命令");
            command.setUpdTime(new Date());
            aotemanCommandMapper.updateById(command);
        }
        return responseString;
    }

    public void handleStatusFrame(String frame) {
        List<String> frameArray = AepUtils.stringToArray(frame);
        String meterAddress = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(2, 9)));
        if(meterAddress.length() < 16){
            for(int i=16;i>=meterAddress.length();i--){
                meterAddress = "0" + meterAddress;
            }
        }
        AotemanSendCommand command = aotemanCommandMapper.selectOne(new QueryWrapper<AotemanSendCommand>()
                .eq("meter_address",meterAddress)
                .eq("flag","1"));
        command.setFlag("2");
        command.setResultData("开关阀指令成功");
        aotemanCommandMapper.updateById(command);
    }

    public MeterFrameDataAoteman resolveWtm(String frame,String deviceId) {
        System.out.println("收到的上报的报文信息如下：" + frame);
        List<String> frameArray = AepUtils.stringToArray(frame);
        String frameType = ProtoConstant.FarmeType.ReadType;
        MeterFrameDataAoteman frameWaterData = new MeterFrameDataAoteman();
        frameWaterData.setStartcode(Integer.parseInt(frameArray.get(0)));
        frameWaterData.setType(Integer.parseInt(frameArray.get(1)));
        frameWaterData.setAddress(AepUtils.join(frameArray.subList(2, 9)));
        frameWaterData.setContolCode((frameArray.get(9)));
        frameWaterData.setByteLength(AepUtils.bigEndian(frameArray.subList(10, 12)));
        frameWaterData.setDataLogo(AepUtils.join(frameArray.subList(12, 14)));
        frameWaterData.setSerialId((frameArray.get(14)));
        frameWaterData.setReportTime((BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(frameArray.size() - 18,frameArray.size() - 12)))));
        frameWaterData.setCheckCode((frameArray.get(frameArray.size() - 2)));
        frameWaterData.setDeviceId(deviceId);

        frame = frame.substring(0, frame.length() - 4);
        //收到报文需要校验帧数据是否正确
        if ("".equals(frameWaterData.getCheckCode()) ||frameWaterData.getCheckCode()==null|| !frameWaterData.getCheckCode().equalsIgnoreCase(AepUtils.makeChecksum(frame))) {
            System.out.println("收到的数据帧校验错误，丢弃，打印错误日志");
            return null;
        }
        if (frameType.equals(frameWaterData.getContolCode())) {
            return resolveReadFrame(frameWaterData, frameArray);

        } else {
            return resolveValveFrame(frameWaterData, frameArray);
            // return resolveSyncFrame(frameWaterData);
        }
    }

    /***
     * 解析主动上报帧
     * @param frameWaterData
     * @param frameArray
     *
     * @return
     */
    public MeterFrameDataAoteman resolveReadFrame(MeterFrameDataAoteman frameWaterData, List<String> frameArray) {
        int startNode;
        frameWaterData.setTotalNmbel(AepUtils.join(frameArray.subList(15, 17)));
        frameWaterData.setCurrentFrmId(AepUtils.join(frameArray.subList(17, 19)));
        frameWaterData.setTicurrentFrmNuber(Integer.parseInt(frameArray.get(19), 16));
        String logo = ProtoConstant.FarmeLogo.OffineLogoA;

        if (logo.equals(frameWaterData.getDataLogo())) {
            startNode = 26 + frameWaterData.getTicurrentFrmNuber() * 4;
            Double flower  = Double.parseDouble(BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(startNode, startNode + 4))));
//            double math = flower.setScale(3,BigDecimal.ROUND_HALF_UP).doubleValue();
            frameWaterData.setCurrentIntegreFlow(flower*0.01);
            frameWaterData.setImei(AepUtils.join(frameArray.subList(startNode + 22, startNode + 30)).replaceAll("^(0+)", ""));
            frameWaterData.setImsi(AepUtils.join(frameArray.subList(startNode + 30, startNode + 38)));

        } else {
            startNode = 26 + frameWaterData.getTicurrentFrmNuber() * 5;
            Double flower =Double.parseDouble(BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(startNode, startNode + 5))));
//            int value = BCDCode.bcdToInt(AepUtils.join(frameArray.subList(startNode, startNode + 5)));
//            Double flower =  new Double(value * 0.0001);
            frameWaterData.setCurrentIntegreFlow(flower*0.0001);
            frameWaterData.setImei(AepUtils.join(frameArray.subList(startNode + 24, startNode + 32)).replaceAll("^(0+)", ""));
            frameWaterData.setImsi(AepUtils.join(frameArray.subList(startNode + 32, startNode + 40)));
        }
        String onlineFrame = makeOfflineFrame(frameWaterData, ProtoConstant.ResponStatus.Online);
        String syncFrameB = makeSyncFrame(frameWaterData, "0017078000");
        String syncFrame = makeSyncFrame(frameWaterData, "95000000");//实例32018000


//        createCommand(masterKey, mqDataReport.getDeviceId(), mqDataReport.getProductId(), operator, valveFrame);
        //createCommand(productProperties.getMasterKey(), frameWaterData.getDeviceId(), productProperties.getProductId(), productProperties.getOperator(),syncFrame);
        //存储到数据库
//      System.out.println("存储到数据库success");
//      System.out.println("下发的离线帧数据为："+onlineFrame);
//      System.out.println("下发的阀门帧数据为：" + syncFrame);
//        打开阀门收到的报文：681029000011215022840500a017 01 80 010716
//        关闭阀门收到的报文：681029000011215022840500a017 01 81 010816
        return frameWaterData;
    }

    /***
     * 解析开阀门开关操作的响应帧
     * @param frameWaterData
     * @param frameArray
     * @return
     */
    public MeterFrameDataAoteman resolveValveFrame(MeterFrameDataAoteman frameWaterData, List<String> frameArray) {
        frameWaterData.setWaterMeterStatus0(Integer.parseInt(frameArray.get(15)));
        //需要校验帧数据是否正确
        String makeValveFrame = makeValveFrame(frameWaterData, ProtoConstant.ValveStatus.Open);
        //发送确认帧 ,下达指令
        //createCommand(masterKey, deviceId, productId, operator, makeValveFrame);
        //存储到数据库
//        System.out.println("打开阀门开关success并存储记录");
        System.out.println(makeValveFrame);
        return frameWaterData;
    }

    /****
     * 下达指令
     * @param masterKey
     * @param deviceId
     * @param productId
     * @param operator
     * @param payload
     */
    public String createCommand(String masterKey, String deviceId, String productId, String operator, String payload) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("MasterKey", masterKey);
        HashMap<String, Object> body = new HashMap<>();
        body.put("deviceId", deviceId);
        body.put("operator", operator);
        body.put("productId", productId);
        body.put("ttl", 864000);
        //body.put("deviceGroupId",)
        //body.put("level",)
        HashMap<String, Object> content = new HashMap<>();
        content.put("dataType", "2");
        content.put("payload", payload);
        body.put("content", content);
        String relust = aepApiService.invockApi(AepDeviceCommandEnum.CreateCommand, params, body);
        System.out.println("执行命令返回结果为：" + relust);
        return  relust;
    }


}
