package com.sso.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/6/28
 */
@Data
@TableName("role_menu_relation")
public class RoleMenuRelation {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long menuId;

    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long roleId;

    private Boolean addFlag;

    private Boolean updateFlag;

    private Boolean deleteFlag;
}
