package aep.nbiot.strategy.aepdevicemanage;

import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.util.ParamsUtil;
import com.ctg.ag.sdk.biz.AepNbDeviceManagementClient;
import com.ctg.ag.sdk.biz.aep_device_management.QueryDeviceListRequest;
import com.ctg.ag.sdk.biz.aep_nb_device_management.BatchCancelDevicesRequest;
import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 批量注销设备
 * @date 2021/11/17 8:03
 */
public class BatchCancelDevicesStrategy implements IAepStrategy {

    @Override
        public BaseApiResponse invockApi(BaseApiClient _client, HashMap<String,Object> params, HashMap<String,Object> body) {
        try {
            ParamsUtil paramsUtil = new ParamsUtil(new QueryDeviceListRequest());
            BatchCancelDevicesRequest request = (BatchCancelDevicesRequest) paramsUtil.addParams(params,body);
            AepNbDeviceManagementClient client = (AepNbDeviceManagementClient)_client;
            return client.BatchCancelDevices(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
