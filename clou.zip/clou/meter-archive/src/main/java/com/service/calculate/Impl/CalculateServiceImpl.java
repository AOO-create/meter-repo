package com.service.calculate.Impl;

import com.common.Const;
import com.mapper.calculate.CalculateFeeMapper;
import com.mapper.calculate.CalculateMapper;
import com.mapper.calculate.CalculateParamMapper;
import com.mapper.organization.BDGradeMapper;
import com.entity.calculate.CalculateFee;
import com.entity.calculate.CalculateParam;
import com.entity.Org;
import com.mapper.systemSetup.UserMapper;
import com.service.calculate.CalculateService;
import com.service.organization.impl.GradeServiceImpl;
import com.util.ShiroConstUtils;
import com.vo.calculateVo.CalculateFeeVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DecimalFormat;
import java.util.*;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */
@Service
public class CalculateServiceImpl  implements CalculateService {

    @Autowired
    private CalculateParamMapper calclulateParamMapper;

    @Autowired
    private CalculateFeeMapper calculateFeeMapper;

    @Autowired
    private CalculateMapper mapper;

    @Autowired
    private GradeServiceImpl gradeService;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public Page<CalculateFeeVo> getAllCalculate(CalculateFeeVo calculateVo) {
        Org org = shiroConstUtils.getOrg();
        Page<CalculateFee> page = new Page<>(calculateVo.getPage(),calculateVo.getLimit());
        QueryWrapper<CalculateFee> qw = new QueryWrapper<>();
        List<String> ids = new ArrayList<>();
        if(null == calculateVo.getTgBuildDoorplate()){
            //点击树节点为组织区域 顶级节点,查找该组织区域下面所有房间
            ids = gradeService.reGetChildGradeId(calculateVo.getAreaId()+"",org.getOrgId(),ids);
            ids = gradeService.getBDGradeId(ids);
            if(ids.size() == 0){
                return null;
            }
            qw.in("tg_build_doorplate",ids);
        }else{
            ids = gradeService.reGetChildBDGradeId(calculateVo.getTgBuildDoorplate()+"",org.getOrgId(),ids);
            if( ids.size() == 0){
                return null;
            }
            qw.in("tg_build_doorplate",ids);
        }

        page = calculateFeeMapper.selectPage(page,qw);

        Page<CalculateFeeVo> voPage = new Page<>(calculateVo.getPage(),calculateVo.getLimit());
        voPage.setTotal(page.getTotal());
        voPage.setSize(page.getSize());
        voPage.setCurrent(page.getCurrent());
        voPage.setPages(page.getPages());
        List<CalculateFeeVo> voList = new ArrayList<>();
        page.getRecords().forEach(val->{
            String bdName = bdGradeMapper.selectById(val.getTgBuildDoorplate()).getBdName();
            String userName =  userMapper.selectById(val.getCreateUser()).getName();
            CalculateFeeVo vo = new CalculateFeeVo();
            vo.setId(val.getId());
            vo.setTgBuildDoorplate(val.getTgBuildDoorplate());
            vo.setCreateTime(val.getCreateTime());
            vo.setName(val.getName());
            vo.setBdName(bdName);
            vo.setUserName(userName);
            vo.setStatus(val.getStatus());
            vo.setFormula(val.getFormula());
            vo.setRealFormula(val.getRealFormula());
            voList.add(vo);
        });
        voPage.setRecords(voList);
        return voPage;
    }

    @Transactional
    @Override
    public boolean createCalculateOneType(CalculateFeeVo calculateFeeVo) throws Exception {
        //先插入公式表格中
        String userId = Const.userId;
        CalculateFee fee = new CalculateFee();
        fee.setCreateTime(new Date());
        fee.setCreateUser(Long.valueOf(userId));
        fee.setName("统一水价缴费方案");
        String calculate = "吨数*" + calculateFeeVo.getPrice();
        fee.setFormula(calculate);
        fee.setTgBuildDoorplate(calculateFeeVo.getTgBuildDoorplate());
        fee.setStatus("0");
        fee.setRealFormula("统一水价方案:"+calculateFeeVo.getPrice()+"元/每吨");
        int count = calculateFeeMapper.insert(fee);
        if(count <= 0){
            throw new Exception();
        }

        //插入参数表
        CalculateParam calculateParam = new CalculateParam();
        calculateParam.setCalculateFeeId(fee.getId());
        calculateParam.setRemark("统一水价方案，元/每吨");
        calculateParam.setType("1");
        calculateParam.setValue(calculateFeeVo.getPrice());
        count = calclulateParamMapper.insert(calculateParam);
        if(count <= 0){
            throw new Exception();
        }
        return true;
    }

    @Transactional
    @Override
    public boolean createCalculateTwoType(CalculateFeeVo calculateFeeVo) throws Exception {
        //先插公式表
        String userId = Const.userId;
        List<CalculateParam> paramList = calculateFeeVo.getParamList();
        String formula = "";
        String realFormula = "";
        for(int i=0 ; i<paramList.size();i++){
            String preEnd;
            if(i == 0){
                preEnd = "0";
            }else {
                preEnd = paramList.get(i-1).getEnd();
            }
            String end = paramList.get(i).getEnd();
            double value = paramList.get(i).getValue();
            if(i == paramList.size() -1){
                formula = "(X" + "-" + preEnd + ")*" + value + "+" + formula;
                realFormula = realFormula + paramList.get(i).getLevel() + "级阶梯水价" + paramList.get(i).getValue() + "" +
                        "；阶梯结束值为：阶梯结束值不限制;";
                continue;
            }

            formula =  "(" + end + "-" + preEnd + ")*" + value + "+" + formula;
            realFormula = realFormula + paramList.get(i).getLevel() + "级阶梯水价" + paramList.get(i).getValue() + "" +
                    "；阶梯结束值为："+paramList.get(i).getEnd()+";";
        }
        formula = formula.substring(0,formula.length()-1);
        CalculateFee fee = new CalculateFee();
        String name = "阶梯缴费方案";
        fee.setRealFormula(realFormula);
        fee.setName(name);
        fee.setStatus("0");
        fee.setTgBuildDoorplate(calculateFeeVo.getTgBuildDoorplate());
        fee.setFormula(formula);
        fee.setCreateUser(Long.valueOf(userId));
        fee.setCreateTime(new Date());
        int count ;
        count = calculateFeeMapper.insert(fee);
        if(count <= 0){
            throw new Exception();
        }
        //插入参数表
        Long formulaId = fee.getId();
        for(CalculateParam calculateParam : paramList){
            calculateParam.setCalculateFeeId(formulaId);
            String remark = calculateParam.getLevel() + "级阶梯水价" + calculateParam.getValue();
            calculateParam.setRemark(remark);
            count = calclulateParamMapper.insert(calculateParam);
            if(count <= 0){
                throw new Exception();
            }
        }
        return true;
    }

    /**
       * 功能描述 根据房间号 用水量获得应缴水费
       * @author liuwei
       * @date  2022/8/11
       * @param
       * @return
    */
    @Override
    public Map<String,String> getWaterValue(Long bdId, double waterConsumption) {
        Map<String,String> map = new HashMap<>();
        if(waterConsumption == 0d){
            map.put("waterValue","");
            map.put("calculate","");
            return map;
        }
        DecimalFormat df = new DecimalFormat("######0.000");

        CalculateFee fee = calculateFeeMapper.selectOne(new QueryWrapper<CalculateFee>().eq("tg_build_doorplate",bdId));
        if(fee == null ){
            return null;
        }
        List<CalculateParam> paramList = calclulateParamMapper.selectList(new QueryWrapper<CalculateParam>()
                          .eq("calculate_fee_id",fee.getId()).orderByAsc("level"));
        if(paramList == null ){
            return null;
        }

        double waterValue = 0;
        String calculate = "";
        String type = paramList.get(0).getType();
        if(type.equals("1")){
            double value = paramList.get(0).getValue();
            waterValue = waterConsumption * value;
        }else if(type.equals("2")){
            //阶梯缴费
            int level = 0;
            //计算属于第几阶梯

            for(int j=0;j<=paramList.size() -1;j++){
                if(j == paramList.size() -1){
                    level = paramList.size();
                    break;
                }
                double end = Double.parseDouble(paramList.get(j).getEnd());
                if(waterConsumption <= end){
                    level = Integer.parseInt(paramList.get(j).getLevel());
                    break;
                }
            }

            for(int i=0 ; i<=level -1 ;i ++){
                if(i == 0 && level == 1){
                    waterValue = waterConsumption * paramList.get(i).getValue();
                    waterValue = Double.parseDouble(df.format(waterValue));
                    calculate =  waterConsumption + "*" + paramList.get(i).getValue();
                    break;
                }

                if(i == 0 && level > 1){
                    waterValue = waterValue + Double.parseDouble(paramList.get(i).getEnd()) * paramList.get(i).getValue();
                    calculate = calculate + "（" + paramList.get(i).getEnd() + "-" + 0 + "）* " + paramList.get(i).getValue();
                }else if(i !=level -1){
                    waterValue = waterValue + (Double.parseDouble(paramList.get(i).getEnd()) - Double.parseDouble(paramList.get(i-1).getEnd())) * paramList.get(i).getValue();
                    calculate = calculate + "+" +  "("+paramList.get(i).getEnd() + "-" + paramList.get(i-1).getEnd() +") * " + paramList.get(i).getValue();
                }else{
                    waterValue = waterValue + (waterConsumption - Double.parseDouble(paramList.get(i-1).getEnd())) * paramList.get(i).getValue();
                    calculate = calculate + "+ (" + waterConsumption + "-" + paramList.get(i-1).getEnd() +") * "+paramList.get(i).getValue();
                }
            }
        }
        map.put("waterValue",waterValue+"");
        map.put("calculate",calculate);
        return map;
    }

}
