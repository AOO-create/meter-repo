package com.constant;

import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/5/5
 */
@Data
public class PageConstant {
    private Integer limit;//页数
    private Integer page;//当前页
    private Integer currentPos;
}
