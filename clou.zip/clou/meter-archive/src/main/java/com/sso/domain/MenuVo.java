package com.sso.domain;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/21
 */
@Data
public class MenuVo {
    private Long id; //主键

    private String menuId;//菜单Id

    private String parentMenuId;//父级菜单ID

    private String icon;//菜单图标

    private String menuName;//菜单名称

    private String url;//菜单路径

    private int hasThird;//菜单是否具有子节点 1 -- 有 0 -- 无

    private int menuIndex;//菜单索引

    private List<MenuVo> childList = new ArrayList<>();//孩子节点

    private Boolean addFlag;

    private Boolean updateFlag;

    private Boolean deleteFlag;
}
