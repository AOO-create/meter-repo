package com.service.organization.impl;

import com.entity.systemSetup.Role;
import com.entity.systemSetup.User;
import com.mapper.systemSetup.UserMapper;
import com.service.organization.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/5/11
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper mapper;

    @Override
    public User getUserByNameAndPwd(Map<String, Object> pd) {
        return mapper.getUserByNameAndPwd(pd);
    }

    @Override
    public void updateLastLogin(User user) {
        mapper.updateLastLogin(user);
    }

    @Override
    public List<String> getAllResUrls() {
        return null;
    }

    @Override
    public List<String> getUserResUrls(List<Role> roleList, User user) {
        return null;
    }
}
