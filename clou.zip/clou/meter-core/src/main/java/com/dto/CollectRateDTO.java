package com.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/6/26
 */

@Data
public class CollectRateDTO {
    private String areaId;
    private String tgId;
    private String name;//区域名称
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date  collDate;
    private Integer planNum;
    private Integer collNum;
    private double failRate;
    private double succuessRate;
    private String meterType;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date startDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;


    private String meterAddress;//表地址
    private String imei;
    private String termAddress;
    private String flowSum;//采集数据
    private String flag;//采集成功标志0 成功 1 失败
    private String instAddress;//安装地址
    private String meterName;//表名称

    private List<String> areaIdList;
    private List<String> tgList;
}
