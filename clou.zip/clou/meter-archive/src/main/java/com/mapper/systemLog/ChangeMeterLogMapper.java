package com.mapper.systemLog;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.log.ChangeMeterLog;

/**
 * @author liuwei
 * @description
 * @date 2023/4/25
 */
public interface ChangeMeterLogMapper extends BaseMapper<ChangeMeterLog> {
}
