package com.websocket.configuration;
import com.alibaba.fastjson.JSONObject;
import com.websocket.service.WebSocketService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@Slf4j
public class MySubcribe implements MessageListener {

    WebSocketService webSocketService = new WebSocketService();

    @Override
    public void onMessage(Message message, byte[] pattern) {
        //JSONString数据转为JSONObject
        //        String key = new String(message.getBody());
        String method = new String(message.getChannel());
        String messageJson = message.toString().substring(7,message.toString().length());
        switch (method){
            case "changeTerm":{
                try {
                    webSocketService.sendMessage(messageJson);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
            case "channel1":
            {
                JSONObject json = JSONObject.parseObject(messageJson);
                String userName = json.getString("userName");
                System.out.println("data：{}"+messageJson);
                try {
                    WebSocketService.sendMessage(userName,messageJson);
                } catch (Exception e) {
                    log.info("消息发送失败！IO异常" + e);
                    e.printStackTrace();
                }
                break;
            }
            case "channel2":
            {
                System.out.println("data:{}"+messageJson);
                try{
                    webSocketService.sendMessage(messageJson);
                } catch (Exception e){
                    log.info("消息发送失败！IO异常" + e);
                    e.printStackTrace();
                }
                break;
            }
        }

    }

}
