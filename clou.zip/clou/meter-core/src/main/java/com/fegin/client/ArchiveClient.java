package com.fegin.client;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import com.dto.equipment.*;
import com.entity.Org;
import com.pojo.Role;
import com.pojo.User;
import com.vo.analysisDataVo.CollectMeterVo;
import com.vo.excelOpVo.ExportExcelParamsVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;
import java.util.Map;


@FeignClient(name = "archive-provider", url = "${service-url.archive-provider}")
public interface ArchiveClient {
    @RequestMapping("/archive/ToCollect/getRole")
    public Role getRole();

    @RequestMapping("/archive/ToCollect/getUser")
    public User getUser();

    @RequestMapping("/archive/ToCollect/getOrg")
    public Org getOrg();

    @RequestMapping("/archive/ToCollect/getTgId")
    public String getTgId();

    @RequestMapping("/archive/ToCollect/getAreaId")
    public String getAreaId();

    @RequestMapping("/archive/ToCollect/ExcelDayDataIn")
    public void ExcelDayDataIn(@RequestBody Map<String,Object> map);

    @RequestMapping("/archive/ToCollect/ExcelTermIn")
    public Result ExcelTermIn(@RequestBody List<TermDTO> list);

    @RequestMapping("/archive/ToCollect/ExcelWiredIn")
    public Result  ExcelWiredIn(@RequestBody List<WiredMeterDTO> list);

    @RequestMapping("/archive/ToCollect/ExcelNBIn")
    public Result ExcelNBIn(@RequestBody List<NBDTO> list) throws Exception;

    @RequestMapping("/archive/ToCollect/ExcelNBProductIn")
    public Result ExcelNBProductIn(@RequestBody List<NBDTO> list) throws Exception;

    @RequestMapping("/archive/ToCollect/ternalfileList")
    @ResponseBody
    public Page<TermDTO> getTerm(@RequestBody TermDTO dto);

    @PostMapping("/archive/ToCollect/getMeter")
    @ResponseBody
    public Page<WiredMeterDTO> getMeter(@RequestBody WiredMeterDTO dto);

    @PostMapping("/archive/ToCollect/getAllDayData")
    @ResponseBody
    public Map<String, Page<MeterDayDataDTO>> getAllDayData(@RequestBody MeterDayDataDTO dto) throws ParseException;

    @RequestMapping("/archive/ToCollect/getWiredExportData")
    List<MeterDayDataDTO> getWiredExportData(@RequestBody ExportExcelParamsVo exportExcelParams);

    @RequestMapping("/archive/grade/reGetChildBDGradeId")
    public List<String> reGetChildBDGradeId(@RequestParam(value = "tgBuildDoorplate") String tgBuildDoorplate, @RequestParam(value = "orgId") String orgId);

    @RequestMapping("/archive/grade/reGetChildGradeId")
    public List<String> reGetChildGradeId(@RequestParam(value = "areaId") String areaId, @RequestParam(value = "orgId") String orgId);

    @RequestMapping("/archive/ToCollect/getGradeNameById")
    String getGradeNameById(@RequestParam(value = "id") String id);

    @RequestMapping("/archive/ToCollect/getBDGradeNameById")
    String getBDGradeNameById(@RequestParam(value = "id") String id);

    @RequestMapping("/archive/ToCollect/getCL6904PapR")
    List<WiredMeterDTO> getCL6904PapR(@RequestParam(value = "id")String id , @RequestParam(value = "date") String dateString
            , @RequestParam(value = "currentPos") String currentPos, @RequestParam(value = "limit") String limit);

    @RequestMapping("/archive/ToCollect/getReportCl6904")
    int getReportCl6904(@RequestBody MeterDayDataDTO dto);

    @RequestMapping("/archive/ToCollect/getPapR")
    MeterDayDataDTO getPapR(@RequestParam("id") String id,@RequestParam("date") String date);

    @RequestMapping("/archive/ToCollect/getCL6904NoReport")
    List<CollectMeterVo> getCL6904NoReport(MeterDayDataDTO dayDataDTO);

    @RequestMapping("/archive/dataView/getDataByDay")
    Page<MeterDayVo> getDataByDay(MeterDayVo meterDayVo);
    @RequestMapping("/archive/dataView/getIncDataByDay")
    Page<MeterDayVo> getIncDataByDay(MeterDayVo meterDayVo);
}
