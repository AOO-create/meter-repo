package com.dto.equipment;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2023/2/2
 */
@Data
public class StatisticsDataDTO {
    private String areaName;
    private String areaId;
    private String tgBuildDoorplate;
    private String deviceNum;
    private String dateSum ;
    private String nbSum;
}
