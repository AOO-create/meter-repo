package com.mapper.systemSetup;

import com.entity.systemSetup.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/5/11
 */
public interface UserMapper extends BaseMapper<User>{
    User getUserByNameAndPwd(@Param("pd") Map<String, Object> pd);

    void updateLastLogin(@Param("user") User user);

    void updatePassword(@Param("password") String newPassword);
}
