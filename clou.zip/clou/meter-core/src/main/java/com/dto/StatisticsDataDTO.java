package com.dto;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2023/2/2
 */
@Data
public class StatisticsDataDTO {
    private String areaName;
    private String deviceNum;
    private String dateSum ;
}
