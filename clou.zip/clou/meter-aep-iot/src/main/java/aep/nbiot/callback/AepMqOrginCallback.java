package aep.nbiot.callback;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AER MQ回调函数
 * @date 2021/11/19 8:26
 */
public interface AepMqOrginCallback {

    /***
     * 监听MQ消息回调方法
     * @param msg
     */
    public void listener(String msg);

}
