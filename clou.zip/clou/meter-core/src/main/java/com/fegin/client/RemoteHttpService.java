package com.fegin.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "remote-http-provider", url = "${service-url.remote-http-provider}")
public interface RemoteHttpService {
    @GetMapping("/remoteHttp/queryMeter")
    public void receiveCtHttp() throws Exception ;

    @GetMapping("/remoteHttp/queryMeterData")
    public void queryMeterData() throws Exception ;
}
