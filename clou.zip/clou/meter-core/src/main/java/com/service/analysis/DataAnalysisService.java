package com.service.analysis;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.vo.analysisDataVo.CollectMeterVo;
import com.vo.analysisDataVo.MeterVo;
import com.vo.analysisDataVo.NbDataVo;

import java.text.ParseException;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/11/2
 */
public interface DataAnalysisService {
    MeterVo predictionData(MeterVo vo);

    CollectMeterVo predictRateAndGetNoReport(CollectMeterVo vo) throws ParseException;

    NbDataVo signalWarning(NbDataVo vo);

    CollectMeterVo collectionFailed(CollectMeterVo vo);

    Page<CollectMeterVo> getAllMeterOnArea(CollectMeterVo vo);

    CollectMeterVo getCatastrophe(CollectMeterVo vo) ;
}
