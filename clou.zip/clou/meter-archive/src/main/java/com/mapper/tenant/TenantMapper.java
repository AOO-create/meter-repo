package com.mapper.tenant;

import com.dto.equipment.MeterDayDataDTO;
import com.entity.tenant.Tenant;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author liuwei
 * @description
 * @date 2022/7/26
 */
public interface TenantMapper extends BaseMapper<Tenant> {
    MeterDayDataDTO getNBDay(@Param("imei") String imei , @Param("monthDate") String monthDate);

    MeterDayDataDTO getWiredDay(@Param("meterAddress") String meterAddress,@Param("termAddress") String termAddress,@Param("monthDate") String monthDate);

    MeterDayDataDTO getFourthDay(@Param("meterAddress") String meterAddress,@Param("monthDate") String monthDate);
}
