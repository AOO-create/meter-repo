package aep.nbiot.strategy.aepdevicemanage;

import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.util.ParamsUtil;
import com.ctg.ag.sdk.biz.AepDeviceManagementClient;
import com.ctg.ag.sdk.biz.aep_device_management.ListDeviceInfoRequest;
import com.ctg.ag.sdk.biz.aep_device_management.QueryDeviceListRequest;
import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 根据设备ID列表查询设备信息
 * @date 2021/11/17 8:03
 */
public class ListDeviceInfoStrategy implements IAepStrategy {

    @Override
    public BaseApiResponse invockApi(BaseApiClient _client, HashMap<String,Object> params, HashMap<String,Object> body) {
        try {
            ParamsUtil paramsUtil = new ParamsUtil(new QueryDeviceListRequest());
            ListDeviceInfoRequest request = (ListDeviceInfoRequest) paramsUtil.addParams(params,body);
            AepDeviceManagementClient client = (AepDeviceManagementClient)_client;
            return client.ListDeviceInfo(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
