package com.service;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.vo.SystemLogVo.OperateMeterLogVO;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
public interface MeterOperateLogService {
    Page<OperateMeterLogVO> getLog(OperateMeterLogVO dto);
}
