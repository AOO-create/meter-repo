package com.controller.systemSetup;

import com.entity.systemSetup.Menu;
import com.entity.systemSetup.Role;
import com.service.systemSetup.MenuManagerService;
import com.service.systemSetup.RoleMenuRelationService;
import com.vo.systemSetUpVo.MenuVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2022/6/28
 */
@RestController
@RequestMapping("/archive/menu")
public class MenuController {

    @Autowired
    private MenuManagerService menuManagerService;

    @Autowired
    private RoleMenuRelationService roleMenuRelationService;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @GetMapping("getAllMenu")
    @ResponseBody
    public MenuVo getAllMenu(@RequestBody Role role){
        return menuManagerService.getAllMenu(role);
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @GetMapping("getCurrentUserMenu")
    @ResponseBody
    public List<String> getCurrentUserMenu(){
        return menuManagerService.getCurrentUserMenu();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getParentMenu")
    @ResponseBody
    public List<Menu> getParentMenu(){
        return menuManagerService.getParentMenu();
    }




}

