package com.service.cl6904;

import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.WiredMeterDTO;
import com.vo.equipment.CollectMeterVo;

import java.util.List;

public interface CL6904Service {
    List<WiredMeterDTO> getCL6904PapR(String id, String date, String currentPos, String limit);

    int getReportCl6904(String date, String id, List<String> bdIds);

    MeterDayDataDTO getPapR(String id, String date);

    List<CollectMeterVo> getCL6904NoReport(MeterDayDataDTO dayDataDTO);
}
