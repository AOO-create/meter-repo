package com.service.tenant.Impl;

import com.common.Const;
import com.entity.User;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.systemSetup.UserMapper;
import com.mapper.tenant.TenantBuildRelaMapper;
import com.mapper.tenant.TenantMapper;
import com.entity.Org;
import com.entity.tenant.Tenant;
import com.entity.tenant.TenantBuildRela;
import com.service.organization.impl.GradeServiceImpl;
import com.service.tenant.TenantService;
import com.util.ShiroConstUtils;
import com.vo.tenant.TenantVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.ApiException;
import com.common.ResultCodeEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/7/26
 */
@Service
public class TenantServiceImpl implements TenantService {

    @Autowired
    private TenantMapper mapper;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TenantBuildRelaMapper tenantBuildRelaMapper;

    @Autowired
    private GradeServiceImpl gradeService;

    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public Page<TenantVo> getAllTenant(TenantVo vo) {
        Page<TenantVo> page = new Page<>();
        //当前的areaId为空bdId为空，分页查询所有的租户
        if(vo.getTgBuildDoorplate() == null && vo.getAreaId() != null){
             page = readTenant(vo,"1");
        }

        if(vo.getTgBuildDoorplate() == null && vo.getAreaId() == null){
             page = readTenant(vo,"0");
        }
        if(vo.getTgBuildDoorplate() != null) {
            page = readTenant(vo,"2");
        }
        return page;
    }

    @Transactional
    @Override
    public Boolean tenantSave(TenantVo vo) {
        String user = Const.userId;
        Org org = shiroConstUtils.getOrg();
        int count = 0;
        String mobile = vo.getMobile();


        if(null == vo.getId() || vo.getId() == 0){
            Tenant tenant1 = mapper.selectOne(new QueryWrapper<Tenant>().eq("mobile",mobile));
            if(null != tenant1){
                //已经存在了该用户,不走下面的新增了，只添加关系
                TenantBuildRela tenantBuildRela = new TenantBuildRela();
                tenantBuildRela.setTenantId(tenant1.getId());
                tenantBuildRela.setTgBuildDoorplate(vo.getTgBuildDoorplate());
                tenantBuildRelaMapper.insert(tenantBuildRela);
            }else{
                //新增
                Tenant tenant = new Tenant();
                tenant.setAreaId(vo.getAreaId());
                tenant.setCreateTime(new Date());
                tenant.setOpera(Long.valueOf(user));
                tenant.setMobile(vo.getMobile());
                tenant.setOrgId(Long.valueOf(org.getOrgId()));
                tenant.setName(vo.getName());
                tenant.setSex(vo.getSex());
                tenant.setBalance(vo.getBalance());
                if(vo.getBalance() > 0){
                    tenant.setStatus("1");
                }else{
                    tenant.setStatus("0");
                }
                tenant.setWxNumber(vo.getWxNumber());
                tenant.setTgBuildDoorplate(vo.getTgBuildDoorplate());
                count = mapper.insert(tenant);
                //添加到关系上
                TenantBuildRela tenantBuildRela = new TenantBuildRela();
                tenantBuildRela.setTenantId(tenant.getId());
                tenantBuildRela.setTgBuildDoorplate(vo.getTgBuildDoorplate());
                tenantBuildRelaMapper.insert(tenantBuildRela);
                int countTwo = mapper.selectCount(new QueryWrapper<Tenant>().eq("tg_build_doorplate",vo.getTgBuildDoorplate()));
                if(countTwo > 1){
                    throw new ApiException(ResultCodeEnum.SAVE_TENANT_ERROR);
                }
            }
        }else{
            //修改
            Tenant tenant = new Tenant();
            tenant.setId(vo.getId());
            tenant.setCreateTime(new Date());
            tenant.setOpera(Long.valueOf(user));
            tenant.setMobile(vo.getMobile());
            tenant.setOrgId(Long.valueOf(org.getOrgId()));
            tenant.setName(vo.getName());
            tenant.setSex(vo.getSex());
            tenant.setWxNumber(vo.getWxNumber());
            count = mapper.updateById(tenant);
        }
        if(count == 0){
            throw new ApiException(ResultCodeEnum.SAVE_TENANT_ERROR);
        }
        return true;
    }

    @Transactional
    @Override
    public Boolean deleteTenant(String id) {
        int count = mapper.deleteById(id);
        tenantBuildRelaMapper.delete(new QueryWrapper<TenantBuildRela>().eq("tenant_id",id));
        return count > 0;
    }

    @Transactional
    @Override
    public Boolean batchDeleteTenant(List<String> ids) {
        int count = mapper.deleteBatchIds(ids);
        tenantBuildRelaMapper.delete(new QueryWrapper<TenantBuildRela>().in("tenant_id",ids));
        return count > 0;
    }

    @Override
    public Page<TenantVo> getTenantByAreaId(TenantVo vo) {
        return readTenant(vo,"1");
    }

    @Override
    public Page<TenantVo> getTenantBybdId(TenantVo vo) {
        return readTenant(vo,"2");
    }

    private Page<TenantVo> readTenant(TenantVo  vo,String type){
        Org org = shiroConstUtils.getOrg();
        Page<Tenant> page = new Page<>(vo.getPage(),vo.getLimit());
        QueryWrapper<Tenant> qw = new QueryWrapper<>();
        List<String> bdId = new ArrayList<>();
        if(null !=vo.getName() && !vo.getName().equals("")){
            qw.like("name",vo.getName());
        }
        if(null != vo.getMobile() && !vo.getMobile().equals("")){
            //查找ID
            qw.eq("mobile",vo.getMobile());
        }

        qw.eq("org_id",org.getOrgId());
        if(type.equals("1")){
            //点击树组织区域
            qw.eq("area_id",vo.getAreaId());
        }else if(type.equals("2")){
            //点击树门东单元
            bdId = gradeService.reGetChildBDGradeId(vo.getTgBuildDoorplate()+"",org.getOrgId(),new ArrayList<>());
            qw.in("tg_build_doorplate", bdId);
        }else if(type.equals("0")){
            if(!shiroConstUtils.getRole().getRoleCode().equals("admin")&&shiroConstUtils.getTgBuildDoorplate() != null && !shiroConstUtils.getTgBuildDoorplate().equals("")){
                bdId = gradeService.reGetChildBDGradeId(vo.getTgBuildDoorplate()+"",org.getOrgId(),new ArrayList<>());
                qw.in("tg_build_doorplate", bdId);
            }else if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
                qw.eq("area_id",shiroConstUtils.getAreaId());
            }
        }

        page = mapper.selectPage(page,qw);

        Page<TenantVo> voPage = new Page<>(vo.getPage(),vo.getLimit());
        voPage.setPages(page.getPages());
        voPage.setCurrent(page.getCurrent());
        voPage.setSize(page.getSize());
        voPage.setTotal(page.getTotal());
        List<TenantVo> list = new ArrayList<>();
        for(Tenant tenant : page.getRecords()){
            TenantVo vo1 = new TenantVo();
            BeanUtils.copyProperties(tenant,vo1);
            String areaName = gradeMapper.selectById(tenant.getAreaId()).getAreaName();
            String bdName = bdGradeMapper.selectById(tenant.getTgBuildDoorplate()).getBdName();
            String operaName = userMapper.selectById(tenant.getOpera()).getName();
            vo1.setAreaName(areaName);
            vo1.setBdName(bdName);
            vo1.setOperaName(operaName);
            list.add(vo1);
        }
        voPage.setRecords(list);
        return voPage;
    }
}
