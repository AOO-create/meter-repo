package com.controller.dataView;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dto.dataView.CommonMapDTO;
import com.dto.dataView.MeterPapR;
import com.dto.equipment.MeterHourVo;
import com.dto.equipment.MeterDayVo;
import com.dto.equipment.MeterMonthVo;
import com.entity.organization.BDGrade;
import com.service.dataView.DataViewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/dataView")
public class DataViewController {

    @Autowired
    private DataViewService service;

    @Autowired
    private com.service.dataView.DoorService doorService;


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getDataByDay")
    public IPage<MeterDayVo> getDataByDay(@RequestBody MeterDayVo meterDayVo){

        return service.getDataByDay(meterDayVo);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("selectSumHourByAreaId")
    public IPage<MeterDayVo> selectSumHourByAreaId(@RequestBody MeterDayVo meterDayVo){

        return service.selectSumHourByAreaId(meterDayVo);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getIncDataByDay")
    public IPage<MeterDayVo> getIncDataByDay(@RequestBody MeterDayVo meterDayVo){

        return service.getIncDataByDay(meterDayVo);
    }
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getSevenDataByDay")
    public IPage<MeterDayVo> getSevenDataByDay(@RequestBody MeterDayVo meterDayVo){

        return service.getSevenDataByDay(meterDayVo);
    }
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getDataByHour")
    public IPage<MeterHourVo> getDataByHour(@RequestBody MeterDayVo meterDayVo){
        return service.getDataByHour(meterDayVo);
    }
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getTfourByHour")
    public IPage<MeterHourVo> getTfourByHour(@RequestBody MeterDayVo meterDayVo){
        return service.getTfourByHour(meterDayVo);
    }

//    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getPageByMonth")
    @ResponseBody
    public IPage<MeterMonthVo> getDataByMonth(@RequestBody MeterMonthVo dto){
        return service.getDataByMonth(dto);
    }

    @RequestMapping("/getDoorById")
    public List<BDGrade>  getDoorById(){
        List<BDGrade> list = new ArrayList<BDGrade>();
        Long id = 1732581861462405122L;
        return doorService.getDoorById(list,id);
    }
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getTitleNumber")
    public List<Double[]> getTitleNumber(){
        return service.getTitleNumber();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getAreaTenantNumber")
    public List<CommonMapDTO> getAreaTenantNumber(){
        return service.getAreaTenantNumber();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getCollectRate")
    public List<Double> getCollectRate(){
        return service.getCollectRate();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getRecordOperate")
    public List<int[]> getRecordOperate(){
        return service.getRecordOperate();
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getAreaMeter")
    public List<CommonMapDTO> getAreaMeter(){
        return service.getAreaMeter();
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getReportRate")
    public List<CommonMapDTO> getReportRate(){
        return service.getReportRate();
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getRateData")
    public CommonMapDTO getRateData(){
        return service.getRateData();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getDosage")
    public CommonMapDTO getDosage() {
        return service.getDosage();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER" +
            ""})
    @RequestMapping("/searchData")
    public List<MeterDayVo> searchData(@RequestBody MeterDayVo dto) {
        return service.searchData(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/searchHourData")
    public List<MeterDayVo> searchHourData(@RequestBody MeterDayVo dto) {
        return service.searchHourData(dto);
    }
}
