package com.mapper.analysis;


import com.dto.BDGradeDTO;
import com.dto.GradeDTO;
import com.vo.analysisDataVo.CollectMeterVo;
import com.vo.analysisDataVo.MeterVo;
import com.vo.analysisDataVo.NbDataVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/11/2
 */
public interface DataAnalysisMapper {

    String getNowDayDataNB(@Param("vo")MeterVo vo);

    String getYesDayDataNB(@Param("vo")MeterVo vo);

    String getMonthDataNB(@Param("vo")MeterVo vo,@Param("monthDate") String monthDate);

    String getYearDataNB(@Param("vo")MeterVo vo,@Param("yearDate") String yearDate);

    String getNowDayDataWired(@Param("vo")MeterVo vo);

    String getYesDayDataWired(@Param("vo")MeterVo vo);

    String getMonthDataWired(@Param("vo")MeterVo vo,@Param("monthDate") String monthDate);

    String getYearDataWired(@Param("vo")MeterVo vo,@Param("yearDate") String yearDate);

    String getLastDayDataNB(@Param("vo") MeterVo vo);

    String getLastDayDataWired(@Param("vo") MeterVo vo);

    String getFlowByDateNB(@Param("imei") String imei,@Param("date") String date);

    String getFlowByDateWired(@Param("meterAddress") String meterAddress,@Param("termId") String termId,@Param("date")String date);

    List<CollectMeterVo> getNoReportMeterNB(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList,
                                            @Param("date")String date);

    int getSumNB(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList);

    List<CollectMeterVo> getNoReportMeterWired(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList,
                                               @Param("meterType") String meterType,@Param("date")String date);

    int getSumWired(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList,@Param("meterType")String meterType);

    int getReportNB(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList,@Param("date") String dd);

    int getReportWired(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList,@Param("date") String dd,@Param("meterType") String meterType);

    int getReportSum(@Param("areaId") String areaId,@Param("bdIds") List<String> bdIdList,@Param("date") String dd);

    List<CollectMeterVo> getNbByAreaIdAndTgId(@Param("areaId") String areaId,@Param("bdIds") List<String> s);

    List<NbDataVo> getNbReportByAreaIdAndTgId(@Param("areaId") String areaId,@Param("bdIds") List<String> s,@Param("date") String date);

    List<NbDataVo> getNbNoReportByAreaIdAndTgId(@Param("areaId") String areaId,@Param("bdIds") List<String> s,
                                                @Param("date") String date);

    CollectMeterVo getReportDataWired(@Param("meterAddress") String meterAddress,@Param("termId") String termId);

    CollectMeterVo getReportDataNB(@Param("imei") String imei);

    List<GradeDTO> getAllGrade(@Param("orgId") String orgId);

    List<BDGradeDTO> getAllBDGradeByAreaId(@Param("areaId") String areaId);

    List<BDGradeDTO> getSonBDGrade(@Param("tgId") String tgId);

    List<CollectMeterVo> getWiredMeter(@Param("vo") CollectMeterVo vo,@Param("bdIds") List<String> bdIds);

    List<CollectMeterVo> getNBMeter(@Param("vo") CollectMeterVo vo,@Param("bdIds") List<String> bdIds);

    int getWiredMeterCount(@Param("vo") CollectMeterVo vo,@Param("bdIds") List<String> bdIds);

    int getNBMeterCount(@Param("vo") CollectMeterVo vo,@Param("bdIds") List<String> bdIds);

    List<MeterVo> getNBHalfYearData(@Param("imei") String imei);

    List<MeterVo> getWiredHalfYearData(@Param("meterAddress") String meterAddress,@Param("termAddress") String termId);
}
