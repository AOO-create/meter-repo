package com.mapper.area;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.area.Grade;


/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface GradeMapper extends BaseMapper<Grade> {

}
