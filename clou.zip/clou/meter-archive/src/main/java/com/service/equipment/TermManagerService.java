package com.service.equipment;

import com.common.Result;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.log.ChangeTermLog;
import com.entity.equipment.Term;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
public interface TermManagerService {
    List<Term> getTermData(String areaId);

    String termSave(TermDTO dto);

    Page<TermDTO> getTerm(TermDTO dto);

    Page<WiredMeterDTO> getMeter(WiredMeterDTO assetNo);

    boolean validAddress(TermDTO dto);

    List<TermDTO> getTermByAreaId(String areaId);

    Result  ExcelTermIn(List<TermDTO> list) throws Exception;

    Result deleteTerm(String terminalId);

    String getAreaIdByTermId(String id);

    Result changeTermStatus(String terminalId);

    Result changeTerm(TermDTO dto);

    Result getChangeTermLog(ChangeTermLog log);

    Result batchDeleteTerm(List<String> idList);
}
