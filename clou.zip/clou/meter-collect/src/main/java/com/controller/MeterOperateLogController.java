package com.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.service.MeterOperateLogService;
import com.vo.SystemLogVo.OperateMeterLogVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/collect/systemLog")
public class MeterOperateLogController {
    @Autowired
    private MeterOperateLogService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/meterOp/getLog")
    @ResponseBody
    public Page<OperateMeterLogVO> getLog(@RequestBody OperateMeterLogVO dto) {
        return service.getLog(dto);
    }

}
