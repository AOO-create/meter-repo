package com.dto.organization;

import com.common.PageConstant;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/28
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class GradeDTO extends PageConstant {
    private String id;
    private String areaNo;
    private String areaName;
    private String orgId;
    private String parentId;
    private String email;
    private String remark;

    private Date updTime;
    private List<String> gradeIdList;
    private String parentName;
}
