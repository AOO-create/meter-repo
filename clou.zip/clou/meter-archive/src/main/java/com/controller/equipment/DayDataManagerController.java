package com.controller.equipment;

import com.dto.equipment.MeterDayDataDTO;
import com.service.equipment.DayDataManagerService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/6/8
 */
@RestController
@RequestMapping("/archive/equipment/dayData")
public class DayDataManagerController {
    @Autowired
    private DayDataManagerService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getAllDayData")
    @ResponseBody
    public Map<String, Page<MeterDayDataDTO>> getAllDayData(@RequestBody MeterDayDataDTO dto) throws ParseException {
        return service.getAllDayData(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getDataByDay")
    @ResponseBody
    public Page<MeterDayDataDTO> getDataByDay(@RequestBody MeterDayDataDTO dto){
        return service.getDataByDay(dto);
    }

}
