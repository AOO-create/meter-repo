package com.dto.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.entity.WiredMeterMonthRead;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class MeterMonthVo  {

    private String meterAddress;

    private String name;

    private String instLoc;

    private Date instTime;

    /****
     * 表具类型 0：冷水水表 1：生活热水水表 2：直饮水水表 3：中水水表 4：电表
     */
    private String meterType;

    private String channel;

    private String uartbps;

    private String termId;
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    private String protocol;

    private String orgId;
    //    组织区域ID
    private String areaId;
    //    小区楼栋ID
    private String tgBuildDoorplate;
    private Integer pn;

    private String dataDate;
    private Date collTime;
    private String bdName;
    private Integer page;
    private Integer limit;
    private BigDecimal fee1;
    private BigDecimal fee2;
    private BigDecimal fee3;
    private BigDecimal fee4;
    private BigDecimal realSumFlow;
}
