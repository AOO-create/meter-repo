package com.mapper.equipment;


import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
public interface DayDataManagerMapper{

    List<MeterDayDataDTO> oldWaterDayData(@Param("dto") MeterDayDataDTO dto, @Param("ids") List<String> idList, @Param("date") String date);

    int getOldDataCount(@Param("dto") MeterDayDataDTO dto,@Param("ids") List<String> idList,@Param("date") String date);

    void BatchInsertNB(@Param("list") List<MeterDayDataDTO> list);

    void BatchInsertWired(@Param("list") List<MeterDayDataDTO> list);

    List<NBDTO> getDataByDay(@Param("dto") NBDTO nbdto);

    int getDataByDayCount(@Param("dto") NBDTO nbdto);

    List<MeterDayDataDTO> warningDayData(@Param("startTime") String startTime,@Param("endTime") String endTime);
}
