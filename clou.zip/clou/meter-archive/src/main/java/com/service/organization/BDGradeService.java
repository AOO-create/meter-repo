package com.service.organization;

import com.dto.organization.BDGradeDTO;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface BDGradeService {
    Page<BDGradeDTO> findBDGrade(BDGradeDTO dto);


    boolean saveBDGrade(BDGradeDTO dto);

    boolean updateBDGrade(BDGradeDTO dto);

    boolean deleteBDGrade(String id);

    boolean deleteAllBD(List<String> ids);

    List<BDGradeDTO> getBDGradeToSel( BDGradeDTO dto);

    String getBDGradeNameById(String id);
}
