package com.controller.analysisData;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.service.analysis.DataAnalysisService;
import com.vo.analysisDataVo.MeterVo;
import com.vo.analysisDataVo.CollectMeterVo;
import com.vo.analysisDataVo.NbDataVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;


/**
 * @author liuwei
 * @用量趋势分析
 * @date 2023/11/2 
 */
@RestController
@RequestMapping("/core/analysis")
public class DataAnalysisController {

    @Autowired
    private DataAnalysisService service;

    @RequestMapping("/predictionData")
    public MeterVo predictionData(@RequestBody MeterVo vo){
        return service.predictionData(vo);
    }

    @RequestMapping("/predictRateAndGetNoReport")
    public CollectMeterVo predictRateAndGetNoReport(@RequestBody CollectMeterVo vo) throws ParseException {
        return service.predictRateAndGetNoReport(vo);
    }

    @RequestMapping("/signalWarning")
    public NbDataVo signalWarning(@RequestBody NbDataVo vo){
        return service.signalWarning(vo);
    }

    @RequestMapping("/collectionFailed")
    public CollectMeterVo collectionFailed(@RequestBody CollectMeterVo vo){
        return service.collectionFailed(vo);
    }

    @RequestMapping("getAllMeterOnArea")
    public Page<CollectMeterVo> getAllMeterOnArea(@RequestBody CollectMeterVo vo){
        return service.getAllMeterOnArea(vo);
    }

    @RequestMapping("getCatastrophe")
    public CollectMeterVo getCatastrophe(@RequestBody CollectMeterVo vo){
        return service.getCatastrophe(vo);
    }


}
