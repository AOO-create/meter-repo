package com.controller.organization;

import com.dto.organization.BuildDTO;
import com.dto.organization.GradeDTO;
import com.entity.TreeData;
import com.service.organization.GradeService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/grade")
public class GradeController {

    @Autowired
    private GradeService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getGradePage")
    @ResponseBody
    public Page<GradeDTO> findGrade(@RequestBody GradeDTO dto){
        return service.findGrade(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getSonBuild")
    @ResponseBody
    public Page<BuildDTO> getSonBuild(@RequestBody BuildDTO dto){
        return service.getSonBuild(dto);
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/saveOrUpdateGrade")
    @ResponseBody
    public boolean saveOrUpdateGrade(@RequestBody BuildDTO dto) {
        return service.saveOrUpdateGrade(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/deleteGrade")
    @ResponseBody
    public boolean deleteGrade(@RequestBody BuildDTO dto) {
        return service.deleteGrade(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/deleteAll")
    @ResponseBody
    public boolean deleteAll(@RequestBody List<BuildDTO> list) {
        return service.deleteAll(list);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getGradeToSel")
    @ResponseBody
    public List<GradeDTO> getGradeToSel(@RequestParam("id") String id){
        return service.getGradeToSel(id);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("isHaveGrade")
    @ResponseBody
    public boolean isHaveGrade(@RequestBody String account){
        return service.isHaveGrade(account);
    }

    //暂未用
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getTreeData")
    @ResponseBody
    public List<TreeData> getTreeData(){
        return service.getTreeData();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getAllArea")
    @ResponseBody
    public List<TreeData> getAllArea(){
        return service.getAllArea();
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("getTreeByTermId")
    @ResponseBody
    public List<TreeData> getTreeByTermId(@RequestParam("termId") String termId){
        return service.getTreeByTermId(termId);
    }


    @RequestMapping("findBdGradeByAreaId")
    @ResponseBody
    public  List<TreeData> findBdGradeByAreaId(@RequestParam("areaId") String areaId){
        return service.findBdGradeByAreaId(areaId);
    }

    @RequestMapping("findBdGradeByBdId")
    @ResponseBody
    public  List<TreeData> findBdGradeByBdId(@RequestParam("id") String bdId){
        return service.findBdGradeByBdId(bdId);
    }

    @RequestMapping("reGetChildGradeId")
    @ResponseBody
    public List<String> reGetChildGradeId(@RequestParam("areaId") String areaId,@RequestParam("orgId") String orgId){
        List<String> tempList = new ArrayList<>();
        return service.reGetChildGradeId(areaId,orgId,tempList);
    }

    @RequestMapping("reGetChildBDGradeId")
    @ResponseBody
    public List<String> reGetChildBDGradeId(@RequestParam("tgBuildDoorplate") String tgId,@RequestParam("orgId") String orgId){
        List<String> tempList = new ArrayList<>();
        return service.reGetChildBDGradeId(tgId,orgId,tempList);
    }

}
