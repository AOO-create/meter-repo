package com.service.organization.impl;

import com.dto.organization.BDGradeDTO;
import com.mapper.cons.ConsMapper;
import com.mapper.equipment.MeterMapper;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.WaterMeterMapper;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.OrgMapper;
import com.entity.organization.BDGrade;
import com.entity.Org;
import com.service.organization.BDGradeService;
import com.util.ShiroConstUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Service
public class BDGradeServiceImpl implements BDGradeService {

    @Autowired
    private BDGradeMapper mapper;

    @Autowired
    private ConsMapper consMapper;

    @Autowired
    private MeterMapper meterMapper;

    @Autowired
    private WaterMeterMapper waterMeterMapper;

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private OrgMapper orgMapper;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public Page<BDGradeDTO> findBDGrade(BDGradeDTO dto) {
        Page<BDGradeDTO> page = new Page<>();
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        List<BDGradeDTO> list = mapper.getAllBDGradeByAreaId(dto);

        int number = mapper.getBDGradeNumber(dto);

        //查看是否存在表，如果存在添加上不可删除，修改标志
        for(BDGradeDTO bdGradedto : list){
            bdGradedto.setDeleteFlag(true);

            //查看集中器，查看有线表待添加

            //首先查看水表：
            int wCount = waterMeterMapper.findCountByBDGradeId(bdGradedto.getId());
            if(wCount > 0){
                bdGradedto.setDeleteFlag(false);
                continue;
            }
            //NB水表
            int NBCount = nBmeterMapper.findCountByBDGradeId(bdGradedto.getId());
            if(NBCount > 0){
                bdGradedto.setDeleteFlag(false);
                continue;
            }
            //电表
            int mCount = meterMapper.findCountByBDGradeId(bdGradedto.getId());
            if(mCount > 0){
                bdGradedto.setDeleteFlag(false);
                continue;
            }
            //用户
            int cCount = consMapper.findCountByBDGradeId(bdGradedto.getId());
            if(cCount > 0){
                bdGradedto.setDeleteFlag(false);
                continue;
            }

            int childCount = mapper.selectCount(new QueryWrapper<BDGrade>().eq("parent_id",bdGradedto.getId()));
//                    mapper.haveChild(bdGradedto.getId());
            if(childCount > 0){
                bdGradedto.setDeleteFlag(false);
            }
        }

        if(null != list && list.size() != 0 ){
            page.setRecords(list);
            page.setTotal(number);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    /**
       * 新增小区楼栋，在新增的时候需要判断是否是子小区楼栋，父需要进行不可删除标志
       * @author liuwei
       * @date  2022/5/10
       * @param
       * @return
     */
    @Override
    public boolean saveBDGrade(BDGradeDTO dto) {
        Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());
        dto.setUpdTime(new Date());
        BDGrade grade = new BDGrade();
        BeanUtils.copyProperties(dto,grade);

        int result = mapper.insert(grade);
//                mapper.saveBDGrade(dto);
        return result > 0 ;
    }

    @Override
    public boolean updateBDGrade(BDGradeDTO dto) {
        BDGrade grade = new BDGrade();
        BeanUtils.copyProperties(dto,grade);
        grade.setId(Long.valueOf(dto.getId()));
        grade.setParentId(Long.valueOf(dto.getParentId()));
        int result = mapper.updateById(grade);
//                mapper.updateBDGrade(dto);
        return result > 0;
    }

    @Override
    public boolean deleteBDGrade(String id){
        int result = mapper.deleteById(id);
//                deleteBDGrade(id);
        return result > 0;
    }

    @Override
    public boolean deleteAllBD(List<String> ids){
        return mapper.deleteBatchIds(ids) > 0;
//                deteteAllBD(ids) > 0;
    }

    @Override
    public List<BDGradeDTO> getBDGradeToSel(BDGradeDTO dto) {
        Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());
        List<BDGradeDTO> list = mapper.getBDGradeToSel(dto);
        return list;
    }

    @Override
    public String getBDGradeNameById(String id) {
        return mapper.selectById(id).getBdName();
    }

}
