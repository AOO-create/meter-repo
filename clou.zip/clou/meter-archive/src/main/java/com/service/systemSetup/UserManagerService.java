package com.service.systemSetup;

import com.entity.systemSetup.Role;
import com.vo.systemSetUpVo.UserVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/27
 */
public interface UserManagerService {
    Page<UserVo> findAllUser(UserVo user);

    Result addUser(UserVo user);

    Result updateUser(UserVo user);

    Result deleteUser(String id);

    Result batchDelUser(List<String> ids);

    boolean updatePassword(String id,String pass,String updatePassword);

    List<Role> getRoleToSel();

    Page<UserVo> getUserListByRole(UserVo vo);
}
