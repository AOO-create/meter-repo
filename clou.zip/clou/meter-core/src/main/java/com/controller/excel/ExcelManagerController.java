package com.controller.excel;

import com.alibaba.fastjson.JSON;
import com.fegin.client.ArchiveClient;
import com.common.ApiException;
import com.common.Const;
import com.common.Result;
import com.common.ResultCodeEnum;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.service.excel.ExcelManagerService;
import com.utils.PoiUtils;
import com.vo.excelOpVo.ExportExcelParamsVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/core/excelManager")
public class ExcelManagerController {

    @Autowired
    private ExcelManagerService service;

    @Autowired
    private ArchiveClient archiveClient;

    @Value("${download.url}")
    private String basePath;

    private static String addHexMeterAddress(String meterAddress) {
        char[] charArray = meterAddress.toCharArray();
        int length = charArray.length;
        StringBuilder meterAddressBuilder = new StringBuilder(meterAddress);
        for(int i = 0; i<16 - length; i++){
            meterAddressBuilder.insert(0, "0");
        }
        meterAddress = meterAddressBuilder.toString();
        return meterAddress;
    }

    /**
     * 文件上传
     * @param file
     * @return
     */
    @RequestMapping("/uploadFile")
    public Result upload(MultipartFile file) {
        //file是一个临时文件，需要转存到指定位置，否则本次请求完成后临时文件会删除

        //原始文件名
        String oldFileName = file.getOriginalFilename();//mjz.jpg
        String suffix = oldFileName.substring(oldFileName.lastIndexOf("."));

        //使用UUID生随机的文件名，防止文件名称重复造成文件覆盖
        String fileName = UUID.randomUUID().toString() + suffix;

        //创建一个目录对象
        File dir = new File(basePath);
        //判断目录对象是否存在
        if (!dir.exists()) {
            //目录不存在，需要创建
            dir.mkdirs();
        }

        try {
            //将临时文件转存到指定位置
            file.transferTo(new File(basePath + oldFileName));

        } catch (IOException e) {
            e.printStackTrace();
        }
        //返回文件名到前端
        return Result.OK(fileName);
    }

    /**
     * 文件下载
     * @param name
     * @param response
     */
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @GetMapping("/downloadFile")
    public void download(@RequestParam("fileName") String name, HttpServletResponse response){

        try {
            //输入流，通过输入流读取文件内容
            FileInputStream fileInputStream = new FileInputStream(new File(basePath + name));

            response.setContentType("application/vnd.ms-word;charset=utf-8");
            response.addHeader("Content-Disposition","attachment;fileName=" +new String(name.getBytes("UTF-8"),"iso-8859-1"));
//            response.setContentType("blob");
            response.setCharacterEncoding("UTF-8");
            //输出流，通过输出流将文件写回浏览器
            ServletOutputStream outputStream = response.getOutputStream();

            int len = 0;
            byte[] bytes = new byte[1024];
            while ((len = fileInputStream.read(bytes)) != -1){
                outputStream.write(bytes,0,len);
                outputStream.flush();
            }

            //关闭资源
            outputStream.close();
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("/download")
    public void  download(HttpServletResponse response, @RequestBody ExportExcelParamsVo exportExcelParams) throws Exception {
           service.OutExcel(response,exportExcelParams);

    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("/downloadModel")
    public void downloadModel(HttpServletResponse response,@RequestParam("type") String type) {
        try{
            service.downloadModel(response,type);
        }catch (Exception e){

        }
    }


//    /**
//       * 功能描述
//       * @author liuwei
//       * @date  2022/10/13
//       * @param
//       * @return
//     */
//    @PostMapping("/fileUpload")
//    @ResponseBody
//    public Result fileUpload(@RequestParam("file") MultipartFile attach) {
//
//
//    }

    /**
     * 导入EXCEL插入数据库
     * @param attach
     * @return
     */
    @PostMapping("/upload")
    @ResponseBody
    public Result importExcel(@RequestParam("file") MultipartFile attach,@RequestParam("type") String type,
                              @RequestParam("meterType") String meterType) {
        try{
            //数据集合，选择对应表头对应的列集合
            List<String> keyList = ChooseHeaderList(type);
            //读取完excel数据后 得到String json格式字符串
            String jsonStr = PoiUtils.importExcel(attach, keyList);
            //读取完了数据然后要插入库，根绝类型进行插入
            return batchInByType(type,jsonStr,meterType);
        }catch (Exception e){
            e.printStackTrace();
            return Result.ERROR(new ApiException(ResultCodeEnum.EXCELIN_ERROR));
        }
    }

    private Result  batchInByType(String type, String jsonStr,String meterType) throws Exception {
        Result result = new Result();
        switch (type){
            case "DAY_DATA_EXCEL" : {
                List<MeterDayDataDTO> list = JSON.parseArray(jsonStr,MeterDayDataDTO.class);
                Map<String,Object> map = new HashMap<>();
                map.put("list",list);
                map.put("meterType",meterType);
                archiveClient.ExcelDayDataIn(map);
                break;
            }
            case "TERM_EXCEL" : {
                List<TermDTO> list = JSON.parseArray(jsonStr, TermDTO.class);
                result = archiveClient.ExcelTermIn(list);
                break;
            }
            case "WIRED_EXCEL" : {
                List<WiredMeterDTO> list = JSON.parseArray(jsonStr,WiredMeterDTO.class);
                //循环将表地址补齐16位
                for(WiredMeterDTO wiredMeterDTO : list){

                    if(wiredMeterDTO.getMeterAddress().toCharArray().length < 16){
                        wiredMeterDTO.setInstTime(new Date());
                       String newMeterAddress =  addHexMeterAddress(wiredMeterDTO.getMeterAddress());
                       wiredMeterDTO.setMeterAddress(newMeterAddress);
                    }
                }
                result = archiveClient.ExcelWiredIn(list);
                break;
            }
            case "NB_EXCEL" : {
                List<NBDTO> list = JSON.parseArray(jsonStr,NBDTO.class);
                result = archiveClient.ExcelNBIn(list);
                break;
            }
            case "NB_PRODUCT_EXCEL" : {
                List<NBDTO> list = JSON.parseArray(jsonStr,NBDTO.class);
                result = archiveClient.ExcelNBProductIn(list);
                break;
            }
            default :{
                return result;
            }
        }
        return result;
    }

    private List<String> ChooseHeaderList(String type) {
        switch (type){
            case "DAY_DATA_EXCEL" : {
                return Const.DAY_DATE_EXCEL;
            }
            case "TERM_EXCEL" : {
               return Const.TERM_EXCEL;
            }
            case "WIRED_EXCEL" : {
                return Const.WIRED_EXCEL;
            }
            case "NB_EXCEL" : {
                return Const.NB_EXCEL;
            }
            case "NB_PRODUCT_EXCEL" : {
                return Const.NB_PRODUCT_EXCEL;
            }
            default :{
                return null;
            }
        }
    }

}
