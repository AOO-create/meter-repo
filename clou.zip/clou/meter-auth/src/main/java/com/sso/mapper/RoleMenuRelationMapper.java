package com.sso.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sso.domain.RoleMenuRelation;
import org.apache.ibatis.annotations.Param;

public interface RoleMenuRelationMapper extends BaseMapper<RoleMenuRelation> {


    int updateFlag(@Param("relation") RoleMenuRelation relation);
}
