package aep.nbiot.service;

import aep.nbiot.client.ClientFactory;
import aep.nbiot.command.AepCommandEnum;
import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.command.AepDeviceManagementEnum;
import aep.nbiot.command.AepNbDeviceManagementEnum;
import aep.nbiot.propertie.AepIotProperties;
import aep.nbiot.strategy.AepStrategyContext;
import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.strategy.aepdevicecommand.*;
import aep.nbiot.strategy.aepdevicemanage.*;
import aep.nbiot.util.ResultUtil;
import com.ctg.ag.sdk.biz.AepDeviceCommandClient;
import com.ctg.ag.sdk.biz.AepDeviceManagementClient;
import com.ctg.ag.sdk.biz.AepNbDeviceManagementClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 对外提供的服务接口
 * @date 2021/11/17 8:52
 */
public class AepApiService {

    /**
     * AepIot配置对象
     */
    AepIotProperties aepIotProperties;

    public AepApiService(AepIotProperties aepIotProperties) {
        this.aepIotProperties = aepIotProperties;
    }

    /**
     * 调用AEP相应API得到报文信息  返回 BaseApiResponse 对象
     *
     * @param command 命令
     * @param params  命令相应参数
     * @return 返回报文
     */
    private BaseApiResponse invockApiResponse(AepCommandEnum command, HashMap<String, Object> params, HashMap<String, Object> body) {
        //TODO 此处可以优化 写通用代码 无需每个指令都写
        //设备管理
        if (command instanceof AepDeviceManagementEnum) {
            AepDeviceManagementEnum aepDeviceManagementEnum = (AepDeviceManagementEnum) command;
            AepDeviceManagementClient client = (AepDeviceManagementClient) ClientFactory.getClient(command, aepIotProperties);
            switch (aepDeviceManagementEnum) {
                case CreateDevice: {
                    IAepStrategy aepStrategy = new CreateDeviceStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case DeleteDeviceByPost: {
                    IAepStrategy aepStrategy = new DeleteDeviceByPostStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case DeleteDevice: {
                    IAepStrategy aepStrategy = new DeleteDeviceStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case ListDeviceActiveStatus: {
                    IAepStrategy aepStrategy = new ListDeviceActiveStatusStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case ListDeviceInfo: {
                    IAepStrategy aepStrategy = new ListDeviceInfoStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case QueryDeviceList: {
                    IAepStrategy aepStrategy = new QueryDeviceListStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case QueryDevice: {
                    IAepStrategy aepStrategy = new QueryDeviceStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case UpdateDevice: {
                    IAepStrategy aepStrategy = new UpdateDeviceStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                default: {
                }
            }
        }
        else if (command instanceof AepNbDeviceManagementEnum) {
            AepNbDeviceManagementClient client = (AepNbDeviceManagementClient) ClientFactory.getClient(command, aepIotProperties);
            AepNbDeviceManagementEnum aepNbDeviceManagementEnum = (AepNbDeviceManagementEnum) command;
            switch (aepNbDeviceManagementEnum) {
                case BatchCancelDevices: {
                    IAepStrategy aepStrategy = new BatchCancelDevicesStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case BatchCreateNBDevice: {
                    IAepStrategy aepStrategy = new BatchCreateNBDeviceStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
            }
        }

        //指令下发
        if (command instanceof AepDeviceCommandEnum) {
            AepDeviceCommandEnum aepDeviceCommandEnum = (AepDeviceCommandEnum) command;
            AepDeviceCommandClient client = (AepDeviceCommandClient) ClientFactory.getClient(command, aepIotProperties);
            switch (aepDeviceCommandEnum) {
                case CancelCommand: {
                    IAepStrategy aepStrategy = new CancelCommandStrategy();//
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case CreateCommand: {
                    IAepStrategy aepStrategy = new CreateCommandStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case QueryCommand: {
                    IAepStrategy aepStrategy = new QueryCommandStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case QueryCommandList: {
                    IAepStrategy aepStrategy = new QueryCommandListStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                case CreateCommandLwm2mProfile: {
                    IAepStrategy aepStrategy = new CreateCommandLwm2mProfileStrategy();
                    AepStrategyContext aepStrategyContext = new AepStrategyContext(aepStrategy);
                    return aepStrategyContext.invockApi(client, params, body);
                }
                default: {

                }
            }
        }
        return null;
    }

    /**
     * 调用AEP相应API得到报文信息 直接返回真实Body信息
     *
     * @param command 命令
     * @param params  命令相应参数
     * @return 返回报文
     */
    public String invockApi(AepCommandEnum command, HashMap<String, Object> params) {
        return invockApi(command, params, null);
    }

    /**
     * 调用AEP相应API得到报文信息 直接返回真实Body信息
     *
     * @param command 命令
     * @param params  命令相应参数
     * @param body    请求体参数
     * @return
     */
    public String invockApi(AepCommandEnum command, HashMap<String, Object> params, HashMap<String, Object> body) {
        BaseApiResponse baseApiResponse = invockApiResponse(command, params, body);
        if (baseApiResponse != null) {
            return ResultUtil.convetResponse(baseApiResponse);
        }
        return ResultUtil.defaultError().toString();
    }
}
