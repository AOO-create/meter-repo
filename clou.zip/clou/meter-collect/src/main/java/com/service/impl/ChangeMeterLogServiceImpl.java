package com.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fegin.client.ArchiveClient;
import com.common.Const;
import com.entity.log.ChangeMeterLog;
import com.entity.area.Org;
import com.mapper.log.ChangeMeterLogMapper;
import com.service.ChangeMeterLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/9
 */
@Service
public class ChangeMeterLogServiceImpl implements ChangeMeterLogService {
    @Autowired
    private ChangeMeterLogMapper mapper;

    @Autowired
    private ArchiveClient archiveClient;

    @Override
    public Page<ChangeMeterLog> getChangeLog(ChangeMeterLog dto) {
        Page<ChangeMeterLog> page = new Page<>();

        Org org = archiveClient.getOrg();
        dto.setOrgId(org.getOrgId());
        dto.setCurrentPos((dto.getPage() - 1) * dto.getLimit());
        if(archiveClient.getTgId() == null ||archiveClient.getTgId().equals("")){
            dto.setAreaId(archiveClient.getAreaId());
        }else{
            dto.setOpUser(Const.userId);
        }

        List<ChangeMeterLog> list = mapper.getLog(dto);
        int count = mapper.getLogCount(dto);

        if (list.size() != 0 && list != null) {
            page.setRecords(list);
            page.setTotal(count);
        } else {
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }
}
