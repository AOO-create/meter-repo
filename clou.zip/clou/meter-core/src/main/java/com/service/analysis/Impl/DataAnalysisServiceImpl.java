package com.service.analysis.Impl;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.BDGradeDTO;
import com.dto.GradeDTO;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.WiredMeterDTO;
import com.fegin.client.ArchiveClient;
import com.mapper.analysis.DataAnalysisMapper;
import com.service.analysis.DataAnalysisService;
import com.util.Predicted;
import com.utils.AepUtils;
import com.vo.analysisDataVo.CollectMeterVo;
import com.vo.analysisDataVo.MeterVo;
import com.vo.analysisDataVo.NbDataVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * @author liuwei
 * @description
 * @date 2023/11/2
 */
@Service
public class DataAnalysisServiceImpl implements DataAnalysisService {

    @Autowired
    private DataAnalysisMapper mapper;

    @Autowired
    private ArchiveClient archiveClient;

    /***
     * 预测区域用量信息。
     * @author liuwei
     * @date 2023/11/6
     * @params [vo]
     * @return com.vo.analysisDataVo.MeterVo
     */
    @Override
    public MeterVo predictionData(MeterVo vo) {
        MeterVo meter = new MeterVo();
        DecimalFormat df = new DecimalFormat("######0.000");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH, -1);
        Date smallMonthDate = calendar.getTime();
        calendar.add(Calendar.MONTH, -1);
        Date lastMonth = calendar.getTime();
        String yesMonthDate = dateFormat.format(smallMonthDate);
        String lastMonthDate = dateFormat.format(lastMonth);
        String nowMonthDate = dateFormat.format(new Date());

        SimpleDateFormat format = new SimpleDateFormat("yyyy");
        Calendar calendarYear = Calendar.getInstance();
        calendarYear.setTime(new Date());
        calendarYear.add(Calendar.YEAR, -1);
        Date yesYear = calendarYear.getTime();
        calendarYear.add(Calendar.YEAR, -1);
        Date lastYear = calendar.getTime();
        String yesYearDate = format.format(yesYear);
        String lastYearDate = format.format(lastYear);
        String nowYearDate = format.format(new Date());

        String dayFlow = "";
        String yesDayFlow = "";
        String lastDFlow = "";
        //查找环比同比数据，根据表地址
        //当日昨日用水量
        if (vo.getMeterType().equals("1")) {
            dayFlow = mapper.getNowDayDataNB(vo);
            yesDayFlow = mapper.getYesDayDataNB(vo);
            lastDFlow = mapper.getLastDayDataNB(vo);
        } else {
            dayFlow = mapper.getNowDayDataWired(vo);
            yesDayFlow = mapper.getYesDayDataWired(vo);
            lastDFlow = mapper.getLastDayDataWired(vo);
        }

        double ssdayFlow = 0;
        double yesSSDayFlow = 0;
        double dayTrend = 0;
        double dayRate = 0.00;

        if (dayFlow != null && yesDayFlow != null) {
            ssdayFlow = Double.parseDouble(df.format(Double.parseDouble(dayFlow) - Double.parseDouble(yesDayFlow)));
            meter.setDayFlow(ssdayFlow + "");
        } else {
            meter.setDayFlow("--");
        }
        if (yesDayFlow != null && lastDFlow != null) {
            yesSSDayFlow = Double.parseDouble(df.format(Double.parseDouble(yesDayFlow) - Double.parseDouble(lastDFlow)));
            meter.setYesDayFlow(yesSSDayFlow + "");
        } else {
            meter.setYesDayFlow("--");
        }
        if (dayFlow != null && yesDayFlow != null) {
            dayTrend = ssdayFlow - yesSSDayFlow;
            dayTrend = Double.parseDouble(df.format(dayTrend));
            meter.setDayTrend(dayTrend + "");

            if (dayTrend == 0) {
                meter.setDayRate("0.00%");
            } else {
                dayRate = (dayTrend / yesSSDayFlow) * 100;
                dayRate = Double.parseDouble(df.format(dayRate));
                meter.setDayRate(dayRate + "%");
            }
        }

        //当月上月用水量
        String nowFlow = "";
        String yesFlow = "";
        String lastFlow = "";
        if (vo.getMeterType().equals("1")) {
            nowFlow = mapper.getMonthDataNB(vo, nowMonthDate);
            yesFlow = mapper.getMonthDataNB(vo, yesMonthDate);
            lastFlow = mapper.getMonthDataNB(vo, lastMonthDate);
        } else {
            nowFlow = mapper.getMonthDataWired(vo, nowMonthDate);
            yesFlow = mapper.getMonthDataWired(vo, yesMonthDate);
            lastFlow = mapper.getMonthDataWired(vo, lastMonthDate);
        }
        double monthFlow = 0;
        double yesMonthFlow = 0;
        double monthTrend = 0;
        double monthRate = 0;

        if (nowFlow != null && yesFlow != null) {
            monthFlow = Double.parseDouble(nowFlow) - Double.parseDouble(yesFlow);
            monthFlow = Double.parseDouble(df.format(monthFlow));
            meter.setMonthFlow(monthFlow + "");
        } else {
            meter.setMonthFlow("--");
        }

        if (yesFlow != null && lastFlow != null) {
            yesMonthFlow = Double.parseDouble(yesFlow) - Double.parseDouble(lastFlow);
            yesMonthFlow = Double.parseDouble(df.format(yesMonthFlow));
            meter.setYesMonthFlow(yesMonthFlow + "");
        } else {
            meter.setYesMonthFlow("--");
        }

        if (nowFlow != null && yesFlow != null && lastFlow != null) {
            monthTrend = monthFlow - yesMonthFlow;
            monthTrend = Double.parseDouble(df.format(monthTrend));
            meter.setMonthTrend(monthTrend + "");
            if (monthTrend == 0) {
                meter.setMonthRate("0.00%");
            } else {
                monthRate = (monthTrend / yesMonthFlow) * 100;
                monthRate = Double.parseDouble(df.format(monthRate));
                meter.setMonthRate(monthRate + "%");
            }
        } else {
            meter.setMonthTrend("--");
            meter.setMonthRate("--");
        }

        //当年去年用水量
        String nowYearFlow = "";
        String yesYearFlow = "";
        String lastYearFlow = "";
        if (vo.getMeterType().equals("1")) {
            nowYearFlow = mapper.getYearDataNB(vo, nowYearDate);
            yesYearFlow = mapper.getYearDataNB(vo, yesYearDate);
            lastYearFlow = mapper.getYearDataNB(vo, lastYearDate);
        } else {
            nowYearFlow = mapper.getYearDataWired(vo, nowYearDate);
            yesYearFlow = mapper.getYearDataWired(vo, yesYearDate);
            lastYearFlow = mapper.getYearDataWired(vo, lastYearDate);
        }

        double yearFlow = 0;
        double qunianYearFlow = 0;
        double yearTrend = 0;
        double yearRate = 0;

        if (nowYearFlow == null && yesYearFlow != null) {
            yearFlow = Double.parseDouble(nowYearFlow) - Double.parseDouble(yesYearFlow);
            yearFlow = Double.parseDouble(df.format(yearFlow));

            meter.setYearFlow(yearFlow + "");
        } else {
            meter.setYearFlow("--");
        }

        if (yesYearFlow != null && lastYearFlow != null) {
            qunianYearFlow = Double.parseDouble(yesYearFlow) - Double.parseDouble(lastYearFlow);
            qunianYearFlow = Double.parseDouble(df.format(qunianYearFlow));

            meter.setYesYearFlow(qunianYearFlow + "");
        } else {
            meter.setYesYearFlow("--");
        }

        if (nowYearFlow != null && yesYearFlow != null && lastYearFlow != null) {
            yearTrend = yearFlow - qunianYearFlow;
            yearTrend = Double.parseDouble(df.format(yearTrend));
            meter.setYearTrend(yearTrend + "");
            if (yearTrend == 0) {
                meter.setYearRate("0.00%");
            } else {
                yearRate = (yearTrend / qunianYearFlow) * 100;
                yearRate = Double.parseDouble(df.format(yearRate));
                meter.setYearRate(yearRate + "%");
            }
        } else {
            meter.setYearTrend("--");
            meter.setYearRate("--");
        }
        //根据过去几天数据进行预测分析
        List<String> date = new ArrayList<>();
        List<String> realData = new ArrayList<>();
        List<String> predictedData = new ArrayList<>();
        Map<String, Map<String, String>> map = getDateData(vo);
        Map<String, String> realMap = map.get("realData");
        Map<String, String> predictedMap = map.get("predicted");
        predictedMap.forEach((key, value) -> {
            date.add(key);
            predictedData.add(value);
        });
        realMap.forEach((key, value) -> {
            realData.add(value);
        });
        meter.setDate(date);
        meter.setPredictedData(predictedData);
        meter.setRealData(realData);
        return meter;
    }

    /***
     * 获取上报数据，和预测数据，调用回归曲线工具类
     * @author liuwei
     * @date 2023/11/6
     * @params [vo]
     * @return java.util.Map<java.lang.String, java.util.Map < java.lang.String, java.lang.String>>
     */
    private Map<String, Map<String, String>> getDateData(MeterVo vo) {
        List<String> date = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        for (int i = -15; i <= 15; i++) {
            Date dd = new Date();
            Calendar cal = Calendar.getInstance();
            //获取前面的时间用-负号
            cal.setTime(dd);
            cal.add(Calendar.DAY_OF_MONTH, i);
            date.add(sdf.format(cal.getTime()));
        }
        Map<String, String> map = new LinkedHashMap<>();
        Map<String, Map<String, String>> resultMap = new LinkedHashMap<>();
        String value = "";
        //赋值前面15个值
        if (vo.getMeterType().equals("1")) {
            //NB表具
            for (int j = 0; j < 15; j++) {
                value = mapper.getFlowByDateNB(vo.getImei(), date.get(j));
                if (null == value || ("").equals(value)) {
                    map.put(date.get(j), "0.00");
                } else {
                    map.put(date.get(j), value);
                }
            }
        } else {
            //冷水水表和电表
            for (int j = 0; j < 15; j++) {
                value = mapper.getFlowByDateWired(vo.getMeterAddress(), vo.getTermId(), date.get(j));
                if (null == value || ("").equals(value)) {
                    map.put(date.get(j), "0.00");
                } else {
                    map.put(date.get(j), value);
                }
            }
        }

        resultMap.put("realData", map);
        Map<String, String> map1 = new LinkedHashMap<>();
        //开始预测
        double[] xData = new double[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        double[] yData = new double[15];
        for (int i = 0; i < 15; i++) {
            double y = Double.parseDouble(map.get(date.get(i)));
            yData[i] = y;
        }
        Predicted lineRegression = new Predicted();
        //绘制直线
        lineRegression.leastSquareMethod(xData, yData);
        //预测下面15个值
        for (int i = 0; i < 30; i++) {
            map1.put(date.get(i), lineRegression.getY(i + 1) + "");
        }
        resultMap.put("predicted", map1);

        return resultMap;
    }

    /***
     * 采集率趋势分析
     * @author liuwei
     * @date 2023/11/6
     * @params [vo]
     * @return com.vo.analysisDataVo.CollectMeterVo
     */
    @Override
    public CollectMeterVo predictRateAndGetNoReport(CollectMeterVo vo) throws ParseException {
        //返回结果
        CollectMeterVo result = new CollectMeterVo();
        //根据参数查询未上报表具信息
        String orgId = archiveClient.getOrg().getOrgId();
        String tgId = vo.getTgBuildDoorplate();
        String areaId = vo.getAreaId();
        List<String> bdIdList = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(dateFormat.parse(vo.getDate()));
        if(null == areaId || areaId.equals("") ){
            //点击组织树单元门栋
            bdIdList = archiveClient.reGetChildBDGradeId(tgId, orgId);
        }

        //未上报表具
        List<CollectMeterVo> voList = new ArrayList<>();
        int nbSum = 0;
        int wiredSum = 0;
        int elecSum = 0;
        //获取未上报数量，上报数量
        int reportCount = 0;
        int noReportCount = 0;

        Predicted predicted = new Predicted();
        List<String> halfYearDate = predicted.getNearlySixMonthDates();
        nbSum = mapper.getSumNB(areaId, bdIdList);
        wiredSum = mapper.getSumWired(areaId, bdIdList, "0");
        elecSum = mapper.getSumWired(areaId, bdIdList, "4");
        List<String> reportRate = new ArrayList<>();
        List<String> predictRate = new ArrayList<>();
        if (vo.getMeterType().equals("1")) {
            //类型NB表具
            voList = mapper.getNoReportMeterNB(areaId, bdIdList, date);
            reportCount = nbSum - voList.size();
            noReportCount = voList.size();
            //获取6个月上报率
            for (String dd : halfYearDate) {
                int reportDD = mapper.getReportNB(areaId, bdIdList, dd);
                if (reportDD == 0 || nbSum == 0) {
                    reportRate.add("0");
                } else {
                    String rate = Double.parseDouble(reportDD + "") / Double.parseDouble(nbSum + "") + "";
                    reportRate.add(rate);
                }
            }
        } else if (vo.getMeterType().equals("0") || vo.getMeterType().equals("4")) {
            //类型水电表接集中器
            voList = mapper.getNoReportMeterWired(areaId, bdIdList, vo.getMeterType(), date);
            if (vo.getMeterType().equals("0")) {
                reportCount = wiredSum - voList.size();
                noReportCount = voList.size();
            } else if (vo.getMeterType().equals("4")) {
                int num = 0 ;
                MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                meterDayDataDTO.setDate(date);
                if(null == areaId || areaId.equals("") ){
                    meterDayDataDTO.setTgIds(bdIdList);
                    num = archiveClient.getReportCl6904(meterDayDataDTO);

                }else{
                    meterDayDataDTO.setAreaId(areaId);
                    num = archiveClient.getReportCl6904(meterDayDataDTO);
                }
                //未上报的List
                List<CollectMeterVo> meterVos = archiveClient.getCL6904NoReport(meterDayDataDTO);
                voList.addAll(meterVos);
                int count = mapper.getReportWired(areaId,bdIdList,date,"4");
                reportCount = count + num;
                noReportCount = elecSum - reportCount;
            }
            MeterDayDataDTO dayDataDTO = new MeterDayDataDTO();
            dayDataDTO.setAreaId(areaId);
            dayDataDTO.setTgIds(bdIdList);
            //获取6个月上报率
            for (String dd : halfYearDate) {
                int sum = 0;
                int reportDD = mapper.getReportWired(areaId, bdIdList, dd, vo.getMeterType());
                if (vo.getMeterType().equals("0")) {
                    sum = wiredSum;
                } else if (vo.getMeterType().equals("4")) {
                    dayDataDTO.setDate(dd);
                    reportDD = archiveClient.getReportCl6904(dayDataDTO) + reportDD;
                    sum = elecSum;
                }
                if (reportDD == 0 || sum == 0) {
                    reportRate.add("0");
                } else {
                    String rate = Double.parseDouble(reportDD + "") / Double.parseDouble(sum + "") + "";
                    reportRate.add(rate);
                }
            }
        } else if (vo.getMeterType().equals("11")) {
            //类型全部  未上报
            List<CollectMeterVo> voListOne = mapper.getNoReportMeterNB(areaId, bdIdList, date);
            //计算的是6610下电表还差818电表
            List<CollectMeterVo> voListTwo = mapper.getNoReportMeterWired(areaId, bdIdList, vo.getMeterType(), date);
            voList.addAll(voListOne);
            voList.addAll(voListTwo);
            MeterDayDataDTO dayDataDTO = new MeterDayDataDTO();
            dayDataDTO.setAreaId(areaId);
            dayDataDTO.setTgIds(bdIdList);
            dayDataDTO.setDate(date);
            int reportNum = mapper.getReportNB(areaId,bdIdList,date)
                    + mapper.getReportWired(areaId,bdIdList,date,"1")
                    + mapper.getReportWired(areaId,bdIdList,date,"4")
                    + archiveClient.getReportCl6904(dayDataDTO);
            //未上报的List
            List<CollectMeterVo> meterVos = archiveClient.getCL6904NoReport(dayDataDTO);
            voList.addAll(meterVos);
            reportCount = reportNum;
            noReportCount = nbSum +wiredSum + elecSum - reportNum;

            //获取6个月上报率
            for (String dd : halfYearDate) {
                int reportDD = mapper.getReportSum(areaId, bdIdList, dd);
                dayDataDTO.setDate(dd);
                reportDD = reportDD + archiveClient.getReportCl6904(dayDataDTO);
                if (reportDD == 0 || (nbSum + wiredSum + elecSum) == 0) {
                    reportRate.add("0");
                } else {
                    String rate = Double.parseDouble(reportDD + "") / Double.parseDouble(nbSum + "") + "";
                    reportRate.add(rate);
                }
            }
        }

        result.setReportCount(reportCount + "");
        result.setNoReportCount(noReportCount + "");
        halfYearDate.addAll(predicted.getNearlyFutureMonthDates());
        result.setHalfYearDate(halfYearDate);
        result.setReportRate(reportRate);
        //预测下一个月的上报率
        double[] xData = new double[365];
        double[] yData = new double[365];
        for (int i = 0; i < reportRate.size(); i++) {
            xData[i] = i + 1;
            yData[i] = Double.parseDouble(reportRate.get(i));
        }

        Predicted lineRegression = new Predicted();
        lineRegression.leastSquareMethod(xData, yData);
        for (int i = 0; i < 30; i++) {
            predictRate.add(lineRegression.getY(reportRate.size() + i + 1) + "");
        }
        result.setPredictRate(predictRate);
        Page<CollectMeterVo> page = new Page<>(vo.getPage(), vo.getLimit());
        if (voList.size() == 0) {
            page.setTotal(0);
            page.setRecords(null);
        } else {
            page.setTotal(voList.size());
            page.setRecords(voList);
        }
        result.setCollectList(page);
        return result;
    }

    /***
       * NB新协议表具信号强弱预警分析
       * @author liuwei
       * @date  2023/11/21
       * @params [vo]
       * @return com.vo.analysisDataVo.NbDataVo
     */
    @Override
    public NbDataVo signalWarning(NbDataVo vo) {
        String roleCode = archiveClient.getRole().getRoleCode();
        String tgId = archiveClient.getTgId();
        String areaId = vo.getAreaId();
        int sum = 0;
        AtomicInteger normalNum = new AtomicInteger();
        AtomicInteger weakSignalNum = new AtomicInteger();
        AtomicInteger exceptionNum = new AtomicInteger();
        AtomicInteger warningNum = new AtomicInteger();
        List<CollectMeterVo> sumList = new ArrayList<>();
        List<String> bdIds = new ArrayList<>();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        NbDataVo result = new NbDataVo();
        if (roleCode.equals("admin")) {
            //管理员用户
            sumList = mapper.getNbByAreaIdAndTgId(areaId, null);
        } else if (null == tgId || "".equals(tgId)) {
            //组织区域用户
            sumList = mapper.getNbByAreaIdAndTgId(areaId, null);
        } else {
            //门栋用户
            bdIds = archiveClient.reGetChildBDGradeId(tgId, archiveClient.getOrg().getOrgId());
            sumList = mapper.getNbByAreaIdAndTgId(areaId, bdIds);
        }
        //上报表具
        List<NbDataVo> reportList = mapper.getNbReportByAreaIdAndTgId(areaId, bdIds, format.format(new Date()));
        List<CollectMeterVo> finalSumList = sumList;
        reportList.forEach(val -> {
            finalSumList.forEach(ss -> {
                if (ss.getImei().equals(val.getDeviceId())) {
                    val.setInstLoc(ss.getInstLoc());
                }
            });
            if (!val.getRunStatus().equals("0100") && !val.getRunStatus().equals("0000")) {
                //run_status字段显示,运行异常
                val.setType("2");
                val.setRunMessage(judgeStatus(val.getRunStatus()));
                exceptionNum.getAndIncrement();
            } else {
                val.setRunMessage("运行正常");
            }

            short rsrp = Integer.valueOf(val.getRsrp(), 16).shortValue();
            short snr = Integer.valueOf(val.getSnr(), 16).shortValue();
            short ecl = Integer.valueOf(val.getEcl(), 16).shortValue();
            val.setRsrp(rsrp + "");
            val.setSnr(snr + "");
            val.setEcl(ecl + "");
            if (rsrp < -105 && null == val.getType()) {
                //rsrp <-105且不为异常时设定为弱信号表具
                val.setType("1");
                weakSignalNum.getAndIncrement();
            }

            if (null == val.getType() || val.getType().equals("")) {
                val.setType("0");
                normalNum.getAndIncrement();
            }
        });

        //查找示故障的机器、、当天未上报表具，定时24小时上报未上报，故障机器
        List<NbDataVo> noReportList = mapper.getNbNoReportByAreaIdAndTgId(areaId, bdIds, format.format(new Date()));
        noReportList.forEach(val -> {
            val.setType("3");
            val.setRunMessage("运行故障，未上报日冻结数据");
            val.setCsq("--");
            val.setRsrp("--");
            val.setSnr("--");
            val.setEcl("--");
            warningNum.getAndIncrement();
        });

        reportList.addAll(noReportList);
        sum = sumList.size();
        result.setSum(sum + "");
        result.setNormalnum(normalNum.get() + "");
        result.setWeakSignalNum(weakSignalNum.get() + "");
        result.setExceptionNum(exceptionNum.get() + "");
        result.setWarningNum(warningNum.get() + "");
        result.setInfoList(reportList);
        List<NbDataVo> voList = new ArrayList<>();
        //根据vo传参进行筛选 表地址不为空，类型为空
        if (null != vo.getImei() && !vo.getImei().equals("") && (null == vo.getType() || vo.getType().equals(""))) {
            reportList.forEach(val -> {
                if (val.getImei().equals(vo.getImei())) {
                    voList.add(val);
                }
            });
            result.setInfoList(voList);
        }
        //表地址为空，类型不为空
        if (null != vo.getType() && !vo.getType().equals("") && (null == vo.getImei() || vo.getImei().equals(""))) {
            reportList.forEach(val -> {
                if (val.getType().equals(vo.getType())) {
                    voList.add(val);
                }
            });
            result.setInfoList(voList);
        }
        //表地址类型都不为空
        if (null != vo.getType() && !vo.getType().equals("") && null != vo.getImei() && !vo.getImei().equals("")) {
            reportList.forEach(val -> {
                if (val.getType().equals(vo.getType()) && val.getImei().equals(vo.getImei())) {
                    voList.add(val);
                }
            });
            result.setInfoList(voList);
        }
        return result;
    }

    /***
       * NB新协议表具预警功能方法 -- 解析运行状态字段，判断异常类型
       * @author liuwei
       * @date  2023/11/21
       * @params [runStatus]
       * @return java.lang.String
     */
    private String judgeStatus(String runStatus) {
        String binString = AepUtils.hexString2binaryString(runStatus);
        String result = "";
        if (binString.substring(2, 3).equals("1")) {
            result = result + "长时间未上报异常";
        }
        if (binString.substring(3, 4).equals("1")) {
            result = result + "长时间未使用异常";
        }
        if (binString.substring(4, 5).equals("1")) {
            result = result + "存储器异常";
        }
        if (binString.substring(5, 6).equals("1")) {
            result = result + "电池电压欠压";
        }
        if (binString.substring(6, 8).equals("11")) {
            result = result + "阀门状态异常/半开闭";
        }
        if (binString.substring(13, 14).equals("1")) {
            result = result + "拆卸告警异常";
        }

        if (binString.substring(14, 15).equals("1")) {
            result = result + "计量异常";
        }
        if (binString.substring(15, 16).equals("1")) {
            result = result + "磁干扰异常";
        }

        if (result.equals("")) {
            result = "运行正常";
        }
        return result;
    }

    /***
       * 未上报表具统计分析。
       * @author liuwei
       * @date  2023/11/21
       * @params [vo]
       * @return com.vo.analysisDataVo.CollectMeterVo
     */
    @Override
    public CollectMeterVo collectionFailed(CollectMeterVo vo) {
        String orgId = archiveClient.getOrg().getOrgId();
        String areaId = archiveClient.getAreaId();
        String tgId = archiveClient.getTgId();
        String roleCode = archiveClient.getRole().getRoleCode();
        String meterType = vo.getMeterType();
        String date = vo.getDate();
        CollectMeterVo result = new CollectMeterVo();
        List<String> areaNameList = new ArrayList<>();
        List<String> noReportList = new ArrayList<>();
        List<CollectMeterVo> list = new ArrayList<>();
        if (roleCode.equals("admin")) {
            //管理员用户查看所有组织区域
            List<GradeDTO> gradeDTOList = mapper.getAllGrade(orgId);
            gradeDTOList.forEach(val -> {
                List<CollectMeterVo> voList = new ArrayList<>();
                if (meterType.equals("0") || meterType.equals("4")) {
                    voList = mapper.getNoReportMeterWired(val.getId(), null, meterType, date);
                } else if (meterType.equals("1")) {
                    voList = mapper.getNoReportMeterNB(val.getId(), null, date);
                }
                //为查到的数据添加上最近上报时间,时隔多少天没上报，上报最早时间，总共上报次数。
                if(voList.size() != 0){
                    selectReportData(voList);
                    noReportList.add(voList.size() + "");
                    areaNameList.add(val.getAreaName());
                    list.addAll(voList);
                }
            });
        } else if (null == tgId || "".equals(tgId)) {
            //组织区域用户,查找下属所有bdGrade
            List<BDGradeDTO> bdGradeDTOList = mapper.getAllBDGradeByAreaId(areaId);
            bdGradeDTOList.forEach(val ->{
                List<CollectMeterVo> voList = new ArrayList<>();
                List<String> bdIds = archiveClient.reGetChildBDGradeId(val.getId(),orgId);
                if (meterType.equals("0") || meterType.equals("4")) {
                    voList = mapper.getNoReportMeterWired(null, bdIds, meterType, date);
                } else if (meterType.equals("1")) {
                    voList = mapper.getNoReportMeterNB(null, bdIds, date);
                }
                if(voList.size() != 0){
                    selectReportData(voList);
                    noReportList.add(voList.size() + "");
                    areaNameList.add(val.getBdName());
                    list.addAll(voList);
                }
            });
        } else {
            //楼栋用户
            List<BDGradeDTO> bdGradeDTOList = mapper.getSonBDGrade(tgId);
            bdGradeDTOList.forEach(val ->{
                List<CollectMeterVo> voList = new ArrayList<>();
                List<String> bdIds = archiveClient.reGetChildBDGradeId(val.getId(),orgId);
                if (meterType.equals("0") || meterType.equals("4")) {
                    voList = mapper.getNoReportMeterWired(null, bdIds, meterType, date);
                } else if (meterType.equals("1")) {
                    voList = mapper.getNoReportMeterNB(null, bdIds, date);
                }
                if(voList.size() != 0){
                    selectReportData(voList);
                    noReportList.add(voList.size() + "");
                    areaNameList.add(val.getBdName());
                    list.addAll(voList);
                }
            });
        }
        Page<CollectMeterVo> page = new Page<>(vo.getPage(), vo.getLimit());
        if (list.size() == 0) {
            page.setTotal(0);
            page.setRecords(null);
        } else {
            page.setTotal(list.size());
            page.setRecords(list);
        }
        result.setCollectList(page);
        result.setAreaList(areaNameList);
        result.setNoReportList(noReportList);
        return result;
    }

    /***
       * 查询区域内未上报表具信息及 相关上报数据 -- 1、最近上报 2、最近距今天数 3、初次上报日期 4、上报总次数
       * @author liuwei
       * @date  2023/11/21
       * @params [voList]
       * @return void
     */
    private void selectReportData(List<CollectMeterVo> voList) {
        voList.forEach(value -> {
            CollectMeterVo meterVo = new CollectMeterVo();
            if (null == value.getMeterType() || "".equals(value.getMeterType())) {
                meterVo = mapper.getReportDataNB(value.getImei());
            } else if (value.getMeterType().equals("0") || value.getMeterType().equals("4")) {
                meterVo = mapper.getReportDataWired(value.getMeterAddress(),value.getTermId());
            }
            if(null == meterVo.getRecentDate() || meterVo.getRecentDate().equals("")){
                //不存在最近的一次日期，则从未上报过
                value.setDayCount("--");
                value.setStartDate("从未上报");
                value.setRecentDate("从未上报");
                value.setSumReportCount("0");
            }else{
                value.setDayCount(dayCount(meterVo.getRecentDate()));
                value.setRecentDate(meterVo.getRecentDate());
                value.setSumReportCount(meterVo.getSumReportCount());
                value.setStartDate(meterVo.getStartDate());
            }
        });
    }

    /***
       * 工具方法 -- 判断日期参数距今有多少天数。
       * @author liuwei
       * @date  2023/11/21
       * @params [startDate]
       * @return java.lang.String
     */
    private String dayCount(String startDate){
        SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
        Date Star = null;
        Date End = null;
        try {
            Star = sdf.parse(startDate);
            End = sdf.parse(sdf.format(new Date()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long StarTime =Star.getTime();
        long EndTime =End.getTime();
        long E_S =EndTime-StarTime;
        long interval =E_S/(24*60*60*1000);
        return interval+"";
    }

    /***
       * 根据组织区域树获取全部表具
       * @author liuwei
       * @date  2023/11/29
       * @params [vo]
       * @return java.util.List<com.vo.analysisDataVo.CollectMeterVo>
     */
    @Override
    public Page<CollectMeterVo> getAllMeterOnArea(CollectMeterVo vo) {
        String areaId = vo.getAreaId();
        String tgId = vo.getTgBuildDoorplate();
        String orgId = archiveClient.getOrg().getOrgId();
        List<CollectMeterVo> collectMeterVos = new ArrayList<>();
        List<String> bdIds = new ArrayList<>();
        int count = 0;
        if(vo.getPage() != null){
            vo.setCurrentPos((vo.getPage() - 1)*vo.getLimit());
        }

        if(!tgId.equals("") && areaId.equals("")){
            bdIds = archiveClient.reGetChildBDGradeId(tgId,orgId);
        }

        if(vo.getMeterType().equals("0") || vo.getMeterType().equals("4")){
            //冷水水表 or 电表
            collectMeterVos = mapper.getWiredMeter(vo,bdIds);
            count = mapper.getWiredMeterCount(vo,bdIds);
        }else if(vo.getMeterType().equals("1")){
            //NB
            collectMeterVos = mapper.getNBMeter(vo,bdIds);
            count = mapper.getNBMeterCount(vo,bdIds);
        }
        Page<CollectMeterVo> page = new Page<>();
        if(collectMeterVos.size() != 0){
            page.setRecords(collectMeterVos);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Override
    public CollectMeterVo getCatastrophe(CollectMeterVo vo) {
        String meterType = vo.getMeterType();
        CollectMeterVo result = new CollectMeterVo();
        List<MeterVo> collData = new ArrayList<>();
        //近半年日期
        if(meterType.equals("1")){
            //查询NB表
            collData = mapper.getNBHalfYearData(vo.getImei());
        }else{
            //冷水水表 or NB表
            collData = mapper.getWiredHalfYearData(vo.getMeterAddress(),vo.getTermId());
        }
        List<String> halfYearDate = new ArrayList<>();
        List<String> coll = new ArrayList<>();
        List<String> catastropheDate = new ArrayList<>();
        List<String> catastropheData = new ArrayList<>();
        int catastropheDown = 0;
        int catastropheUp = 0;
        int catastropheSum = 0;
        //循环判断是否存在突变值
        for(int i=0;i<collData.size()-1;i++){
            halfYearDate.add(collData.get(i).getDataDate());
            coll.add(collData.get(i).getRealSumFlow());
            if(!(collData.size() == 1)){
               if(Double.parseDouble(collData.get(i+1).getRealSumFlow()) < Double.parseDouble(collData.get(i).getRealSumFlow())){
                   catastropheDown++;
                   catastropheSum++;
                   catastropheData.add(collData.get(i+1).getRealSumFlow());
                   catastropheDate.add(collData.get(i+1).getDataDate());
               }
               if(Double.parseDouble(collData.get(i+1).getRealSumFlow()) > (Double.parseDouble(collData.get(i).getRealSumFlow()) + 100)){
                   catastropheUp++;
                   catastropheSum++;
                   catastropheData.add(collData.get(i+1).getRealSumFlow());
                   catastropheDate.add(collData.get(i+1).getDataDate());
               }
            }
        }
        result.setCatastropheData(catastropheData);
        result.setCatastropheDate(catastropheDate);
        result.setCatastropheUp(catastropheUp);
        result.setCatastropheDown(catastropheDown);
        result.setCatastropheSum(catastropheSum);
        result.setHalfYearDate(halfYearDate);
        result.setCollData(coll);
        return result;
    }
}
