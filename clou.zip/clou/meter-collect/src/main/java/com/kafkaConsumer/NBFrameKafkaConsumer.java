package com.kafkaConsumer;

import com.AepResolve.AepCompanyAoteman;
import com.AepResolve.AepCompanyChuanren;
import com.AepResolve.AepCompanyNew;
import com.alibaba.fastjson.JSONObject;
import com.utils.AepUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class NBFrameKafkaConsumer {

    @Autowired
    AepCompanyAoteman aepCompanyAoteman;

    @Autowired
    AepCompanyChuanren aepCompanyChuanren;

    @Autowired
    AepCompanyNew aepCompanyNew;

    // 消费监听
    @KafkaListener(id = "AOTEMN_TOPIC",groupId = "AOTEMN_TOPIC",topics = {"AOTEMN_TOPIC"})
    public void listen1(String data, Acknowledgment ack) {
        Map<String,String> map = common(data);
        ack.acknowledge();
        String frame = map.get("frame");
        List<String> frameArray = AepUtils.stringToArray(frame);

        String logo = AepUtils.join(frameArray.subList(12, 14));
        if(logo.equals("a017")||logo.equals("A017")){
            aepCompanyAoteman.handleStatusFrame(frame);
        }else{
            aepCompanyAoteman.handleFrame(map.get("device"), map.get("frame"));
        }
    }


    // 消费监听
    @KafkaListener(id = "CHUANGREN_TOPIC",groupId = "CHUANGREN_TOPIC",topics = {"CHUANGREN_TOPIC"})
    public void listen2(String data, Acknowledgment ack) {
        Map<String,String> map = common(data);
        ack.acknowledge();
        aepCompanyChuanren.handleFrame(map.get("device"), map.get("frame"));
    }

    // 消费监听
    @KafkaListener(id = "NEW_TOPIC_ONE",groupId = "NEW_TOPIC_ONE",topics = {"NEW_TOPIC_ONE"})
    public void listen3(String data, Acknowledgment ack) {
        Map<String,String> map = common(data);
        ack.acknowledge();
        aepCompanyNew.handleResponseFrame(map.get("device"), map.get("frame"));
    }

    // 消费监听
    @KafkaListener(id = "NEW_TOPIC_TWO",groupId = "NEW_TOPIC_TWO",topics = {"NEW_TOPIC_TWO"})
    public void listen4(String data, Acknowledgment ack) {
        Map<String,String> map = common(data);
        ack.acknowledge();
        aepCompanyNew.handleFrame(map.get("device"), map.get("frame"));
    }

    public Map<String,String> common(String data){
        JSONObject value  = JSONObject.parseObject(data);
        String deviceId = value.getString("device");
        String frame = value.getString("frame");
        log.info("消息监听成功！");
        log.info("deviceId:"+deviceId);
        log.info("frame:"+frame);
        Map<String,String> map = new HashMap<>();
        map.put("device",deviceId);
        map.put("frame",frame);
        return map;
    }


}