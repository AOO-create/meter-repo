package com.mapper.calculate;

import com.entity.calculate.CalculateParam;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */
public interface CalculateParamMapper extends BaseMapper<CalculateParam> {
}
