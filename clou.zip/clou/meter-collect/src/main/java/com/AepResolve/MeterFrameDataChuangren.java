package com.AepResolve;

public class MeterFrameDataChuangren extends MeterFrameData{


    private String frameStart;//帧头
    private String isEncry;//是否加密
    private String frameLength;//帧长度
    private String frameNumber;//帧序号
    private String imei;
    private String timeStampReport;//上报时间
    private String deviceId;

    private String commandType;//命令类型
    private String commandCode;//功能码
    private String commandLength;//数据长度
    private String dataType;//数据类型
    private String power;//倍率

    private String timeStampColl;//采集时间戳
    private String forwardFlower;//反向累积脉冲
    private String torwardFlower;//累积净脉冲
    private String currentFlower;//当前采样纪录值
    private String checkCode;//校验码

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getFrameStart() {
        return frameStart;
    }

    public void setFrameStart(String frameStart) {
        this.frameStart = frameStart;
    }

    public String getIsEncry() {
        return isEncry;
    }

    public void setIsEncry(String isEncry) {
        this.isEncry = isEncry;
    }

    public String getFrameLength() {
        return frameLength;
    }

    public void setFrameLength(String frameLength) {
        this.frameLength = frameLength;
    }

    public String getFrameNumber() {
        return frameNumber;
    }

    public void setFrameNumber(String frameNumber) {
        this.frameNumber = frameNumber;
    }

    @Override
    public String getImei() {
        return imei;
    }

    @Override
    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getTimeStampReport() {
        return timeStampReport;
    }

    public void setTimeStampReport(String timeStampReport) {
        this.timeStampReport = timeStampReport;
    }

    public String getCommandType() {
        return commandType;
    }

    public void setCommandType(String commandType) {
        this.commandType = commandType;
    }

    public String getCommandCode() {
        return commandCode;
    }

    public void setCommandCode(String commandCOde) {
        this.commandCode = commandCOde;
    }

    public String getCommandLength() {
        return commandLength;
    }

    public void setCommandLength(String commandLength) {
        this.commandLength = commandLength;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getTimeStampColl() {
        return timeStampColl;
    }

    public void setTimeStampColl(String timeStampColl) {
        this.timeStampColl = timeStampColl;
    }

    public String getForwardFlower() {
        return forwardFlower;
    }

    public void setForwardFlower(String forwardFlower) {
        this.forwardFlower = forwardFlower;
    }

    public String getTorwardFlower() {
        return torwardFlower;
    }

    public void setTorwardFlower(String torwardFlower) {
        this.torwardFlower = torwardFlower;
    }

    public String getCurrentFlower() {
        return currentFlower;
    }

    public void setCurrentFlower(String currentFlower) {
        this.currentFlower = currentFlower;
    }

    @Override
    public String getCheckCode() {
        return checkCode;
    }

    @Override
    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }
}
