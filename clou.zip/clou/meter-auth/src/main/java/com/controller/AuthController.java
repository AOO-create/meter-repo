package com.controller;

import com.alibaba.cloud.commons.lang.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.aop.annotation.LoginLogAnnotation;
import com.fegin.client.ArchiveClient;
import com.common.Const;
import com.common.Result;
import com.entity.User;
import com.sso.domain.SysUser;
import com.sso.domain.UserDto;
import com.sso.mapper.UserMapper;
import com.sso.prop.RsaKeyProperties;
import com.sso.utils.JwtUtils;
import com.utils.RedisUtils;
import com.utils.UserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class AuthController {

    @Autowired(required = false)
    private RedisUtils redisUtils;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private RsaKeyProperties prop;

    @Autowired
    private ArchiveClient archiveClient;

    @Autowired
    private UserMapper userMapper;

    //    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @LoginLogAnnotation(description = "退出")
    @RequestMapping("/doLogout")
    public Result doLogout(@RequestBody SysUser user) {
        Result result = new Result();
        String tokenKey = "token:" + user.getId();
        String userInfoKey = "userInfo:" + user.getId();
        redisUtils.setCacheObject(tokenKey, "");
        redisUtils.setCacheObject(userInfoKey, "");
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("code", Const.loginSingle);
//        jsonObject.put("userId", user.getId());
//        archiveClient.sendMessage(user.getId()+"login", jsonObject.toJSONString());
        result.setCode(200);
        result.setMsg("用戶退出成功");
        result.setData(null);
        return result;
    }

    @LoginLogAnnotation(description = "登录")
    @RequestMapping("/doLogin")
    public Result doLogin(@RequestBody SysUser user) {

        Result result = new Result();
        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword());
        Authentication authenticate = authenticationManager.authenticate(authRequest);
        SysUser sysUser = (SysUser) authenticate.getPrincipal();
        String tokenKey = "token:" + sysUser.getId();
        String userInfoKey = "userInfo:" + sysUser.getId();
        String redisToken = redisUtils.getCacheObject(tokenKey);
        //重复登录 ,发送websocket 踢掉token下线.redis覆蓋原來的
        if (!StringUtils.isEmpty(redisToken)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("code", Const.loginSingle);
            jsonObject.put("userId", sysUser.getId());
            archiveClient.sendMessage(sysUser.getId() + "login", jsonObject.toJSONString());
        }
        UserDto dto = new UserDto();
        BeanUtils.copyProperties(sysUser, dto);
        user.setRoles(sysUser.getSysRoles());
        String token = JwtUtils.generateTokenExpireInMinutes(user, prop.getPrivateKey(), 24 * 60);
        String token2 = "Bearer " + token;
        dto.setToken(token2);
        UserInfo userInfo = UserDto.sysUserToInfo(sysUser);
        User currentUser = userMapper.selectById(sysUser.getId());
        userInfo.setTgBuildDoorplate(currentUser.getTgBuildDoorplate());
        userInfo.setAreaId(currentUser.getAreaId());


        redisUtils.setCacheObject(tokenKey, token);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userInfo", userInfo);
        redisUtils.setCacheObject(userInfoKey, jsonObject.toJSONString());
        result.setCode(200);
        result.setMsg("用户认证通过");
        result.setData(dto);
        return result;
    }

    @RequestMapping("/getToken")
    public String getToken(@RequestBody SysUser user) {
        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword());
        Authentication authenticate = authenticationManager.authenticate(authRequest);
        SysUser sysUser = (SysUser) authenticate.getPrincipal();
        String tokenKey = "tokens:" + sysUser.getUsername();

        String token = JwtUtils.generateTokenExpireInMinutes(user, prop.getPrivateKey(), 24 * 60);
        String token2 = "Bearer " + token;

        redisUtils.setCacheObject(tokenKey, token2);
        JSONObject js = new JSONObject();
        js.put("token", token2);
        js.put("code", 200);
        return js.toJSONString();
    }

}
