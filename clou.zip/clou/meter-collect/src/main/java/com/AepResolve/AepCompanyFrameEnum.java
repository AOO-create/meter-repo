package com.AepResolve;

public enum AepCompanyFrameEnum implements AepFrameEnum{

    ;
//    public  static final String CHUANGREN="53";
//    public  static final String AOTEMAN="68";
//    public  static final String newProto = "6810";
    public  static final String CHUANGREN="CHUANGREN";
    public  static final String AOTEMAN="AOTEMAN";
    public  static final String NEWPROTO = "NEWPROTO";

    public  static final String HEART="44";
    public  static final String REPORT="45";
    public  static final String REGISTER="43";

    public  static final String REPORT_COMMAND="6545000100";
    /**设备应答帧
     *
     */
    public  static final String HEARTBEAT_COMMAND="6544000100";
    public  static final String REGISTER_COMMAND="6545000100";

    public  static final String NOW="04";
    public  static final String WEEK="00";
    public  static final String ZERO="0";

    public  static final String HEAD="5354415254";
    public  static final String CONTENT="ff0015";
    public  static final String ORDER_NUMBER="0000";

    /***
     * 是否加密
     */
    public  static final String ENCRY="AA";
}
