package com.sso.domain;

import com.entity.Org;
import com.entity.Role;
import com.entity.User;
import com.utils.UserInfo;
import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
public class UserDto {
    private String id;
    private String username;
    private String token;
    private MenuVo menuVoString;
    private String orgId;
    private Org org;
    private String name;

    public static UserInfo sysUserToInfo(SysUser sysUser){
        UserInfo userInfo = new UserInfo();
        SysRole sysRole = sysUser.getSysRoles().get(0);
        Role role = new Role();
        User user1 = new User();
        BeanUtils.copyProperties(sysRole,role);
        BeanUtils.copyProperties(sysUser,user1);
        userInfo.setUser(user1);
        userInfo.setOrg(sysUser.getOrg());
        userInfo.setRole(role);
        return userInfo;
    }
}
