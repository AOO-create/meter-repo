package aep.nbiot.dto.param.devicemanage.create.batch;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 批量新增设备列表参数对象
 * @date 2021/12/13 8:45
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NBDevice {

    /**
     * imei号，必填
     */
    private String imei;

    /**
     * 设备名称，必填
     */
    private String deviceName;

    /**
     * 0.自动订阅 1.取消自动订阅，选填
     */
    private Integer autoObserver;

    /**
     * 总长度不超过15位，使用0~9的数字，String类型,选填
     */
    private String imsi;

    /**
     * 由大小写字母加0-9数字组成的16位字符串,选填
     */
    private String pskValue;

    /**
     * 取值0或者1,0代表普通字符串，1代表16进制字符串,选填
     */
    private Integer pskType;
}
