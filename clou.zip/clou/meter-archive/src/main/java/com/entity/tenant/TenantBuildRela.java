package com.entity.tenant;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/8/11
 */
@Data
@TableName("tenant_build_rela")
public class TenantBuildRela {

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;



    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tenantId;



    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tgBuildDoorplate;

}
