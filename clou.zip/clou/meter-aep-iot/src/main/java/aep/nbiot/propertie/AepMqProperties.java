package aep.nbiot.propertie;

import org.springframework.beans.factory.annotation.Value;

import java.util.List;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AEP MQ配置
 * @date 2021/12/28 8:44
 */
public class AepMqProperties {

    /**
     * aep mq服务地址
     */
    @Value("${mq.server}")
    private String server;

    /**
     * 租户ID
     */
    @Value("${mq.tenantId}")
    private String tenantId;

    /**
     * 身份认证token串
     */
    @Value("${mq.token}")
    private String token;

    /**
     * 监听topic 名称列表
     */
    @Value("${mq.topicNames}")
    private List<String> topicNames;

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public List<String> getTopicNames() {
        return topicNames;
    }

    public void setTopicNames(List<String> topicNames) {
        this.topicNames = topicNames;
    }

}
