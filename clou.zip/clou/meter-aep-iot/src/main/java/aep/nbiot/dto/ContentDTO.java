package aep.nbiot.dto;

import java.io.Serializable;

/**
 * @author wufanghao
 * @version 1.0
 * @description: Content传输对象
 * @date 2021/12/9 8:45
 */
public class ContentDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Object params;

    private String serviceIdentifier;

    public Object getParams() {
        return params;
    }

    public void setParams(Object params) {
        this.params = params;
    }

    public String getServiceIdentifier() {
        return serviceIdentifier;
    }

    public void setServiceIdentifier(String serviceIdentifier) {
        this.serviceIdentifier = serviceIdentifier;
    }
}
