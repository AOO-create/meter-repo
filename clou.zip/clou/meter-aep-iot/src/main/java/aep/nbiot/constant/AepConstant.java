package aep.nbiot.constant;

/**
 * @author lanccj
 * @version 1.0
 * @description: 常量定义
 * @date 2021/11/19 10:05 下午
 */
public interface AepConstant {

    /**
     * Mq数据加解密类型
     */
    interface constant{
        /**
         * 十六进制
         */
        String HEX = "hex";

        /**
         * 普通文本(字符串)
         */
        String TXT = "txt";
    }

    /**
     * Mq消息类型
     */
    interface MqMsgType{
        /**
         * 数据上报
         */
        String DataReport = "dataReport";

        /**
         * 设备上线下线通知
         */
        String OnlineOffReport = "deviceOnlineOfflineReport";

        /**
         * 设备指令执行返回信息
         */
        String CommandResponse = "commandResponse";
    }

    /**
     * 消息中属性key定义，集中定义和取用
     */
    interface MqMsgDefineKey{
        String MessageType = "messageType";
    }

}