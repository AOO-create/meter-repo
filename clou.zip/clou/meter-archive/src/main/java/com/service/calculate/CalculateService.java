package com.service.calculate;

import com.vo.calculateVo.CalculateFeeVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */
public interface CalculateService {
    Page<CalculateFeeVo> getAllCalculate(CalculateFeeVo calculateVo);

    boolean createCalculateOneType(CalculateFeeVo calculateFeeVo) throws Exception;

    boolean createCalculateTwoType(CalculateFeeVo calculateFeeVo) throws Exception;

    Map<String,String> getWaterValue(Long bdId, double waterConsumption);

}
