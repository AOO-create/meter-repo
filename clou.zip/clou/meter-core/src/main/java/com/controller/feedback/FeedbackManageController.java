package com.controller.feedback;

import com.common.Result;
import com.dto.FeedbackDTO;
import com.service.feedback.FeedbackManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuwei
 * @description
 * @date 2023/10/18
 */
@RestController
@RequestMapping("/core/feedbackManager")
public class FeedbackManageController {

    @Autowired
    private FeedbackManagerService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getFeedbackByUser")
    public Result getFeedbackByUser(@RequestParam("id") String id){
        return service.getFeedbackByUser(id);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getFeedback")
    public Result getFeedback(@RequestBody FeedbackDTO feedback){
        return service.getFeedback(feedback);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/replay")
    public Result replay(@RequestBody FeedbackDTO dto){
        return service.replay(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @RequestMapping("/getFeedbackAnalysisData")
    public Result getFeedbackAnalysisData(){
        return service.getFeedbackAnalysisData();
    }


}
