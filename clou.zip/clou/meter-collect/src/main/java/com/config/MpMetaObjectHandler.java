package com.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component //一定不要忘记把处理器加到IOC容器中
@Slf4j //开启Log4j日志
public class MpMetaObjectHandler implements MetaObjectHandler {
    //插入时的填充策略
    @Override
    public void insertFill(MetaObject metaObject) {
        log.info("start insert fill..");
        //第一个参数 字段名
        //第二个参数 值
        //第三个参数 metaObject
        this.setFieldValByName("deleted",0,metaObject);
        this.setFieldValByName("createTime",new Date(),metaObject);
        this.setFieldValByName("updateTime",new Date(),metaObject);
    }
    //更新时的填充策略
    @Override
    public void updateFill(MetaObject metaObject) {
        log.info("start update fill..");
        this.setFieldValByName("updateTime",new Date(),metaObject);
    }
}
