package com.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.equipment.FourthGenerationMeter;

public interface FourthGenerationMapper extends BaseMapper<FourthGenerationMeter> {
}