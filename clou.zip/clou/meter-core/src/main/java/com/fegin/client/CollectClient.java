package com.fegin.client;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.GradeDTO;
import com.dto.StatisticsDataDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name = "collect-provider", url = "${service-url.collect-provider}")
public interface CollectClient {

    @RequestMapping("/collect/equipment/dayData/statisticsSum")
    public Page<StatisticsDataDTO> statisticsSum(GradeDTO dto);
}
