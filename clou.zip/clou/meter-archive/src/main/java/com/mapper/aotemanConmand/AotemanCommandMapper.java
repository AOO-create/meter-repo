package com.mapper.aotemanConmand;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.command.AotemanSendCommand;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
public interface AotemanCommandMapper extends BaseMapper<AotemanSendCommand> {
}
