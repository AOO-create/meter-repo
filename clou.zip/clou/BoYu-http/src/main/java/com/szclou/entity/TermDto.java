package com.szclou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2023/8/17
 */
@Data
public class TermDto {
    private String  madeNo;
    private String instLoc;
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date instDate;//安装日期
    private String installStaff;
}
