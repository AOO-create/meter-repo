package com.mapper.systemSetup;

import com.entity.systemSetup.RoleUserRelation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface RoleUserRelationMapper extends BaseMapper<RoleUserRelation> {
}
