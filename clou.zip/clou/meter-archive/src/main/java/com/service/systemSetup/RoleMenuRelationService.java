package com.service.systemSetup;

import com.entity.systemSetup.RoleMenuRelation;
import com.vo.systemSetUpVo.RoleMenuRelationVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface RoleMenuRelationService extends IService<RoleMenuRelation> {
    Page<RoleMenuRelationVo> flagList(RoleMenuRelationVo vo);

    Boolean updateMenuPremitByType(RoleMenuRelationVo vo);

    Boolean updateMenuPremit(List<RoleMenuRelationVo> voList);
}
