package com.fegin.client;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.area.GradeDTO;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.area.Org;
import com.entity.Role;
import io.micrometer.core.instrument.Meter;
import org.apache.ibatis.annotations.Param;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "archive-provider", url = "${service-url.archive-provider}")
public interface ArchiveClient {
    @PostMapping("/archive/equipment/wiredMeter/getWiredDayData")
    public Page<MeterDayDataDTO> getWiredDayData(@RequestBody MeterDayDataDTO dto);

    @RequestMapping("/archive/grade/reGetChildGradeId")
    public List<String> reGetChildGradeId(@RequestParam(value = "areaId") String areaId, @RequestParam(value = "orgId") String orgId);

    @RequestMapping("/archive/grade/reGetChildBDGradeId")
    public List<String> reGetChildBDGradeId(@RequestParam(value = "tgBuildDoorplate") String tgBuildDoorplate, @RequestParam(value = "orgId") String orgId);

    @PostMapping("/archive/equipment/meterSetup/getDataDay")
    public Page<NBDTO> getDataDay(@RequestBody NBDTO dto);

    @RequestMapping("/archive/FourthMeterManage/getAllFourthDayData")
    public Page<MeterDayDataDTO> getAllFourthDayData(@RequestBody MeterDayDataDTO dto);

    @RequestMapping("/archive/ToCollect/getOrg")
    public Org getOrg();

    @RequestMapping("/archive/ToCollect/getRole")
    public Role getRole();

    @RequestMapping("/archive/ToCollect/getTgId")
    public String getTgId();

    @RequestMapping("/archive/ToCollect/getAreaId")
    public String getAreaId();


    @RequestMapping("/archive/ToCollect/websocket")
    public void sendMessage(@RequestParam(value = "userName") String userName ,@RequestParam(value = "message") String message);

    @RequestMapping("/archive/ToCollect/findGrade")
    public Page<GradeDTO> findGrade(@RequestBody GradeDTO dto);

    @RequestMapping("/archive/ToCollect/getAreaIdByName")
    public String getAreaIdByName(@RequestBody MeterDayDataDTO dto);

    @RequestMapping("/archive/ToCollect/getCL6904PapR")
    List<WiredMeterDTO> getCL6904PapR(@RequestParam(value = "id")String id , @RequestParam(value = "date") String dateString
            , @RequestParam(value = "currentPos") String currentPos, @RequestParam(value = "limit") String limit);

    @RequestMapping("/archive/ToCollect/getReportCl6904")
    int getReportCl6904(@RequestBody MeterDayDataDTO dto);

    @RequestMapping("/archive/ToCollect/getPapR")
    MeterDayDataDTO getPapR(@RequestParam("id") String id,@RequestParam("date") String date);
}
