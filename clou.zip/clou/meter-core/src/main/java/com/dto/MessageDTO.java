package com.dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/9/30
 */
@Data
public class MessageDTO {

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;//主键ID

    private String status;//阅读状态 1:已读 2：未读

    private String title;//标题

    private String content;//内容

    private String filename;//附件

    private String type;//消息类型，1：系统消息 2：通知消息  管理员发送即为系统，其他为通知

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;//创建时间


    private Long createUser;//创建人


    private Long recieveUser;//接收人

    private String recieveName;//接收人姓名

    private String createName;//创建人姓名

    private Long tgBuildDoorplate;

    private Long areaId;

    private Integer page;

    private String sendType;//发送用户住户2、组织区域1、全体成员0

    private Integer limit;

    private String identity;

    private String deal;

    private List<String> userIds;

    private List<String> tenantIds;
}
