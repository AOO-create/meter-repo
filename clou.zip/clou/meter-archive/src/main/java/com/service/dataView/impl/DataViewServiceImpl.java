package com.service.dataView.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.config.DynamicDataSource;
import com.dto.dataView.MeterPapR;
import com.dto.dataView.OperateRecordDTO;
import com.dto.dataView.CommonMapDTO;
import com.dto.equipment.MeterHourVo;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.MeterDayVo;
import com.dto.equipment.MeterMonthVo;
import com.entity.Org;
import com.entity.WiredReadHourData;
import com.entity.equipment.*;
import com.entity.organization.BDGrade;
import com.entity.organization.Grade;
import com.mapper.dataView.DataViewMapper;
import com.mapper.equipment.*;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.tenant.TenantMapper;
import com.service.dataView.DataViewService;
import com.service.dataView.DoorService;
import com.service.organization.GradeService;
import com.util.ShiroConstUtils;
import org.omg.PortableInterceptor.INACTIVE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
@Service
public class DataViewServiceImpl implements DataViewService {

    @Autowired
    private DataViewMapper dataViewMapper;

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    @Autowired
    private GradeService gradeService;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired
    private TermManagerMapper termManagerMapper;

    @Autowired
    private TenantMapper mapper;

    @Autowired
    private DoorService doorService;
    @Autowired
    private WaterMeterDayReadMapper dayReadMapper;
    @Autowired
    private DayMapper dayMapper;

    public static List<String> getDayByMonth() {
        List<String> data = new ArrayList<>();
        try {
            Calendar c = Calendar.getInstance();
            // 获取当前的年份
            int year = c.get(Calendar.YEAR);
            // 获取当前的月份（需要加1才是现在的月份）
            int month = c.get(Calendar.MONTH) + 1;
            // 获取本月的总天数
            // 定义时间格式
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            // 开始日期为当前年月拼接1号
            Date startDate = sdf.parse(year + "-" + month + "-01");
            // 结束日期为当前年月拼接该月最大天数
            Date endDate = new Date();
            // 设置calendar的开始日期
            c.setTime(startDate);
            // 当前时间小于等于设定的结束时间
            while (c.getTime().compareTo(endDate) <= 0) {
                String time = sdf.format(c.getTime());
                data.add(time);
                // 当前日期加1
                c.add(Calendar.DATE, 1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return data;
    }

    @Override
    public IPage<MeterDayVo> selectSumHourByAreaId(MeterDayVo dto) {
        String date = dto.getDataDate();
        List<BDGrade> list = new ArrayList<BDGrade>();
        String areaId = dto.getAreaId();
        String orgId = dto.getOrgId();
        if (!"".equals(dto.getAreaId())) {
            list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        } else {
            Long id = Long.parseLong(dto.getTgBuildDoorplate());
            list = doorService.getDoorById(list, id);
        }
        Iterator<BDGrade> iterator = list.iterator();
        while (iterator.hasNext()){
            BDGrade str = iterator.next();
            if(str.getParentId()==null){
                iterator.remove();
            }
        }
        IPage<MeterDayVo> page = new Page<MeterDayVo>(1, 30);
        List<String> meterList = new ArrayList<String>();
        String meterAddress = dto.getMeterAddress();

            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()+""));
                if (meter != null) {
                    meterList.add(meter.getMeterAddress());
                }
            });
            if (meterList.isEmpty()) {
                return null;
            }
        Calendar cal=Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        cal.add(Calendar.DATE,-1);
        String yesterday= sdf.format(cal.getTime())+" 00:00:00";
            page = dayMapper.selectSumHourByAreaId(yesterday, meterList, page);

        page.getRecords().forEach(item->{
            item.getRealSumFlow();
        });

        return page;
    }

    @Override
    public IPage<MeterDayVo> getDataByDay(MeterDayVo dto) {
        String date = dto.getDataDate();
        List<BDGrade> list = new ArrayList<BDGrade>();
        String areaId = dto.getAreaId();
        String orgId = dto.getOrgId();
        if (!"".equals(dto.getAreaId())) {
            list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        } else {
            Long id = Long.parseLong(dto.getTgBuildDoorplate());
            list = doorService.getDoorById(list, id);
        }
        Iterator<BDGrade> iterator = list.iterator();
        while (iterator.hasNext()){
            BDGrade str = iterator.next();
            if(str.getParentId()==null){
                iterator.remove();
            }
        }
        IPage<MeterDayVo> page = new Page<MeterDayVo>(dto.getPage(), dto.getLimit());
        List<String> meterList = new ArrayList<String>();
        String meterAddress = dto.getMeterAddress();

        if ("".equals(meterAddress) || meterAddress == null) {
            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()+""));
                if (meter != null) {


                    meterList.add(meter.getMeterAddress());
                }
            });
            if (meterList.isEmpty()) {
                return null;
            }
            page = dayMapper.selectPageByAreaId(date, meterList, page);
            BigDecimal result ;
            if(!page.getRecords().isEmpty()){
                result = page.getRecords().get(0).getRealSumFlow().multiply(new BigDecimal(page.getRecords().get(0).getOverride()));
                page.getRecords().get(0).setFlow(result);
            }
        } else {
            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()));
                meterList.add(meter.getMeterAddress());
            });
            Boolean b = meterList.contains(meterAddress);
            if (!b||meterList.isEmpty()) {
                return null;
            }
            page = dayMapper.selectPageByMeterAdder(date, meterAddress, page);
        }
        page.getRecords().forEach(item->{
            BigDecimal result = item.getRealSumFlow().multiply(new BigDecimal(item.getOverride()));
            item.setFlow(result);
            item.getRealSumFlow();
        });

        return page;
    }
    @Override
    public IPage<MeterDayVo> getSevenDataByDay(MeterDayVo meterDayVo) {
            String meterAddress  = meterDayVo.getMeterAddress();
            IPage<MeterDayVo> page= new Page<MeterDayVo>(meterDayVo.getPage(), meterDayVo.getLimit());
            List<MeterDayVo> list =new ArrayList<MeterDayVo>();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            for(int i=0;i<30;i++){
                Calendar cal=Calendar.getInstance();
                cal.add(Calendar.DATE,-i-1);
                String yesterday= sdf.format(cal.getTime());
                page = dayMapper.selectPageByMeterAdder(yesterday, meterAddress, page);
                if( page.getRecords().isEmpty()){
                    MeterDayVo meterDayVo1 =new  MeterDayVo();
                    meterDayVo1.setRealSumFlow(new BigDecimal(0));
                    meterDayVo1.setSevenDay(i);
                    meterDayVo1.setDataDate(yesterday);
                    list.add(meterDayVo1);
                }else {
                    page.getRecords().get(0).setSevenDay(i);
                    list.add(page.getRecords().get(0));
                }


            }
            if(list.size()<30){page.setRecords(list);return page;}
            for(int i=0;i<30;i++){
                BigDecimal difference =null;
                if(i==29){
                    difference = new BigDecimal(0);
//                    list.get(6) .setRealSumFlow(difference);
                }else {
                    BigDecimal bigDecimal1= list.get(i+1).getRealSumFlow();
                    BigDecimal bigDecimal2= list.get(i).getRealSumFlow();
                    difference = bigDecimal2.subtract(bigDecimal1);
                }
                list.get(i) .setRealSumFlow(difference);
            }
            page.setRecords(list);
            return page;
        }

    @Override
    public IPage<MeterHourVo> getTfourByHour(MeterDayVo meterDayVo) {
        String meterAddress  = meterDayVo.getMeterAddress();
        String dataDate  = meterDayVo.getDataDate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal=Calendar.getInstance();

        try {
            cal.setTime(sdf.parse(dataDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        cal.add(Calendar.DATE,-2);
        String yesterday= sdf.format(cal.getTime())+" 00:00:00";
        IPage<MeterHourVo> page= new Page<MeterHourVo>(meterDayVo.getPage(),24);
        List<MeterHourVo> list = page.getRecords();
        page= dayMapper.selectPageByHour(meterAddress,yesterday,page);
        if(page.getTotal()<24){page.setRecords(list);return page;}
        for(int i=0;i<23;i++){
            BigDecimal difference =null;
            BigDecimal bigDecimal1= page.getRecords().get(i+1).getRealSumFlow();
            BigDecimal bigDecimal2= page.getRecords().get(i).getRealSumFlow();
            difference = bigDecimal1.subtract(bigDecimal2);
            page.getRecords().get(i) .setRealSumFlow(difference);
        }
        page.getRecords().remove(23);
        MeterHourVo meterHourVo1 = page.getRecords().get(0);
        MeterHourVo meterHourVo0 = new MeterHourVo();
        for(int i=1;i<22;i++){
            page.getRecords().get(i).setRealSumFlow(page.getRecords().get(i+1).getRealSumFlow());
            page.getRecords().get(i).setHour(page.getRecords().get(i+1).getHour());
        }
        meterHourVo0.setRealSumFlow(new BigDecimal(0));
        meterHourVo0.setHour("00:00");
        page.getRecords().add(0,meterHourVo0);
        page.getRecords().set(1,meterHourVo1);
        page.getRecords().get(23).setHour("23:00");
        return page;
    }
    @Override
    public IPage<MeterDayVo> getIncDataByDay(MeterDayVo dto) {
        String date = dto.getDataDate();
        List<BDGrade> list = new ArrayList<BDGrade>();
        String areaId = dto.getAreaId();
        if (!"".equals(dto.getAreaId())) {
            list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        } else {
            Long id = Long.parseLong(dto.getTgBuildDoorplate());
            list = doorService.getDoorById(list, id);
        }

        IPage<MeterDayVo> page1 = new Page<MeterDayVo>(dto.getPage(), dto.getLimit());
        IPage<MeterDayVo> page2 = new Page<MeterDayVo>(dto.getPage(), dto.getLimit());
        List<String> meterList = new ArrayList<String>();
        String meterAddress = dto.getMeterAddress();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal=Calendar.getInstance();

        try {
            cal.setTime(sdf.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        cal.add(Calendar.DATE,-1);
        String yesterday= sdf.format(cal.getTime());
        cal.add(Calendar.DATE,-1);
        String yesterday2= sdf.format(cal.getTime());
        if ("".equals(meterAddress) || meterAddress == null) {
            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()+""));
                if (meter != null) {
                    meterList.add(meter.getMeterAddress());
                }
            });
            if (meterList.isEmpty()) {
                return null;
            }
            page1 = dayMapper.selectPageByAreaId(yesterday, meterList, page1);

//            page2 = dayMapper.selectPageByAreaId(yesterday, meterList, page2);
            List<MeterDayVo> records1= page1.getRecords();
            List<MeterDayVo> records2= new ArrayList<MeterDayVo>();

            for(MeterDayVo item :records1){
                MeterDayVo meterDayVo = new MeterDayVo();
                page2 =dayMapper.selectPageByMeterAdder(yesterday2, item.getMeterAddress(), page2);
                if( page2.getTotal()==0){
                    meterDayVo.setRealSumFlow(new BigDecimal(0.0));
                }else {
                    meterDayVo =    page2.getRecords().get(0);
                }

                records2.add(meterDayVo);
            }

            for(int i= 0 ;i<records2.size();i++){
                BigDecimal difference =null;
                if(records1.isEmpty()){
                    difference = records2.get(i).getRealSumFlow();
                }else {
                    BigDecimal bigDecimal1= records1.get(i).getRealSumFlow();
                    BigDecimal bigDecimal2= records2.get(i).getRealSumFlow();
                    difference = bigDecimal1.subtract(bigDecimal2);
                    BigDecimal result = difference.multiply(new BigDecimal(records1.get(i).getOverride()));
                    records1.get(i).setFlow(result);
                }

                records1.get(i) .setIncFlow(difference);
                page2.setRecords(records1);
                page2.setTotal(page1.getTotal());
            }
        } else {
            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()));
                meterList.add(meter.getMeterAddress());
            });
            Boolean b = meterList.contains(meterAddress);
            if (!b||meterList.isEmpty()) {
                return null;
            }
            page1 = dayMapper.selectPageByMeterAdder(date, meterAddress, page1);
            page2 = dayMapper.selectPageByMeterAdder(yesterday, meterAddress, page2);
            List<MeterDayVo> records1= page1.getRecords();
            List<MeterDayVo> records2= page2.getRecords();
            for(int i= 0 ;i<records2.size();i++){
                BigDecimal bigDecimal1= records1.get(i).getRealSumFlow();
                BigDecimal bigDecimal2= records2.get(i).getRealSumFlow();
                BigDecimal difference = bigDecimal1.subtract(bigDecimal2);
                BigDecimal result = difference.multiply(new BigDecimal(records2.get(i).getOverride()));
                page2.getRecords().get(i).setFlow(result);
                page2.getRecords().get(i) .setIncFlow(difference);
            }

        }

        return page2;
    }


    @Override
    public IPage<MeterHourVo> getDataByHour(MeterDayVo meterDayVo) {
        String meterAddress  = meterDayVo.getMeterAddress();
        String dataDate  = meterDayVo.getDataDate();
        IPage<MeterHourVo> page= new Page<MeterHourVo>(meterDayVo.getPage(), meterDayVo.getLimit());
        page= dayMapper.selectPageByHour(meterAddress,dataDate,page);
        return page;
    }

    @Override
    public IPage<MeterMonthVo> getDataByMonth(MeterMonthVo dto) {
        String date = dto.getDataDate()+"-01";
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            calendar.setTime(sdf.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        calendar.add(Calendar.MONTH,+1);
        String endDate= sdf.format(calendar.getTime());
        List<BDGrade> list = new ArrayList<BDGrade>();
        String areaId = dto.getAreaId();
        if (!"".equals(dto.getAreaId())) {
            list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        } else {
            Long id = Long.parseLong(dto.getTgBuildDoorplate());
            list = doorService.getDoorById(list, id);
        }

        IPage<MeterMonthVo> page = new Page<MeterMonthVo>(dto.getPage(), dto.getLimit());
        List<String> meterList = new ArrayList<String>();
        String meterAddress = dto.getMeterAddress();

        if ("".equals(meterAddress) || meterAddress == null) {
            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()));
                if (meter != null) {
                    meterList.add(meter.getMeterAddress());
                }
            });
            if (meterList.isEmpty()) {
                return null;
            }
            page = dayMapper.selectMonthByAreaId(date,endDate,  meterList, page);
        } else {
            list.forEach(item -> {
                WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()));
                meterList.add(meter.getMeterAddress());
            });
            Boolean b = meterList.contains(meterAddress);
            if (!b||meterList.isEmpty()) {
                return null;
            }
            page = dayMapper.selectMonthByMeterAdder(date,endDate, meterAddress, page);
        }
        return  page;
    }

    @Override
    public List<Double[]> getTitleNumber() {
        List<Double[]> list = new ArrayList<>();
        String orgId = "";
        String areaId = "";
        List<String> bdList = new ArrayList<>();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy-MM-dd");
        DecimalFormat df = new DecimalFormat("######0.000");

        if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
            //管理员差org
            orgId = shiroConstUtils.getOrg().getOrgId();
        } else if (shiroConstUtils.getTgBuildDoorplate() == null || shiroConstUtils.getTgBuildDoorplate().equals("")) {
            //普通用户组织区域用户查本组织区域下
            areaId = shiroConstUtils.getAreaId();
        } else {
            //楼栋单元
            bdList = gradeService.reGetChildBDGradeId(shiroConstUtils.getTgBuildDoorplate(), shiroConstUtils.getOrg().getOrgId(), bdList);
        }
        String ss = shiroConstUtils.getAreaId();
        List<String> meterId = new ArrayList<>();
        if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
            meterId = dataViewMapper.getAllMeterId();
        } else {
            meterId = getMeterIds(ss);
        }

        //cl818集中器下电表 -- 挂在cl6904库上
        DynamicDataSource.name.set("w");
        int oioElecReportValue = 0;
        if (meterId.size() != 0) {
            oioElecReportValue = dataViewMapper.getOioElecReport(meterId, simpleDateFormat.format(new Date()));
        }
        DynamicDataSource.name.set("r");

        //今日上报总记录数 vs 总表具安装数
        Double[] one = new Double[2];
        int meterSum = dataViewMapper.getMeterSum(orgId, areaId, bdList);
        int reportSum = dataViewMapper.getReportSum(orgId, areaId, simpleDateFormat.format(new Date()), bdList) + oioElecReportValue;
        one[1] = (double) meterSum;
        one[0] = (double) reportSum;

        //欠费用户总数 vs 总用户数
        Double[] two = new Double[2];
        int userSum = dataViewMapper.getUserSum(orgId, areaId, bdList);
        int feeSum = dataViewMapper.getFeeSum(orgId, areaId, bdList);
        two[0] = (double) feeSum;
        two[1] = (double) userSum;

        //电表总数量 vs 水表总数量
        Double[] three = new Double[2];
        int elecSum = dataViewMapper.getWireSumByMeterType(orgId, areaId, bdList, "4");
        int waterSum = dataViewMapper.getWaterSum(orgId, areaId, bdList);
        three[0] = (double) elecSum;
        three[1] = (double) waterSum;
        //电表今日上报率
        Double[] five = new Double[1];
        if (elecSum == 0) {
            five[0] = 0.00;
        } else {
            int reportElec = dataViewMapper.getElecReport(orgId, areaId, simpleDateFormat.format(new Date()), bdList) + oioElecReportValue;
            double elecRate = ((double) reportElec / (double) elecSum) * 100;
            five[0] = elecRate;
        }


        //水表今日上报率
        Double[] six = new Double[1];
        if (waterSum == 0) {
            six[0] = 0.00;
        } else {
            int reportWater = dataViewMapper.getWireReportSum(orgId, areaId, simpleDateFormat.format(new Date()), bdList) +
                    dataViewMapper.getNbReportSum(orgId, areaId, simpleDateFormat.format(new Date()), bdList);
            double rateWater = ((double) reportWater / (double) waterSum) * 100;
            six[0] = rateWater;
        }


        //集中器总数
        Double[] four = new Double[1];
        if (areaId.equals("") && orgId.equals("")) {
            areaId = shiroConstUtils.getAreaId();
        }
        int termSum = dataViewMapper.getTermSum(orgId, areaId);
        four[0] = (double) termSum;

        list.add(one);
        list.add(two);
        list.add(three);
        list.add(four);
        list.add(five);
        list.add(six);
        return list;
    }

    @Override
    public List<CommonMapDTO> getAreaTenantNumber() {
        List<CommonMapDTO> list = new ArrayList<>();
        Org org = shiroConstUtils.getOrg();
        String areaId = shiroConstUtils.getAreaId();
        String tgBuildDoorplate = shiroConstUtils.getTgBuildDoorplate();
        if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
            //管理员查看org下的area
            list = dataViewMapper.getOrgTenantNumber(org.getOrgId());
        } else {
            //非管理员查看
            if (null == tgBuildDoorplate || "".equals(tgBuildDoorplate)) {
                //该用户建立在组织区域上，查看该组织区域下一级门栋单元或房门号用户
                List<String> idList = dataViewMapper.getTgNameByAreaId(areaId);
                if (idList.size() != 0 && null != idList) {
                    //根据父亲节点找到所有子节点的用户
                    for (String id : idList) {
                        List<String> bdList = new ArrayList<>();
                        bdList = gradeService.reGetChildBDGradeId(id, org.getOrgId(), bdList);
                        CommonMapDTO tenantAreaNum = dataViewMapper.getRoomTenantNumber(id, bdList);
                        list.add(tenantAreaNum);
                    }
                }
            } else {
                //该用户建立在门栋单元上，查看下级房门号或门栋单元用户
                List<BDGrade> List = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                        .eq("parent_id", tgBuildDoorplate)
                        .or()
                        .eq("id", tgBuildDoorplate));
                if (List.size() != 0 && null != List) {
                    for (BDGrade bd : List) {
                        List<String> bdList = new ArrayList<>();
                        bdList = gradeService.reGetChildBDGradeId(bd.getId() + "", org.getOrgId(), bdList);
                        CommonMapDTO tenantAreaNum = dataViewMapper.getRoomTenantNumber(bd.getId() + "", bdList);
                        list.add(tenantAreaNum);
                    }
                }
            }
        }
        return list;
    }

    @Override
    public List<Double> getCollectRate() {
        List<Double> list = new ArrayList<>();
        double wireRate = 0D;
        double nbRate = 0D;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String orgId = "";
        String areaId = "";
        List<String> bdList = new ArrayList<>();
        if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
            //管理员
            orgId = shiroConstUtils.getOrg().getOrgId();
        } else if (shiroConstUtils.getTgBuildDoorplate().equals("") || shiroConstUtils.getTgBuildDoorplate() == null) {
            //组织区域的
            areaId = shiroConstUtils.getAreaId();
        } else {
            //门栋单元的
            bdList = gradeService.reGetChildBDGradeId(shiroConstUtils.getTgBuildDoorplate(), shiroConstUtils.getOrg().getOrgId(), bdList);
        }
        double wireMeterNumber = dataViewMapper.getWireSumByMeterType(orgId, areaId, bdList, "");
        double reportNumber = dataViewMapper.getWireReportSum(orgId, areaId, simpleDateFormat.format(new Date()), bdList);
        wireRate = (double) (reportNumber / wireMeterNumber);
        double nbMeterNumber = dataViewMapper.getNbSum(orgId, areaId, bdList);
        double nbReport = dataViewMapper.getNbReportSum(orgId, areaId, simpleDateFormat.format(new Date()), bdList);
        nbRate = (double) (nbReport / nbMeterNumber);
        list.add(wireRate);
        list.add(nbRate);
        return list;
    }

    @Override
    public List<int[]> getRecordOperate() {
        String orgId = "";
        String areaId = "";
        List<int[]> listArray = new ArrayList<>();
        if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
            orgId = shiroConstUtils.getOrg().getOrgId();
        } else {
            areaId = shiroConstUtils.getAreaId();
        }
        List<OperateRecordDTO> list = dataViewMapper.getRecordOperate(orgId, areaId);
        for (int i = 1; i <= 7; i++) {
            int[] a = new int[1];
            for (OperateRecordDTO dto : list) {
                if (dto.getOpType().equals(i + "")) {
                    a[0] = dto.getValue();
                }
            }
            listArray.add(a);
        }
        return listArray;
    }

    @Override
    public List<CommonMapDTO> getAreaMeter() {
        List<CommonMapDTO> list = new ArrayList<>();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String areaId = shiroConstUtils.getAreaId();
        String tgId = shiroConstUtils.getTgBuildDoorplate();
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        List<String> bdList = new ArrayList<>();

        if (roleCode.equals("admin")) {
            List<Grade> nameList = gradeMapper.selectList(new QueryWrapper<Grade>().eq("org_id", orgId));
            for (Grade grade : nameList) {
                CommonMapDTO dto = new CommonMapDTO();
                dto.setType("1");
                dto.setId(grade.getId() + "");
                dto.setName(grade.getAreaName());
                int nbSum = dataViewMapper.getNbSum(orgId, grade.getId() + "", null);
                int wireSum = dataViewMapper.getWireSumByMeterType(orgId, grade.getId() + "", null, "0");
                int elecSum = dataViewMapper.getWireSumByMeterType(orgId, grade.getId() + "", null, "4");
                int termSum = dataViewMapper.getTermSum(orgId, grade.getId() + "");
                dto.setTermValue(termSum);
                dto.setNbValue(nbSum);
                dto.setWireValue(wireSum);
                dto.setElecValue(elecSum);
                dto.setValue(nbSum + wireSum + elecSum);
                list.add(dto);
            }
        } else if ("".equals(tgId) || null == tgId) {
            List<BDGrade> nameList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>().eq("area_id", areaId).isNull("parent_id"));
            for (BDGrade bdGrade : nameList) {
                CommonMapDTO dto = new CommonMapDTO();
                dto.setType("2");
                dto.setId(bdGrade.getId() + "");
                dto.setName(bdGrade.getBdName());
                bdList = gradeService.reGetChildBDGradeId(bdGrade.getId() + "", orgId, new ArrayList<>());
                int nbSum = dataViewMapper.getNbSum(orgId, "", bdList);
                int wireSum = dataViewMapper.getWireSumByMeterType(orgId, "", bdList, "0");
                int elecSum = dataViewMapper.getWireSumByMeterType(orgId, "", bdList, "4");
                int termSum = dataViewMapper.getTermSum(orgId, areaId);
                dto.setTermValue(termSum);
                dto.setTermValue(termSum);
                dto.setNbValue(nbSum);
                dto.setWireValue(wireSum);
                dto.setElecValue(elecSum);
                dto.setValue(nbSum + wireSum + elecSum);
                list.add(dto);
            }
        } else {
            List<BDGrade> nameList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                    .eq("parent_id", tgId)
                    .or()
                    .eq("id", tgId));
            for (BDGrade bdGrade : nameList) {
                CommonMapDTO dto = new CommonMapDTO();
                dto.setType("2");
                dto.setId(bdGrade.getId() + "");
                dto.setName(bdGrade.getBdName());
                bdList = gradeService.reGetChildBDGradeId(bdGrade.getId() + "", orgId, new ArrayList<>());
                int wireSum = dataViewMapper.getWireSumByMeterType(orgId, "", bdList, "0");
                int nbSum = dataViewMapper.getNbSum(orgId, "", bdList);
                int elecSum = dataViewMapper.getWireSumByMeterType(orgId, "", bdList, "4");
                int termSum = dataViewMapper.getTermSum(orgId, areaId);
                dto.setTermValue(termSum);
                dto.setNbValue(nbSum);
                dto.setWireValue(wireSum);
                dto.setElecValue(elecSum);
                dto.setValue(nbSum + wireSum + elecSum);
                list.add(dto);
            }
        }
        return list;
    }

    @Override
    public List<CommonMapDTO> getReportRate() {
        List<CommonMapDTO> list = getAreaMeter();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        int reportSum = 0;
        int nbReportValue = 0;
        int wireReportValue = 0;
        int elecReportValue = 0;
        int yesNbReportValue = 0;
        int yesWireReportValue = 0;
        int yesElecReportValue = 0;
        int yesReportSum = 0;
        for (CommonMapDTO dto : list) {
            List<String> ids = new ArrayList<>();
            Date yseterday = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
            if (dto.getType().equals("2")) {
                ids = gradeService.reGetChildBDGradeId(dto.getId(), orgId, ids);
                String areaId = bdGradeMapper.selectById(dto.getId()).getAreaId();
                List<String> meterId = getMeterIds(areaId);

                //cl818集中器下电表 -- 挂在cl6904库上
                DynamicDataSource.name.set("w");
                int oioElecReportValue = 0;
                if (meterId.size() != 0) {
                    oioElecReportValue = dataViewMapper.getOioElecReport(meterId, simpleDateFormat.format(new Date()));
                }
                DynamicDataSource.name.set("r");

                nbReportValue = dataViewMapper.getNbReportSum(orgId, "", simpleDateFormat.format(new Date()), ids);
                wireReportValue = dataViewMapper.getWireReportSum(orgId, "", simpleDateFormat.format(new Date()), ids);
                //cl818集中器下电表 -- 挂在cl6904库上
                elecReportValue = dataViewMapper.getElecReport(orgId, "", simpleDateFormat.format(new Date()), ids) + oioElecReportValue;
                reportSum = dataViewMapper.getReportSum(orgId, "", simpleDateFormat.format(new Date()), ids) + oioElecReportValue;

                DynamicDataSource.name.set("w");
                int yesOioElecReportValue = 0;
                if (meterId.size() != 0) {
                    yesOioElecReportValue = dataViewMapper.getOioElecReport(meterId, simpleDateFormat.format(yseterday));
                }
                DynamicDataSource.name.set("r");
                yesNbReportValue = dataViewMapper.getNbReportSum(orgId, "", simpleDateFormat.format(yseterday), ids);
                yesWireReportValue = dataViewMapper.getWireReportSum(orgId, "", simpleDateFormat.format(yseterday), ids);
                yesElecReportValue = dataViewMapper.getElecReport(orgId, "", simpleDateFormat.format(yseterday), ids) + yesOioElecReportValue;
                yesReportSum = dataViewMapper.getReportSum(orgId, "", simpleDateFormat.format(yseterday), ids) + yesOioElecReportValue;
            } else if (dto.getType().equals("1")) {
                List<String> meterId = getMeterIds(dto.getId());
                //cl818集中器下电表 -- 挂在cl6904库上
                DynamicDataSource.name.set("w");
                int oioElecReportValue = 0;
                if (meterId.size() != 0) {
                    dataViewMapper.getOioElecReport(meterId, simpleDateFormat.format(new Date()));
                }
                DynamicDataSource.name.set("r");

                reportSum = dataViewMapper.getReportSum(orgId, dto.getId(), simpleDateFormat.format(new Date()), null) + oioElecReportValue;
                nbReportValue = dataViewMapper.getNbReportSum(orgId, dto.getId(), simpleDateFormat.format(new Date()), null);
                wireReportValue = dataViewMapper.getWireReportSum(orgId, dto.getId(), simpleDateFormat.format(new Date()), null);
                elecReportValue = dataViewMapper.getElecReport(orgId, dto.getId(), simpleDateFormat.format(new Date()), null) + oioElecReportValue;

                DynamicDataSource.name.set("w");
                int yesOioElecReportValue = 0;
                if (meterId.size() != 0) {
                    yesOioElecReportValue = dataViewMapper.getOioElecReport(meterId, simpleDateFormat.format(yseterday));
                }
                DynamicDataSource.name.set("r");
                yesNbReportValue = dataViewMapper.getNbReportSum(orgId, dto.getId(), simpleDateFormat.format(yseterday), null);
                yesWireReportValue = dataViewMapper.getWireReportSum(orgId, dto.getId(), simpleDateFormat.format(yseterday), null);
                yesElecReportValue = dataViewMapper.getElecReport(orgId, dto.getId(), simpleDateFormat.format(yseterday), null) + yesOioElecReportValue;
                yesReportSum = dataViewMapper.getReportSum(orgId, dto.getId(), simpleDateFormat.format(yseterday), null) + yesOioElecReportValue;
            }
            dto.setReportValue(reportSum);
            dto.setNbReportValue(nbReportValue);
            dto.setElecReportValue(elecReportValue);
            dto.setWireReportValue(wireReportValue);
            dto.setYesNbReportValue(yesNbReportValue);
            dto.setYesWireReportValue(yesWireReportValue);
            dto.setYesElecReportValue(yesElecReportValue);
            dto.setYesReportSum(yesReportSum);
        }
        return list;
    }

    public List<String> getMeterIds(String areaId) {
        List<Term> termList = termManagerMapper.selectList(new QueryWrapper<Term>()
                .eq("area_id", areaId).eq("model_type", "1"));
        if (null == termList || termList.size() == 0) {
            return new ArrayList<>();
        }
        List<String> address = new ArrayList<>();
        termList.forEach(val -> {
            address.add(val.getAddress());
        });
        List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                .in("term_id", address));
        if (null == wiredMeterList || wiredMeterList.size() == 0) {
            return new ArrayList<>();
        }
        List<String> wiredMeterIds = new ArrayList<>();
        wiredMeterList.forEach(val -> wiredMeterIds.add(val.getId() + ""));
        return dataViewMapper.getMeterId(wiredMeterIds);
    }

    @Override
    public CommonMapDTO getRateData() {
        //1、获取从月初到今天的所有日期，调用方法查询上报总数，查询所有，获得rate
        CommonMapDTO dto = new CommonMapDTO();
        List<String> list = getDayByMonth();
        List<Double> rateList = new ArrayList<>();
        List<Integer> sumMeter = new ArrayList<>();
        List<Integer> reportMeter = new ArrayList<>();
        String orgId = "";
        String areaId = "";
        List<String> bdList = new ArrayList<>();
        if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
            //管理员差org
            orgId = shiroConstUtils.getOrg().getOrgId();
        } else if (shiroConstUtils.getTgBuildDoorplate() == null || shiroConstUtils.getTgBuildDoorplate().equals("")) {
            //普通用户组织区域用户查本组织区域下
            areaId = shiroConstUtils.getAreaId();
        } else {
            //楼栋单元
            bdList = gradeService.reGetChildBDGradeId(shiroConstUtils.getTgBuildDoorplate(), shiroConstUtils.getOrg().getOrgId(), bdList);
        }

        for (String date : list) {
            String ss = shiroConstUtils.getAreaId();
            List<String> meterId = new ArrayList<>();
            if (shiroConstUtils.getRole().getRoleCode().equals("admin")) {
                meterId = dataViewMapper.getAllMeterId();
            } else {
                meterId = getMeterIds(ss);
            }

            //cl818集中器下电表 -- 挂在cl6904库上
            DynamicDataSource.name.set("w");
            int oioElecReportValue = 0;
            if (meterId.size() != 0) {
                oioElecReportValue = dataViewMapper.getOioElecReport(meterId, date);
            }
            DynamicDataSource.name.set("r");

            int reportSum = dataViewMapper.getReportSum(orgId, areaId, date, bdList) + oioElecReportValue;
            int meterSum = dataViewMapper.getMeterSumByDate(orgId, areaId, bdList, date);
            double aa = 0D;
            if (meterSum != 0 && reportSum != 0) {
                aa = Double.parseDouble(reportSum + "") / Double.parseDouble(meterSum + "");
            }
            reportMeter.add(reportSum);
            rateList.add(aa);
            sumMeter.add(meterSum);
        }
        dto.setReportMeter(reportMeter);
        dto.setSumMeter(sumMeter);
        dto.setRateList(rateList);
        return dto;
    }

    @Override
    public CommonMapDTO getDosage() {
        String areaId = shiroConstUtils.getAreaId();
        String tgId = shiroConstUtils.getTgBuildDoorplate();
        String roleCode = shiroConstUtils.getRole().getRoleCode();

        DecimalFormat df = new DecimalFormat("######0.000");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH, -1);
        Date smallMonthDate = calendar.getTime();
        String monthDateSmall = dateFormat.format(smallMonthDate);
        String monthDate = dateFormat.format(new Date());

        List<WNB> wnbs = new ArrayList<>();
        List<WiredMeter> wiredMeterList = new ArrayList<>();
        List<WiredMeter> elecMeterList = new ArrayList<>();
        if (roleCode.equals("admin")) {
            //管理员查看所有
            wnbs = nBmeterMapper.selectList(null);
            wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>().eq("meter_type", "0"));
            elecMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>().eq("meter_type", "4"));
        } else if ("".equals(tgId)) {
            //组织区域查看下面所有单元门栋
            wnbs = nBmeterMapper.selectList(new QueryWrapper<WNB>().eq("area_id", areaId));
            wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>().eq("meter_type", "0")
                    .eq("area_id", areaId));
            elecMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>().eq("meter_type", "4")
                    .eq("area_id", areaId));
        } else {
            //递归遍历所有子门栋单元，查看下面所有
            List<String> bdIds = gradeService.reGetChildBDGradeId(tgId, shiroConstUtils.getOrg().getOrgId(), new ArrayList<>());
            wnbs = nBmeterMapper.selectList(new QueryWrapper<WNB>().in("tg_build_doorplate", bdIds));
            wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                    .eq("meter_type", "0").in("tg_build_doorplate", bdIds));
            elecMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                    .eq("meter_type", "4").in("tg_build_doorplate", bdIds));
        }
        //用水总量 ：包含NB水表用水、有线冷水水表用水。本月截止至当前日期
        double waterConsumption = 0d;
        double elecConsumption = 0d;
        //NB水表用水量
        for (WNB wnb : wnbs) {
            MeterDayDataDTO meterDayDataDTOBig = mapper.getNBDay(wnb.getImei(), monthDate);
            MeterDayDataDTO meterDayDataDTOSmall = mapper.getNBDay(wnb.getImei(), monthDateSmall);
            double realSumFlow;
            if (null != meterDayDataDTOBig && null != meterDayDataDTOSmall) {
                //本月上月都存在
                realSumFlow = Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) - Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow());
                realSumFlow = Double.parseDouble(df.format(realSumFlow));
                waterConsumption = waterConsumption + realSumFlow;
            }
        }
        //有线冷水水表用水量
        for (WiredMeter wiredMeter : wiredMeterList) {
            MeterDayDataDTO meterDayDataDTOBig = mapper.getWiredDay(wiredMeter.getMeterAddress(), wiredMeter.getTermId(), monthDate);
            MeterDayDataDTO meterDayDataDTOSmall = mapper.getWiredDay(wiredMeter.getMeterAddress(), wiredMeter.getTermId(), monthDateSmall);
            double realSumFlow = 0d;
            if (null != meterDayDataDTOBig && null != meterDayDataDTOSmall) {
                realSumFlow = Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) - Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow());
                realSumFlow = Double.parseDouble(df.format(realSumFlow));
                waterConsumption = waterConsumption + realSumFlow;
            }
        }

        //有线电表用电量
        for (WiredMeter wiredMeter : elecMeterList) {
            MeterDayDataDTO meterDayDataDTOBig = mapper.getWiredDay(wiredMeter.getMeterAddress(), wiredMeter.getTermId(), monthDate);
            MeterDayDataDTO meterDayDataDTOSmall = mapper.getWiredDay(wiredMeter.getMeterAddress(), wiredMeter.getTermId(), monthDateSmall);
            double realSumFlow = 0d;
            if (null != meterDayDataDTOBig && null != meterDayDataDTOSmall) {
                realSumFlow = Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) - Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow());
                realSumFlow = Double.parseDouble(df.format(realSumFlow));
                elecConsumption = waterConsumption + realSumFlow;
            }
        }

        CommonMapDTO dto = new CommonMapDTO();
        dto.setUseElec(elecConsumption);
        dto.setUseWater(waterConsumption);
        return dto;
    }

    @Override
    public List<MeterDayVo> searchData(MeterDayVo meterDayVo) {

        Integer dayType = meterDayVo.getDayType();
        List<String> conList = new ArrayList<String>();
        Calendar cal=Calendar.getInstance();
        List<String> meterList = new ArrayList<String>();
        List<String> dateList = new ArrayList<String>();
        List<MeterDayVo> result= new ArrayList<MeterDayVo>();
        for (int i =1;i<=dayType;i++){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            cal.add(Calendar.DATE,-1);
            String yesterday= sdf.format(cal.getTime());
            conList.add(yesterday);
        }
        Collections.reverse(conList);
        List<BDGrade> list = new ArrayList<BDGrade>();
        String areaId = meterDayVo.getAreaId();
        list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        if (!"".equals(meterDayVo.getAreaId())) {
            list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        } else {
            Long id = Long.parseLong(meterDayVo.getTgBuildDoorplate());
            list = doorService.getDoorById(list, id);
        }
        list.forEach(item -> {
            WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()));
            if (meter != null) {
                meterList.add(meter.getMeterAddress());
            }
        });
        for(int i = 0;i<conList.size();i++){
            MeterDayVo meterDayVo1 = dayMapper.selectSumDataByMeter(conList.get(i), meterList);
            result.add(meterDayVo1);
        }
        return result;
    }



    @Override
    public List<MeterDayVo> searchHourData(MeterDayVo dto) {
        Integer timeType = dto.getTimeType();
        List<String> conList = new ArrayList<String>();
        for (int i =0 ;i<(timeType+1)*6;i++){

            String hourString="";
            if(i<10){
                hourString = "0"+i+":00";
            }else {
                hourString = i+":00";
            }
            conList.add(hourString);
        }
        List<BDGrade> list = new ArrayList<BDGrade>();
        String areaId = dto.getAreaId();
        if (!"".equals(dto.getAreaId())) {
            list = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getAreaId, areaId));
        } else {
            Long id = Long.parseLong(dto.getTgBuildDoorplate());
            list = doorService.getDoorById(list, id);
        }
        List<String> meterList = new ArrayList<String>();
        String meterAddress = dto.getMeterAddress();

        list.forEach(item -> {
            WiredMeter meter = wiredMeterMapper.selectOne(new LambdaQueryWrapper<WiredMeter>().eq(WiredMeter::getTgBuildDoorplate, item.getId()));
            if (meter != null) {
                meterList.add(meter.getMeterAddress());
            }
        });
        IPage<MeterDayVo> page = new Page<MeterDayVo>(1, 30);
        Calendar cal=Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        cal.add(Calendar.DATE,-1);
        String yesterday= sdf.format(cal.getTime())+" 00:00:00";
        page = dayMapper.selectSumHourByAreaIdTu(yesterday, meterList,conList, page);
        if(page.getRecords().size()==0){
            cal.add(Calendar.DATE,-2);
            String yesterday2= sdf.format(cal.getTime())+" 00:00:00";
            page = dayMapper.selectSumHourByAreaIdTu(yesterday2, meterList, conList,page);
        }
        return  page.getRecords();
    }
//这个方法有问题，需要重新写这个放啊
//    @Override
//    public List<MeterPapR> searchHourData(MeterPapR dto) {
//        String timeType = dto.getTimeType();
//        String areaId = dto.getAreaId();
//        String tgId = dto.getTgBuildDoorplate();
//        String timeString = dto.getTimeString();
//        List<MeterPapR> result = new ArrayList<>();
//        //昨天的数据,显示24小时数
//        if (timeType.equals("0")) {
//            String date = getNearlyOneMouth().get(getNearlyOneMouth().size() - 1);
//
//            if (shiroConstUtils.getRole().getRoleCode().equals("admin") && areaId.equals("") && tgId.equals("")) {
//                //查所有相加
//                MeterPapR papR = dataViewMapper.getAllPapR(date);
//                result.add(papR);
//            } else {
//                if (areaId.equals("") && tgId.equals("")) {
//                    //查当前登录用户
//                    List<String> wiredMeterIds = new ArrayList<>();
//                    List<String> bdIds = new ArrayList<>();
//                    if (shiroConstUtils.getTgBuildDoorplate().equals("") || null == shiroConstUtils.getTgBuildDoorplate()) {
//                        areaId = shiroConstUtils.getAreaId();
//                    } else {
//                        tgId = shiroConstUtils.getTgBuildDoorplate();
//                        bdIds = gradeService.reGetChildBDGradeId(tgId, shiroConstUtils.getOrg().getOrgId(), new ArrayList<>());
//                    }
//                    wiredMeterIds = dataViewMapper.getWiredMeterIds(areaId, bdIds);
//                    if (null == wiredMeterIds || wiredMeterIds.size() == 0) {
//                        return result;
//                    }
//                    MeterPapR papR = dataViewMapper.getPapR(date, wiredMeterIds);
//                    result.add(papR);
//                } else if (!areaId.equals("") && tgId.equals("")) {
//                    List<String> wiredMeterIds = dataViewMapper.getWiredMeterIds(areaId, null);
//                    if (null == wiredMeterIds || wiredMeterIds.size() == 0) {
//                        return result;
//                    }
//                    MeterPapR papR = dataViewMapper.getPapR(date, wiredMeterIds);
//                    result.add(papR);
//                } else if (areaId.equals("") && !tgId.equals("")) {
//                    List<String> bdIds = gradeService.reGetChildBDGradeId(tgId, shiroConstUtils.getOrg().getOrgId(), new ArrayList<>());
//                    List<String> wiredMeterIds = dataViewMapper.getWiredMeterIds("", bdIds);
//                    if (null == wiredMeterIds || wiredMeterIds.size() == 0) {
//                        return result;
//                    }
//                    MeterPapR papR = dataViewMapper.getPapR(date, wiredMeterIds);
//                    result.add(papR);
//                }
//            }
//        } else { //最近7天时段值，解析时段
//            List<String> date = new ArrayList<>();
//            if (timeType.equals("1")) {
//                date = getNearlySevenDayDates();
//            } else if (timeType.equals("2")) {
//                date = getNearlyOneMouth();
//            }
//
//            List<String> time = Arrays.asList(timeString.split(";"));
//            if (shiroConstUtils.getRole().getRoleCode().equals("admin") && areaId.equals("") && tgId.equals("")) {
//                List<MeterPapR> papR = new ArrayList<>();
//                List<String> finalDate = date;
//                time.forEach(val -> {
//                    MeterPapR papR1 = new MeterPapR();
//                    String[] str = val.split("-");
//                    String one = "papr_" + str[0];
//                    String two = "papr_" + str[1];
//                    Double sumNum = 0d;
//                    List<String> pap = new ArrayList<>();
//                    for (String dd : finalDate) {
//                        sumNum = dataViewMapper.getAllTimePapR(dd, one, two);
//                        pap.add(sumNum + "");
//                    }
//                    papR1.setListPapR(pap);
//                    papR1.setDateList(finalDate);
//                    papR.add(papR1);
//                });
//                //查所有相加
//                result.addAll(papR);
//            } else {
//                if (areaId.equals("") && tgId.equals("")) {
//                    //查当前登录用户
//                    List<String> wiredMeterIds = new ArrayList<>();
//                    List<String> bdIds = new ArrayList<>();
//                    if (shiroConstUtils.getTgBuildDoorplate().equals("") || null == shiroConstUtils.getTgBuildDoorplate()) {
//                        areaId = shiroConstUtils.getAreaId();
//                    } else {
//                        tgId = shiroConstUtils.getTgBuildDoorplate();
//                        bdIds = gradeService.reGetChildBDGradeId(tgId, shiroConstUtils.getOrg().getOrgId(), new ArrayList<>());
//                    }
//                    wiredMeterIds = dataViewMapper.getWiredMeterIds(areaId, bdIds);
//                    if (null == wiredMeterIds || wiredMeterIds.size() == 0) {
//                        return result;
//                    }
//                    List<MeterPapR> papR = new ArrayList<>();
//                    List<String> finalWiredMeterIds = wiredMeterIds;
//                    List<String> finalDate1 = date;
//                    time.forEach(val -> {
//                        MeterPapR papR1 = new MeterPapR();
//                        String[] str = val.split("-");
//                        String one = "papr_" + str[0];
//                        String two = "papr_" + str[1];
//                        Double sumNum = 0d;
//                        List<String> pap = new ArrayList<>();
//                        for (String dd : finalDate1) {
//                            sumNum = dataViewMapper.getTimePapR(dd, one, two, finalWiredMeterIds);
//                            pap.add(sumNum + "");
//                        }
//                        papR1.setListPapR(pap);
//                        papR1.setDateList(finalDate1);
//                        papR.add(papR1);
//                    });
//                    result.addAll(papR);
//                } else if (!areaId.equals("") && tgId.equals("")) {
//                    List<String> wiredMeterIds = dataViewMapper.getWiredMeterIds(areaId, null);
//                    if (null == wiredMeterIds || wiredMeterIds.size() == 0) {
//                        return result;
//                    }
//                    List<MeterPapR> papR = new ArrayList<>();
//                    List<String> finalDate2 = date;
//                    time.forEach(val -> {
//                        MeterPapR papR1 = new MeterPapR();
//                        String[] str = val.split("-");
//                        String one = "papr_" + str[0];
//                        String two = "papr_" + str[1];
//                        Double sumNum = 0d;
//                        List<String> pap = new ArrayList<>();
//                        for (String dd : finalDate2) {
//                            sumNum = dataViewMapper.getTimePapR(dd, one, two, wiredMeterIds);
//                            pap.add(sumNum + "");
//                        }
//                        papR1.setListPapR(pap);
//                        papR1.setDateList(finalDate2);
//                        papR.add(papR1);
//                    });
//                    result.addAll(papR);
//                } else if (areaId.equals("") && !tgId.equals("")) {
//                    List<String> bdIds = gradeService.reGetChildBDGradeId(tgId, shiroConstUtils.getOrg().getOrgId(), new ArrayList<>());
//                    List<String> wiredMeterIds = dataViewMapper.getWiredMeterIds("", bdIds);
//                    if (null == wiredMeterIds || wiredMeterIds.size() == 0) {
//                        return result;
//                    }
//                    List<MeterPapR> papR = new ArrayList<>();
//                    List<String> finalDate3 = date;
//                    time.forEach(val -> {
//                        MeterPapR papR1 = new MeterPapR();
//                        String[] str = val.split("-");
//                        String one = "papr_" + str[0];
//                        String two = "papr_" + str[1];
//                        Double sumNum = 0d;
//                        List<String> pap = new ArrayList<>();
//                        for (String dd : finalDate3) {
//                            sumNum = dataViewMapper.getTimePapR(dd, one, two, wiredMeterIds);
//                            pap.add(sumNum + "");
//                        }
//                        papR1.setListPapR(pap);
//                        papR1.setDateList(finalDate3);
//                        papR.add(papR1);
//                    });
//                    result.addAll(papR);
//                }
//            }
//        }
//        return result;
//    }


    /**
     * 最近一个月的所有日期
     *
     * @return
     */
    public List<String> getNearlyOneMouth() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        // 过去一月
        c.setTime(new Date(new Date().getTime() - 1000 * 24 * 60 * 60));
        String today = format.format(new Date(new Date().getTime() - 1000 * 24 * 60 * 60));
        c.add(Calendar.MONTH, -1);
        Date m = c.getTime();
        String mon = format.format(m);
        List<String> result = getBetweenDates(mon, today, false);

        return result;
    }

    /**
     * 最近七天的所有日期
     *
     * @return
     */
    public List<String> getNearlySevenDayDates() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        // 过去一月
        c.setTime(new Date(new Date().getTime() - 1000 * 24 * 60 * 60));
        String today = format.format(new Date(new Date().getTime() - 1000 * 24 * 60 * 60));
        c.add(Calendar.DATE, -7);
        Date m = c.getTime();
        String mon = format.format(m);
        List<String> result = getBetweenDates(mon, today, false);

        return result;
    }

    /**
     * 最近一年的所有日期
     *
     * @return
     */
    public List<String> getNearlyThreeMonthDates() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        // 过去一月
        c.setTime(new Date(new Date().getTime() - 1000 * 24 * 60 * 60));
        String today = format.format(new Date(new Date().getTime() - 1000 * 24 * 60 * 60));
        c.add(Calendar.MONTH, -3);
        Date m = c.getTime();
        String mon = format.format(m);
        List<String> result = getBetweenDates(mon, today, false);

        return result;
    }

    /**
     * 补全给定起止时间区间内的所有日期
     *
     * @param startTime
     * @param endTime
     * @param isIncludeStartTime
     * @return
     */
    public List<String> getBetweenDates(String startTime, String endTime, boolean isIncludeStartTime) {
        List<String> result = new ArrayList<>();
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            // 定义起始日期
            Date d1 = new SimpleDateFormat("yyyy-MM-dd").parse(startTime);
            // 定义结束日期 可以去当前月也可以手动写日期。
            Date d2 = new SimpleDateFormat("yyyy-MM-dd").parse(endTime);
            // 定义日期实例
            Calendar dd = Calendar.getInstance();
            // 设置日期起始时间
            dd.setTime(d1);
            if (isIncludeStartTime) {
                result.add(format.format(d1));
            }
            // 判断是否到结束日期
            while (dd.getTime().before(d2)) {
                // 进行当前日期加1
                dd.add(Calendar.DATE, 1);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String str = sdf.format(dd.getTime());
                result.add(str);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
