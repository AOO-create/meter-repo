package com.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.equipment.*;
import com.entity.equipment.Term;
import com.fegin.client.ArchiveClient;
import com.dto.area.GradeDTO;
import com.entity.area.BDGrade;
import com.entity.area.Grade;
import com.entity.area.Org;
import com.entity.equipment.WNB;
import com.entity.equipment.WiredMeter;
import com.mapper.area.BDGradeMapper;
import com.mapper.area.GradeMapper;
import com.mapper.equipment.DayDataManagerMapper;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.TermMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.service.DayDataManagerService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
@Service
public class DayDataManagerServiceImpl implements DayDataManagerService {

    @Autowired
    private DayDataManagerMapper mapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired
    private TermMapper termMapper;

    @Autowired
    private ArchiveClient archiveClient;

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Override
    public Map<String, Page<MeterDayDataDTO>> getAllDayData(MeterDayDataDTO dto) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        String dateString = formatter.format(dto.getDataDate());
        dto.setDataDate(formatter.parse(dateString));
        Org org = archiveClient.getOrg();
        dto.setOrgId(org.getOrgId());
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        Map<String, Page<MeterDayDataDTO>> map = new HashMap<>();

        if(dto.getMeterType() == 2){
            //先查询有线表日数据
            Page<MeterDayDataDTO> wireData = archiveClient.getWiredDayData(dto);
            map.put("wired",wireData);
        }else if(dto.getMeterType() == 1){
            //查询电表日冻结数据
            Page<MeterDayDataDTO> page = archiveClient.getWiredDayData(dto);
            map.put("elec",page);
        }else if(dto.getMeterType() == 0){
            //查询NB表日数据
            NBDTO nbdto = new NBDTO();
            nbdto.setOrgId(org.getOrgId());

            nbdto.setTgBuildDoorplate(dto.getTgBuildDoorplate());
            nbdto.setDataDate(dateString);
            nbdto.setPage(dto.getPage());
            nbdto.setLimit(dto.getLimit());
            nbdto.setAreaId(dto.getAreaId());
            nbdto.setInstLoc(dto.getInstLoc());
            nbdto.setMeterAddress(dto.getMeterAddress());
            Page<NBDTO> nbData = archiveClient.getDataDay(nbdto);

            Page<MeterDayDataDTO> nbRealData = new Page<>();

            List<MeterDayDataDTO> list = new ArrayList<>();
            if(nbData.getRecords() == null || nbData.getRecords().size() == 0){
                nbRealData.setRecords(null);
                nbRealData.setTotal(0);
            }else{
                for(NBDTO nbdto1 : nbData.getRecords()){
                    MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                    meterDayDataDTO.setMeterAddress(nbdto1.getMeterAddress());
                    meterDayDataDTO.setInstLoc(nbdto1.getInstLoc());
                    meterDayDataDTO.setName(nbdto1.getName());
                    meterDayDataDTO.setBdNo(nbdto1.getTgBuildDoorplate());
                    Date dataDate = formatter.parse(nbdto1.getDataDate() + " 00:00:00");
                    formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date collTime = formatter.parse(nbdto1.getCollTime());
                    meterDayDataDTO.setCollTime(collTime);
                    meterDayDataDTO.setDataDate(dataDate);

                    meterDayDataDTO.setUpdTime(nbdto1.getUpdTime());
                    meterDayDataDTO.setRealSumFlow(nbdto1.getRealSumFlow());
                    meterDayDataDTO.setEcl(nbdto1.getEcl());
                    meterDayDataDTO.setRsrp(nbdto1.getRsrp());
                    meterDayDataDTO.setSnr(nbdto1.getSnr());
                    meterDayDataDTO.setCsq(nbdto1.getCsq());
                    meterDayDataDTO.setWaterCurrentDate(nbdto1.getWaterCurrentDate());
                    meterDayDataDTO.setRunStatus(nbdto1.getRunStatus());
                    list.add(meterDayDataDTO);
                }
                nbRealData.setRecords(list);
                nbRealData.setTotal(nbData.getTotal());
            }
            map.put("nb",nbRealData);
        }else if(dto.getMeterType() == 3){
            //查询4G水表日数据
            Page<MeterDayDataDTO> fourthData = archiveClient.getAllFourthDayData(dto);
            map.put("fourth",fourthData);
        }
        return map;
    }


    @Transactional
    @Override
    public void ExcelDayDataIn(List<MeterDayDataDTO> list,String meterType) {
        switch (meterType){
            case "0":{
                //NB批量插入
                mapper.BatchInsertNB(list);
                break;
            }
            case "2":{
                mapper.BatchInsertWired(list);
                break;
            }
            default:break;
        }
    }

    @Override
    public Page<MeterDayDataDTO> getDataByDay(MeterDayDataDTO dto) {
        Org org = archiveClient.getOrg();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        String dateString = formatter.format(dto.getDataDate());
        NBDTO nbdto = new NBDTO();
        nbdto.setOrgId(org.getOrgId());
        nbdto.setDataDate(dateString);
        nbdto.setPage(dto.getPage());
        nbdto.setLimit(dto.getLimit());

        nbdto.setMeterAddress(dto.getMeterAddress());
        if(nbdto.getPage() != null){
            nbdto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        List<NBDTO> nbData = mapper.getDataByDay(nbdto);
        int count = mapper.getDataByDayCount(nbdto);
        Page<MeterDayDataDTO> nbRealData = new Page<>();

        List<MeterDayDataDTO> list = new ArrayList<>();
        if(null == nbData || nbData.size() == 0){
            nbRealData.setRecords(null);
            nbRealData.setTotal(0);
        }else{
            for(NBDTO nbdto1 : nbData){
                MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                meterDayDataDTO.setMeterAddress(nbdto1.getMeterAddress());
                meterDayDataDTO.setInstLoc(nbdto1.getInstLoc());
                meterDayDataDTO.setName(nbdto1.getName());
                meterDayDataDTO.setBdNo(nbdto1.getTgBuildDoorplate());
                meterDayDataDTO.setCsq(nbdto1.getCsq());
                if(nbdto1.getSnr() == null){
                    meterDayDataDTO.setSnr("");
                }else{
                    meterDayDataDTO.setSnr(Integer.valueOf(nbdto1.getSnr(), 16).shortValue()+"");
                }
                if(nbdto1.getRsrp() == null){
                    meterDayDataDTO.setRsrp("");
                }else{
                    meterDayDataDTO.setRsrp(Integer.valueOf(nbdto1.getRsrp(), 16).shortValue()+"");
                }
                if(nbdto1.getEcl() == null){
                    meterDayDataDTO.setEcl("");
                }else{
                    meterDayDataDTO.setEcl(Integer.valueOf(nbdto1.getEcl(), 16).shortValue()+"");
                }
                meterDayDataDTO.setWaterCurrentDate(nbdto1.getWaterCurrentDate());
                meterDayDataDTO.setRunStatus(nbdto1.getRunStatus());

                Date dataDate = null;
                try {
                    dataDate = formatter.parse(nbdto1.getDataDate() + " 00:00:00");
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date collTime = null;
                try {
                    collTime = formatter.parse(nbdto1.getCollTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                meterDayDataDTO.setCollTime(collTime);
                meterDayDataDTO.setDataDate(dataDate);

                meterDayDataDTO.setUpdTime(nbdto1.getUpdTime());
                meterDayDataDTO.setRealSumFlow(nbdto1.getRealSumFlow());

                list.add(meterDayDataDTO);
            }
            nbRealData.setRecords(list);
            nbRealData.setTotal(count);
        }
        return nbRealData;
    }

    @Override
    public Page<MeterDayDataDTO> getDataByMonth(MeterDayDataDTO dto) {
        Org org = archiveClient.getOrg();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM");
        String dateString = formatter.format(dto.getDataDate()) + "%";
        int  meterType = dto.getMeterType();
        Page<MeterDayDataDTO> nbRealData = new Page<>();

        if(meterType == 0){
            //NB表月采集数据
            NBDTO nbdto = new NBDTO();
            nbdto.setOrgId(org.getOrgId());
            nbdto.setDataDate(dateString);
            nbdto.setPage(dto.getPage());
            nbdto.setLimit(dto.getLimit());

            nbdto.setMeterAddress(dto.getMeterAddress());
            if(nbdto.getPage() != null){
                nbdto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
            }
            List<NBDTO> nbData = mapper.getDataByMonth(nbdto);
            int count = mapper.getDataByMonthCount(nbdto);

            List<MeterDayDataDTO> list = new ArrayList<>();
            if(null == nbData || nbData.size() == 0){
                nbRealData.setRecords(null);
                nbRealData.setTotal(0);
            }else{
                for(NBDTO nbdto1 : nbData){
                    MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                    meterDayDataDTO.setMeterAddress(nbdto1.getMeterAddress());
                    meterDayDataDTO.setInstLoc(nbdto1.getInstLoc());
                    meterDayDataDTO.setName(nbdto1.getName());
                    meterDayDataDTO.setBdNo(nbdto1.getTgBuildDoorplate());
                    meterDayDataDTO.setCsq(nbdto1.getCsq());
                    if(nbdto1.getSnr() == null){
                        meterDayDataDTO.setSnr("");
                    }else{
                        meterDayDataDTO.setSnr(Integer.valueOf(nbdto1.getSnr(), 16).shortValue()+"");
                    }
                    if(nbdto1.getRsrp() == null){
                        meterDayDataDTO.setRsrp("");
                    }else{
                        meterDayDataDTO.setRsrp(Integer.valueOf(nbdto1.getRsrp(), 16).shortValue()+"");
                    }
                    if(nbdto1.getEcl() == null){
                        meterDayDataDTO.setEcl("");
                    }else{
                        meterDayDataDTO.setEcl(Integer.valueOf(nbdto1.getEcl(), 16).shortValue()+"");
                    }
                    meterDayDataDTO.setWaterCurrentDate(nbdto1.getWaterCurrentDate());
                    meterDayDataDTO.setRunStatus(nbdto1.getRunStatus());

                    formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date collTime = null;
                    Date dataDate = null;
                    try {
                        collTime = formatter.parse(nbdto1.getCollTime());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    meterDayDataDTO.setCollTime(collTime);
                    try {
                        dataDate = formatter.parse(nbdto1.getDataDate() + " 00:00:00");
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    meterDayDataDTO.setDataDate(dataDate);

                    meterDayDataDTO.setUpdTime(nbdto1.getUpdTime());
                    meterDayDataDTO.setRealSumFlow(nbdto1.getRealSumFlow());

                    list.add(meterDayDataDTO);
                }
                nbRealData.setRecords(list);
                nbRealData.setTotal(count);
            }
        }else{
            //冷水水表，电表月采集数据
            WiredMeterDTO wiredMeterDTO = new WiredMeterDTO();
            wiredMeterDTO.setOrgId(org.getOrgId());
            wiredMeterDTO.setDataDate(dateString);
            wiredMeterDTO.setPage(dto.getPage());
            wiredMeterDTO.setLimit(dto.getLimit());
            wiredMeterDTO.setTermId(dto.getTermAddress());
            //0 冷水水表 4 电表
            wiredMeterDTO.setMeterType(dto.getMeterType() == 1 ? "4": "0" );
            wiredMeterDTO.setMeterAddress(dto.getMeterAddress());

            if(wiredMeterDTO.getPage() != null){
                wiredMeterDTO.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
            }
            List<WiredMeterDTO> nbData = mapper.getWiredMouthData(wiredMeterDTO);
            int count = mapper.getWiredMouthDataCount(wiredMeterDTO);

            if(dto.getModelType().equals("1")){
                //为818型号集中器下表具查6904库
                List<WiredMeterDTO> wiredMeterDTOS = new ArrayList<>();
                WiredMeter wiredMeter = wiredMeterMapper.selectById(dto.getId());
                List<WiredMeterDTO> papRList = archiveClient.getCL6904PapR(dto.getId(),dateString,
                        wiredMeterDTO.getCurrentPos()+"",wiredMeterDTO.getLimit()+"");
                for(int i=0;i<papRList.size();i++){
                    WiredMeterDTO wiredMeterDTO1 = new WiredMeterDTO();
                    BeanUtils.copyProperties(wiredMeter,wiredMeterDTO1);
                    wiredMeterDTO1.setRealSumFlow(papRList.get(i).getRealSumFlow());
                    wiredMeterDTO1.setCollTime(papRList.get(i).getCollTime());
                    wiredMeterDTO1.setDataDate(papRList.get(i).getDataDate());
                    wiredMeterDTOS.add(wiredMeterDTO1);
                }
                nbData.addAll(wiredMeterDTOS);
                count =  count + wiredMeterDTOS.size();
            }

            List<MeterDayDataDTO> list = new ArrayList<>();
            if(null == nbData || nbData.size() == 0){
                nbRealData.setRecords(null);
                nbRealData.setTotal(0);
            }else{
                for(WiredMeterDTO nbdto1 : nbData){
                    MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                    meterDayDataDTO.setMeterAddress(nbdto1.getMeterAddress());
                    meterDayDataDTO.setTermAddress(nbdto1.getTermId());
                    meterDayDataDTO.setChannel(nbdto1.getChannel());
                    meterDayDataDTO.setProtocol(nbdto1.getProtocol());
                    meterDayDataDTO.setUartbps(nbdto1.getUartbps());
                    meterDayDataDTO.setInstLoc(nbdto1.getInstLoc());
                    meterDayDataDTO.setName(nbdto1.getName());
                    meterDayDataDTO.setBdNo(nbdto1.getTgBuildDoorplate());

                    formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date collTime = null;
                    Date dataDate = null;
                    try {
                        collTime = formatter.parse(nbdto1.getCollTime());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    meterDayDataDTO.setCollTime(collTime);
                    try {
                        dataDate = formatter.parse(nbdto1.getDataDate() + " 00:00:00");
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    meterDayDataDTO.setDataDate(dataDate);

                    meterDayDataDTO.setRealSumFlow(nbdto1.getRealSumFlow());

                    list.add(meterDayDataDTO);
                }
                nbRealData.setRecords(list);
                nbRealData.setTotal(count);
            }
        }
        return nbRealData;
    }

    @Override
    public Page<StatisticsDataDTO> statisticsSum(GradeDTO dto) throws ParseException {
        Date date = dto.getUpdTime();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = simpleDateFormat.format(date);
        String roleCode = archiveClient.getRole().getRoleCode();
        String tgId = archiveClient.getTgId();
        List<String> dateStr = getMonthFullDay(Integer.parseInt(dateString.substring(0,4)),date.getMonth()+1);
        String meterType = "";
        List<StatisticsDataDTO> list = new ArrayList<>();
        Page<StatisticsDataDTO> page = new Page<>();
        if(roleCode.equals("admin") || (tgId == null||tgId.equals("") )){
            //查找组织区域名称List
            Page<GradeDTO> gradeDTOList = archiveClient.findGrade(dto);
            for(GradeDTO gradeDTO : gradeDTOList.getRecords()){
                //赋值结果集
                StatisticsDataDTO statisticsDataDTO = new StatisticsDataDTO();
                statisticsDataDTO.setAreaId(gradeDTO.getId());
                statisticsDataDTO.setAreaName(gradeDTO.getAreaName());
                if(dto.getMeterType().equals("0")){
                    //NB水表
                    Integer deviceSum = mapper.getAllByAreaId(gradeDTO.getId());
                    statisticsDataDTO.setDeviceNum(deviceSum+"");
                    if(deviceSum == 0) {
                        list.add(statisticsDataDTO);
                        continue;
                    }
                    Integer nbNumber = mapper.getNbByAreaId(gradeDTO.getId());
                    statisticsDataDTO.setNbSum(nbNumber+"");
                    //赋值每日上报表数量
                    String string = "";
                    for(String str : dateStr){
                        int dataSum = mapper.getDayReportCount(str,gradeDTO.getId());
                        string = string + str.substring(5) + ":" +dataSum + ";";
                    }
                    statisticsDataDTO.setDateSum(string);
                }else {
                    //电表
                    if(dto.getMeterType().equals("1")){
                        meterType = "4";
                    }else if(dto.getMeterType().equals("2")){
                        //水表
                        meterType = "0";
                    }
                    List<WiredMeter> wiredMeterList = mapper.getWiredMeterByAreaId(gradeDTO.getId(),meterType);
                    int deviceSum = wiredMeterList.size();
                    statisticsDataDTO.setDeviceNum(deviceSum+"");
                    if(deviceSum == 0) {
                        list.add(statisticsDataDTO);
                        continue;
                    }
                    String string = "";
                    for(String str : dateStr){
                        int dataSum = mapper.getReportWiredByDateAndAreaId(str,gradeDTO.getId(),meterType);
                        int num = 0;
                        MeterDayDataDTO dayDataDTO = new MeterDayDataDTO();
                        //获取818集中器上报的表具数量;
                        dayDataDTO.setAreaId(gradeDTO.getId());
                        dayDataDTO.setDate(str);
                        num = archiveClient.getReportCl6904(dayDataDTO);
                        dataSum = dataSum + num;
                        string = string + str.substring(5) + ":" +dataSum + ";";
                    }
                    statisticsDataDTO.setDateSum(string);
                }
                list.add(statisticsDataDTO);
            }
            page.setPages(gradeDTOList.getPages());
            page.setSize(gradeDTOList.getSize());
            page.setCurrent(gradeDTOList.getCurrent());
        }else{
            //登录用户非管理员且非组织区域管理人员
            //查找组织区域名称List
            String orgId = archiveClient.getOrg().getOrgId();
            List<String> idList = archiveClient.reGetChildBDGradeId(tgId,orgId);
            for(String id : idList){
                BDGrade bdGrade = bdGradeMapper.selectById(id);
                //赋值结果集
                StatisticsDataDTO statisticsDataDTO = new StatisticsDataDTO();
                statisticsDataDTO.setTgBuildDoorplate(id);
                statisticsDataDTO.setAreaName(bdGrade.getBdName());
                List<String> idLists = archiveClient.reGetChildBDGradeId(id,orgId);
                if(dto.getMeterType().equals("0")){
                    //NB水表
                    Integer deviceSum = mapper.getAllByTgId(idLists);
                    statisticsDataDTO.setDeviceNum(deviceSum+"");
                    if(deviceSum == 0) {
                        list.add(statisticsDataDTO);
                        continue;
                    }
                    Integer nbNumber = mapper.getNbByTgId(idLists);
                    statisticsDataDTO.setNbSum(nbNumber+"");
                    //赋值每日上报表数量
                    String string = "";
                    for(String str : dateStr){
                        int dataSum = mapper.getDayReportCountByTgId(str,idLists);
                        string = string + str.substring(5) + ":" +dataSum + ";";
                    }
                    statisticsDataDTO.setDateSum(string);
                }else {
                    //电表
                    if(dto.getMeterType().equals("1")){
                        meterType = "4";
                    }else if(dto.getMeterType().equals("2")){
                        //水表
                        meterType = "0";
                    }
                    List<WiredMeter> wiredMeterList = mapper.getWiredMeterByTgId(idLists,meterType);
                    int deviceSum = wiredMeterList.size();
                    statisticsDataDTO.setDeviceNum(deviceSum+"");
                    if(deviceSum == 0) {
                        list.add(statisticsDataDTO);
                        continue;
                    }
                    String string = "";
                    for(String str : dateStr){
                        int dataSum = mapper.getReportWiredByDateAndTgId(str,idLists,meterType);
                        int num = 0;
                        MeterDayDataDTO dayDataDTO = new MeterDayDataDTO();
                        //获取818集中器上报的表具数量;
                        dayDataDTO.setTgIds(idLists);
                        dayDataDTO.setDate(str);
                        num = archiveClient.getReportCl6904(dayDataDTO);
                        dataSum = dataSum + num;
                        string = string + str.substring(5) + ":" +dataSum + ";";
                    }
                    statisticsDataDTO.setDateSum(string);
                }
                list.add(statisticsDataDTO);
            }
            page.setPages(dto.getPage());
            page.setSize(dto.getLimit());
        }

        page.setTotal(list.size());
        page.setRecords(list);
        return page;
    }

    @Override
    public Page<MeterDayDataDTO> getDayData(MeterDayDataDTO dto) throws ParseException {
        if(archiveClient.getRole().getRoleCode().equals("admin")||archiveClient.getTgId() == null || archiveClient.getTgId().equals("")){
            String id = archiveClient.getAreaIdByName(dto);
            dto.setAreaId(id);
        }else {
            dto.setAreaId(archiveClient.getAreaId());
        }

        Page<MeterDayDataDTO> page = new Page<>();
        if(dto.getMeterType() == 0){
            page = getAllDayData(dto).get("nb");
        }else if(dto.getMeterType() == 1){
            page = getAllDayData(dto).get("elec");
        }else if(dto.getMeterType() == 2){
            page = getAllDayData(dto).get("wired");
        }
        //清除掉不是新NB协议的表具（清除奥特曼和创仁表具）
        List<MeterDayDataDTO> list = page.getRecords();
        if(dto.getMeterType() == 0){
            List<MeterDayDataDTO> list1 = new ArrayList<>(list);
            for(MeterDayDataDTO meter : list1){
                if(meter.getRsrp() == null){
                    String protoCode = nBmeterMapper.selectOne(new QueryWrapper<WNB>().eq("meter_address",meter.getMeterAddress())).getProtoCode();
                    meter.setProtoCode(protoCode);
                }
            }
        }
        page.setRecords(list);
        return page;
    }

    @Override
    public List<CollectRateDTO> getCollRateByTimeArea(CollectRateDTO dto) throws ParseException {
        List<String> areaList = dto.getAreaIdList();
        List<String> tgList = dto.getTgList();
        List<String> dateList = getBetweenDates(dto.getStartDate(),dto.getEndDate());
        List<CollectRateDTO> list = new ArrayList();
        String meterType = dto.getMeterType();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        List<Grade> gradeList = new ArrayList<>();
        List<BDGrade> bdGradeList = new ArrayList<>();

        List<String> bdList = new ArrayList<>();
        for(String areaId : areaList){
            Grade grade = gradeMapper.selectById(areaId);
            gradeList.add(grade);
        }

        for(String tgId : tgList){
            BDGrade bdGrade = bdGradeMapper.selectById(tgId);
            String areaId = bdGrade.getAreaId();
            if(areaList.contains(areaId)){
                continue;
            }else{
                bdGradeList.add(bdGrade);
            }
        }

        switch(meterType){
            case "1" :{
                //查询NB表具
                for(Grade grade : gradeList){
                    for(String date:dateList){
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setAreaId(grade.getId()+"");
                        rateDTO.setName(grade.getAreaName());
                        rateDTO.setCollDate(format.parse(date));
                        int count = nBmeterMapper.selectCount(new QueryWrapper<WNB>().eq("area_id",grade.getId()));
                        rateDTO.setPlanNum(count);
                        int num = mapper.getCountByDateAndAreaId(date,grade.getId()+"");
                        toGiveRate(list, rateDTO, count, num);
                    }
                }

                for(BDGrade bdGrade : bdGradeList){
                    //门栋单元的
                    bdList = archiveClient.reGetChildBDGradeId(bdGrade.getId() +"",bdGrade.getOrgId());
                    for(String date:dateList){
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setTgId(bdGrade.getId()+"");
                        rateDTO.setName(bdGrade.getBdName());
                        rateDTO.setCollDate(format.parse(date));
                        int count = nBmeterMapper.selectCount(new QueryWrapper<WNB>().in("tg_build_doorplate",bdList));
                        rateDTO.setPlanNum(count);
                        int num = mapper.getCountByDateAndTgId(date,bdList);
                        toGiveRate(list, rateDTO, count, num);
                    }
                }
                break;
            }
            case "2" : {
                //查询冷水水表
                for(Grade grade : gradeList){
                    for(String date:dateList){
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setAreaId(grade.getId()+"");
                        rateDTO.setName(grade.getAreaName());
                        rateDTO.setCollDate(format.parse(date));
                        int count = mapper.getCountWiredMeterByAreaId(grade.getId()+"","0");
                        rateDTO.setPlanNum(count);
                        int num = mapper.getReportWiredByDateAndAreaId(date,grade.getId()+"","0");
                        toGiveRate(list, rateDTO, count, num);
                    }
                }

                for(BDGrade bdGrade : bdGradeList){
                    //门栋单元的
                    bdList = archiveClient.reGetChildBDGradeId(bdGrade.getId() +"",bdGrade.getOrgId());
                    for(String date:dateList){
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setTgId(bdGrade.getId()+"");
                        rateDTO.setName(bdGrade.getBdName());
                        rateDTO.setCollDate(format.parse(date));
                        int count =  mapper.getCountWiredMeterByTgId(bdList,"0");
                        rateDTO.setPlanNum(count);
                        int num = mapper.getReportWiredByDateAndTgId(date,bdList,"0");
                        toGiveRate(list, rateDTO, count, num);
                    }
                }
                break;
            }
            case "3" : {
               //查询电表
                for(Grade grade : gradeList){
                    for(String date:dateList){
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setAreaId(grade.getId()+"");
                        rateDTO.setName(grade.getAreaName());
                        rateDTO.setCollDate(format.parse(date));
                        int count = mapper.getCountWiredMeterByAreaId(grade.getId()+"","4");
                        rateDTO.setPlanNum(count);
                        int num = mapper.getReportWiredByDateAndAreaId(date,grade.getId()+"","4");
                        int clNum = 0;
                        MeterDayDataDTO dd = new MeterDayDataDTO();
                        dd.setAreaId(grade.getId()+"");
                        dd.setDate(date);
                            clNum = archiveClient.getReportCl6904(dd);
                        toGiveRate(list, rateDTO, count, num + clNum);
                    }
                }
                for(BDGrade bdGrade : bdGradeList){
                    //门栋单元的
                    bdList = archiveClient.reGetChildBDGradeId(bdGrade.getId() +"",bdGrade.getOrgId());
                    for(String date:dateList){
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setTgId(bdGrade.getId()+"");
                        rateDTO.setName(bdGrade.getBdName());
                        rateDTO.setCollDate(format.parse(date));
                        int count =  mapper.getCountWiredMeterByTgId(bdList,"4");
                        rateDTO.setPlanNum(count);
                        int num = mapper.getReportWiredByDateAndTgId(date,bdList,"4");
                        int clNum = 0;
                        MeterDayDataDTO dd = new MeterDayDataDTO();
                        dd.setTgIds(bdList);
                        dd.setDate(date);
                        clNum = archiveClient.getReportCl6904(dd);
                        toGiveRate(list, rateDTO, count, num + clNum);
                    }
                }
                break;
            }
        }
        return list;
    }

    @Override
    public List<CollectRateDTO> getCollectMeter(CollectRateDTO dto) {
        List<CollectRateDTO> list = new ArrayList<>();
        String areaId = dto.getAreaId();
        String tgId = dto.getTgId();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(dto.getCollDate());
        List<String> bdList = new ArrayList<>();
        if(areaId != null){
            //点击组织区域
            switch (dto.getMeterType()){
                case "1":{
                    //NB水表
                    List<WNB> wnbList = nBmeterMapper.selectList(new QueryWrapper<WNB>().eq("area_id",areaId));
                    for(WNB nb : wnbList){
                        MeterDayDataDTO meterDayDataDTO = mapper.getDataDayByNb(nb,date);
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setMeterAddress(nb.getMeterAddress());
                        rateDTO.setImei(nb.getImei());
                        rateDTO.setInstAddress(nb.getInstLoc());
                        rateDTO.setMeterName(nb.getName());
                        rateDTO.setMeterType(dto.getMeterType());
                        rateDTO.setCollDate(meterDayDataDTO == null ? null : dto.getCollDate());
                        rateDTO.setFlag(meterDayDataDTO == null ? "1" : "0");
                        rateDTO.setFlowSum(meterDayDataDTO == null ? "--" : meterDayDataDTO.getRealSumFlow());
                        list.add(rateDTO);
                    }
                    break;
                }
                case "2":{
                    //冷水水表
                    List<WiredMeter> wiredList = mapper.getWiredMeterByAreaId(areaId,"0");
                    for(WiredMeter wiredMeter : wiredList){
                        MeterDayDataDTO meterDayDataDTO = mapper.getDataDayByWired(wiredMeter,date,"0");
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setMeterAddress(wiredMeter.getMeterAddress());
                        rateDTO.setTermAddress(wiredMeter.getTermId());
                        rateDTO.setInstAddress(wiredMeter.getInstLoc());
                        rateDTO.setMeterName(wiredMeter.getName());
                        rateDTO.setMeterType(dto.getMeterType());
                        rateDTO.setCollDate(meterDayDataDTO == null ? null : dto.getCollDate());
                        rateDTO.setFlag(meterDayDataDTO == null ? "1" : "0");
                        rateDTO.setFlowSum(meterDayDataDTO == null ? "--" : meterDayDataDTO.getRealSumFlow());
                        list.add(rateDTO);
                    }
                    break;
                }
                case "3":{
                    //有线电表
                    List<WiredMeter> wiredList = mapper.getWiredMeterByAreaId(areaId,"4");
                    for(WiredMeter wiredMeter : wiredList){
                        Term term = termMapper.selectOne(new QueryWrapper<Term>().eq("address",wiredMeter.getTermId()));
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();

                        if(term.getModelType().equals("1")){
                            //818集中器电表
                            meterDayDataDTO = archiveClient.getPapR(wiredMeter.getId() +"",date);
                        }else{
                            meterDayDataDTO = mapper.getDataDayByWired(wiredMeter,date,"4");
                        }
                        //6610集中器电表
                        rateDTO.setMeterAddress(wiredMeter.getMeterAddress());
                        rateDTO.setTermAddress(wiredMeter.getTermId());
                        rateDTO.setInstAddress(wiredMeter.getInstLoc());
                        rateDTO.setMeterName(wiredMeter.getName());
                        rateDTO.setMeterType(dto.getMeterType());
                        rateDTO.setCollDate(meterDayDataDTO == null ? null : dto.getCollDate());
                        rateDTO.setFlag(meterDayDataDTO == null ? "1" : "0");
                        rateDTO.setFlowSum(meterDayDataDTO == null ? "--" : meterDayDataDTO.getRealSumFlow());

                        list.add(rateDTO);
                    }
                    break;
                }
            }
        }else{
            //点击非组织区域,需查询子孙节点
            BDGrade bdGrade = bdGradeMapper.selectById(tgId);
            bdList = archiveClient.reGetChildBDGradeId(tgId,bdGrade.getOrgId());
            switch (dto.getMeterType()) {
                case "1": {
                    //NB水表
                    List<WNB> wnbList = nBmeterMapper.selectList(new QueryWrapper<WNB>().in("tg_build_doorplate", bdList));
                    for (WNB nb : wnbList) {
                        MeterDayDataDTO meterDayDataDTO = mapper.getDataDayByNb(nb, date);
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setMeterAddress(nb.getMeterAddress());
                        rateDTO.setImei(nb.getImei());
                        rateDTO.setInstAddress(nb.getInstLoc());
                        rateDTO.setMeterName(nb.getName());
                        rateDTO.setMeterType(dto.getMeterType());
                        rateDTO.setCollDate(meterDayDataDTO == null ? null : dto.getCollDate());
                        rateDTO.setFlag(meterDayDataDTO == null ? "1" : "0");
                        rateDTO.setFlowSum(meterDayDataDTO == null ? "--" : meterDayDataDTO.getRealSumFlow());
                        list.add(rateDTO);
                    }
                    break;
                }
                case "2": {
                    //冷水水表
                    List<WiredMeter> wiredList = mapper.getWiredMeterByTgId(bdList, "0");
                    for (WiredMeter wiredMeter : wiredList) {
                        MeterDayDataDTO meterDayDataDTO = mapper.getDataDayByWired(wiredMeter, date, "0");
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setMeterAddress(wiredMeter.getMeterAddress());
                        rateDTO.setTermAddress(wiredMeter.getTermId());
                        rateDTO.setInstAddress(wiredMeter.getInstLoc());
                        rateDTO.setMeterName(wiredMeter.getName());
                        rateDTO.setMeterType(dto.getMeterType());
                        rateDTO.setCollDate(meterDayDataDTO == null ? null : dto.getCollDate());
                        rateDTO.setFlag(meterDayDataDTO == null ? "1" : "0");
                        rateDTO.setFlowSum(meterDayDataDTO == null ? "--" : meterDayDataDTO.getRealSumFlow());
                        list.add(rateDTO);
                    }
                    break;
                }
                case "3": {
                    //有线电表
                    List<WiredMeter> wiredList = mapper.getWiredMeterByTgId(bdList, "4");
                    for (WiredMeter wiredMeter : wiredList) {
                        MeterDayDataDTO meterDayDataDTO = mapper.getDataDayByWired(wiredMeter, date, "4");
                        CollectRateDTO rateDTO = new CollectRateDTO();
                        rateDTO.setMeterAddress(wiredMeter.getMeterAddress());
                        rateDTO.setTermAddress(wiredMeter.getTermId());
                        rateDTO.setInstAddress(wiredMeter.getInstLoc());
                        rateDTO.setMeterName(wiredMeter.getName());
                        rateDTO.setMeterType(dto.getMeterType());
                        rateDTO.setCollDate(meterDayDataDTO == null ? null : dto.getCollDate());
                        rateDTO.setFlag(meterDayDataDTO == null ? "1" : "0");
                        rateDTO.setFlowSum(meterDayDataDTO == null ? "--" : meterDayDataDTO.getRealSumFlow());
                        list.add(rateDTO);
                    }
                    break;
                }
            }
        }
        return list;
    }

    /**
       * 赋值采集失败，采集成功率
       * @author liuwei
       * @date  2023/6/28
       * @param [start_date, end_date]
       * @return java.util.List<java.lang.String>
     */
    private void toGiveRate(List<CollectRateDTO> list, CollectRateDTO rateDTO, int count, int num) {
        rateDTO.setCollNum(num);
        double successRate = Double.parseDouble(num + "") / Double.parseDouble(count + "");
        double failRate = 1d - successRate;
        rateDTO.setFailRate(failRate);
        rateDTO.setSuccuessRate(successRate);
        list.add(rateDTO);
    }

    /**
       * 获取两者个日期之间的所有日期
       * @author liuwei
       * @date  2023/6/27
       * @param
       * @return
     */
    private List<String> getBetweenDates(Date start_date,Date end_date) {
        List<String> result = new ArrayList<String>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar tempStart = Calendar.getInstance();
        tempStart.setTime(start_date);
        Calendar tempEnd = Calendar.getInstance();
        tempEnd.setTime(end_date);
        while (tempStart.before(tempEnd) || tempStart.equals(tempEnd)) {
            result.add(sdf.format(tempStart.getTime()));
            tempStart.add(Calendar.DAY_OF_YEAR, 1);
        }
        Collections.reverse(result);
        return result;
    }

    public  List<String> getMonthFullDay(int year, int month){
        SimpleDateFormat dateFormatYYYYMMDD = new SimpleDateFormat("yyyy-MM-dd");
        List<String> fullDayList = new ArrayList<>(32);
        // 获得当前日期对象
        Calendar cal = Calendar.getInstance();
        cal.clear();// 清除信息
        cal.set(Calendar.YEAR, year);
        // 1月从0开始
        cal.set(Calendar.MONTH, month-1 );
        // 当月1号
        cal.set(Calendar.DAY_OF_MONTH,1);
        int count = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int j = 1; j <= count ; j++) {
            fullDayList.add(dateFormatYYYYMMDD.format(cal.getTime()));
            cal.add(Calendar.DAY_OF_MONTH,1);
        }
        return fullDayList;
    }



}
