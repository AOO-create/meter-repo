package com.dto.dataView;

import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2023/10/24 
 */
@Data
public class DateDataDTO {
    private String date;
    private int num;

}
