package com.mapper.equipment;

import com.dto.equipment.NBDTO;
import com.entity.equipment.Protocol;
import com.entity.equipment.WNB;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface NBmeterMapper extends BaseMapper<WNB> {


    List<NBDTO> selectNBToConsIsnullByArea(@Param("dto") NBDTO dto, @Param("areaId") String areaId,@Param("bids") List<String> bdList);

    int getCount(@Param("dto") NBDTO dto, @Param("areaId") String areaId,@Param("bids")List<String> bdList);

    int findMeterInMtrRela(@Param("id") String wmtrId);

    int findCountByBDGradeId(@Param("id") String id);

    List<NBDTO> getNBDateByAreaIdAndOrgId(@Param("dto") NBDTO dto, @Param("areaId") String areaId);

    int getDateDayCount(@Param("dto") NBDTO dto, @Param("areaId") String areaId);

    void batchInsert(@Param("list") List<NBDTO> list);

    List<Protocol> getProtocol();

    List<NBDTO> getDataByTgIdAndOrgId(@Param("dto") NBDTO dto, @Param("ids") List<String> ids);

    int getDateDayCountByTgId(@Param("dto") NBDTO dto, @Param("ids") List<String> ids);
}
