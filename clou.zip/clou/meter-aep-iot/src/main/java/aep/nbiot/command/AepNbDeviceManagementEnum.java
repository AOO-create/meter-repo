package aep.nbiot.command;

public enum AepNbDeviceManagementEnum  implements AepCommandEnum{

    BatchCancelDevices("BatchCancelDevices","批量注销设备"),
    BatchCreateNBDevice("BatchCreateNBDevice","批量增加NB设备"),
    ;
    private String commandKey;
    private String commandName;

    AepNbDeviceManagementEnum(String commandKey, String commandName) {
        this.commandKey = commandKey;
        this.commandName = commandName;
    }
}
