package com.dto.dataView;

import lombok.Data;
import java.util.List;
@Data
public class MeterPapR {
    private String id;
    private String wiredMeterId;
    private String meterAddress;
    private String termAddress;
    private String papr1;
    private String papr2;
    private String papr3;
    private String papr4;
    private String papr5;
    private String papr6;
    private String papr7;
    private String papr8;
    private String papr9;
    private String papr10;
    private String papr11;
    private String papr12;
    private String papr13;
    private String papr14;
    private String papr15;
    private String papr16;
    private String papr17;
    private String papr18;
    private String papr19;
    private String papr20;
    private String papr21;
    private String papr22;
    private String papr23;
    private String papr24;
    private String dataDate;
    private String updTime;

    private String areaId;
    private String tgBuildDoorplate;
    private String timeType;
    private String timeString;
    private List<String> listPapR;
    private List<String> dateList;

}
