package com.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fegin.client.ArchiveClient;
import com.dto.area.GradeDTO;
import com.dto.equipment.CollectRateDTO;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.StatisticsDataDTO;
import com.service.DayDataManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.Map;
import java.util.List;


/**
 * @author liuwei
 * @description
 * @date 2022/6/8
 */
@RestController
@RequestMapping("/collect/equipment/dayData")
public class DayDataManagerController {
    @Autowired
    private DayDataManagerService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getAllDayData")
    @ResponseBody
    public Map<String, Page<MeterDayDataDTO>> getAllDayData(@RequestBody MeterDayDataDTO dto) throws ParseException {
        return service.getAllDayData(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getDataByDay")
    @ResponseBody
    public Page<MeterDayDataDTO> getDataByDay(@RequestBody MeterDayDataDTO dto){
        return service.getDataByDay(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getDataByMonth")
    @ResponseBody
    public Page<MeterDayDataDTO> getDataByMonth(@RequestBody MeterDayDataDTO dto){
        return service.getDataByMonth(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("statisticsSum")
    @ResponseBody
    public Page<StatisticsDataDTO> statisticsSum(@RequestBody GradeDTO dto) throws ParseException {
        return service.statisticsSum(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getDayData")
    @ResponseBody
    public Page<MeterDayDataDTO> getDayData(@RequestBody MeterDayDataDTO dto) throws ParseException {
        return service.getDayData(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getCollRateByTimeArea")
    @ResponseBody
    public List<CollectRateDTO> getCollRateByTimeArea(@RequestBody CollectRateDTO dto) throws ParseException {
        return service.getCollRateByTimeArea(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getCollectMeter")
    @ResponseBody
    public List<CollectRateDTO> getCollectMeter(@RequestBody CollectRateDTO dto) throws ParseException {
        return service.getCollectMeter(dto);
    }

}
