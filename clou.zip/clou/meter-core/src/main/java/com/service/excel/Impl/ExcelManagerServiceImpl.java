package com.service.excel.Impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.equipment.MeterDayVo;
import com.fegin.client.ArchiveClient;
import com.fegin.client.CollectClient;
import com.dto.CollectRateDTO;
import com.dto.GradeDTO;
import com.dto.StatisticsDataDTO;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.Org;
import com.service.excel.ExcelManagerService;
import com.utils.PoiUtils;
import com.vo.excelOpVo.ExportExcelParamsVo;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;
/**
 * @author liuwei
 * @description
 * @date 2022/6/9
 */
@Service
public class ExcelManagerServiceImpl implements ExcelManagerService {

    @Autowired
    private ArchiveClient archiveClient;

    @Autowired
    private CollectClient collectClient;

    /**
       * 导出表格根据传入参数
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    @Override
    public void OutExcel(HttpServletResponse response, ExportExcelParamsVo exportExcelParams) throws Exception {
        String type = exportExcelParams.getType();
        //表格流生成，表格标题行生成
        Workbook workbook = PoiUtils.exportExcel(type,exportExcelParams.getDataDate());
        //表格sheet页名称设置
        Sheet sheet = workbook.getSheet(PoiUtils.sheetName(type));
        //表格样式设置
        CellStyle style = PoiUtils.excelStyle(workbook);
        //表格数据查询，数据循环遍历
        chooseList(exportExcelParams,sheet,style);
        //输出流打印
        export(response,workbook);
    }

    /**
       * 导出模板
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    @Override
    public void downloadModel(HttpServletResponse response,String type) {
        Workbook workbook = PoiUtils.exportExcel(type,"");

        Sheet sheet = workbook.getSheet(PoiUtils.sheetName(type));

        CellStyle style = PoiUtils.excelStyle(workbook);

        export(response,workbook);
    }

    /**
       * 文件输出流
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    private void export(HttpServletResponse response, Workbook workbook){
        try (OutputStream osOut = response.getOutputStream()) {
            // 设置响应类型与编码
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("学生表.xlsx", "UTF-8"));
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");  // .xlsx 用这个
//            response.setContentType("application/vnd.ms-excel;charset=utf-8"); // .xls 用这个
            response.setCharacterEncoding("utf-8");
            // 将指定的字节写入此输出流
            workbook.write(osOut);
            // 刷新此输出流并强制将所有缓冲的输出字节被写出
            osOut.flush();
            // 关闭流
            osOut.close();
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
       * 查询数据，循环遍历赋值给表格
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    private void chooseList(ExportExcelParamsVo exportExcelParams,Sheet sheet,CellStyle style) throws ParseException {
        Org org = archiveClient.getOrg();
        exportExcelParams.setOrgId(org.getOrgId());
        //查询出结果List，然后赋值给表格
        String type = exportExcelParams.getType();
        Map<String,List<Map<Integer,String>>> map = assignMap(type,exportExcelParams);
        List<Map<Integer,String>> list = map.get(type);

        loopAssignCell(type,sheet,style,list,exportExcelParams.getDataDate());
    }

    /**
       * 循环遍历赋值
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    public void loopAssignCell(String type,Sheet sheet,CellStyle style, List<Map<Integer,String>>  list,String dataDate){
        for (int j = 0; j < list.size(); j++) {
            Row row = sheet.createRow(j + 1);
            for (int i = 0; i < PoiUtils.chooseHeaderExcel(type,dataDate).length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(list.get(j).get(i));
                cell.setCellType(1);
                cell.setCellStyle(style);
            }
        }
    }

    /**
       * 查询数据,根据类型不同进行不同赋值，会根据业务增加而增加
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */

    public Map<String,List<Map<Integer,String>>> assignMap(String type,ExportExcelParamsVo exportExcelParams) throws ParseException {
        Map<String,List<Map<Integer,String>>> map = new HashMap<>();
        Org org = archiveClient.getOrg();
        exportExcelParams.setOrgId(org.getOrgId());

        SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //查询出结果List，然后赋值给表格
        switch (type) {
            case "DAY_DATA_EXCEL": {
                MeterDayVo meterDayVo =new MeterDayVo();
                meterDayVo.setAreaId(exportExcelParams.getAreaId());
                meterDayVo.setMeterAddress(exportExcelParams.getMeterAddress());
                meterDayVo.setDataDate(exportExcelParams.getDataDate());
                meterDayVo.setPage(1);
                meterDayVo.setLimit(1000);
                Page<MeterDayVo> page = archiveClient.getDataByDay(meterDayVo);
                List<MeterDayVo> list = page.getRecords();
                List<Map<Integer,String>> list1 = new ArrayList<>();
                for(MeterDayVo dto:list){
                    Map<Integer,String> map1 = new HashMap<>();
                    map1.put(0,dto.getBdName());
                    map1.put(1,dto.getMeterAddress());
                    map1.put(2,dto.getName());
                    map1.put(3,dto.getRealSumFlow().toString());
//                    map1.put(4,dto.getFlow().toString());
                    String flow = dto.getFlow().toString();
                    map1.put(4,flow);
                    map1.put(5,dto.getFee1().toString());
                    map1.put(6,dto.getFee2().toString());
                    map1.put(7,dto.getFee3().toString());
                    map1.put(8,dto.getFee4().toString());
                    map1.put(9,dto.getDataDate());
                    list1.add(map1);
                }
                map.put(type,list1);
                break;
            }
            case "INCRE_DATA_EXCEL": {
                MeterDayVo meterDayVo =new MeterDayVo();
                meterDayVo.setAreaId(exportExcelParams.getAreaId());
                meterDayVo.setMeterAddress(exportExcelParams.getMeterAddress());
                meterDayVo.setDataDate(exportExcelParams.getDataDate());
                meterDayVo.setPage(1);
                meterDayVo.setLimit(1000);
                Page<MeterDayVo> page = archiveClient.getIncDataByDay(meterDayVo);
                List<MeterDayVo> list = page.getRecords();
                List<Map<Integer,String>> list1 = new ArrayList<>();
                for(MeterDayVo dto:list){
                    Map<Integer,String> map1 = new HashMap<>();
                    map1.put(0,dto.getName());
                    map1.put(1,dto.getMeterAddress());
                    map1.put(2,dto.getBdName());
                    map1.put(3,dto.getIncFlow().toString());
                    map1.put(4,dto.getFlow().toString());
                    map1.put(5,dto.getDataDate());
                    list1.add(map1);
                }
                map.put(type,list1);
                break;
            }
            case "TERM_EXCEL": {
                List<TermDTO> list = new ArrayList<>();
                //根据类型决定并查询出来需要导出的内容
                TermDTO dto = new TermDTO();
                dto.setOrgId(exportExcelParams.getOrgId());
                dto.setAreaId(exportExcelParams.getAreaId());
                dto.setAddress(exportExcelParams.getTermAddress());

                list = archiveClient.getTerm(dto).getRecords();
                List<Map<Integer,String>> list1 = new ArrayList<>();
                for(TermDTO dt:list){
                    Map<Integer,String> map1 = new HashMap<>();
                    map1.put(0,dt.getAddress());
                    map1.put(1,dt.getName());
                    map1.put(2,dt.getAreaName());
                    map1.put(3,dt.getProtocolCode());
                    map1.put(4,dt.getModelType());
//                    map1.put(4,formatter.format(dt.getInstallDate()));
//                    map1.put(5,dt.getInstallAddr());
                    list1.add(map1);
                }
                map.put(type,list1);
                break;
            }
            case "STATISTICS_DATA":{
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                List<StatisticsDataDTO> list3 = new ArrayList<>();
                Date date = simpleDateFormat.parse(exportExcelParams.getDataDate().substring(0,10));
                date = new Date(date.getTime() + 60 * 60 *1000 *24);
                GradeDTO gradeDTO = new GradeDTO();
                gradeDTO.setPage(exportExcelParams.getPage());
                gradeDTO.setMeterType(exportExcelParams.getMeterType());
                gradeDTO.setLimit(exportExcelParams.getLimit());
                gradeDTO.setUpdTime(date);
                list3 = collectClient.statisticsSum(gradeDTO).getRecords();
                List<Map<Integer,String>> list1 = new ArrayList<>();

                for(StatisticsDataDTO statisticsDataDTO : list3){
                    Map<Integer,String> map1 = new HashMap<>();
                    map1.put(0,exportExcelParams.getDataDate().substring(0,4));
                    map1.put(1,statisticsDataDTO.getAreaName());
                    map1.put(2,statisticsDataDTO.getDeviceNum());

                    if(statisticsDataDTO.getDateSum() == null||statisticsDataDTO.getDateSum().equals("0") ){
                        list1.add(map1);
                        continue;
                    }
                    String[] strArray = statisticsDataDTO.getDateSum().split(";");
                    for(int j =0 ;j<strArray.length;j++){
                        map1.put(j+3,strArray[j].substring(6));
                    }
                    list1.add(map1);
                }
                map.put(type,list1);
                break;
            }
            case "COLLECT_METER_EXCEL":{
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                List<CollectRateDTO> rateList = exportExcelParams.getMeterList();
                List<Map<Integer,String>> list1 = new ArrayList<>();
                for(CollectRateDTO dto:rateList){
                    Map<Integer,String> map1 = new HashMap<>();
                    map1.put(0,dto.getMeterAddress());
                    map1.put(1,dto.getMeterType().equals("1")? dto.getImei():dto.getTermAddress());
                    map1.put(2,dto.getMeterName());
                    map1.put(3,dto.getInstAddress());
                    map1.put(4,dto.getFlowSum());
                    map1.put(5,dto.getCollDate() == null ? "--":simpleDateFormat.format(dto.getCollDate()));
                    map1.put(6,dto.getMeterType().equals("1") ? "NB水表":(dto.getMeterType().equals("2")? "冷水水表":"电表") );
                    map1.put(7,dto.getFlag().equals("0") ? "成功" :"失败"  );
                    list1.add(map1);
                }
                map.put(type,list1);
                break;

            }
            default: break;
        }
        return map;
    }
}
