package com.service.organization;

import com.dto.organization.BuildDTO;
import com.dto.organization.GradeDTO;
import com.entity.TreeData;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface GradeService {
    Page<GradeDTO> findGrade(GradeDTO dto);

    boolean saveOrUpdateGrade(BuildDTO dto) ;

    boolean deleteGrade(BuildDTO dto);

    boolean deleteAll(List<BuildDTO> list);

    List<GradeDTO> getGradeToSel(String id);

    boolean isHaveGrade(String account);

    List<TreeData> getTreeData();

    List<TreeData> getAllArea();

    List<TreeData> findBdGradeByAreaId(String areaId);

    List<TreeData> findBdGradeByBdId(String bdId);

    List<TreeData> getTreeByTermId(String termId);

    List<String> reGetChildGradeId(String areaId, String orgId, List<String> tempList);

    List<String> reGetChildBDGradeId(String tgBuildDoorplate, String orgId, List<String> tempList);

    String getAreaIdByName(String areaName);

    Page<BuildDTO> getSonBuild(BuildDTO dto);

    String getGradeNameById(String id);
}
