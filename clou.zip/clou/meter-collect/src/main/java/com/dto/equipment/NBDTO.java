package com.dto.equipment;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.constant.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class NBDTO extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long wmtrId;
    private String meterAddress;
    private String name;
    private String instLoc;
    private String dataDate;
    private String type = "77777";
    private String imei;
    private Date updTime;
    private String realSumFlow;
    private String collTime;
    private String orgId;
    private String areaId;
    private String tgBuildDoorplate ;
    private String protoCode;

    private String csq;
    private String rsrp;
    private String snr;
    private String ecl;
    private String waterCurrentDate;
    private String runStatus;

}
