package com.service.organization;


import com.entity.systemSetup.Role;
import com.entity.systemSetup.User;

import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/5/11
 */
public interface UserService {
     User getUserByNameAndPwd(Map<String, Object> pd) ;

     void updateLastLogin(User user);

     List<String> getAllResUrls();

     List<String> getUserResUrls(List<Role> roleList, User user);
}
