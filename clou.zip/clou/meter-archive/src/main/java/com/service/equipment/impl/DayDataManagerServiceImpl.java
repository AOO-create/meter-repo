package com.service.equipment.impl;

import com.controller.equipment.FourthMeterFrameDealInterface;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.mapper.equipment.DayDataManagerMapper;
import com.entity.Org;
import com.service.equipment.DayDataManagerService;
import com.service.equipment.WiredMeterService;
import com.service.organization.impl.GradeServiceImpl;
import com.util.ShiroConstUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
@Service
public class DayDataManagerServiceImpl implements DayDataManagerService {

    @Autowired
    private DayDataManagerMapper mapper;

    @Autowired
    private WiredMeterService wiredMeterService;

    @Autowired
    private NBmeterServiceImpl nBmeterService;

    @Autowired
    private GradeServiceImpl gradeService;

    @Autowired
    private FourthMeterFrameDealInterface frameDealInterface;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public Map<String, Page<MeterDayDataDTO>> getAllDayData(MeterDayDataDTO dto) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        String dateString = formatter.format(dto.getDataDate());
        dto.setDataDate(formatter.parse(dateString));
        Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        Map<String, Page<MeterDayDataDTO>> map = new HashMap<>();

        if(dto.getMeterType() == 2){
            //先查询有线表日数据
            Page<MeterDayDataDTO> wireData = wiredMeterService.getWiredDayData(dto,dateString);
            map.put("wired",wireData);
        }else if(dto.getMeterType() == 1){
            //查询旧四表合一平台的数据  未使用
            Page<MeterDayDataDTO> page = new Page<>();
            List<String> idList = new ArrayList<>();
            List<String> tempList = new ArrayList<>();

            idList = gradeService.reGetChildGradeId(dto.getAreaId(),dto.getOrgId(),tempList);
            List<MeterDayDataDTO> oldData = mapper.oldWaterDayData(dto,idList,dateString);
            int count = mapper.getOldDataCount(dto,idList,dateString);
            if(oldData.size() !=0 && oldData !=null){
                page.setRecords(oldData);
                page.setTotal(count);
            }else{
                page.setRecords(null);
                page.setTotal(0);
            }
            map.put("old",page);
        }else if(dto.getMeterType() == 0){
            //查询NB表日数据
            NBDTO nbdto = new NBDTO();
            nbdto.setOrgId(org.getOrgId());
            nbdto.setTgBuildDoorplate(dto.getTgBuildDoorplate());
            nbdto.setDataDate(dateString);
            nbdto.setPage(dto.getPage());
            nbdto.setLimit(dto.getLimit());
            nbdto.setAreaId(dto.getAreaId());
            nbdto.setInstLoc(dto.getInstLoc());
            nbdto.setMeterAddress(dto.getMeterAddress());
            Page<NBDTO> nbData = nBmeterService.getDataDay(nbdto);

            Page<MeterDayDataDTO> nbRealData = new Page<>();

            List<MeterDayDataDTO> list = new ArrayList<>();
            if(nbData.getRecords() == null || nbData.getRecords().size() == 0){
                nbRealData.setRecords(null);
                nbRealData.setTotal(0);
            }else{
                for(NBDTO nbdto1 : nbData.getRecords()){
                    MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                    meterDayDataDTO.setMeterAddress(nbdto1.getMeterAddress());
                    meterDayDataDTO.setInstLoc(nbdto1.getInstLoc());
                    meterDayDataDTO.setName(nbdto1.getName());
                    meterDayDataDTO.setBdNo(nbdto1.getTgBuildDoorplate());
                    Date dataDate = formatter.parse(nbdto1.getDataDate() + " 00:00:00");
                    formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date collTime = formatter.parse(nbdto1.getCollTime());
                    meterDayDataDTO.setCollTime(collTime);
                    meterDayDataDTO.setDataDate(dataDate);

                    meterDayDataDTO.setUpdTime(nbdto1.getUpdTime());
                    meterDayDataDTO.setRealSumFlow(nbdto1.getRealSumFlow());

                    list.add(meterDayDataDTO);
                }
                nbRealData.setRecords(list);
                nbRealData.setTotal(nbData.getTotal());
            }
            map.put("nb",nbRealData);
        }
//        else if(dto.getMeterType() == 3){
//            //先查询有线表日数据
//            Page<MeterDayDataDTO> fourthData = frameDealInterface.getAllFourthDayData(dto);
//            map.put("fourth",fourthData);
//        }
        return map;
    }


    @Transactional
    @Override
    public void ExcelDayDataIn(List<MeterDayDataDTO> list,String meterType) {
        switch (meterType){
            case "0":{
                //NB批量插入
                mapper.BatchInsertNB(list);
                break;
            }
            case "2":{
                mapper.BatchInsertWired(list);
                break;
            }
            default:break;
        }
    }

    @Override
    public Page<MeterDayDataDTO> getDataByDay(MeterDayDataDTO dto) {
        Org org = shiroConstUtils.getOrg();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        String dateString = formatter.format(dto.getDataDate());
        NBDTO nbdto = new NBDTO();
        nbdto.setOrgId(org.getOrgId());
        nbdto.setDataDate(dateString);
        nbdto.setPage(dto.getPage());
        nbdto.setLimit(dto.getLimit());

        nbdto.setMeterAddress(dto.getMeterAddress());
        if(nbdto.getPage() != null){
            nbdto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        List<NBDTO> nbData = mapper.getDataByDay(nbdto);
        int count = mapper.getDataByDayCount(nbdto);
        Page<MeterDayDataDTO> nbRealData = new Page<>();

        List<MeterDayDataDTO> list = new ArrayList<>();
        if(null == nbData || nbData.size() == 0){
            nbRealData.setRecords(null);
            nbRealData.setTotal(0);
        }else{
            for(NBDTO nbdto1 : nbData){
                MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                meterDayDataDTO.setMeterAddress(nbdto1.getMeterAddress());
                meterDayDataDTO.setInstLoc(nbdto1.getInstLoc());
                meterDayDataDTO.setName(nbdto1.getName());
                meterDayDataDTO.setBdNo(nbdto1.getTgBuildDoorplate());
                meterDayDataDTO.setCsq(nbdto1.getCsq());
                meterDayDataDTO.setSnr(Integer.valueOf(nbdto1.getSnr(), 16).shortValue()+"");
                meterDayDataDTO.setRsrp(Integer.valueOf(nbdto1.getRsrp(), 16).shortValue()+"");
                meterDayDataDTO.setEcl(Integer.valueOf(nbdto1.getEcl(), 16).shortValue()+"");
                meterDayDataDTO.setWaterCurrentDate(nbdto1.getWaterCurrentDate());
                meterDayDataDTO.setRunStatus(nbdto1.getRunStatus());

                Date dataDate = null;
                try {
                    dataDate = formatter.parse(nbdto1.getDataDate() + " 00:00:00");
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date collTime = null;
                try {
                    collTime = formatter.parse(nbdto1.getCollTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                meterDayDataDTO.setCollTime(collTime);
                meterDayDataDTO.setDataDate(dataDate);

                meterDayDataDTO.setUpdTime(nbdto1.getUpdTime());
                meterDayDataDTO.setRealSumFlow(nbdto1.getRealSumFlow());

                list.add(meterDayDataDTO);
            }
            nbRealData.setRecords(list);
            nbRealData.setTotal(count);
        }
        return nbRealData;
    }
}
