package com.controller.organization;

import com.dto.organization.BDGradeDTO;
import com.service.organization.BDGradeService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/7
 */
@RestController
@RequestMapping("/archive/BDgrade")
public class BDGradeController {
    @Autowired
    private BDGradeService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/selectAllBDGrade")
    @ResponseBody
    public Page<BDGradeDTO> findBDGrade(@RequestBody BDGradeDTO dto){
        return service.findBDGrade(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/saveOrUpdateBDGrade")
    @ResponseBody
    public boolean saveOrUpdateBDGrade(@RequestBody BDGradeDTO dto){
        if(StringUtils.isEmpty(dto.getId())){
            return service.saveBDGrade(dto);
        }else{
            return service.updateBDGrade(dto);
        }
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/deleteBDGrade")
    @ResponseBody
    public boolean deleteBDGrade(@RequestParam("id") String id){
        return service.deleteBDGrade(id);
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/deleteAllBD")
    @ResponseBody
    public boolean deleteAllBD(@RequestBody List<String> ids){
        return service.deleteAllBD(ids);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getBDGradeToSel")
    @ResponseBody
    public List<BDGradeDTO> getBDGradeToSel(@RequestBody BDGradeDTO dto){
        return service.getBDGradeToSel(dto);
    }

}
