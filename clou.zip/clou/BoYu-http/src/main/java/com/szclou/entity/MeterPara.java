package com.szclou.entity;

import java.util.Date;

/**
 * 说明：表计参数
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-1-31
 */

public class MeterPara {
    private String mtrParaId;
    private Integer meterIndex;//电能表序号
    private Integer mpedIndex;//所属测量点号
    private Integer commRate;//通信速率
    private Integer commPort;//端口号
    private Integer protocolType;//通信规约类型
    private String commAddr;//通信地址
    private String commPwd;//通信密码
    private Integer tariffNum;//电能费率个数
    private Integer integerNum;//有功电能示值的整数位个数
    private Integer decimalNum;//有功电能示值的小数位个数
    private String collectorAddr;//所属采集器通信地址
    private Integer consMainType;//用户大类号
    private Integer consSubType;//用户小类号
    private Integer hardwareType; //合闸方式
    private Date updTime;

    private String meterType;//表类型

    public String getMeterType() {
        return meterType;
    }

    public void setMeterType(String meterType) {
        this.meterType = meterType;
    }

    public String getMtrParaId() {
        return mtrParaId;
    }

    public void setMtrParaId(String mtrParaId) {
        this.mtrParaId = mtrParaId == null ? null : mtrParaId.trim();
    }

    public Integer getMeterIndex() {
        return meterIndex;
    }

    public void setMeterIndex(Integer meterIndex) {
        this.meterIndex = meterIndex;
    }

    public Integer getMpedIndex() {
        return mpedIndex;
    }

    public void setMpedIndex(Integer mpedIndex) {
        this.mpedIndex = mpedIndex;
    }

    public Integer getCommRate() {
        return commRate;
    }

    public void setCommRate(Integer commRate) {
        this.commRate = commRate;
    }

    public Integer getCommPort() {
        return commPort;
    }

    public void setCommPort(Integer commPort) {
        this.commPort = commPort;
    }

    public Integer getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(Integer protocolType) {
        this.protocolType = protocolType;
    }

    public String getCommAddr() {
        return commAddr;
    }

    public void setCommAddr(String commAddr) {
        this.commAddr = commAddr == null ? null : commAddr.trim();
    }

    public String getCommPwd() {
        return commPwd;
    }

    public void setCommPwd(String commPwd) {
        this.commPwd = commPwd == null ? null : commPwd.trim();
    }

    public Integer getTariffNum() {
        return tariffNum;
    }

    public void setTariffNum(Integer tariffNum) {
        this.tariffNum = tariffNum;
    }

    public Integer getIntegerNum() {
        return integerNum;
    }

    public void setIntegerNum(Integer integerNum) {
        this.integerNum = integerNum;
    }

    public Integer getDecimalNum() {
        return decimalNum;
    }

    public void setDecimalNum(Integer decimalNum) {
        this.decimalNum = decimalNum;
    }

    public String getCollectorAddr() {
        return collectorAddr;
    }

    public void setCollectorAddr(String collectorAddr) {
        this.collectorAddr = collectorAddr;
    }

    public Integer getConsMainType() {
        return consMainType;
    }

    public void setConsMainType(Integer consMainType) {
        this.consMainType = consMainType;
    }

    public Integer getConsSubType() {
        return consSubType;
    }

    public void setConsSubType(Integer consSubType) {
        this.consSubType = consSubType;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public Integer getHardwareType() {
        return hardwareType;
    }

    public void setHardwareType(Integer hardwareType) {
        this.hardwareType = hardwareType;
    }

    @Override
    public String toString() {
        return "MeterPara{" +
                "mtrParaId='" + mtrParaId + '\'' +
                ", meterIndex=" + meterIndex +
                ", mpedIndex=" + mpedIndex +
                ", commRate=" + commRate +
                ", commPort=" + commPort +
                ", protocolType=" + protocolType +
                ", commAddr='" + commAddr + '\'' +
                ", commPwd='" + commPwd + '\'' +
                ", tariffNum=" + tariffNum +
                ", integerNum=" + integerNum +
                ", decimalNum=" + decimalNum +
                ", collectorAddr='" + collectorAddr + '\'' +
                ", consMainType=" + consMainType +
                ", consSubType=" + consSubType +
                ", hardwareType=" + hardwareType +
                ", updTime=" + updTime +
                ", meterType='" + meterType + '\'' +
                '}';
    }
}