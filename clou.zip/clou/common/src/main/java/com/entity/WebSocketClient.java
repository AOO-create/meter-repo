package com.entity;

import lombok.Data;

import javax.websocket.Session;

//这里我使用了Lombok的注解，如果没有添加这个依赖 可以创建get set方法
@Data
public class WebSocketClient {

    // 与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;

    //连接的uri
    private String uri;

}
