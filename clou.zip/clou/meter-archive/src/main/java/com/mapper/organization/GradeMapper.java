package com.mapper.organization;

import com.dto.organization.BuildDTO;
import com.dto.organization.GradeDTO;
import com.entity.organization.Grade;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface GradeMapper extends BaseMapper<Grade> {

    List<GradeDTO> getAllGradeIdByOrgId(@Param("dto") GradeDTO orgId);

    int getGradeNumber(@Param("dto") GradeDTO dto);

    List<GradeDTO> getGradeToSel(@Param("dto") GradeDTO dto,@Param("id") String id);

    String getInstLocById(@Param("areaId") String areaId,@Param("tgBuildDoorplate") String tgBuildDoorplate);

    int isHaveGrade(@Param("account") String account);

    List<String> findIdByOrgId(@Param("areaId")String areaId,@Param("orgId") String orgId);

    BuildDTO getGrade(@Param("dto") BuildDTO dto);

    List<BuildDTO> getGradeList(@Param("dto") BuildDTO dto);

    int getGradeListCount(@Param("dto") BuildDTO dto);

    List<BuildDTO> getAreaList(@Param("dto") BuildDTO dto);

    int getAreaListCount(@Param("dto") BuildDTO dto);

    List<BuildDTO> getTgList(@Param("dto") BuildDTO dto);

    int getTgListCount(@Param("dto") BuildDTO dto);
}
