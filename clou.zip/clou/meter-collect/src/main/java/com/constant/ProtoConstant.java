package com.constant;

/**
 * @author lanccj
 * @version 1.0
 * @description: 常量定义
 * @date 2021/11/19 10:05 下午
 */
public interface ProtoConstant {


    /**
     * 水表上报的帧数据类型
     */
    interface FarmeType{

        /**
         * 读数据
         */
        String ReadType = "81";

        /**
         * 写开关阀门，或者是写同步数据
         */
        String WriteType = "84";

        /**
         * 计量单位 立方米m³
         */
        String Unit = "2C";

    }

    interface FarmeCode{
        /**
         * 读数据
         */
        String StartCode = "68";

        /**
         * 写开关阀门，或者是写同步数据
         */
        String EndCode = "16";
        /**
         * 主动上报应答帧长度
         */
        String OffineLength = "0700";

        /**
         * 主动上报应答帧长度
         */
        String OffineContol = "01";

        /**
         * 开关阀应答帧长度
         */
        String  ValveLength = "0400";
        /**
         * 开关阀应答帧长度
         */
        String  ValveContol = "04";
        /**
         * 让水表等待命令
         */
        String  WaitControl = "44";

        /**
         * 同步应答帧长度
         */
        String  SyncLengthA = "0800";
        /**
         * 同步应答帧长度
         */
        String  SyncLengthB = "0900";
        /**
         * 同步应答帧长度
         */
        String  SyncContol = "04";


    }
    interface FarmeLogo{
        /**
         * 有磁霍尔水表数据标志
         */
        String OffineLogoA = "9021";

        /**
         * 无磁水表数据标志
         */
        String OffineLogoB = "9023";


        /**
         * 同步机电数据标志
         */
        String  SyncLogoA = "A016";

        /**
         * 同步机电数据标志
         */
        String  SyncLogoB = "A026";

        /**
         * 开关阀数据标志
         */
        String  ValveLogo = "A017";
    }

    interface ResponStatus{
        /**
         * 应答在线
         */
        String Online = "41";

        /**
         * 应答离线
         */
        String Offine = "01";


    }

    interface ResponControCode{
        /**
           * 正确无误，无需答复
         */
        String rightCode = "87";

        /**
           * 需要后续操作，请等待至少一分钟
         */
        String waitCode = "A7";

        /**
           * 错误，无反应
         */
        String errorCode = "C7";
    }

    interface ReponseDataLength{
        /**
           * 返回帧数据长度
         */
        String reponseDataLength = "0900";
    }

    interface ValveStatus{
        /**
         * 应答在线
         */
        String Open = "55";

        /**
         * 应答离线
         */
        String Close = "99";

        String Status1 = "02";
    }

}
