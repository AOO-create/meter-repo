package com.entity.log;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/6/9
 */
@Data
@TableName("operate_meter_log")
public class OperateMeterLog {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;//主键ID

    private Integer opType;//操作类型

    private String meterAddress;//操作表地址

    private String meterName;//操作表名

    private String areaId;//操作表所属组织区域

    private Date opTime;// 操作日期

    private String opUser;//操作人

    private Long opUseTime;//操作耗时时间

    private String orgId;

}
