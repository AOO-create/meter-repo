package com.mapper.systemSetup;

import com.entity.systemSetup.Role;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface RoleMapper extends BaseMapper<Role> {
    @Select("SELECT role.* FROM role ${ew.customSqlSegment}")
    IPage<Role> selectMyPage(IPage<Role> page,@Param(Constants.WRAPPER) Wrapper<Role> queryWrapper);
}
