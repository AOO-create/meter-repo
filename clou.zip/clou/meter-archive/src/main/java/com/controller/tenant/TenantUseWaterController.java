package com.controller.tenant;

import com.service.tenant.TenantUseWaterService;
import com.vo.tenant.TenantUseWaterVo;
import com.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;

/**
 * @author liuwei
 * @description
 * @date 2022/8/4
 */
@RestController
@RequestMapping("/archive/tenantUseWater")
public class TenantUseWaterController {

    @Autowired
    private TenantUseWaterService service;


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getUseWaterRecord")
    @ResponseBody
    public Result getUseWaterRecord(@RequestBody TenantUseWaterVo vo) {
        return Result.OK(service.getUseWaterRecord(vo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getUseElecRecord")
    @ResponseBody
    public Result getUseElecRecord(@RequestBody TenantUseWaterVo vo) {
        return Result.OK(service.getUseElecRecord(vo));
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getTenantStatistics")
    @ResponseBody
    public Result getTenantStatistics(@RequestBody TenantUseWaterVo vo) throws ParseException {
        return Result.OK(service.getTenantStatistics(vo));
    }

}
