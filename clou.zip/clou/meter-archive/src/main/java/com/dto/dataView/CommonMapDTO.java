package com.dto.dataView;

import lombok.Data;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/3/29
 */
@Data
public class CommonMapDTO {
    private String id;//区域ID
    private String name;//区域名称
    private String type;//1顶级区域 2楼栋单元
    private int nbValue;//nb表数量
    private int wireValue;//有线表数量
    private int elecValue;//有线电表数量
    private int value;//通用数量
    private int reportValue;//上报数量
    private int nbReportValue;//nb上报数量
    private int wireReportValue;//有线上报数量
    private int elecReportValue;//电表上报数量
    private int yesNbReportValue;//昨日NB上报
    private int yesWireReportValue;//昨日冷水水表上报
    private int yesElecReportValue;//昨日电表上报
    private int yesReportSum;//昨日总上报数量
    private int termValue;//集中器数量
    private double useWater;//用水量
    private double useElec;//用电量

    private List<Double> rateList;//月度上报完整率
    private List<Integer> sumMeter;//每日表总数一月内
    private List<Integer> reportMeter;//每日上报表数一月内
    private List<String> dateList;//日期集合
    private List<String> useElecList;//每日用量的集合
    private String areaId;
    private String tgBuildDoorplate;
    private String timeType;
    private String timeString;
}
