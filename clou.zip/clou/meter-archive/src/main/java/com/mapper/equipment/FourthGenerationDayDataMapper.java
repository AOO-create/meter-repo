package com.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.equipment.FourthGenerationMeterDayData;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface FourthGenerationDayDataMapper extends BaseMapper<FourthGenerationMeterDayData> {

}
