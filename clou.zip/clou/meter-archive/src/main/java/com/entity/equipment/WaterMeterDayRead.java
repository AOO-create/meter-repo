package com.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@Accessors(chain = true)
@TableName("water_meter_day_read")

@EqualsAndHashCode(callSuper=false)
public class WaterMeterDayRead {
    /**
     * id
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    private Date collTime;

    private BigDecimal realSumFlow;

    private Date updTime;

    private String deviceId;

    private Date dataDate;

    private String csq;

    private String rsrp;

    private String snr;

    private String ecl;

    private Date  waterCurrentDate;

    private String runStatus;

    private String imsi;
}
