package com.entity.organization;

import java.util.Date;

/**
 * 说明：部门
 * 作者：刘英俊/CL19852
 * 版本：v1.0
 * 时间：2016-1-20 19:19
 */
public class Department {
    private String deptId;      //部门ID

    private String deptNo;      //部门编号

    private String deptName;    //部门名称

    private String deptType;    //部门类型

    private String remark;      //备注

    private String orgId;

    private String tollPoint;   //TOLL_POINT

    private Date updTime;

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId == null ? null : deptId.trim();
    }

    public String getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo == null ? null : deptNo.trim();
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName == null ? null : deptName.trim();
    }

    public String getDeptType() {
        return deptType;
    }

    public void setDeptType(String deptType) {
        this.deptType = deptType == null ? null : deptType.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getTollPoint() {
        return tollPoint;
    }

    public void setTollPoint(String tollPoint) {
        this.tollPoint = tollPoint;
    }
}
