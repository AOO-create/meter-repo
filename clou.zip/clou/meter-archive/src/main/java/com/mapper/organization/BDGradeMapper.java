package com.mapper.organization;

import com.dto.organization.BDGradeDTO;
import com.entity.organization.BDGrade;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Component
public interface BDGradeMapper extends BaseMapper<BDGrade> {
    List<BDGradeDTO> getAllBDGradeByAreaId(@Param("dto") BDGradeDTO dto);

    int getBDGradeNumber(@Param("dto") BDGradeDTO dto);

    List<BDGradeDTO> getBDGradeToSel(@Param("dto") BDGradeDTO dto);

}
