package aep.nbiot.strategy.aepdevicecommand;

import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.util.ParamsUtil;
import com.ctg.ag.sdk.biz.AepDeviceCommandClient;
import com.ctg.ag.sdk.biz.aep_device_command.QueryCommandListRequest;
import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: lwm2m协议有profile指令下发接口
 * @date 2021/11/17 16:07
 */
public class CreateCommandLwm2mProfileStrategy implements IAepStrategy {

    @Override
    public BaseApiResponse invockApi(BaseApiClient _client, HashMap<String,Object> params, HashMap<String,Object> body) {
        try {
            ParamsUtil paramsUtil = new ParamsUtil(new QueryCommandListRequest());
            QueryCommandListRequest request = (QueryCommandListRequest) paramsUtil.addParams(params,body);
            AepDeviceCommandClient client = (AepDeviceCommandClient)_client;
            return client.QueryCommandList(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
