package com.dto.dataView;

import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2023/3/29
 */
@Data
public class OperateRecordDTO {
    private String opType;//操作类型
    private int value;//记录数量
}
