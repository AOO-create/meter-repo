package com.szclou.controller;


import com.alibaba.fastjson.JSONObject;
import com.szclou.entity.*;
import com.szclou.mapper.ProvideDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/provideData/")
public class ApiController {


    @Autowired
    private ProvideDataMapper provideDataMapper;

    @PostMapping("/queryTerm")
    public List<TermDto> queryTerm() throws Exception {
        List<Term> termList = provideDataMapper.getAllTerm();
        List<TermDto> termDtos = new ArrayList<>();
        for(Term term : termList){
            TermDto term1 = new TermDto();
            term1.setMadeNo(term.getAssetNo());
            term1.setInstLoc(term.getInstallAddr());
            term1.setInstDate(term.getInstallDate());
            term1.setInstallStaff(term.getInstallStaff());
            termDtos.add(term1);
        }
        return termDtos;
    }

//    @PostMapping("/ss")
//    public List<Term> getElecData() {
//        DynamicDataSource.name.set("w");
//        List<Term> termList = provideDataMapper.getAllTermByKl();
//        return termList;
//    }

    @PostMapping("/queryMeter")
    public JSONObject queryMeter(@RequestBody Term term1){
        JSONObject jsonObject = new JSONObject();
        if(null == term1.getAssetNo()){
            jsonObject.put("msg","缺少参数集中器地址，请添加");
            return jsonObject;
        }

        if(0 >= term1.getPage()){
            jsonObject.put("msg","请输入大于0的参数当前页码");
            return jsonObject;
        }

        if(0 >= term1.getSize()){
            jsonObject.put("msg","请输入大于0的参数分页条数");
            return jsonObject;
        }

        if(!term1.getSearchType().equals("1") && !term1.getSearchType().equals("2")){
            jsonObject.put("msg","缺少查询表具类型 1水表，2电表，请正确输入");
            return jsonObject;
        }

        String address = term1.getAssetNo();
        String searchType = term1.getSearchType();
        int currentPos = (term1.getPage()-1)*term1.getSize();

        Term term = provideDataMapper.getTerm(address);
        jsonObject.put("address",address);
        jsonObject.put("install_addr",term.getInstallAddr());

        List<ExcelWmtrData>   excelWmtrData= new ArrayList<>();
        List<ExcelMeterData>  excelMeterData = new ArrayList<>();

        if(searchType.equals("1")){
            //根据水表编号查找前13列，参数配置
            List<Wmtr> wmtrList = provideDataMapper.getWmtr(term.getTerminalId(),currentPos,term1.getSize());
            for(Wmtr wmtr:wmtrList){
                MeterPara para = provideDataMapper.getParaByWmtrId(wmtr.getWmtrId());
                ExcelWmtrData data = toPushWmtrExcle(para,wmtr);
                excelWmtrData.add(data);
            }
            jsonObject.put("wmtr",excelWmtrData);
            jsonObject.put("wmtrCount",excelWmtrData.size());
        }else if(searchType.equals("2")){
            //根据水表编号查找前13列，参数配置
            List<Meter> meterList = provideDataMapper.getMeter(term.getTerminalId(),currentPos,term1.getSize());
            for(Meter meter:meterList){
                MeterPara para = provideDataMapper.getParaByMeterId(meter.getMeterId());
                ExcelMeterData data = toPushMeterExcle(para,meter);
                excelMeterData.add(data);
            }
            jsonObject.put("meter",excelMeterData);
            jsonObject.put("meterCount",excelMeterData.size());
        }

        return jsonObject;
    }

    private ExcelWmtrData  toPushWmtrExcle(MeterPara para,Wmtr wmtr){
        ExcelWmtrData excelMeterData = new ExcelWmtrData();

        Caliber caliber = provideDataMapper.getCaliber(wmtr.getCaliberId());
        if(null != caliber){
            excelMeterData.setDayAlrUp(caliber.getDayAlrUp());                          //日报警水量上限
            excelMeterData.setDayAlrLow(caliber.getDayAlrLow());                        //日报警水量下限
            excelMeterData.setMtrCaliber(caliber.getMtrCaliber()+"");                    //口径
        }

        if(null != para){
            excelMeterData.setMeterIndex(para.getMeterIndex());         //0序号
            excelMeterData.setMpedIndex(para.getMpedIndex());           //1测量点号
            excelMeterData.setCommPort(para.getCommPort());             //2通信端口
            excelMeterData.setCommRate(para.getCommRate());             //3通信速率
            excelMeterData.setProtocolType(para.getProtocolType());     //4通信类型
            excelMeterData.setCommAddr(para.getCommAddr());             //5通信地址
            excelMeterData.setCommPwd(para.getCommPwd());               //6通信密码
            excelMeterData.setTariffNum(para.getTariffNum());           //7费率个数
            excelMeterData.setDecimalNum(para.getDecimalNum());         //8小数位个数
            excelMeterData.setIntegerNum(para.getIntegerNum());         //9整数位个数
            excelMeterData.setCollectorAddr(para.getCollectorAddr());   //10采集地址
            excelMeterData.setConsMainType(para.getConsMainType());     //11用户大类号
            excelMeterData.setConsSubType(para.getConsSubType());       //12用户小类号
        }

        BDGrade bdGrade = provideDataMapper.getBDGrade(wmtr.getTgBuildDoorplate());
        if(null != bdGrade){
            excelMeterData.setDoorplate(bdGrade.getBdName());           //14门牌
            if(bdGrade.getParentId()  != null){
                BDGrade unit = provideDataMapper.getBDGrade(bdGrade.getParentId());
                excelMeterData.setBuildingUnit(unit.getBdName());       //楼栋
            }
            excelMeterData.setBdNo(bdGrade.getBdNo());                                  //门派编号
        }


        excelMeterData.setWmtrType(wmtr.getWmtrType() == 1?"冷水表":"热水表");         //表具类型
        excelMeterData.setWmtrUsage(wmtr.getWmtrUsage() == 1?"结算":"考核");          //水表用途
        excelMeterData.setAssessType(wmtr.getAssessType() == 1?"考核楼栋":"考核小区"); //考核类型
        excelMeterData.setRate(wmtr.getRate());                                     //倍率

        excelMeterData.setInstLoc(wmtr.getInstLoc());                               //安装位置
        excelMeterData.setGpsLatitude(wmtr.getGpsLatitude());                       //GPS纬度
        excelMeterData.setGpsLongitude(wmtr.getGpsLongitude());                     //GPS经度
        excelMeterData.setInstDate(wmtr.getInstDate());                             //安装日期
        excelMeterData.setWmtrNo(wmtr.getWmtrNo());                                 //水表编号
        excelMeterData.setIsTap("无阀");                                             //是否有阀

        return excelMeterData;
    }

    private ExcelMeterData toPushMeterExcle(MeterPara para,Meter meter){
        ExcelMeterData excelMeterData = new ExcelMeterData();
        if(null != para){
            excelMeterData.setMeterIndex(para.getMeterIndex());         //0序号
            excelMeterData.setMpedIndex(para.getMpedIndex());           //1测量点号
            excelMeterData.setCommPort(para.getCommPort());             //2通信端口
            excelMeterData.setCommRate(para.getCommRate());             //3通信速率
            excelMeterData.setProtocolType(para.getProtocolType());     //4通信类型
            excelMeterData.setCommAddr(para.getCommAddr());             //5通信地址
            excelMeterData.setCommPwd(para.getCommPwd());               //6通信密码
            excelMeterData.setTariffNum(para.getTariffNum());           //7费率个数
            excelMeterData.setDecimalNum(para.getDecimalNum());         //8小数位个数
            excelMeterData.setIntegerNum(para.getIntegerNum());         //9整数位个数
            excelMeterData.setCollectorAddr(para.getCollectorAddr());   //10采集地址
            excelMeterData.setConsMainType(para.getConsMainType());     //11用户大类号
            excelMeterData.setConsSubType(para.getConsSubType());       //12用户小类号
            excelMeterData.setHardwareType(para.getHardwareType()==1?"合闸":"直接合闸") ;     //继电器合闸方式(1:合闸，2直接合闸)
        }

        BDGrade bdGrade = provideDataMapper.getBDGrade(meter.getTgBuildDoorplate());

        if(null != bdGrade){
            excelMeterData.setDoorplate(bdGrade.getBdName());           //14门牌
            if(bdGrade.getParentId()  != null){
                BDGrade unit = provideDataMapper.getBDGrade(bdGrade.getParentId());
                excelMeterData.setBuildingUnit(unit.getBdName());       //楼栋
            }
            excelMeterData.setBdNo(bdGrade.getBdNo());          //门派编号
        }


        excelMeterData.setMeasMode(meter.getMeasMode().equals("1")?"高供高计" :(meter.getMeasMode().equals("2")?"高供低计":"低供低计"));            //计量方式
        excelMeterData.setVoltCode(converteVoltCode(meter.getVoltCode()));             //电压等级
        excelMeterData.setTFactor(meter.gettFactor());                  //综合倍率
        excelMeterData.setPapR(meter.getPapR());    //正向有功总电能示值
        excelMeterData.setPapR1(meter.getPapR1());  //正向有功费率1示值
        excelMeterData.setPapR2(meter.getPapR2());  //正向有功费率2示值
        excelMeterData.setPapR3(meter.getPapR3());  //正向有功费率3示值
        excelMeterData.setPapR4(meter.getPapR4());  //正向有功费率4示值
        excelMeterData.setGpsLongitude(meter.getGpsLongitude()); //Gps经度
        excelMeterData.setGpsLatitude(meter.getGpsLatitude());   //Gps纬度
        excelMeterData.setBaseValue(meter.getBaseValue());      //电表低度
        excelMeterData.setWiringMode(convertWiringMode(meter.getWiringMode()));    //接线方式
        excelMeterData.setAssetNo(meter.getAssetNo());      //电表编号
        excelMeterData.setInstLoc(meter.getInstLoc());      //安装位置
        excelMeterData.setMeterUsage(meter.getMeterUsage() == 1?"结算":"考核");  //电表用途
        excelMeterData.setIsTap("否");                       //是否有阀
        excelMeterData.setInstDate(meter.getInstDate());    //安装时间
        return excelMeterData;
    }

    private String converteVoltCode(String value){
        if("1".equals(value)){
            return "10KV";
        }else if("2".equals(value)){
            return "110KV";
        }else if("3".equals(value)){
            return "220KV";
        }else if("4".equals(value)){
            return "35KV";
        }else if("5".equals(value)){
            return "220V";
        }else if("6".equals(value)){
            return "6KV";
        }else if("7".equals(value)){
            return "380V";
        }else if("8".equals(value)){
            return "500KV";
        }else {
            return "10KV";
        }
    }

    private String convertWiringMode(String value){

        if("1".equals(value)){
            return "单相";
        }else if("2".equals(value)){
            return "三相三线";
        }else if("3".equals(value)){
            return "三相四线";
        }else {
            return "单相";
        }
    }


}
