package com.service.organization.impl;

import com.mapper.organization.OrgMapper;
import com.entity.organization.Org;
import com.service.organization.OrgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 说明：单位service
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-12-30
 */
@Service
public class OrgServiceImpl implements OrgService {

    @Autowired
    private OrgMapper orgMapper;


    @Override
    public Org getOrg(String orgId) {
        return orgMapper.getOrg(orgId);
    }

    @Override
    public Org getOrgByAccount(String orgAccount) {
        return orgMapper.getOrgByAccount(orgAccount);
    }
}
