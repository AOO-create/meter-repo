package com.common;

public enum ResultCodeEnum {
    SUCCESS(200, "成功"),
    UNVERIFIED(401, "未登录"),
    UNKNOWN_ERROR(500, "服务器异常"),
    PARAM_ERROR(501, "参数错误"),
    HTTP_CLIENT_ERROR(700, "http 客户端 异常"),
    ACCOUNT_ERROR(401, "用户名重复，注册失败"),
    UPDATE_PWD_FAIL(402, "认证服务不正常！"),
    ACCOUNT_NOT_FOUND(403, "用户名找不到"),
    ACCOUNT_IS_EXIST(403, "用户名已存在"),
    ACCOUNT_NOT_POWER(403, "用户权限不够"),
    FILE_NOT_FOUND(403, "文件找不到"),
    ACCOUNT_NOT_ERROR(404,"用户名或密码错误"),
    UPDATE_PWD_ERROR(405,"密码错误"),
    URL_ERROR(40006,"URL路径错误"),
    ORG_NOT_FOUND_ERROR(40007,"该url下无公司，请输入正确的url"),
    LOGOUT_ERROR(40008,"用户注销登录出现异常"),
    LOGOUT(4000, "用户登出"),
    EXCELIN_ERROR(4009, "导入文件失败,导入文件存在问题"),
    EXCELOUT_ERROR(4010, "导出文件失败"),
    DELETE_TERM_ERROR(4011,"集中器删除失败，存在关联表具，请先解除"),
    DELETE_WIRED_ERROR(4012,"有线表具删除失败"),
    ADD_USER_ERROR(4013,"用户新增失败"),
    UPDATE_USER_ERROR(4014,"用户更新失败"),
    DELETE_USER_ERROR(4015,"用户删除失败"),
    BATCHDELETE_USER_ERROR(4015,"用户批量删除失败"),

    ADD_ROLE_ERROR(6001,"角色新增失败"),
    UPDATE_ROLE_ERROR(6002,"角色更新失败"),
    DELETE_ROLE_ERROR(6003,"角色删除失败"),

    UPDATE_ROLE_MENU_PREMIT_ERROR(6003,"菜单权限修改失败"),
    BATCH_UPDATE_ROLE_MENU_PREMIT_ERROR(6003,"菜单权限批量修改失败"),

    SAVE_TENANT_ERROR(5001,"租户保存失败"),
    CALCULATE_ADD_ERROR(5002,"方案添加失败"),



    ;

    // 响应状态码
    private Integer code;
    // 响应信息
    private String message;

    ResultCodeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
