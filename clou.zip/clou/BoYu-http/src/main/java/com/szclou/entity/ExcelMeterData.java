package com.szclou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2023/8/17
 */
@Data
public class ExcelMeterData {
    private double baseValue;//水表低度
    private String buildingUnit;//楼栋单元
    private String doorplate;//门牌
    private double rate;//倍率
    private String instLoc;//安装位置
    private String gpsLongitude;//gps经度
    private String gpsLatitude;//gps纬度
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date instDate;

    private String bdNo;//门派编号

    private String isTap;
    private Integer meterIndex;//电能表序号
    private Integer mpedIndex;//所属测量点号
    private Integer commRate;//通信速率
    private Integer commPort;//端口号
    private Integer protocolType;//通信规约类型
    private String commAddr;//通信地址
    private String commPwd;//通信密码
    private Integer tariffNum;//电能费率个数
    private Integer integerNum;//有功电能示值的整数位个数
    private Integer decimalNum;//有功电能示值的小数位个数
    private String collectorAddr;//所属采集器通信地址
    private Integer consMainType;//用户大类号
    private Integer consSubType;//用户小类号
    private String hardwareType; //合闸方式


    private String assetNo;//资产编号
    private String wiringMode;//接线方式
    private String measMode;//计量方式
    private String voltCode;//电压等级
    private String tFactor;//综合倍率
    private int doorPlate;//门牌
    private double papR;//费率总
    private double papR1;//费率1
    private double papR2;//费率2
    private double papR3;//费率3
    private double papR4;//费率4
    private String meterUsage;

}
