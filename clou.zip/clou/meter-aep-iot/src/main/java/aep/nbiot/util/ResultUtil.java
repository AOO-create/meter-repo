package aep.nbiot.util;

import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AEP 请求返回处理
 * @date 2021/11/17 13:16
 */
public class ResultUtil {

    private static Integer code = 1000;

    private static String msg = "暂未实现该API能力，通知下开发者吧！^_^";

    /**
     * 将AEP返回结果转换为字符串
     * @param baseApiResponse AEP请求返回对象
     * @return
     */
    public static String convetResponse(BaseApiResponse baseApiResponse){
        return new String(baseApiResponse.getBody());
    }

    /**
     * 默认ERROR错误信息
     * @return
     */
    public static HashMap<String,Object> defaultError(){
        HashMap<String,Object> defaultErrorResult = new HashMap<>();
        defaultErrorResult.put("code",code);
        defaultErrorResult.put("msg",msg);
        return defaultErrorResult;
    }

    public static HashMap<String,Object> defaultSuccess(){
        HashMap<String,Object> defaultErrorResult = new HashMap<>();
        defaultErrorResult.put("code",0);
        defaultErrorResult.put("msg","ok");
        return defaultErrorResult;
    }

}
