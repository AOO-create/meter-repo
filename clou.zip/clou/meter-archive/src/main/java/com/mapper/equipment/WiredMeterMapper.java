package com.mapper.equipment;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.equipment.WiredMeter;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface WiredMeterMapper extends BaseMapper<WiredMeter> {
    
    List<WiredMeterDTO> getMeter(@Param("dto") WiredMeterDTO dto, @Param("areaId") String areaId,@Param("bids")List<String> bdList);

    int getCount(@Param("dto") WiredMeterDTO dto,  @Param("areaId") String areaId,@Param("bids")List<String> bdList);

    List<MeterDayDataDTO> getDateByAreaIdAndOrgId(@Param("dto") MeterDayDataDTO dto,@Param("date") String date);

    int getDateDayCount(@Param("dto") MeterDayDataDTO dto,@Param("date") String date);

    void addDayData(@Param("dto") MeterDayDataDTO dto);

    void batchInsertWired(@Param("list") List<WiredMeterDTO> list);

    void updateTermAddress(@Param("oldAddress") String oldAddress,@Param("newAddress") String newAddress);

    List<MeterDayDataDTO> getDataByTgIdAndOrgId(@Param("dto") MeterDayDataDTO dto, @Param("ids") List<String> idList,@Param("date") String date);

    int getDateDayCountByTgId(@Param("dto") MeterDayDataDTO dto, @Param("ids") List<String> idList,@Param("date") String date);

    List<MeterDayDataDTO> get818Meter(@Param("areaId") String areaId,@Param("ids") List<String> ids);
}
