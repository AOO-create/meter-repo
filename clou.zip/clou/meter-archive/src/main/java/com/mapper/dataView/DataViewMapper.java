package com.mapper.dataView;


import com.dto.dataView.DateDataDTO;
import com.dto.dataView.MeterPapR;
import com.dto.dataView.OperateRecordDTO;
import com.dto.dataView.CommonMapDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
public interface DataViewMapper {
    int getMeterSum(@Param("orgId")String orgId,@Param("areaId")String areaId,@Param("ids")List<String> ids);

    int getUserSum(@Param("orgId")String orgId,@Param("areaId")String areaId,@Param("ids")List<String> ids);

    int getTermSum(@Param("orgId")String orgId,@Param("areaId") String areaId);

    int getReportSum(@Param("orgId")String orgId, @Param("areaId") String areaId, @Param("date") String date, @Param("ids")List<String> ids);

    int getFeeSum(@Param("orgId")String orgId,@Param("areaId") String areaId,@Param("ids")List<String> ids);

    int getWireSumByMeterType(@Param("orgId")String orgId,@Param("areaId") String areaId,@Param("ids")List<String> ids,@Param("meterType")String meterType);

    List<CommonMapDTO> getOrgTenantNumber(@Param("orgId") String orgId);

    CommonMapDTO getRoomTenantNumber(@Param("id")String tgBuildDoorplate, @Param("ids") List<String> ids);

    List<CommonMapDTO> getTgTenantNumber(@Param("tgId")String tgBuildDoorplate);

    List<String> getTgNameByAreaId(@Param("areaId") String areaId);

    int getWireReportSum(@Param("orgId") String orgId, @Param("areaId") String areaId, @Param("date") String date,@Param("ids") List<String> bdList);

    int getNbSum(@Param("orgId")String orgId,@Param("areaId") String areaId,@Param("ids")List<String> ids);

    int getNbReportSum(@Param("orgId") String orgId, @Param("areaId") String areaId, @Param("date") String date,@Param("ids") List<String> bdList);

    List<OperateRecordDTO> getRecordOperate(@Param("orgId") String orgId, @Param("areaId") String areaId);

    int getWaterSum(@Param("orgId") String orgId,@Param("areaId") String areaId,@Param("ids") List<String> bdList);

    int getElecReport(@Param("orgId") String orgId,@Param("areaId") String areaId,@Param("date") String date,@Param("ids") List<String> bdList);

    int getMeterSumByDate(@Param("orgId") String orgId,@Param("areaId") String areaId,@Param("ids") List<String> bdList,@Param("date") String date);

    List<String>  getMeterId(@Param("ids") List<String> ids);

    String getCL6904Data(@Param("id") String id,@Param("date") String date);

    List<String> getAllMeterId();

    int getOioElecReport(@Param("ids") List<String> meterId,@Param("date") String format);

    MeterPapR getAllPapR(@Param("date") String s);

    List<String> getWiredMeterIds(@Param("areaId") String areaId,@Param("ids") List<String> bdIds);

    MeterPapR getPapR(@Param("date") String date,@Param("ids") List<String> wiredMeterIds);

    Double getAllTimePapR(@Param("date") String dd,@Param("one") String one,@Param("two") String two);

    Double getTimePapR(@Param("date") String dd,@Param("one") String one,@Param("two") String two,@Param("ids") List<String> finalWiredMeterIds);
}
