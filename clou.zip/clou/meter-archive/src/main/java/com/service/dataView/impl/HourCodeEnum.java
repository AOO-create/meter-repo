package com.service.dataView.impl;

import com.dto.equipment.MeterDayVo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class HourCodeEnum {

    public static List<String> searchHourData(Integer timeType){

        List<String> conList = new ArrayList<String>();
//        Integer hour = (timeType)*6;
        for (int i =0 ;i<(timeType+1)*6;i++){

            String hourString="";
            if(i<10){
                hourString = "0"+i+":00";
            }else {
                hourString = i+":00";
            }
            conList.add(hourString);
            System.out.println(hourString);
        }
        return conList;
    }
    public static List<String> searchDayData(Integer dayType){

        List<String> conList = new ArrayList<String>();
        Calendar cal=Calendar.getInstance();
        List<String> meterList = new ArrayList<String>();
        List<String> dateList = new ArrayList<String>();
        List<MeterDayVo> result= new ArrayList<MeterDayVo>();
        for (int i =1;i<=dayType;i++){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            cal.add(Calendar.DATE,-1);
            String yesterday= sdf.format(cal.getTime());
            conList.add(yesterday);

        }
        Collections.reverse(conList);
        conList.forEach(item->{
            System.out.println(item);
        });
        return conList;
    }


    public static void main(String[] args) {
//        searchDayData(30);
        searchHourData(3);
//        searchHourData(2);
//        searchHourData(3);
    }
}
