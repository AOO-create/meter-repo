package com.service.message.Impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fegin.client.ArchiveClient;
import com.common.Const;
import com.dto.UserAndTenantDTO;
import com.mapper.message.MessageManagerMapper;
import com.mapper.tenant.TenantMapper;
import com.mapper.user.UserMapper;
import com.pojo.Message;
import com.pojo.Role;
import com.pojo.Tenant;
import com.pojo.User;
import com.service.message.MessageManagerService;
import com.dto.MessageDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author liuwei
 * @description
 * @date 2022/9/30
 */
@Service
public class MessageManagerServiceImpl implements MessageManagerService {

    @Autowired
    private MessageManagerMapper mapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TenantMapper tenantMapper;

    @Autowired
    private ArchiveClient archiveClient;

    @Override
    public Page<MessageDTO> findMessage(MessageDTO vo) {
        String roleCode = archiveClient.getRole().getRoleCode();
        QueryWrapper<Message> qw = new QueryWrapper<>();

        if (!roleCode.equals("admin")) {
            if (vo.getDeal().equals("1")) {
                qw.eq("create_user", Const.userId);
            }
            if (vo.getDeal().equals("2")) {
                qw.eq("recieve_user", Const.userId);
            }
        }

        if (null != vo.getStatus() && !vo.getStatus().equals("")) {
            qw.eq("status", vo.getStatus());
        }

        if (null != vo.getTitle() && !vo.getTitle().equals("")) {
            qw.like("title", vo.getTitle());
        }

        Page<Message> page = new Page<>(vo.getPage(), vo.getLimit());
        page = mapper.selectPage(page, qw);
        Page<MessageDTO> pageVo = new Page<>(vo.getPage(), vo.getLimit());
        BeanUtils.copyProperties(page, pageVo);
        List<MessageDTO> voList = new ArrayList<>();
        page.getRecords().forEach(val -> {
            String recieveName = "";

            User user = userMapper.selectById(val.getRecieveUser());
            if(user == null){
                recieveName = tenantMapper.selectById(val.getRecieveUser()).getName();
            }else{
                recieveName = userMapper.selectById(val.getRecieveUser()).getName();
            }
            String createName = userMapper.selectById(val.getCreateUser()).getName();
            MessageDTO messageDto = new MessageDTO();
            messageDto.setFilename(val.getFilename());
            messageDto.setCreateTime(val.getCreateTime());
            messageDto.setRecieveName(recieveName);
            messageDto.setCreateName(createName);
            BeanUtils.copyProperties(val, messageDto);
            voList.add(messageDto);
        });
        pageVo.setRecords(voList);
        return pageVo;
    }

    /**
     * 功能描述  新增消息（分为系统消息、通知消息） sendType 发送类型 0全体 1组织 2用户住户
     * @param
     * @return
     * @author liuwei
     * @date 2022/10/8
     */
    @Transactional
    @Override
    public boolean addMessage(MessageDTO vo) {
        String identity = vo.getIdentity();
        String orgId = archiveClient.getOrg().getOrgId();
        List<User> userList = new ArrayList<>();
        List<Tenant> tenantList = new ArrayList<>();
        List<String> bdList = archiveClient.reGetChildBDGradeId(vo.getTgBuildDoorplate() + "", orgId);
        User currentUser = userMapper.selectById(Const.userId);
        if (vo.getSendType().equals("0")) {
            if (identity.equals("admin")) {
                //管理员发送全部用户
                userList = userMapper.selectList(new QueryWrapper<User>().eq("org_id", orgId).ne("id", Const.userId));
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().eq("org_id", orgId).ne("id", Const.userId));
            } else {
                //发送给全体成员 非管理员
                if (vo.getAreaId() != null && vo.getTgBuildDoorplate() == null) {
                    //查找所有该组织区域下的所有用户
                    tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().eq("area_id", currentUser.getAreaId()));
                    userList = userMapper.selectList(new QueryWrapper<User>().eq("area_id", currentUser.getAreaId()).ne("id", Const.userId));
                } else {
                    bdList = archiveClient.reGetChildBDGradeId(currentUser.getTgBuildDoorplate() + "", orgId);
                    userList = userMapper.selectList(new QueryWrapper<User>().in("tg_build_doorplate", bdList).ne("id", Const.userId));
                    tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("tg_build_doorplate", bdList));
                }
            }
        } else if (vo.getSendType().equals("1")) {
            //发送给组织区域下用户
            if (vo.getAreaId() != null && vo.getTgBuildDoorplate() == null) {
                //点击选中组织区域
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().eq("area_id", vo.getAreaId()));
                userList = userMapper.selectList(new QueryWrapper<User>().eq("area_id", vo.getAreaId()).ne("id", Const.userId));
            } else {
                //点击选中门栋单元
                userList = userMapper.selectList(new QueryWrapper<User>().in("tg_build_doorplate", bdList).ne("id", Const.userId));
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("tg_build_doorplate", bdList));
            }
        } else if (vo.getSendType().equals("2")) {
            //发送给选中的用户
            userList = userMapper.selectList(new QueryWrapper<User>().in("id", vo.getUserIds()).ne("id", Const.userId));
            tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("id", vo.getTenantIds()));
        }
        insertMessage(userList, vo, tenantList);
        return true;
    }

    private void insertMessage(List<User> userList, MessageDTO vo, List<Tenant> tenantList) {
        Date now = new Date();
        for (User user1 : userList) {
            Message message = new Message();
            message.setCreateTime(now);
            message.setStatus("2");
            message.setCreateUser(Long.valueOf(Const.userId));
            message.setTitle(vo.getTitle());
            message.setFilename(vo.getFilename());
            message.setContent(vo.getContent());
            message.setFilename(vo.getFilename());
            if (vo.getIdentity().equals("admin")) {
                message.setType("1");
            } else {
                message.setType("2");
            }
            message.setRecieveUser(user1.getId());
            mapper.insert(message);
        }
        for (Tenant tenant : tenantList) {
            Message message = new Message();
            message.setCreateTime(now);
            message.setStatus("2");
            message.setCreateUser(Long.valueOf(Const.userId));
            message.setTitle(vo.getTitle());
            message.setFilename(vo.getFilename());
            message.setContent(vo.getContent());
            message.setFilename(vo.getFilename());
            if (vo.getIdentity().equals("admin")) {
                message.setType("1");
            } else {
                message.setType("2");
            }
            message.setRecieveUser(tenant.getId());
            mapper.insert(message);
        }
    }

    /**
     * 进入页面给予身份标识信息
     * @param
     * @return
     * @author liuwei
     * @date 2022/10/8
     */
    @Override
    public Map<String, String> userIdentity() {
        Map<String, String> map = new HashMap<>();
        Role role = archiveClient.getRole();
        if (role.getRoleCode().equals("admin")) {
            //管理员用户，
            map.put("identity", "admin");
        } else {
            map.put("identity", "user");
        }
        map.put("userId", Const.userId + "");
        return map;
    }

    /**
     * 根据登录人身份，id获取未读消息的条数
     * @param
     * @return
     * @author liuwei
     * @date 2022/10/17
     */
    @Override
    public Integer getMsCountBelongSelf() {
        QueryWrapper<Message> qw = new QueryWrapper<>();
        qw.eq("recieve_user", Const.userId);
        qw.eq("status", "2");
        return mapper.selectCount(qw);
    }

    /**
       * 查找登录用户接收的所有未读信息
       * @author liuwei
       * @date  2023/10/20
       * @params []
       * @return java.util.List<com.dto.MessageDTO>
     */
    @Override
    public List<MessageDTO> getMessageReadNo() {
        List<Message> messages = new ArrayList<>();
        List<MessageDTO> messageDTOS = new ArrayList<>();
        QueryWrapper<Message> qw = new QueryWrapper<>();
        qw.eq("recieve_user", Const.userId);
        qw.eq("status", "2");
        messages = mapper.selectList(qw);
        for (Message message : messages) {
            String userName = userMapper.selectById(message.getCreateUser()).getName();
            MessageDTO vo = new MessageDTO();
            BeanUtils.copyProperties(message, vo);
            vo.setCreateName(userName);
            messageDTOS.add(vo);
        }
        return messageDTOS;
    }

    /***
       * 读消息，改变消息状态
       * @author liuwei
       * @date  2023/10/20
       * @params [id]
       * @return boolean
     */
    @Override
    public boolean readMessage(String id) {
        Message message = mapper.selectById(id);
        message.setStatus("1");
        return mapper.updateById(message) > 0;
    }

    /**
       * 获取登录用户接收的所有消息
       * @author liuwei
       * @date  2023/10/20
       * @params [id]
       * @return java.util.List<com.dto.MessageDTO>
     */
    @Override
    public List<MessageDTO> getMessageByUser(String id) {
        List<Message> messages = new ArrayList<>();
        List<MessageDTO> messageDTOS = new ArrayList<>();
        QueryWrapper<Message> qw = new QueryWrapper<>();
        qw.eq("recieve_user", id);
        messages = mapper.selectList(qw);
        for (Message message : messages) {
            String userName = userMapper.selectById(message.getCreateUser()).getName();
            MessageDTO vo = new MessageDTO();
            BeanUtils.copyProperties(message, vo);
            vo.setCreateName(userName);
            messageDTOS.add(vo);
        }
        return messageDTOS;
    }

    /**
       * 获取登录用户组织架构管辖下的用户和住户
       * @author liuwei
       * @date  2023/10/20
       * @params [id]
       * @return java.util.List<com.dto.UserAndTenantDTO>
     */
    @Override
    public List<UserAndTenantDTO> getUserAndTenant(String id) {
        String roleCode = archiveClient.getRole().getRoleCode();
        String orgId = archiveClient.getOrg().getOrgId();
        List<UserAndTenantDTO> dtoList = new ArrayList<>();
        List<User> userList = new ArrayList<>();
        List<Tenant> tenantList = new ArrayList<>();
        if (roleCode.equals("admin")) {
            userList = userMapper.selectList(new QueryWrapper<User>().ne("id",Const.userId));
            tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>());
        } else {
            User user = userMapper.selectById(id);
            if ("".equals(user.getTgBuildDoorplate()) || null == user.getTgBuildDoorplate()) {
                //组织区域用户
                List<String> idsList = archiveClient.reGetChildGradeId(user.getAreaId(), orgId);
                userList = userMapper.selectList(new QueryWrapper<User>().in("area_id", idsList).ne("id",Const.userId));
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("area_id", idsList));
            } else {
                //非组织区域用户
                List<String> bdList = archiveClient.reGetChildBDGradeId(user.getTgBuildDoorplate(), orgId);
                userList = userMapper.selectList(new QueryWrapper<User>().in("tg_build_doorplate", bdList).ne("id",Const.userId));
                tenantList = tenantMapper.selectList(new QueryWrapper<Tenant>().in("tg_build_doorplate", bdList));
            }
        }
        userList.forEach(val -> {
            UserAndTenantDTO dto = new UserAndTenantDTO();
            String areaName = "";
            if(null == val.getTgBuildDoorplate()||"".equals(val.getTgBuildDoorplate())){
                areaName = archiveClient.getGradeNameById(val.getAreaId());
            }else{
                areaName = archiveClient.getBDGradeNameById(val.getTgBuildDoorplate());
            }
            dto.setAreaName(areaName);
            dto.setId(val.getId() + "");
            dto.setName(val.getName());
            dto.setType("0");
            dtoList.add(dto);
        });
        tenantList.forEach(val -> {
            UserAndTenantDTO dto = new UserAndTenantDTO();
            String areaName = "";
            if(null == val.getTgBuildDoorplate()){
                areaName = archiveClient.getGradeNameById(val.getAreaId()+"");
            }else{
                areaName = archiveClient.getBDGradeNameById(val.getTgBuildDoorplate()+"");
            }
            dto.setAreaName(areaName);
            dto.setId(val.getId() + "");
            dto.setName(val.getName());
            dto.setType("1");
            dtoList.add(dto);
        });
        return dtoList;
    }


}
