package com.service.tenant;

import com.vo.tenant.TenantVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/7/26
 */
public interface TenantService {
    Page<TenantVo> getTenantByAreaId(TenantVo areaId);

    Page<TenantVo> getTenantBybdId(TenantVo bdId);

    Page<TenantVo> getAllTenant(TenantVo vo);

    Boolean tenantSave(TenantVo vo);

    Boolean deleteTenant(String id);

    Boolean batchDeleteTenant(List<String> ids);
}
