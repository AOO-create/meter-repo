package com.controller.systemSetup;

import com.entity.systemSetup.User;
import com.mapper.systemSetup.UserMapper;
import com.service.systemSetup.UserManagerService;
import com.vo.systemSetUpVo.UserVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/27
 */
@RestController
    @RequestMapping("/archive/userManager")
public class UserManagerController {

    @Autowired
    private UserManagerService service;

    @Autowired
    private UserMapper userMapper;

    public static void main(String[] args) {
        String pass = new BCryptPasswordEncoder().encode("456789123@asd");
        System.out.println(pass);
//        e3e4f753044c6833770bab41cd7102bc2c268b90
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("findAllUser")
    @ResponseBody
    public Page<UserVo>  findAllUser(@RequestBody  UserVo user){
        return service.findAllUser(user);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @GetMapping("updatePassword")
    @ResponseBody
    public boolean updatePassword(@RequestParam("id") String id,@RequestParam("pass") String pass,@RequestParam("updatePassword") String updatePassword){
        return service.updatePassword(id,pass,updatePassword);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("saveUser")
    @ResponseBody
    public Result saveUser(@RequestBody UserVo user){
        if(user.getId() == null ||user.getId() == 0L){
            return service.addUser(user);
        }else {
            return service.updateUser(user);
        }
    }

    //测试用的方法修改密码成加密方式
    @GetMapping("setPassword")
    public void setPassword(@RequestParam("id") String id,@RequestParam("password")String password){
         password = new BCryptPasswordEncoder().encode(password);
         User user = userMapper.selectById(id);
         user.setPassword(password);
         userMapper.updateById(user);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @GetMapping("deleteUser")
    @ResponseBody
    public Result deleteUser(@RequestParam("id") String id){
        return service.deleteUser(id);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("batchDelUser")
    @ResponseBody
    public Result batchDelUser(@RequestParam("ids") List<String> ids){
        return service.batchDelUser(ids);
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("getRoleToSel")
    @ResponseBody
    public Result getRoleToSel(){
        return Result.OK(service.getRoleToSel());
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("getUserListByRole")
    @ResponseBody
    public Result getUserListByRole(@RequestBody UserVo vo){
        return  Result.OK(service.getUserListByRole(vo));
    }

}
