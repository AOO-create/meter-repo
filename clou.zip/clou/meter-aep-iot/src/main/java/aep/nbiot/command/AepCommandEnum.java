package aep.nbiot.command;

/**
 * @author wufanghao
 * @version 1.0
 * @description: AEP 命令定义接口
 * @date 2021/11/17 8:33
 */
public interface AepCommandEnum {

}
