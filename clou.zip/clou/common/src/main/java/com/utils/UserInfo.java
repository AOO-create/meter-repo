package com.utils;


import com.entity.Org;
import com.entity.Role;
import com.entity.User;
import lombok.Data;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
@Component
@Data
public class UserInfo {

    private  Org org ;

    private  User user;

    private  Role role;

    private  String tgBuildDoorplate;

    private String areaId;

}
