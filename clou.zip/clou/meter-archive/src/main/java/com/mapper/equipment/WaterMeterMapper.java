package com.mapper.equipment;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface WaterMeterMapper {


    int findCountByBDGradeId(String id);
}
