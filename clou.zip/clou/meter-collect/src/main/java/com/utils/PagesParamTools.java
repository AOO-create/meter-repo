package com.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public class PagesParamTools<T> {

    public static QueryWrapper pagesParam(Map<String, Object> t){
        QueryWrapper conditions = new QueryWrapper<>();
        t.forEach((k, v) -> {
            for(int i = 0; i < k.length(); i++){
                if(Character.isUpperCase(k.charAt(i))){
                    String m=""+k.charAt(i);
                    k = k.replace(m,"_"+m.toLowerCase());
                }
            }
            if (k.indexOf("name")!=-1) {
                if (v!=null&&!StringUtils.isEmpty(v.toString().trim())) {
                    conditions.like(k, v);
                }
            }else {
                if (v!=null&&!StringUtils.isEmpty(v.toString().trim())) {
                    conditions.eq(k, v);
                }
            }
        });
        return conditions;
    }

}