package com.common;



import java.util.Arrays;
import java.util.List;

/**
 * 说明：
 * 作者：刘威
 * 时间：2022-4-8 10:54
 */
public class Const {
    public static final String SESSION_ORG_ACCOUNT = "_ORG_ACCOUNT";
    public static final String SESSION_ORG = "sessionOrg";//当前供能单位
    public static final String SESSION_ORGNAME = "SESSION_ORGNAME";
    public static final String SESSION_SECURITY_CODE = "sessionSecCode";
    public static final String SESSION_USER = "SESSION_USER";//当前用户
    public static final String SESSION_USERNAME = "SESSION_USERNAME";
    public static final String SESSION_USERROL = "USERROL";                //用户对象
    public static final String SESSION_ROLE = "sessionRoleList";
    public static final String SESSION_allmenuList = "SESSION_allmenuList";

    //表操作日志类型
    public static final int operate_wired_update = 1;
    public static final int operate_wired_insert = 2;
    public static final int operate_nb_insert = 3;
    public static final int operate_nb_update = 4;
    public static final int operate_nb_delete = 5;
    public static final int operate_nb_batch_delete = 6;
    public static final int operate_wired_delete = 7;
    public static final int operate_wired_batch_delete = 8;

    //换表日志类型
    public static final int unbind_nb_meter = 1;
    public static final int change_nb_meter = 2;
    public static final int unbind_wired_meter = 3;
    public static final int change_wired_meter = 4;

    public static final int unbind_meter = 1;
    public static final int change_meter = 2;

    /***
     * 单点登录構建websocket
     */
    public static final String loginSingle = "0001";
    /***
     * 实时抄表
     */
    public static final String CurrentMeter = "0000";
    /***
     * 删除websocket值
     */
    public static final String deleteWebsocket = "0002";
    /***
     * 4G水表开关阀状态变化
    */
    public static final String FourthStatus = "0003";
    /***
     * 4G水表实时抄表
     */
    public static final String FourthRead = "0004";
    /**
     * 集中器下行命令
     */
    public static final String TermCommand = "0005";
    /***
     * 抄集中器成功
     */
    public static final String rspReadTermSuc = "000006";
    /***
     * 抄集中器失败
     */
    public static final String rspReadTermFail = "000001";
    /***
     *集中器下行命令重复
     */
    public static final String termCommandRe = "0000002";

 //--- 导入对应列
    //导入集中器模板类型
    public static final List<String> TERM_EXCEL = Arrays.asList("address","name","areaName","protocolCode","modelType");
    //导入有线表模板类型
    public static final List<String> WIRED_EXCEL = Arrays.asList("meterAddress","name","bdName","termId","meterType","channel",
            "protocol","uartbps");
    //导入NB表模板类型
    public static final List<String> NB_EXCEL = Arrays.asList("meterAddress","name","areaName","bdName","imei","protoCode");
    //导入NB表生产环境模板类型
    public static final List<String> NB_PRODUCT_EXCEL = Arrays.asList("name","meterAddress","imei");


 //---导出表格标题
    //导出日冻结数据表格标题
    public static final String[] EXPORT_DAY_DATA_EXCEL = {"安装地址","表地址","表具名称", "总电量","实际电量","尖电量","峰电量","平电量","谷电量","采集日期",};
    public static final String[] EXPORT_INCRE_DATA_EXCEL = {"电表名称","表地址","表具地址", "日增量数据","实际日增量","采集日期",};
    //导出有线表表具档案表格标题
    public static final String[] EXPORT_WIRED_METER_EXCEL = {"表地址","表名","房间号","关联集中器","表具类型","硬件通道","通信协议","串口波特率"};
    //导出集中器档案标题
    public static final String[] EXPORT_TERM_EXCEL = {"集中器地址","集中器名称","组织区域","通讯规约","集中器型号"};
    //导出NB表档案标题(生产环境)
    public static final String[]  EXPORT_NB_PRODUCT_EXCEL=  {"NB表名称","表地址","IMEI"};
    //导出NB表档案标题
    public static final String[] EXPORT_NB_EXCEL =  {"表地址","NB表名称","组织区域","门栋单元","IMEI","传输协议"};
    //导出采集表具标题
    public static final String[] EXPORT_COLLECT_METER_EXCEL = {"表地址","imei/集中器","表名称","安装位置","采集冻结数据","采集日期","表具类型","采集结果"};

 //----sheet页名称
    //导出日冻结数据表格sheet页名称
    public static final String EXPORT_SHEET_DAY_DATA = "日冻结数据";
    public static final String EXPORT_SHEET_INCRE_DAY_DATA = "日增量数据";
    //导出有线表表具档案表格sheet页名称
    public static final String EXPORT_SHEET_WIRED_METER = "有线表表具档案";
    //导出集中器档案表格sheet页名称
    public static final String EXPORT_SHEET_TERM = "集中器档案";
    //导出NB档案表格sheet页名称
    public static final String EXPORT_SHEET_NB = "NB表具档案";
    //导出NB档案表格sheet页名称(生产环境)
    public static final String EXPORT_SHEET_NB_PRODUCT = "NB表具档案（生产环境）";
    //导出日数据统计表格sheet页名称
    public static final String EXPORT_SHEET_STATISTICS_DATA = "区域采集统计";
    //导出采集失败表具表格sheet页名称
    public static final String EXPORT_SHEET_COLLECT_METER = "抄见统计统计";

    //新协议下行命令类型
    public static final String TO_SEND_FRAME_ONE = "1";
    public static final String TO_SEND_FRAME_TWO = "2";
    public static final String TO_SEND_FRAME_THREE = "3";
    public static final String TO_SEND_FRAME_FOUR = "4";
    public static final String TO_SEND_FRAME_FIVE = "5";
    public static final String TO_SEND_FRAME_SIX = "6";
    public static final String TO_SEND_FRAME_SEVEN = "7";
    public static final String TO_SEND_FRAME_EIGHT = "8";
    public static final String TO_SEND_FRAME_NINE = "9";
    public static String userId = "";
    //导入表格模板类型
    public static List<String> DAY_DATE_EXCEL = Arrays.asList("collTime", "realSumFlow", "meterAddress", "dataDate",
            "updTime");//日冻结模板

}
