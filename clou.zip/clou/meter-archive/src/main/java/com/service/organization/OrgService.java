package com.service.organization;


import com.entity.organization.Org;

/**
 * @author liuwei
 * @description
 * @date 2022/5/11
 */
public interface OrgService {

     Org getOrg(String orgId);

    Org getOrgByAccount(String orgAccount);
}
