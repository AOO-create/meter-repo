package com.service.loginLog;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.log.LoginLog;
import com.vo.SystemLogVo.LoginLogVo;

/**
 * @author liuwei
 * @description
 * @date 2023/10/26 
 */
public interface LoginLogService {
    Page<LoginLog> getPageLoginLog(LoginLogVo log);
}
