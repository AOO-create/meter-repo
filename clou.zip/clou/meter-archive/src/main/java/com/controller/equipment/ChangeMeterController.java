package com.controller.equipment;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.equipment.MeterDTO;
import com.dto.equipment.NBDTO;
import com.service.equipment.ChangeMeterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/equipment/changeMeter")
public class ChangeMeterController {

    @Autowired
    private ChangeMeterService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getMeterByBuild")
    @ResponseBody
    public Page<MeterDTO> getMeterByBuild(@RequestBody MeterDTO dto){
        return service.getMeterByBuild(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/unBindMeter")
    @ResponseBody
    public boolean unBindMeter(@RequestBody MeterDTO dto){
        return service.unBindMeter(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/toChangeMeter")
    @ResponseBody
    public boolean toChangeMeter(@RequestBody MeterDTO dto){
        return service.toChangeMeter(dto);
    }



}
