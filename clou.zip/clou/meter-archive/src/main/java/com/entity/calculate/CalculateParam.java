package com.entity.calculate;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
@TableName("calculate_param")
public class CalculateParam {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;

    private String type;//方案类型 1：统一水价 2：阶梯水价

    private String level;//阶梯水价特有。分为1-N阶 1-N

    private String end;//结尾值；阶梯水价

    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long calculateFeeId;//计算方式的id

    private Double value;//参数值

    private String remark;//参数描述
}
