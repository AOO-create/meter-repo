package com.service.systemSetup;

import com.common.Result;
import com.entity.systemSetup.Menu;
import com.entity.systemSetup.Role;
import com.vo.systemSetUpVo.RoleVo;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface RoleService extends IService<Role> {

    public Boolean addRole(RoleVo roleVo) throws Exception;
    public Boolean addRole2(RoleVo roleVo) throws Exception;
    public Boolean updateRole(RoleVo roleVo) throws Exception;
    public Result delRole(Role role)throws Exception;
    public IPage selectRole(RoleVo roleVo);
    public List<Menu> selectMenuByRole(Role role);

    List<String> findCurrentNode(String roleId);


}
