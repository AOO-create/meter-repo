package com.entity.tenant;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@TableName("tenant")
public class Tenant {

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tgBuildDoorplate; //房间id

    private String name;//租户名称


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long orgId;//机构id


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long areaId;//组织区域ID

    private String mobile;//手机号

    private String wxNumber;//微信号

    private String sex;//性别


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long opera;//操作用户

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    private Double balance;//余额

    private String status;//缴费状态
}
