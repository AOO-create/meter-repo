package com.sso.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sso.domain.SysRole;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;


public interface SysRoleMapper extends BaseMapper<SysRole> {
    //根据用户编号查询角色列表
    @Select("select * from `role` where id in (" +
            "  select role_id from `role_user_relation` where user_id = #{uid}" +
            ")")
    List<SysRole> findByUid(@Param("uid") Long uid);
}
