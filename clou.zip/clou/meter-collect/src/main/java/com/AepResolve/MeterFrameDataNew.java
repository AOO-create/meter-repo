package com.AepResolve;

import lombok.Data;

@Data
public class MeterFrameDataNew {
    private Integer startcode;
    private Integer type;
    private String address;
    private String contolCode;
    private Integer byteLength;
    private String deviceId;

    private String dataLogo;
    private String serialId;
    private String totalNmbel;
    private String currentFrmId;
    private Integer ticurrentFrmNuber;//本帧条数

    private String reportTime;
    private Integer collGay;//采集间隔

    private String currentIntegreFlow;//当前累积流量
    private Integer instantFlow;// 瞬时流量
    private Integer thwStrenthA;
    private Integer thwStrenthB;
    private Integer retain;

    private Integer cellVolt;//电池电压
    private Integer signalPoint;//信号指示
    private Integer signalStrenth;
    private Integer signalQual;//信号质量
    private Integer signalNoise;

    private String csq;//NB信号强度
    private String rsrp;//NB参考信号接收功率
    private String snr;//NB信噪比
    private String ecl;//NB信号覆盖等级
    private String waterCurrentDate;//水表当前运行时间
    private String runStatus;//水表运行状态

    private Integer coverGrade;//覆盖等级
    private Integer pciId;
    private String imei;//
    private String imsi;//
    private Integer loginedNumber;//累计上线成功次数

    private Integer FailedNumber;//累计上线失败次数
    private String sendTime;//发送的实时时间
    /***
     * 水表阀门状态
     */
    private Integer waterMeterStatus0;//水表状态
    private Integer waterMeterStatus1;
    private Integer alarm;

    private Integer hardware;//硬件版本号
    private Integer software;//软件版本号
    private String checkCode;//校验码
    private Integer endCode;//结束码
}
