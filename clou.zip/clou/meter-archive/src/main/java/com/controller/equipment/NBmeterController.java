package com.controller.equipment;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dto.equipment.NBDTO;
import com.entity.command.AotemanSendCommand;
import com.entity.equipment.Protocol;
import com.entity.equipment.WNB;
import com.mapper.aotemanConmand.AotemanCommandMapper;
import com.service.equipment.NBmeterService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/equipment/meterSetup")
public class NBmeterController {

    @Autowired
    private NBmeterService service;

    @Autowired
    private AotemanCommandMapper aotemanCommandMapper;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/selectMetIsull")
    @ResponseBody
    public Page<NBDTO> findMeterToConsIsnull(@RequestBody NBDTO dto){
        return service.findMeterToConsIsnull(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/saveOrUpdateNB")
    @ResponseBody
    public String saveOrUpdateNB(@RequestBody NBDTO nBdto) throws Exception {
        if(!StringUtils.isEmpty(nBdto.getWmtrId())){
            return service.updateNB(nBdto);
        }else{
            return service.addNB(nBdto);
        }
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("/deleteNB")
    @ResponseBody
    public boolean deleteNB(@RequestParam("wmtrId") String wmtrId) throws Exception {
        return service.deleteNB(wmtrId);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("batchDeleteNB")
    @ResponseBody
    public boolean batchDeleteNB(@RequestBody List<String> ids) throws Exception {
        return service.batchDeleteNB(ids);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("validWmtrNo")
    @ResponseBody
    public boolean validWmtrNo(@RequestBody String wmtrNo){
        return service.validWmtrNo(wmtrNo);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("validImei")
    @ResponseBody
    public boolean validImei(@RequestBody String imei){
        return service.validImei(imei);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getDataDay")
    @ResponseBody
    public Page<NBDTO> getDataDay(@RequestBody NBDTO dto){
        return service.getDataDay(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getProtocol")
    @ResponseBody
    public List<Protocol> getProtocol(){
        return service.getProtocol();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("findNewProtoMeter")
    @ResponseBody
    public List<WNB> findNewProtoMeter(){
        return service.findNewProtoMeter();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("warningDayData")
    @ResponseBody
    public Map<String,Object> warningDayData(){
        return service.warningDayData();
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("/openAoTeMan")
    @ResponseBody
    public boolean openAoTeMan(@RequestParam("meterAddress") String meterAddress) {
        List<AotemanSendCommand> a = aotemanCommandMapper.selectList(new QueryWrapper<AotemanSendCommand>()
                .eq("meter_address",meterAddress)
                .in("flag","0","1"));
        if(a.size() > 0){
            return false;
        }
        AotemanSendCommand aotemanSendCommand = new AotemanSendCommand();
        aotemanSendCommand.setCreateTime(new Date());
        aotemanSendCommand.setFlag("0");
        aotemanSendCommand.setMeterAddress(meterAddress);
        aotemanSendCommand.setParam("55");
        aotemanCommandMapper.insert(aotemanSendCommand);
        return true;
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("/offAoTeMan")
    @ResponseBody
    public boolean offAoTeMan(@RequestParam("meterAddress") String meterAddress) {
        List<AotemanSendCommand> a = aotemanCommandMapper.selectList(new QueryWrapper<AotemanSendCommand>()
                .eq("meter_address",meterAddress)
                .in("flag","0","1"));
        if(a.size() > 0){
            return false;
        }
        AotemanSendCommand aotemanSendCommand = new AotemanSendCommand();
        aotemanSendCommand.setCreateTime(new Date());
        aotemanSendCommand.setFlag("0");
        aotemanSendCommand.setMeterAddress(meterAddress);
        aotemanSendCommand.setParam("99");
        aotemanCommandMapper.insert(aotemanSendCommand);
        return true;
    }

}
