package com.mapper.equipment;


import com.dto.equipment.MeterDTO;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.security.core.parameters.P;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
public interface ChangeMeterMapper {
    List<MeterDTO> getAllMeterByOrgIdNB(@Param("dto") MeterDTO dto,@Param("ids") List<String> ids);

    int getAllMeterCountByOrgIdNB(@Param("dto") MeterDTO dto,@Param("ids") List<String> ids);

    List<MeterDTO> getAllMeterByOrgIdWire(@Param("dto") MeterDTO dto,@Param("ids") List<String> ids);

    int getAllMeterCountByOrgIdWire(@Param("dto") MeterDTO dto,@Param("ids") List<String> ids);

    int unBindMeterNB(@Param("dto") MeterDTO dto);

    int unBindMeterWire(@Param("dto") MeterDTO dto);
}
