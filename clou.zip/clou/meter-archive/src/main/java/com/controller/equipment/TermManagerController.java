package com.controller.equipment;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fegin.client.NettyClient;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.log.ChangeTermLog;
import com.entity.equipment.Term;
import com.mapper.equipment.TermManagerMapper;
import com.service.equipment.TermManagerService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import com.service.organization.GradeService;
import com.util.ShiroConstUtils;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/equipment/termManager")
public class TermManagerController {
    @Autowired
    private TermManagerService service;

    @Autowired
    private NettyClient nettyService;

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    @Autowired
    private GradeService gradeService;

    @Autowired
    private TermManagerMapper termManagerMapper;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/ternalfileList")
    @ResponseBody
    public Page<TermDTO> getTerm(@RequestBody TermDTO dto) {
        return service.getTerm(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/termSave")
    @ResponseBody
    public String termSave(@RequestBody TermDTO dto) {
        return service.termSave(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getTermData")
    @ResponseBody
    public Map<String, Object> getTermData(@RequestBody String areaId) {
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String userAreaId = shiroConstUtils.getAreaId();
        List<Term> list = service.getTermData(areaId);
        List<Term> termList = new ArrayList<>();
        termList = termManagerMapper.selectList(new LambdaQueryWrapper<Term>().eq(Term::getOrgId,orgId).eq(Term::getModelType,"1"));
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> map2 = new HashMap<String, Object>();
        for (Term term : list) {
            term.setOnline(0);



        }
        map.put("totalTerm", termList.size());
        map.put("areaTotalTerm",list.size());
        termList.forEach(item -> {
            map2.forEach((k, v) -> {
                if (item.getAddress().equals(k)) {
                    item.setOnline(1);
                }
            });
        });

        map.put("onlineTerm", termList.size());
        map.put("onlineTermArea", termList.size());
        map.put("list", termList);
        return map;
    }
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getTermData_feiqi")
    @ResponseBody
    public Map<String, Object> getTermData_feiqi(@RequestBody String areaId) {
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String userAreaId = shiroConstUtils.getAreaId();
        List<Term> list = service.getTermData(areaId);
        List<Term> termList = new ArrayList<>();
        if(roleCode.equals("admin")){
            termList = termManagerMapper.selectList(new QueryWrapper<Term>()
                    .eq("org_id",orgId).eq("status","0"));
        }else{
            termList = service.getTermData(userAreaId);
        }


        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, NioSocketChannel> map2 = nettyService.getSocketMap();
        Map<String,NioSocketChannel> map3 = map2;
        for (Term term : list) {
            term.setOnline(0);
        }
        map.put("totalTerm", termList.size());
        map.put("areaTotalTerm",list.size());
        termList.forEach(item -> {
            map2.forEach((k, v) -> {
                if (item.getAddress().equals(k)) {
                    item.setOnline(1);
                }
            });
        });
        list.forEach(item -> {
            map3.forEach((k, v) -> {
                if (item.getAddress().equals(k)) {
                    item.setOnline(1);
                }
            });
        });
        map.put("onlineTerm", map2.size());
        map.put("onlineTermArea", map3.size());
        map.put("list", list);
        return map;
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getTermStatus")
    @ResponseBody
    public List<Term> getTermStatus(@RequestBody Term dto) {
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String userAreaId = shiroConstUtils.getAreaId();
        List<Term> termList = new ArrayList<>();
        List<Term> list = new ArrayList<>();
        QueryWrapper<Term> qw = new QueryWrapper<>();

        if(dto.getAddress()!= null && !dto.getAddress().equals("")){
            qw.eq("address",dto.getAddress());
        }
        if(roleCode.equals("admin")){
            qw.eq("org_id",orgId).eq("status","0");
        }else{
            List<String> idList = new ArrayList<>();
            //获得所有选择的组织区域下的areaId
            List<String> tempList = new ArrayList<>();
            //递归循环遍历areaId下所有子孙节点,如果为空查询该org下所有gradeId
            idList = gradeService.reGetChildGradeId(userAreaId,orgId,tempList);
            qw.eq("org_id",orgId)
                    .in("area_id",idList)
                    .eq("status","0")
                    .orderByDesc("upd_time");
        }
        termList = termManagerMapper.selectList(qw);

        Map<String, NioSocketChannel> map2 = nettyService.getSocketMap();
        termList.forEach(item -> {
            map2.forEach((k, v) -> {
                if (item.getAddress().equals(k)) {
                    item.setOnline(1);
                }
            });
        });
        if(dto.getOnline() == null){
            return termList;
        }
        if(dto.getOnline() == 0 ){
            termList.forEach(val->{
                if(val.getOnline() == null){

                }else if(val.getOnline() == 0){
                    list.add(val);
                }
            });
        }else if(dto.getOnline() == 1){
            termList.forEach(val->{
                if(val.getOnline() == null||val.getOnline() == 1){
                    list.add(val);
                }
            });
        }
        return list;
    }



    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getMeter")
    @ResponseBody
    public Page<WiredMeterDTO> getMeter(@RequestBody WiredMeterDTO dto) {
        return service.getMeter(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("validAddress")
    @ResponseBody
    public boolean validAddress(@RequestBody TermDTO dto) {
        return service.validAddress(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("getTermByAreaId")
    @ResponseBody
    public List<TermDTO> getTermByAreaId(@RequestParam("areaId") String areaId) {
        return service.getTermByAreaId(areaId);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("deleteTerm")
    @ResponseBody
    public Result deleteTerm(@RequestParam("terminalId") String terminalId) {
        return service.deleteTerm(terminalId);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("batchDeleteTerm")
    @ResponseBody
    public Result batchDeleteTerm(@RequestBody List<String> idList) {
        return service.batchDeleteTerm(idList);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("changeTermStatus")
    @ResponseBody
    public Result changeTermStatus(@RequestParam("terminalId") String terminalId) {
        return service.changeTermStatus(terminalId);
    }
    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/changeTerm")
    @ResponseBody
    public Result changeTerm(@RequestBody TermDTO dto) {
        return service.changeTerm(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getAreaIdByTermId")
    public Result getAreaIdByTermId(@RequestParam("id") String id){
        return  Result.OK(service.getAreaIdByTermId(id));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getChangeTermLog")
    @ResponseBody
    public Result getChangeTermLog(@RequestBody ChangeTermLog log) {
        return service.getChangeTermLog(log);
    }

}
