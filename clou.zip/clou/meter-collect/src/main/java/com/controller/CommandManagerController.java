package com.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.nbFrame.nbSendCommand;
import com.mapper.nbFrame.CommandManagerMapper;
import com.service.CommandManagerService;
import com.vo.nbSendCommandVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
@RestController
@RequestMapping("/collect/command")
public class CommandManagerController {
    @Autowired
    private CommandManagerService service;

    @Autowired
    private CommandManagerMapper mapper;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/findAll")
    @ResponseBody
    public Page<nbSendCommand> findAll(@RequestBody nbSendCommandVo command){
        return service.findAll(command);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/saveOrupdate")
    @ResponseBody
    public boolean saveOrupdate(@RequestBody nbSendCommandVo command){
        if(StringUtils.isEmpty(command.getId())){
            int count = mapper.selectCount(new QueryWrapper<nbSendCommand>()
                    .eq("meter_address",command.getMeterAddress())
                    .eq("type",command.getType())
                    .in("flag","0","1"));
            if(count > 0){
                return false;
            }
            return service.saveCommand(command);
        }else{
            return service.updateCommand(command);
        }
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/deleteCommand")
    @ResponseBody
    public boolean deleteCommand(@RequestParam("id") String id){
        return service.deleteCommand(id);
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/batchDeleteCommand")
    @ResponseBody
    public boolean batchDeleteCommand(@RequestBody List<String> ids){
        return service.batchDeleteCommand(ids);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/getParam")
    @ResponseBody
    public nbSendCommandVo getParam(@RequestBody nbSendCommand command){
        return service.getParam(command);
    }

}
