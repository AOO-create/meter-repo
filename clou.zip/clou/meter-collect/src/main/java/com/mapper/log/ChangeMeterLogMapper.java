package com.mapper.log;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.log.ChangeMeterLog;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/4/25
 */
public interface ChangeMeterLogMapper extends BaseMapper<ChangeMeterLog> {
    List<ChangeMeterLog> getLog(@Param("dto") ChangeMeterLog dto);

    int getLogCount(@Param("dto") ChangeMeterLog dto);
}
