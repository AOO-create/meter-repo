package com.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sso.domain.LoginLog;

/**
 * @author liuwei
 * @description
 * @date 2023/10/26 
 */
public interface LoginLogMapper extends BaseMapper<LoginLog> {
}
