package com.dto.organization;

import com.common.PageConstant;
import com.entity.organization.Grade;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 说明：小区楼栋查询DTO类
 * 作者：刘威/CL19803
 * 版本：v1.0
 * 时间：2022-5-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BDGradeDTO extends PageConstant {

    private String id;
    private String bdNo;
    private String bdName;
    private String orgId;
    private String parentId;
    private String areaId;
    private String remark;
    private String parentName;
    private Date updTime;
    private String gradeId;
    private Grade grade;

    private boolean deleteFlag;
}
