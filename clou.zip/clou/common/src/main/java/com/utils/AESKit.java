package com.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.Security;
import java.util.ArrayList;

/**
 * @author liuwei
 * AES加密解密工具类
 * @date 2022/4/20
 */
@Slf4j
@Component
public class AESKit {

    private static final String SECRET = "v$lk5df%j28_4,u-";
    private static final String CIPHER_ALGORITHM = "AES/ECB/PKCS7Padding";


    static {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null){
            Security.addProvider(new BouncyCastleProvider());
        }
    }
    /**
     * AES加密ECB模式PKCS7Padding填充方式
     * @param enString 字符串z
     * @return 加密字符串
     * @throws Exception 异常信息
     */
    public static String encrypt(String enString) {
        byte[] sSrc = hexToByte(enString);
        if(sSrc == null){
            log.error("输入sSrc为空，请重新输入加密数据");
        }

        Cipher cipher = null;
        byte[] doFinal= null;
        try {
            cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            byte[] keyBytes = SECRET.getBytes(StandardCharsets.UTF_8);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keyBytes, SECRET));
            doFinal = cipher.doFinal(sSrc);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return byteToHexString(doFinal);
    }
    /**
     * AES解密ECB模式PKCS7Padding填充方式
     * @param enString 字符串
     * @return 解密字符串
     * @throws Exception 异常信息
     */
    public static String decrypt(String enString) {
      byte[] enStringArray = hexToByte(enString);
        if(enStringArray == null){
            log.error("输入enString为空，请重新输入解密数据");
        }
        Cipher cipher = null;
        byte[] doFinal= null;
        try {
            cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            byte[] keyBytes = SECRET.getBytes(StandardCharsets.UTF_8);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyBytes, SECRET));
            doFinal = cipher.doFinal(enStringArray);
        } catch (Exception e) {
            log.info("解密有誤，传入的报文不能正确解析");
            e.printStackTrace();
            return null;
        }

        return byteToHexString(doFinal);
    }

    public static String encrypt(byte[] sSrc) {
        if(sSrc == null){
            log.error("输入sSrc为空，请重新输入加密数据");
        }

        Cipher cipher = null;
        byte[] doFinal= null;
        try {
            cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            byte[] keyBytes = SECRET.getBytes(StandardCharsets.UTF_8);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keyBytes, SECRET));
            doFinal = cipher.doFinal(sSrc);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return byteToHexString(doFinal);
    }
    public static String decrypt( byte[] enStringArray ) {
        if(enStringArray == null){
            log.error("输入enString为空，请重新输入解密数据");
        }
        Cipher cipher = null;
        byte[] doFinal= null;
        try {
            cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            byte[] keyBytes = SECRET.getBytes(StandardCharsets.UTF_8);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyBytes, SECRET));
            doFinal = cipher.doFinal(enStringArray);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return byteToHexString(doFinal);
    }

    public static void main(String[] args) throws Exception {
        String aa  = ("869755050069649");
        while (aa.length()<16){
            aa ="0"+aa;
        }
        System.out.println(aa);
    }

    public static ArrayList<String> StringToHexArray(String hex) {
        int m = 0, n = 0;
        int byteLen = hex.length() / 2; // 每两个字符描述一个字节
       // byte[] ret = new String[byteLen]();
        ArrayList<String> ret =new ArrayList<String> ();
        for (int i = 0; i < byteLen; i++) {
            m = i * 2 + 1;
            n = m + 1;
            int intVal = Integer.decode("0x" + hex.substring(i * 2, m) + hex.substring(m, n));
            //ret[i] = Byte.valueOf((byte) intVal);
            ret.add(Integer.toHexString(intVal));
        }
        return ret;
    }


    public static byte[] hexToByte(String hex) {
        int m = 0, n = 0;
        int byteLen = hex.length() / 2; // 每两个字符描述一个字节
        byte[] ret = new byte[byteLen];
        for (int i = 0; i < byteLen; i++) {
            m = i * 2 + 1;
            n = m + 1;
            int intVal = Integer.decode("0x" + hex.substring(i * 2, m) + hex.substring(m, n));
            ret[i] = Byte.valueOf((byte) intVal);
        }
        return ret;
    }
    /**
     * 字节数组转成16进制表示格式的字符串
     *
     * @param byteArray 需要转换的字节数组
     * @return 16进制表示格式的字符串
     */
    //方法一
    public static String byteToHexString(byte[] bytes) {
        String strHex = "";
        StringBuilder sb = new StringBuilder("");
        for (int n = 0; n < bytes.length; n++) {
            strHex = Integer.toHexString(bytes[n] & 0xFF);
            // 每个字节由两个字符表示，位数不够，高位补0
            sb.append((strHex.length() == 1) ? "0" + strHex : strHex);
        }
        return sb.toString().trim();
    }
    //方法二
    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() == 1) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }

    public static int  findVaule(String  str){
        if(!StringUtils.isEmpty(str)){
            char[] chars = str.toCharArray();
            for(int i=0 ;i<chars.length;i++){

                if(chars[i] == '0'){
                    //找到为0的数了，开始往后数
                    for(int j = i; j<chars.length;j++){
                        //找到了后面数不为0的，开始继续下一个往下走。
                        if( chars[j] !='0' ){
                            i = j-1;
                            break;
                        }else if(j == chars.length-1){
                            return i;
                        }
                    }
                }
            }
        }
        return str.toCharArray().length;

    }

    public static String parseByte2HexStr(byte buf[]) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }


}
