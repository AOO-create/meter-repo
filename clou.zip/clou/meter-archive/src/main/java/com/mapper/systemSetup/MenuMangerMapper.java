package com.mapper.systemSetup;

import com.entity.systemSetup.Menu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MenuMangerMapper extends BaseMapper<Menu> {
}
