package com.sso.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sso.domain.Menu;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MenuMangerMapper extends BaseMapper<Menu> {
}
