package com.service.tenant.Impl;

import com.dto.equipment.MeterDayDataDTO;
import com.entity.calculate.CalculateFee;
import com.mapper.calculate.CalculateFeeMapper;
import com.mapper.equipment.FourthGenerationDayDataMapper;
import com.mapper.equipment.FourthGenerationMapper;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.tenant.TenantMapper;
import com.entity.equipment.FourthGenerationMeter;
import com.entity.equipment.WNB;
import com.entity.equipment.WiredMeter;
import com.entity.organization.BDGrade;
import com.entity.Org;
import com.entity.tenant.Tenant;
import com.service.calculate.CalculateService;
import com.service.organization.impl.GradeServiceImpl;
import com.service.tenant.TenantUseWaterService;
import com.util.ShiroConstUtils;
import com.vo.tenant.TenantUseWaterVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author liuwei
 * @description
 * @date 2022/8/4
 */
@Service
public class TenantUseWaterServiceImpl implements TenantUseWaterService {
    @Autowired
    private TenantMapper mapper;

    @Autowired
    private GradeServiceImpl gradeServiceImpl;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private TenantMapper tenantMapper;

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired
    private CalculateService calculateService;

    @Autowired
    private FourthGenerationDayDataMapper fourthGenerationDayDataMapper;

    @Autowired
    private FourthGenerationMapper fourthGenerationMapper;

    @Autowired
    private CalculateFeeMapper calculateFeeMapper;

    @Autowired
    private ShiroConstUtils shiroConstUtils;
    /**
       * 计算用户用水量，根据点击的组织区域，门栋单元，房门号，
       * 计算所有表具之和
       * @author liuwei
       * @date  2022/8/23
       * @param
       * @return
     */
    @Override
    public Page<TenantUseWaterVo> getUseWaterRecord(TenantUseWaterVo vo) {

        Org org = shiroConstUtils.getOrg();
        long areaId = 0;
        long tgBuildDoorplate = 0;
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String tgId = shiroConstUtils.getTgBuildDoorplate();
        String areaIdd = shiroConstUtils.getAreaId();

        if(null != vo.getAreaId()){
            areaId = vo.getAreaId();
        }
        if(null != vo.getTgBuildDoorplate()){
            tgBuildDoorplate = vo.getTgBuildDoorplate();
        }
        DecimalFormat df = new DecimalFormat("######0.000");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(vo.getMonthDate());
        calendar.add(Calendar.MONTH ,- 1);
        Date smallMonthDate = calendar.getTime();
        String monthDateSmall = dateFormat.format(smallMonthDate);
        String monthDate = dateFormat.format(vo.getMonthDate());

        String bigMonth = monthDate.substring(5,7);
        String smallMonth = monthDateSmall.substring(5,7);

        List<TenantUseWaterVo> voList = new ArrayList<>();
        //所有的门栋单元或者房门号ID
        List<String> ids = new ArrayList<>();

        if(areaId == 0 && tgBuildDoorplate == 0){
            QueryWrapper<BDGrade> qw = new QueryWrapper<>();
            //初始全未选择，查询所有用户
            if(roleCode.equals("admin")){
             //管理员查看全部的
                qw.eq("org_id",org.getOrgId());
            }else if(null == tgId || "".equals(tgId)){
                //登录用户为组织区域管理员
                qw.eq("org_id",org.getOrgId()).eq("area_id",areaIdd);
            }else{
                //登录用户为门栋管理员
                List<String> idList = new ArrayList<>();
                idList = gradeServiceImpl.reGetChildBDGradeId(tgId,org.getOrgId(),idList);
                qw.eq("org_id",org.getOrgId()).in("id",idList);
            }
            List<BDGrade> bdGrades = bdGradeMapper.selectList(qw);

            for(BDGrade bdGrade : bdGrades){
                ids.add(bdGrade.getId() + "");
            }
        }else if(tgBuildDoorplate == 0){
            //点击为组织区域
            List<BDGrade> bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>().eq("area_id",areaId));
            for(BDGrade bdGrade : bdGradeList){
                ids.add(bdGrade.getId() + "");
            }
        }else{
            //点击为门栋单元或者房门号
            ids = gradeServiceImpl.reGetChildBDGradeId(tgBuildDoorplate + "",org.getOrgId(),ids);
        }
        QueryWrapper<Tenant> qw = new QueryWrapper<>();
        if( null != vo.getName() && !"".equals(vo.getName())){
            qw.eq("name",vo.getName());
        }
        if(null == ids){
            //没有门栋单元。房门号直接返回空
            return null;
        }

        //用户List
        List<Tenant> tenantList = tenantMapper.selectList(qw.in("tg_build_doorplate",ids));

        for(Tenant tenant : tenantList){
            String areaName = gradeMapper.selectById(tenant.getAreaId()).getAreaName();
            String bdName = bdGradeMapper.selectById(tenant.getTgBuildDoorplate()).getBdName();
            double waterConsumption = 0d;

            TenantUseWaterVo tenantUseWaterVo = new TenantUseWaterVo();
            BeanUtils.copyProperties(tenant,tenantUseWaterVo);
            tenantUseWaterVo.setAreaName(areaName);
            tenantUseWaterVo.setBdName(bdName);


            List<WNB> wnbs = nBmeterMapper.selectList(new QueryWrapper<WNB>()
                    .eq("tg_build_doorplate",tenant.getTgBuildDoorplate()));
            //冷水水表
            List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                    .eq("tg_build_doorplate",tenant.getTgBuildDoorplate())
                    .eq("meter_type","0"));
            List<MeterDayDataDTO> meterDayDataDTOS = new ArrayList<>();
            double realSumFlow = 0d;

            for(WNB wnb : wnbs){
                MeterDayDataDTO meterDayDataDTOBig = mapper.getNBDay(wnb.getImei(),monthDate);
                MeterDayDataDTO meterDayDataDTOSmall = mapper.getNBDay(wnb.getImei(),monthDateSmall);
                MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                meterDayDataDTO.setType("5");
                meterDayDataDTO.setMeterAddress(wnb.getMeterAddress());
                meterDayDataDTO.setImei(wnb.getImei());
                if(null != meterDayDataDTOBig && null != meterDayDataDTOSmall){
                    //本月上月都存在
                    realSumFlow = Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) - Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow());
                    realSumFlow = Double.parseDouble(df.format(realSumFlow));
                    meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                    if(realSumFlow == 0.0){
                        meterDayDataDTO.setErrMsg("冻结数据为"+Double.parseDouble(meterDayDataDTOBig.getRealSumFlow())+"，"+bigMonth+"月用水量为0");
                        meterDayDataDTO.setWaterFee("0.00");
                        meterDayDataDTO.setRealSumFlow(realSumFlow+"");
                        meterDayDataDTO.setCalculate("");
                        meterDayDataDTOS.add(meterDayDataDTO);
                        continue;
                    }else if(realSumFlow < 0.0){
                        meterDayDataDTO.setWaterFee("0.00");
                        meterDayDataDTO.setRealSumFlow(realSumFlow+"");
                        meterDayDataDTO.setCalculate("");
                        meterDayDataDTO.setErrMsg("冻结数据为"+Double.parseDouble(meterDayDataDTOBig.getRealSumFlow())+"，数据异常");
                        meterDayDataDTOS.add(meterDayDataDTO);
                        continue;
                    }
                    waterConsumption = waterConsumption + realSumFlow;
                    Map<String,String> map1 = calculateService.getWaterValue(tenant.getTgBuildDoorplate(),realSumFlow);
                    if(map1 ==null){
                        //未设置缴费方案，返回map为null
                        meterDayDataDTO.setErrMsg("房间上未设置缴费方案");
                        meterDayDataDTO.setRealSumFlow(realSumFlow + "");
                    }else{
                        meterDayDataDTO.setCalculate(map1.get("calculate"));
                        meterDayDataDTO.setWaterFee(map1.get("waterValue"));
                        meterDayDataDTO.setRealSumFlow(realSumFlow + "");
                        meterDayDataDTO.setErrMsg(bigMonth+"月用水量为：" + realSumFlow + "m³");
                    }
                    
                }else if( null == meterDayDataDTOBig && null != meterDayDataDTOSmall){
                    meterDayDataDTO.setErrMsg(bigMonth+"月无冻结数据,用水异常。");
                    meterDayDataDTO.setCollTime(meterDayDataDTOSmall.getCollTime());
                }else if(null != meterDayDataDTOBig){
                    meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                    meterDayDataDTO.setErrMsg(smallMonth+"月无冻结数据，"+bigMonth+"月冻结数据为" + Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()));
                }else{
                    meterDayDataDTO.setErrMsg(smallMonth+"和"+bigMonth+"月无冻结数据！");
                }
                meterDayDataDTOS.add(meterDayDataDTO);
            }


            for(WiredMeter wiredMeter : wiredMeterList){
                MeterDayDataDTO meterDayDataDTOBig = mapper.getWiredDay(wiredMeter.getMeterAddress(),wiredMeter.getTermId(),monthDate);
                MeterDayDataDTO meterDayDataDTOSmall = mapper.getWiredDay(wiredMeter.getMeterAddress(),wiredMeter.getTermId(),monthDateSmall);
                MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                meterDayDataDTO.setMeterAddress(wiredMeter.getMeterAddress());
                meterDayDataDTO.setType("0");
                meterDayDataDTO.setTermAddress(wiredMeter.getTermId());
                if(null != meterDayDataDTOBig && null != meterDayDataDTOSmall){
                    realSumFlow = Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) - Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow());
                    realSumFlow = Double.parseDouble(df.format(realSumFlow));
                    meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                    if(realSumFlow == 0.0){
                        meterDayDataDTO.setWaterFee("0.00");
                        meterDayDataDTO.setRealSumFlow(realSumFlow+"");
                        meterDayDataDTO.setCalculate("");
                        meterDayDataDTO.setErrMsg("冻结数据为"+Double.parseDouble(meterDayDataDTOBig.getRealSumFlow())+"，"+bigMonth+"月用水量为0");
                        meterDayDataDTOS.add(meterDayDataDTO);
                        continue;
                    }else if(realSumFlow < 0.0){
                        meterDayDataDTO.setWaterFee("0.00");
                        meterDayDataDTO.setRealSumFlow(realSumFlow+"");
                        meterDayDataDTO.setCalculate("");
                        meterDayDataDTO.setErrMsg("冻结数据为"+Double.parseDouble(meterDayDataDTOBig.getRealSumFlow())+"，数据异常");
                        meterDayDataDTOS.add(meterDayDataDTO);
                        continue;
                    }
                    waterConsumption = waterConsumption + realSumFlow;
                    Map<String,String> map1 = calculateService.getWaterValue(tenant.getTgBuildDoorplate(),realSumFlow);
                    if(map1 == null){
                        meterDayDataDTO.setErrMsg("房间上未设置缴费方案");
                        meterDayDataDTO.setRealSumFlow(realSumFlow + "");
                    }else{
                        String waterFee = map1.get("waterValue");
                        String calculate = map1.get("calculate");
                        meterDayDataDTO.setCalculate(calculate);
                        meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                        meterDayDataDTO.setWaterFee(waterFee);
                        meterDayDataDTO.setRealSumFlow(realSumFlow + "");
                        meterDayDataDTO.setErrMsg(bigMonth+"月用水量为：" + realSumFlow + "m³");
                    }
                }else if( null == meterDayDataDTOBig && null != meterDayDataDTOSmall){
                    meterDayDataDTO.setErrMsg(bigMonth+"月无冻结数据,用水异常。");
                    meterDayDataDTO.setCollTime(meterDayDataDTOSmall.getCollTime());
                }else if(null != meterDayDataDTOBig){
                    meterDayDataDTO.setErrMsg(smallMonth+"月无冻结数据，"+bigMonth+"月冻结数据为" + Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()));
                    meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                }else{
                    meterDayDataDTO.setErrMsg(smallMonth+"和"+bigMonth+"月无冻结数据！");
                }
                meterDayDataDTOS.add(meterDayDataDTO);
            }


            waterConsumption = Double.parseDouble(df.format(waterConsumption));
            tenantUseWaterVo.setWaterConsumption(waterConsumption);
            //根据房间号公式计算用水费用
            double waterValue = 0d;
            String calculate = "";
            for(MeterDayDataDTO dto : meterDayDataDTOS){
                if(dto.getWaterFee() != null && !dto.getWaterFee().equals("")) {
                    waterValue = waterValue + Double.parseDouble(dto.getWaterFee());
                    if(calculate.equals("")){
                        calculate = dto.getCalculate();
                    }else{
                        calculate = calculate + " + " + dto.getWaterFee();
                    }
                }
            }

            tenantUseWaterVo.setWaterFee(waterValue + "");
            tenantUseWaterVo.setCalculate(calculate);
            tenantUseWaterVo.setMeterDataList(meterDayDataDTOS);
            voList.add(tenantUseWaterVo);
        }


        return getPage(vo,voList);
    }

    @Override
    public Page<TenantUseWaterVo> getTenantStatistics(TenantUseWaterVo vo) throws ParseException {
        QueryWrapper<Tenant> qw = new QueryWrapper<>();
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String tgId = shiroConstUtils.getTgBuildDoorplate();
        String areaId = shiroConstUtils.getAreaId();
        if(null != vo.getName() && !"".equals(vo.getName())){
            qw.like("name","%" + vo.getName() + "%");
        }
        if(roleCode.equals("admin")){
            qw.eq("org_id",orgId);
        }else if(tgId.equals("")||tgId == null){
            qw.eq("area_id",areaId);
        }else {
            List<String> bdIds = gradeServiceImpl.reGetChildBDGradeId(tgId,orgId,new ArrayList<>());
            qw.in("tg_build_doorplate",bdIds);
        }

        //根据住户表获取所有住户拼接信息再
        List<Tenant> tenantList = mapper.selectList(qw);
        Page<TenantUseWaterVo> page = new Page<>(vo.getPage(),vo.getLimit());
        List<TenantUseWaterVo> voList = new ArrayList<>();
        for(Tenant tenant : tenantList){
            vo.setTgBuildDoorplate(tenant.getTgBuildDoorplate());
            if(vo.getType().equals("0")){
                page = getUseWaterRecord(vo);
            }else if(vo.getType().equals("1")){
                page = getUseElecRecord(vo);
            }
            CalculateFee calculateFee = calculateFeeMapper.selectOne(new QueryWrapper<CalculateFee>()
                    .eq("tg_build_doorplate",tenant.getTgBuildDoorplate()));
            TenantUseWaterVo entity = page.getRecords().get(0);
            if(calculateFee == null){
                entity.setMethod("");
                entity.setFormula("");
            }else{
                entity.setMethod(calculateFee.getName());
                entity.setFormula(calculateFee.getFormula());
            }
            voList.add(entity);
        }
        page.setTotal(voList.size());
        page.setPages(vo.getPage());
        page.setSize(vo.getLimit());
        int count = (vo.getPage() - 1) * vo.getLimit();
        if(voList.size() <= count ){
            //没有那么多页返回空
            page.setRecords(null);
        }else if(voList.size() - count >= vo.getLimit()) {
            //有那么多页且超过或刚好等于
            voList = voList.subList(count, count + 10);
            page.setRecords(voList);
        }else {
            //有那么多页但是只超过了一页且不满Limt
            int endCount = voList.size() - count ;
            voList = voList.subList(count,count + endCount);
            page.setRecords(voList);
        }
        return page;
    }

    @Override
    public Page<TenantUseWaterVo> getUseElecRecord(TenantUseWaterVo vo) {
        Org org = shiroConstUtils.getOrg();
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String tgId = shiroConstUtils.getTgBuildDoorplate();
        String areaIdd = shiroConstUtils.getAreaId();
        long areaId = 0;
        long tgBuildDoorplate = 0;

        if(null != vo.getAreaId()){
            areaId = vo.getAreaId();
        }
        if(null != vo.getTgBuildDoorplate()){
            tgBuildDoorplate = vo.getTgBuildDoorplate();
        }
        DecimalFormat df = new DecimalFormat("######0.000");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(vo.getMonthDate());
        calendar.add(Calendar.MONTH ,- 1);
        Date smallMonthDate = calendar.getTime();
        String monthDateSmall = dateFormat.format(smallMonthDate);
        String monthDate = dateFormat.format(vo.getMonthDate());

        String bigMonth = monthDate.substring(5,7);
        String smallMonth = monthDateSmall.substring(5,7);

        List<TenantUseWaterVo> voList = new ArrayList<>();
        //所有的门栋单元或者房门号ID
        List<String> ids = new ArrayList<>();

        if(areaId == 0 && tgBuildDoorplate == 0){
            QueryWrapper<BDGrade> qw = new QueryWrapper<>();
            //初始全未选择，查询所有用户
            if(roleCode.equals("admin")){
                //管理员查看全部的
                qw.eq("org_id",org.getOrgId());
            }else if(null == tgId || "".equals(tgId)){
                //登录用户为组织区域管理员
                qw.eq("org_id",org.getOrgId()).eq("area_id",areaIdd);
            }else{
                //登录用户为门栋管理员
                List<String> idList = new ArrayList<>();
                idList = gradeServiceImpl.reGetChildBDGradeId(tgId,org.getOrgId(),idList);
                qw.eq("org_id",org.getOrgId()).in("id",idList);
            }
            List<BDGrade> bdGrades = bdGradeMapper.selectList(qw);

            for(BDGrade bdGrade : bdGrades){
                ids.add(bdGrade.getId() + "");
            }
        }else if(tgBuildDoorplate == 0){
            //点击为组织区域
            List<BDGrade> bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>().eq("area_id",areaId));
            for(BDGrade bdGrade : bdGradeList){
                ids.add(bdGrade.getId() + "");
            }
        }else{
            //点击为门栋单元或者房门号
            ids = gradeServiceImpl.reGetChildBDGradeId(tgBuildDoorplate + "",org.getOrgId(),ids);
        }
        QueryWrapper<Tenant> qw = new QueryWrapper<>();
        if( null != vo.getName() && !"".equals(vo.getName())){
            qw.eq("name",vo.getName());
        }
        if(null == ids){
            //没有门栋单元。房门号直接返回空
            return null;
        }

        List<Tenant> tenantList = tenantMapper.selectList(qw.in("tg_build_doorplate",ids));
        for(Tenant tenant : tenantList){
            String areaName = gradeMapper.selectById(tenant.getAreaId()).getAreaName();
            String bdName = bdGradeMapper.selectById(tenant.getTgBuildDoorplate()).getBdName();
            double waterConsumption = 0d;

            TenantUseWaterVo tenantUseWaterVo = new TenantUseWaterVo();
            BeanUtils.copyProperties(tenant,tenantUseWaterVo);
            tenantUseWaterVo.setAreaName(areaName);
            tenantUseWaterVo.setBdName(bdName);

            //电表
            List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                    .eq("tg_build_doorplate",tenant.getTgBuildDoorplate())
                    .eq("meter_type","4"));
            List<MeterDayDataDTO> meterDayDataDTOS = new ArrayList<>();
            double realSumFlow = 0d;
            for(WiredMeter wiredMeter : wiredMeterList){
                MeterDayDataDTO meterDayDataDTOBig = mapper.getWiredDay(wiredMeter.getMeterAddress(),wiredMeter.getTermId(),monthDate);
                MeterDayDataDTO meterDayDataDTOSmall = mapper.getWiredDay(wiredMeter.getMeterAddress(),wiredMeter.getTermId(),monthDateSmall);
                MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
                meterDayDataDTO.setType("4");
                meterDayDataDTO.setMeterAddress(wiredMeter.getMeterAddress());
                meterDayDataDTO.setTermAddress(wiredMeter.getTermId());
                if(null != meterDayDataDTOBig && null != meterDayDataDTOSmall){
                    realSumFlow = Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) - Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow());
                    realSumFlow = Double.parseDouble(df.format(realSumFlow));
                    if(realSumFlow == 0.0){
                        meterDayDataDTO.setWaterFee("0.00");
                        meterDayDataDTO.setRealSumFlow(realSumFlow+"");
                        meterDayDataDTO.setCalculate("");
                        meterDayDataDTO.setErrMsg("冻结数据为"+ Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) +bigMonth+"月用电量为0");
                        meterDayDataDTOS.add(meterDayDataDTO);
                        continue;
                    }else if(realSumFlow < 0){
                        meterDayDataDTO.setWaterFee("0.00");
                        meterDayDataDTO.setRealSumFlow(realSumFlow+"");
                        meterDayDataDTO.setCalculate("");
                        meterDayDataDTO.setErrMsg("冻结数据为"+ Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()) +",数据异常");
                        meterDayDataDTOS.add(meterDayDataDTO);
                        continue;
                    }
                    meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                    waterConsumption = waterConsumption + realSumFlow;
                    meterDayDataDTO.setErrMsg(bigMonth+"月用电量为：" + realSumFlow + "kwh");
                    meterDayDataDTO.setRealSumFlow(realSumFlow + "");
                }else if( null == meterDayDataDTOBig && null != meterDayDataDTOSmall){
                    meterDayDataDTO.setCollTime(meterDayDataDTOSmall.getCollTime());
                    meterDayDataDTO.setErrMsg(bigMonth+"月无冻结数据," +smallMonth+"月冻结数据为" + Double.parseDouble(meterDayDataDTOSmall.getRealSumFlow()));
                }else if(null != meterDayDataDTOBig){
                    meterDayDataDTO.setCollTime(meterDayDataDTOBig.getCollTime());
                    meterDayDataDTO.setErrMsg(smallMonth+"月无冻结数据，"+bigMonth+"月冻结数据为" +Double.parseDouble(meterDayDataDTOBig.getRealSumFlow()));
                }else{
                    meterDayDataDTO.setErrMsg(smallMonth+"和"+bigMonth+"月无冻结数据！");
                }
                meterDayDataDTOS.add(meterDayDataDTO);
            }
            waterConsumption = Double.parseDouble(df.format(waterConsumption));
            tenantUseWaterVo.setWaterConsumption(waterConsumption);
            //根据房间号公式计算用水费用
            double waterValue = 0d;
            String calculate = "";
            for(MeterDayDataDTO dto : meterDayDataDTOS){
                if(dto.getWaterFee() != null && !dto.getWaterFee().equals("")) {
                    waterValue = waterValue + Double.parseDouble(dto.getWaterFee());
                    if(calculate.equals("")){
                        calculate = dto.getCalculate();
                    }else{
                        calculate = calculate + " + " + dto.getWaterFee();
                    }
                }
            }

            tenantUseWaterVo.setWaterFee(waterValue + "");
            tenantUseWaterVo.setCalculate(calculate);
            tenantUseWaterVo.setMeterDataList(meterDayDataDTOS);
            voList.add(tenantUseWaterVo);
        }
        return getPage(vo,voList);
    }

    private Page<TenantUseWaterVo> getPage(TenantUseWaterVo vo,List<TenantUseWaterVo> voList){
        Page<TenantUseWaterVo> page = new Page<>(vo.getPage(),vo.getLimit());
        page.setTotal(voList.size());
        page.setPages(vo.getPage());
        page.setSize(vo.getLimit());

        int count = (vo.getPage() - 1) * vo.getLimit();
        if(voList.size() <= count ){
            //没有那么多页返回空
            page.setRecords(null);
        }else if(voList.size() - count >= vo.getLimit()) {
            //有那么多页且超过或刚好等于
            voList = voList.subList(count, count + 10);
            page.setRecords(voList);
        }else {
            //有那么多页但是只超过了一页且不满Limt
            int endCount = voList.size() - count ;
            voList = voList.subList(count,count + endCount);
            page.setRecords(voList);
        }
        return page;
    }
}
