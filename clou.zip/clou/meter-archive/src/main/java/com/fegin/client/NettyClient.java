package com.fegin.client;

import com.dto.equipment.WiredMeterDTO;
import com.entity.CurrentMessage;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@FeignClient(name = "netty-provider", url = "${service-url.netty-provider}")
public interface NettyClient {
    @RequestMapping("/netty/fourthReadFlow")
    public void fourthReadFlow(@RequestParam(value = "meterAddress") String meterAddress,
                               @RequestParam(value = "collId") String collId);

    @RequestMapping("/netty/getMap")
    public Double getMap(@RequestParam(value = "meterAddress") String meterAddress);

    @RequestMapping("/netty/statusControll")
    public void statusControll(@RequestParam(value = "meterAddress") String meterAddress,
                               @RequestParam(value = "type") String type,
                               @RequestParam(value = "collId") String collId);

    @RequestMapping("/netty/getSocketMap")
    public Map<String, NioSocketChannel> getSocketMap();

    @RequestMapping("/netty/selectCurrentFrame")
    public Boolean selectCurrentFrame(@RequestBody CurrentMessage currentMessage);

    @RequestMapping("/netty/makeSetAddressFrame")
    public byte[] makeSetAddressFrame(@RequestParam(value = "oldAddress") String oldAddress,
                                      @RequestParam(value = "newAddress") String newAddress);

    @RequestMapping("/netty/makeSetCollDateFrame")
    public byte[] makeSetCollDateFrame(@RequestParam(value = "oldAddress") String oldAddress,
                                       @RequestParam(value = "dateStr") String dateStr);

    @RequestMapping("/netty/makeReadCollDateFrame")
    public byte[] makeReadCollDateFrame(@RequestParam(value = "address") String address);

    @RequestMapping("/netty/makeSetReportDateFrame")
    public byte[] makeSetReportDateFrame(@RequestParam(value = "address") String address,
                                         @RequestParam(value = "dateStr") String dateStr);

    @RequestMapping("/netty/makeReadReportDateFrame")
    public byte[] makeReadReportDateFrame(@RequestParam(value = "address") String address);

    @RequestMapping("/netty/sendCommandToTerm")
    public Boolean  sendCommandToTerm(@RequestParam(value = "address") String address,
                                      @RequestParam(value = "decodeHex") byte[] decodedHex,
                                      @RequestParam(value = "userName") String userName,
                                      @RequestParam(value = "termType") String termType);
    @RequestMapping("/netty/makeAddMeterFrame")
    public byte[] makeAddMeterFrame(@RequestParam(value = "address") String address,
                                    @RequestBody List<WiredMeterDTO> meterList);


    @RequestMapping("/netty/makeReadMeterFrame")
    public List<String> makeReadMeterFrame(@RequestParam(value = "address") String address);

    @RequestMapping("/netty/makeDeleteFrame")
    byte[] makeDeleteFrame(@RequestParam(value = "address") String address,
                           @RequestBody List<WiredMeterDTO> meterList);
}
