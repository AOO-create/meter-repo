package com.service.systemSetup.Impl;

import com.entity.systemSetup.RoleUserRelation;
import com.mapper.systemSetup.RoleUserRelationMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class RoleUserRelationServiceImpl<RoleUserRelationService> extends ServiceImpl<RoleUserRelationMapper, RoleUserRelation> implements com.service.systemSetup.RoleUserRelationService {
}
