package com.aop.aspect;

import com.aop.annotation.ChangeTermAopAnnotation;
import com.common.Const;
import com.common.Result;
import com.dto.equipment.TermDTO;
import com.entity.log.ChangeTermLog;
import com.mapper.systemLog.ChangeTermLogMapper;
import com.util.ShiroConstUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Aspect
@Component
@EnableAsync
public class ChangeTermLogAspect {
    @Autowired
    private ChangeTermLogMapper logMapper;//日志 mapper

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    private long startTimeMillis = 0; // 开始时间
    private long endTimeMillis = 0; // 结束时间

    /**
     * 注解的位置
     */
    @Pointcut("@annotation(com.aop.annotation.ChangeTermAopAnnotation)")
    public void logPointCut() {
    }

    /**
     * @param joinPoint
     * @Description 前置通知  方法调用前触发   记录开始时间,从session中获取操作人
     */
    @Before(value = "logPointCut()")
    public void before(JoinPoint joinPoint) {
    }

    /**
     * @param joinPoint
     * @return
     * @Description 获取入参方法参数
     */
    public Map<String, Object> getNameAndValue(JoinPoint joinPoint) {
        Map<String, Object> param = new HashMap<>();
        TermDTO dto = (TermDTO) joinPoint.getArgs()[0];
        param.put("address", dto.getAddress());
        param.put("name", dto.getName());
        param.put("areaId", dto.getAreaId());
        param.put("oldAddress",dto.getOldAddress());
        param.put("oldName",dto.getOldName());
        return param;
    }


    /**
     * 功能描述
     * @param joinPoint
     * @return void
     * @author liuwei
     * @date 2022/6/24
     */
    private Result operate(ProceedingJoinPoint joinPoint) throws Throwable {
        ChangeTermLog log = new ChangeTermLog();
        Map<String, Object> map = getNameAndValue(joinPoint);
        Result result = (Result)joinPoint.proceed();
        if(result.getCode() == 500){
            return result;
        }
        log.setAddress((String) map.get("address"));
        log.setOldAddress((String) map.get("oldAddress"));
        log.setAreaId((String) map.get("areaId"));
        log.setOrgId((shiroConstUtils.getOrg().getOrgId()));
        log.setName((String) map.get("name"));
        log.setOldName((String) map.get("oldName"));
        log.setOpUser(String.valueOf(Const.userId));

        endTimeMillis = System.currentTimeMillis();
        log.setOpUseTime(endTimeMillis - startTimeMillis);
        log.setOpTime(new Date());
        logMapper.insert(log);
        return Result.OK("集中器"+log.getOldAddress()+"成功更换为"+log.getAddress()+",更换成功");
    }

    /**
     * @param joinPoint
     * @Description 后置通知    方法调用后触发   记录结束时间 ,操作人 ,入参等
     */
    @Around(value = "logPointCut()")
    public Result after(ProceedingJoinPoint joinPoint) throws Throwable {
        startTimeMillis = System.currentTimeMillis();
        //删除操作在切点前面执行
        String targetName = joinPoint.getTarget().getClass().getName();
        String methodName = joinPoint.getSignature().getName();
        Object[] arguments = joinPoint.getArgs();
        Class<?> targetClass = null;
        try {
            targetClass = Class.forName(targetName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Method[] methods = targetClass.getMethods();
        Class<?>[] clazzs;
        for (Method method : methods) {
            if (method.getName().equals(methodName)) {
                clazzs = method.getParameterTypes();
                if (clazzs != null && clazzs.length == arguments.length && method.getAnnotation(ChangeTermAopAnnotation.class) != null) {
                    return operate(joinPoint);
                }
            }
        }
        return null;
    }
    /**
     * @Description: 获取request
     */
    public HttpServletRequest getHttpServletRequest() {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();
        return request;
    }
}
