package com.controller.systemSetup;

import com.entity.Org;
import com.entity.systemSetup.Role;
import com.service.systemSetup.RoleMenuRelationService;
import com.service.systemSetup.RoleService;
import com.util.ShiroConstUtils;
import com.vo.systemSetUpVo.RoleMenuRelationVo;
import com.vo.systemSetUpVo.RoleVo;
import com.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


/**
 * @author liuwei
 * @description
 * @date 2022/6/28
 */
@RestController
@RequestMapping("/archive/roleManager")
public class RoleManagerController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    @Autowired
    private RoleMenuRelationService roleMenuRelationService;

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("addRole")
    public Result addRole(@RequestBody RoleVo roleVo) throws Exception {
        return Result.OK(roleService.addRole(roleVo));
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("addRole2")
    public Result addRole2(@RequestBody RoleVo roleVo) throws Exception {
        return Result.OK(roleService.addRole2(roleVo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("updateRole")
    public Result updateRole(@RequestBody RoleVo roleVo) throws Exception {
        return Result.OK(roleService.updateRole(roleVo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("delRole")
    public Result delRole(@RequestBody Role role)throws Exception {
        return roleService.delRole(role);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("selectRole")
    public Result selectRole(@RequestBody RoleVo roleVo) throws Exception {
        Org org = shiroConstUtils.getOrg();
        Map map = roleVo.getWhere();
        map.put("orgId",org.getOrgId());
        return Result.OK(roleService.selectRole(roleVo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @GetMapping("findCurrentNode")
    public List<String> findCurrentNode(@RequestParam("id") String roleId){
        return roleService.findCurrentNode(roleId);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER","ROLE_FOURTH"})
    @PostMapping("flagList")
    public Result flagList(@RequestBody RoleMenuRelationVo vo){
        return Result.OK(roleMenuRelationService.flagList(vo));
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("updateMenuPremitByType")
    public Result updateMenuPremitByType(@RequestBody RoleMenuRelationVo vo){
        return Result.OK(roleMenuRelationService.updateMenuPremitByType(vo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON"})
    @PostMapping("updateMenuPremit")
    public Result updateMenuPremit(@RequestBody List<RoleMenuRelationVo> voList){
        return Result.OK(roleMenuRelationService.updateMenuPremit(voList));
    }

}

