package com.utils;


import com.alibaba.fastjson.JSON;
import com.common.Const;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class PoiUtils {
    //这是解析上传的Excel文件为对象集合，从而批量添加数据的方法

    /**
     * 导入excel,解析数据
     *
     * @param file    file传输excel文件
     * @param keyList 表头所对应实体类的key值
     * @return
     */
    public static String importExcel(MultipartFile file, List<String> keyList) {
        try {
            if (!file.isEmpty()) {
                List<Map<String,Object>> dataMapList = new ArrayList<>();
                String filename = file.getOriginalFilename();
                String suffix = filename.substring(filename.lastIndexOf(".") + 1);

                Workbook workbook = WorkbookFactory.create(file.getInputStream());
                Sheet sheet = workbook.getSheetAt(0);  //示意访问sheet
//                if(suffix.equals("xlsx")){
//                    wb = new XSSFWorkbook(file.getInputStream());
//                }else{
//                    wb = new HSSFWorkbook(file.getInputStream());
//                }
//                Sheet sheet = wb.getSheetAt(0);
                Row titleRow = sheet.getRow(0);
                //内容存在的最后一格单元格数量,从0开始
                int lastCellNum = titleRow.getLastCellNum();
                //内存存在的最后一行数量,从0开始
                int lastRowNum = sheet.getLastRowNum();
                //excel内容从1开始
                for (int a = 1; a <= lastRowNum; a++) {
                    Row row = sheet.getRow(a);
                    //key,value形式存储
                    Map<String, Object> dataMap = new HashMap<>();
                    for (int b = 0; b < lastCellNum; b++) {
                        //获取每行单元格
                        Cell  cell = row.getCell(b);
                        String key = keyList.get(b);
                        Object cellValue = "";
                        int cellType = cell.getCellType();
                        if(cell != null){
                            //将cell中的类型转换为String类型
                            //读取excel中value
                            if(cellType ==  Cell.CELL_TYPE_NUMERIC){
                                if (DateUtil.isCellDateFormatted(cell)) {
                                    //时间类型需要转换
                                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    cellValue=sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue())).toString();
                                } else {
                                    cellValue = new DecimalFormat("0").format(cell.getNumericCellValue());
                                }
                            }else {
                                cellValue = cell.getStringCellValue();
                            }
                        }
                        //存入dataMap中
                        dataMap.put(key, cellValue);
                    }
                    //存入list
                    dataMapList.add(dataMap);
                }
                return JSON.toJSONString(dataMapList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
       * 导出excel
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    public static Workbook exportExcel(String type,String dataDate){
        // 1. 创建工作空间
        Workbook workbook = new XSSFWorkbook(); // .xlsx 用 XSSFWorkbook
        String sheetName = sheetName(type);
        // 2. 创建工作表,根据常量type 设置sheet的名称
        Sheet sheet = workbook.createSheet(sheetName);
        /* 设置列宽和表头样式，读取常量根据type读取 */
        String[] headers= chooseHeaderExcel(type,dataDate);
        // 创建标题行（第一行）
        Row headerRow = sheet.createRow(0);
        //获取表头样式
        CellStyle style = excelStyle(workbook);
        for (int i = 0; i < headers.length; i++) {
            // 设置每一列的宽度
            sheet.setColumnWidth(i, 230*30);
            // 设置每一列的 style 和 标题
            Cell headerCell = headerRow.createCell(i);
            headerCell.setCellType(1);
            headerCell.setCellStyle(style);
            headerCell.setCellValue(headers[i]);
        }
        return workbook;
    }

    /**
       * 表格样式封装
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return java.lang.String[]
     */
    public static CellStyle excelStyle(Workbook workbook){
        CellStyle style = workbook.createCellStyle();
        // 3.1 创建字体
        Font headerFont = workbook.createFont();
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setFontName("宋体");

        style.setFont(headerFont);
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.ALIGN_CENTER);
        return style;
    }

    /**
       * 根据type选择标题行
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return java.lang.String
     */
    public static String[] chooseHeaderExcel(String type,String dataDate){
        switch (type){
            case "DAY_DATA_EXCEL":{
                return Const.EXPORT_DAY_DATA_EXCEL;
            }
            case "INCRE_DATA_EXCEL":{
                return Const.EXPORT_INCRE_DATA_EXCEL;
            }
            case "WIRED_EXCEL":{
                return Const.EXPORT_WIRED_METER_EXCEL;
            }
            case "TERM_EXCEL":{
                return Const.EXPORT_TERM_EXCEL;
            }
            case "NB_EXCEL":{
                return Const.EXPORT_NB_EXCEL;
            }
            case "NB_PRODUCT_EXCEL":{
                return Const.EXPORT_NB_PRODUCT_EXCEL;
            }
            case "STATISTICS_DATA" :{
                String[] str = new String[35];
                List<String> list = getMonthFullDay(Integer.parseInt(dataDate.substring(0,4)),Integer.parseInt(dataDate.substring(5,7)) + 1);
                str[0] = "年份";
                str[1] = "组织区域";
                str[2] = "设备总数";
                for(int i=0;i<list.size();i++){
                    str[i+3] = list.get(i);
                }
                return str;
            }
            case "COLLECT_METER_EXCEL":{
                return Const.EXPORT_COLLECT_METER_EXCEL;
            }
            default: return new String[0];
        }
    }

    public static List<String> getMonthFullDay(int year, int month){
        SimpleDateFormat dateFormatYYYYMMDD = new SimpleDateFormat("yyyy-MM-dd");
        List<String> fullDayList = new ArrayList<>(32);
        // 获得当前日期对象
        Calendar cal = Calendar.getInstance();
        cal.clear();// 清除信息
        cal.set(Calendar.YEAR, year);
        // 1月从0开始
        cal.set(Calendar.MONTH, month-1 );
        // 当月1号
        cal.set(Calendar.DAY_OF_MONTH,1);
        int count = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int j = 1; j <= count ; j++) {
            fullDayList.add(dateFormatYYYYMMDD.format(cal.getTime()));
            cal.add(Calendar.DAY_OF_MONTH,1);
        }
        return fullDayList;
    }

    /**
       * 根据type类型决定导出表格sheet的name
       * @author liuwei
       * @date  2022/6/20
       * @param
       * @return
     */
    public static String sheetName(String type){
        String sheetName = "";
        switch (type){
            case "DAY_DATA_EXCEL":{
                sheetName = Const.EXPORT_SHEET_DAY_DATA;
                break;
            }
            case "INCRE_DATA_EXCEL":{
                sheetName = Const.EXPORT_SHEET_INCRE_DAY_DATA;
                break;
            }
            case "WIRED_EXCEL":{
                sheetName = Const.EXPORT_SHEET_WIRED_METER;
                break;
            }
            case "TERM_EXCEL":{
                sheetName = Const.EXPORT_SHEET_TERM;
                break;
            }
            case "NB_EXCEL":{
                sheetName = Const.EXPORT_SHEET_NB;
                break;
            }
            case "NB_PRODUCT_EXCEL":{
                sheetName = Const.EXPORT_SHEET_NB_PRODUCT;
                break;
            }
            case "STATISTICS_DATA":{
                sheetName= Const.EXPORT_SHEET_STATISTICS_DATA;
                break;
            }
            case "COLLECT_METER_EXCEL":{
                sheetName = Const.EXPORT_SHEET_COLLECT_METER;
                break;
            }
            default: return "";
        }
        return sheetName;
    }


}

