package com.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class WiredMeterMonthRead {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    private Date collTime;
    private Date dataDate;
    private String termAddress;
    private String meterAddress;
    private BigDecimal fee1;
    private BigDecimal fee2;
    private BigDecimal fee3;
    private BigDecimal fee4;
    private BigDecimal realSumFlow;
}
