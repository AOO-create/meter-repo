package com.aop.aspect;

import com.aop.annotation.LoginLogAnnotation;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.entity.User;
import com.mapper.LoginLogMapper;
import com.sso.domain.LoginLog;
import com.sso.domain.SysUser;
import com.sso.mapper.UserMapper;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Date;

@Aspect
@Component
public class LoginLogAspect {

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Autowired
    private UserMapper userMapper;

    @Pointcut("@annotation(com.aop.annotation.LoginLogAnnotation)")
    public void loginLog() {
    }

    @AfterReturning(pointcut = "loginLog()")
    public void afterReturning(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        SysUser user = (SysUser) joinPoint.getArgs()[0];

        LoginLogAnnotation loginLogAnnotation = method.getAnnotation(LoginLogAnnotation.class);
        if (loginLogAnnotation != null) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            String ip = request.getHeader("X-Real-IP");
            if (ip != null && !"".equals(ip) && !"unknown".equalsIgnoreCase(ip)) {
                ip = ip;
            }
            ip = request.getHeader("X-Forwarded-For");
            if (ip != null && !"".equals(ip) && !"unknown".equalsIgnoreCase(ip)) {
                int index = ip.indexOf(',');
                if (index != -1) {
                    //只获取第一个值
                    ip = ip.substring(0, index);
                } else {
                    ip = ip;
                }
            } else {
                //取不到真实ip则返回空，不能返回内网地址。
                ip = "";
            }

//            String ip = request.getRemoteAddr();
            String username = user.getUsername();
            String description = loginLogAnnotation.description();
            LoginLog log= new LoginLog();
            log.setIp(ip);
            log.setTime(new Date());
            User uu = userMapper.selectOne(new QueryWrapper<User>().eq("username",username));
            log.setUsername(username);
            log.setName(uu.getName());
            log.setDescription(description);
            loginLogMapper.insert(log);
        }
    }
}
