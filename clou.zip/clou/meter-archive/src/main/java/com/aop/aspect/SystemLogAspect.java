package com.aop.aspect;

import com.aop.annotation.AopAnnotation;
import com.dto.equipment.NBDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.log.OperateMeterLog;
import com.entity.Org;
import com.entity.equipment.WNB;
import com.entity.equipment.WiredMeter;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.mapper.systemLog.MeterOperateLogMapper;
import com.util.ShiroConstUtils;
import com.common.Const;
import com.utils.RedisUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.*;

@Aspect
@Component
@EnableAsync
public class SystemLogAspect {
    @Autowired
    private MeterOperateLogMapper logMapper;//日志 mapper

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired(required = false)
    private RedisUtils redisUtils;

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    private long startTimeMillis = 0; // 开始时间
    private long endTimeMillis = 0; // 结束时间

    /**
     * 注解的位置
     */
    @Pointcut("@annotation(com.aop.annotation.AopAnnotation)")
    public void logPointCut() {
    }

    /**
     * @param joinPoint
     * @Description 前置通知  方法调用前触发   记录开始时间,从session中获取操作人
     */
    @Before(value = "logPointCut()")
    public void before(JoinPoint joinPoint) {
        startTimeMillis = System.currentTimeMillis();
        //删除操作在切点前面执行
        String targetName = joinPoint.getTarget().getClass().getName();
        String methodName = joinPoint.getSignature().getName();
        Object[] arguments = joinPoint.getArgs();
        Class<?> targetClass = null;
        try {
            targetClass = Class.forName(targetName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Method[] methods = targetClass.getMethods();
        Class<?>[] clazzs;
        for (Method method : methods) {
            if (method.getName().equals(methodName)) {
                clazzs = method.getParameterTypes();
                if (clazzs != null && clazzs.length == arguments.length && method.getAnnotation(AopAnnotation.class) != null) {
                    int opType = method.getAnnotation(AopAnnotation.class).opType();
                    if (opType == Const.operate_nb_delete || opType == Const.operate_nb_batch_delete
                            || opType == Const.operate_wired_delete || opType == Const.operate_wired_batch_delete) {
                        operate(joinPoint, opType);
                    }
                }
            }
        }
    }

    /**
     * @param joinPoint
     * @return
     * @Description 获取入参方法参数
     */
    public Map<String, Object> getNameAndValue(JoinPoint joinPoint, int type) {
        Map<String, Object> param = new HashMap<>();
        if (type == Const.operate_wired_update || type == Const.operate_wired_insert) {
            //有线更新插入
            WiredMeterDTO dto = (WiredMeterDTO) joinPoint.getArgs()[0];
            param.put("meterType",dto.getMeterType().equals("0")?"1":"2");
            param.put("meterAddress", dto.getMeterAddress());
            param.put("name", dto.getName());
            param.put("areaId", dto.getAreaId());
            param.put("termAddress",dto.getTermId());
        } else if (type == Const.operate_nb_insert || type == Const.operate_nb_update) {
            //nb更新插入
            NBDTO dto = (NBDTO) joinPoint.getArgs()[0];
            param.put("meterType","0");
            param.put("meterAddress", dto.getMeterAddress());
            param.put("name", dto.getName());
            param.put("areaId", dto.getAreaId());
            param.put("termAddress","");
        } else if (type == Const.operate_nb_delete) {
            String id = (String) joinPoint.getArgs()[0];
            WNB wnb = nBmeterMapper.selectById(id);
            param.put("meterType","0");
            param.put("meterAddress", wnb.getMeterAddress());
            param.put("name", wnb.getName());
            param.put("areaId", wnb.getAreaId());
            param.put("termAddress","");
        } else if (type == Const.operate_nb_batch_delete) {
            List<String> ids = (List<String>) joinPoint.getArgs()[0];
            List<WNB> nbdtos = new ArrayList<>();
            for (String id : ids) {
                WNB wnb = nBmeterMapper.selectById(id);
                nbdtos.add(wnb);
            }
            param.put("meterType","0");
            param.put("dtoList", nbdtos);
            param.put("termAddress","");
        }else if(type == Const.operate_wired_delete){
            String id = (String) joinPoint.getArgs()[0];
            WiredMeter wiredMeter = wiredMeterMapper.selectById(id);
            param.put("meterType",wiredMeter.getMeterType().equals("0")?"1":"2");
            param.put("meterAddress",wiredMeter.getMeterAddress());
            param.put("name",wiredMeter.getName());
            param.put("areaId",wiredMeter.getAreaId());
            param.put("termAddress",wiredMeter.getTermId());
        }else if(type == Const.operate_wired_batch_delete){
            List<String> ids = (List<String>) joinPoint.getArgs()[0];
            List<WiredMeter> wiredMeterList = new ArrayList<>();
            for (String id : ids) {
                WiredMeter wiredMeter = wiredMeterMapper.selectById(id);
                wiredMeterList.add(wiredMeter);
            }
            param.put("dtoList", wiredMeterList);
        }
        return param;
    }


    /**
     * 功能描述
     * @param joinPoint
     * @return void
     * @author liuwei
     * @date 2022/6/24
     */
    private void operate(JoinPoint joinPoint, int opType) {
        //业务操作
        OperateMeterLog log = new OperateMeterLog();
        if (opType == Const.operate_nb_batch_delete) {
            List<WNB> list = (List<WNB>) getNameAndValue(joinPoint, opType).get("dtoList");
            log.setOpType(opType);
            for (WNB nbdto : list) {
                OperateMeterLog logDel = new OperateMeterLog();
                logDel.setMeterAddress(nbdto.getMeterAddress());
                logDel.setMeterName(nbdto.getName());
                logDel.setAreaId(nbdto.getAreaId());

                logDel.setOpUser(String.valueOf(Const.userId));
                Org org = shiroConstUtils.getOrg();
                logDel.setOrgId(org.getOrgId());
                logDel.setMeterType("0");
                endTimeMillis = System.currentTimeMillis();
                logDel.setOpUseTime(endTimeMillis - startTimeMillis);
                logDel.setOpTime(new Date());
                logMapper.insert(logDel);
            }
            return;
        }
        if(opType == Const.operate_wired_batch_delete){
            List<WiredMeter> list = (List<WiredMeter>) getNameAndValue(joinPoint, opType).get("dtoList");
            log.setOpType(opType);
            for (WiredMeter wiredMeter : list) {
                OperateMeterLog logDel = new OperateMeterLog();
                logDel.setMeterAddress(wiredMeter.getMeterAddress());
                logDel.setMeterName(wiredMeter.getName());
                logDel.setAreaId(wiredMeter.getAreaId());

                logDel.setMeterType(wiredMeter.getMeterType().equals("0")?"1":"2");
                logDel.setOpUser(String.valueOf(Const.userId));
                Org org = shiroConstUtils.getOrg();
                logDel.setOrgId(org.getOrgId());

                endTimeMillis = System.currentTimeMillis();
                logDel.setOpUseTime(endTimeMillis - startTimeMillis);
                logDel.setOpTime(new Date());
                logMapper.insert(logDel);
            }
            return;
        }
        log.setOpType(opType);
        Map<String, Object> map = getNameAndValue(joinPoint, opType);
        //获取到表地址；表名称；组织区域；
        log.setMeterType((String) map.get("meterType"));
        log.setMeterAddress((String) map.get("meterAddress"));
        log.setMeterName((String) map.get("name"));
        log.setAreaId((String) map.get("areaId"));
        log.setTermAddress((String) map.get("termAddress"));
        log.setOpUser(String.valueOf(Const.userId));

        Org org = shiroConstUtils.getOrg();
        log.setOrgId(org.getOrgId());

        endTimeMillis = System.currentTimeMillis();
        log.setOpUseTime(endTimeMillis - startTimeMillis);
        log.setOpTime(new Date());
        logMapper.insert(log);
    }

    /**
     * @param joinPoint
     * @Description 后置通知    方法调用后触发   记录结束时间 ,操作人 ,入参等
     */
    @After(value = "logPointCut()")
    public void after(JoinPoint joinPoint) {
        //删除操作在切点前面执行
        String targetName = joinPoint.getTarget().getClass().getName();
        String methodName = joinPoint.getSignature().getName();
        Object[] arguments = joinPoint.getArgs();
        Class<?> targetClass = null;
        try {
            targetClass = Class.forName(targetName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Method[] methods = targetClass.getMethods();
        Class<?>[] clazzs;
        for (Method method : methods) {
            if (method.getName().equals(methodName)) {
                clazzs = method.getParameterTypes();
                if (clazzs != null && clazzs.length == arguments.length && method.getAnnotation(AopAnnotation.class) != null) {
                    int opType = method.getAnnotation(AopAnnotation.class).opType();
                    if (opType != Const.operate_nb_delete && opType != Const.operate_nb_batch_delete
                            && opType != Const.operate_wired_delete && opType != Const.operate_wired_batch_delete) {
                        operate(joinPoint, opType);
                    }
                }
            }
        }
    }

    /**
     * @Description: 获取request
     */
    public HttpServletRequest getHttpServletRequest() {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();
        return request;
    }

    /**
     * @param joinPoint
     * @return 环绕通知
     * @throws Throwable
     */
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        return null;
    }

    /**
     * @param joinPoint
     * @Description 异常通知
     */
    public void throwing(JoinPoint joinPoint) {
        System.out.println("异常通知");
    }
}