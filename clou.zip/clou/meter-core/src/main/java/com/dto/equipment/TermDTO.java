package com.dto.equipment;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.common.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class TermDTO extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long terminalId;

    private String address;//资产编号

    private String name;//集中器名称

    private String orgId ;//供能单位

    private String areaId;//组织区域ID

    private String areaName;

    private Integer online;

    private String protocolCode;//采用通讯规约
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date installDate;//安装日期

    private String installAddr;//安装地址

    private Date updTime;

    private String modelType;//型号类型

}
