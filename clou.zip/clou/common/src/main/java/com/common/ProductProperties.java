package com.common;


public class ProductProperties {
    /**
     * 应用masterKey
     */
    private String masterKey = "2c52ccffa22340958d3886007f6b1480";

    /**
     * 应用productId
     */
    private String productId = "15118798";

    /**
     * 应用operator
     */
    private String operator = "admin";

    public String getMasterKey() {
        return masterKey;
    }

    public void setMasterKey(String masterKey) {
        this.masterKey = masterKey;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
