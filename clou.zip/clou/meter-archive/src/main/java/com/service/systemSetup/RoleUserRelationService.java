package com.service.systemSetup;

import com.entity.systemSetup.RoleUserRelation;
import com.baomidou.mybatisplus.extension.service.IService;

public interface RoleUserRelationService extends IService<RoleUserRelation> {
}
