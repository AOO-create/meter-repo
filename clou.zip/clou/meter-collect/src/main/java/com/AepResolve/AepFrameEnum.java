package com.AepResolve;

public interface AepFrameEnum {
}
