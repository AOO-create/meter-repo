package com.dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;
/**
 * @author liuwei
 * @description
 * @date 2023/10/18 
 */
@Data
public class FeedbackDTO {
    List<String> ids;
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;//主键ID
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long createUser;//发送住户ID
    private String createName;//发送住户姓名
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;//发送时间
    private String type;//反馈类型 0功能 1性能
    private String title;//反馈标题
    private String content;//反馈内容
    private String phone;//住户手机号
    private String status;//反馈状态 0未处理 1已回复
    private Integer level;//评价星级
    private String replay;//反馈回复
    private Integer page;
    private Integer limit;
    private int functionalNum;
    private int performanceNum;
    private int noDealNum;
    private int replayNum;
    private int goodNum;
    private int badNum;
    private double badRate;
    private double replayRate;

}
