package com.entity.log;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2023/4/20
 */
@Data
@TableName("change_meter_log")
public class ChangeMeterLog {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;//主键ID

    private Integer opType;//操作类型

    private String meterAddress;//操作表地址

    private String meterName;//操作表名

    private String oldMeterAddress;//被替换表具表地址

    private String oldMeterName;//被替换表具表名称

    private String areaId;//操作表所属组织区域

    private String tgBuildDoorplate;//房门号

    private Date opTime;// 操作日期

    private String opUser;//操作人

    private Long opUseTime;//操作耗时时间

    private String orgId;

    private String meterType;//表具类型

}
