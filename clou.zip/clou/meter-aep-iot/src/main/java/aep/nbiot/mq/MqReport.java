package aep.nbiot.mq;

import java.io.Serializable;

/**
 * @author lanccj
 * @version 1.0
 * @description: TODO
 * @date 2021/11/20 8:43 上午
 */
public class MqReport implements Serializable {
}
