package com.dto;

import com.common.PageConstant;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/11/20
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BDGradeDTO extends PageConstant {
    private String id;
    private String bdNo;
    private String bdName;
    private String orgId;
    private String parentId;
    private String areaId;
    private String remark;

    private Date updTime;
}
