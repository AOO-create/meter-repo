package com.service.systemSetup.Impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.entity.organization.BDGrade;
import com.entity.organization.Grade;
import com.entity.Org;
import com.entity.systemSetup.Role;
import com.entity.systemSetup.RoleUserRelation;
import com.entity.systemSetup.User;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.systemSetup.RoleMapper;
import com.mapper.systemSetup.RoleUserRelationMapper;
import com.mapper.systemSetup.UserMapper;
import com.service.systemSetup.UserManagerService;
import com.util.ShiroConstUtils;
import com.vo.systemSetUpVo.UserVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import com.common.ResultCodeEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/27
 */
@Service
public class UserManagerServiceImpl implements UserManagerService {

    @Autowired
    private UserMapper mapper;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private RoleUserRelationMapper roleUserRelationMapper;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;
    @Autowired
    private ShiroConstUtils shiroConstUtils;

    public static void main(String[] args) {

        String updatePassword = new BCryptPasswordEncoder().encode("123123");
        System.out.println(updatePassword);
    }

    @Override
    public Page<UserVo> findAllUser(UserVo user) {
        Org org = shiroConstUtils.getOrg();
        QueryWrapper<User> qw = new QueryWrapper<>();
        //根据供能单位ID进行筛选
        qw.eq("org_id",org.getOrgId());

        com.entity.Role role = shiroConstUtils.getRole();
        if( !role.getRoleCode().equals("admin") ){
            //管理员身份无需过滤，非管理员身份，只能查看本楼栋下面的
            qw.eq("tg_build_doorplate",shiroConstUtils.getTgBuildDoorplate());
            qw.eq("area_id",shiroConstUtils.getAreaId());
        }

        if(null != user.getUsername() && !user.getUsername().equals("") ){
            qw.eq("username",user.getUsername());
        }

        if(user.getStatusCode() != null){
            qw.eq("status_code",user.getStatusCode());
        }

        Page<User> page = new Page<>(user.getPage(),user.getLimit());
        page = mapper.selectPage(page,qw);
        Page<UserVo> page1 = new Page<>(user.getPage(),user.getLimit());
        page1.setTotal(page.getTotal());
        page1.setSize(page.getSize());
        page1.setCurrent(page.getCurrent());
        page1.setPages(page.getPages());
        List<UserVo> voList = new ArrayList<>();
        for(User user1 : page.getRecords()){
            UserVo vo = new UserVo();
            BeanUtils.copyProperties(user1,vo);
            Long roleId = roleUserRelationMapper.selectOne(new QueryWrapper<RoleUserRelation>()
                    .eq("user_id",user1.getId())).getRoleId();
            vo.setRoleId(roleId);
            Grade grade = gradeMapper.selectById(user1.getAreaId());
            String areaName =grade.getAreaName();
            if(null != user1.getTgBuildDoorplate() && !user1.getTgBuildDoorplate().equals("")){
                BDGrade bdGrade = bdGradeMapper.selectById(user1.getTgBuildDoorplate());
                String bdName = bdGrade.getBdName();
                vo.setBdName(bdName);
            }
            vo.setAreaName(areaName);
            voList.add(vo);
        }
        page1.setRecords(voList);
        return page1;
    }

    @Transactional
    @Override
    public Result addUser(UserVo user) {
        Org org = shiroConstUtils.getOrg();
        User uu = new User();
        BeanUtils.copyProperties(user,uu);
        User userIsExist = mapper.selectOne(new LambdaQueryWrapper<User>().eq(User::getUsername,uu.getUsername()));
        if(userIsExist!=null){ return Result.ERROR(ResultCodeEnum.ACCOUNT_IS_EXIST);}
        if(null == user.getAreaId() || "".equals(user.getAreaId())){
            //点击树节点为单元门栋
            String areaId = bdGradeMapper.selectOne(new QueryWrapper<BDGrade>().eq("id",user.getTgBuildDoorplate())).getAreaId();
            uu.setAreaId(areaId);
            uu.setTgBuildDoorplate(user.getTgBuildDoorplate());
        }else{
            //点击为组织区域节点则
            uu.setAreaId(user.getAreaId());
        }

        uu.setOrgId(org.getOrgId());
//        String password = DigestUtils.sha1Hex(user.getUsername() + user.getPassword());
        String password = (new BCryptPasswordEncoder().encode(user.getPassword()));
        uu.setPassword(password);
        int count = mapper.insert(uu);
        if(count < 0){
            //插入失败
            return Result.ERROR(ResultCodeEnum.ADD_USER_ERROR);
        }
        //插入关系表中
        RoleUserRelation roleUserRelation = new RoleUserRelation();
        roleUserRelation.setRoleId(user.getRoleId());
        roleUserRelation.setUserId(uu.getId());
        count = roleUserRelationMapper.insert(roleUserRelation);
        if(count <= 0){
            return Result.ERROR(ResultCodeEnum.ADD_USER_ERROR);
        }
        return Result.OK();
    }

    @Transactional
    @Override
    public Result updateUser(UserVo user) {
        User uu = new User();
        BeanUtils.copyProperties(user,uu);
        if(null == user.getAreaId() || "".equals(user.getAreaId())){
            //点击树节点为单元门栋
            String areaId = bdGradeMapper.selectOne(new QueryWrapper<BDGrade>().eq("id",user.getTgBuildDoorplate())).getAreaId();
            uu.setAreaId(areaId);
            uu.setTgBuildDoorplate(user.getTgBuildDoorplate());
        }else{
            //点击为组织区域节点则
            uu.setAreaId(user.getAreaId());
            uu.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        }
        int count = mapper.updateById(uu);
        if(count < 0){
            //插入成功
            return Result.ERROR(ResultCodeEnum.UPDATE_USER_ERROR);
        }
        RoleUserRelation roleUserRelation = roleUserRelationMapper.selectOne(new QueryWrapper<RoleUserRelation>()
                .eq("user_id",user.getId()));
        roleUserRelation.setRoleId(user.getRoleId());
        count = roleUserRelationMapper.updateById(roleUserRelation);
        if(count <= 0){
            return Result.ERROR(ResultCodeEnum.ADD_USER_ERROR);
        }
        return Result.OK();
    }

    @Transactional
    @Override
    public Result deleteUser(String id) {
        int count = mapper.deleteById(id);
        if(count < 0){
            //插入成功
            return Result.ERROR(ResultCodeEnum.DELETE_USER_ERROR);
        }
        count = roleUserRelationMapper.delete(new QueryWrapper<RoleUserRelation>().eq("user_id",id));
        if(count < 0){
            return Result.ERROR(ResultCodeEnum.DELETE_USER_ERROR);
        }
        return Result.OK();
    }

    @Transactional
    @Override
    public Result batchDelUser(List<String> ids) {
        int count = mapper.deleteBatchIds(ids);
        if(count < 0){
            //插入成功
            return Result.ERROR(ResultCodeEnum.BATCHDELETE_USER_ERROR);
        }
        count = roleUserRelationMapper.delete(new QueryWrapper<RoleUserRelation>().in("user_id",ids));
        if(count < 0){
            return Result.ERROR(ResultCodeEnum.DELETE_USER_ERROR);
        }
        return Result.OK();
    }

    @Override
    public boolean updatePassword(String id,String pass,String updatePassword) {
        User user = mapper.selectOne(new QueryWrapper<User>().eq("id",id));
        boolean flag = new BCryptPasswordEncoder().matches(pass,user.getPassword());
        if(!flag){
            return false;
        }
        String encodeUpdatePassword = new BCryptPasswordEncoder().encode(updatePassword);
        user.setPassword(encodeUpdatePassword);
        user.setUpdTime(new Date());
        int count = mapper.updateById(user);
        return count > 0;
    }

    @Override
    public List<Role> getRoleToSel() {
        Org org = shiroConstUtils.getOrg();

        return roleMapper.selectList(new QueryWrapper<Role>().eq("org_id",org.getOrgId()));
    }

    @Override
    public Page<UserVo> getUserListByRole(UserVo vo) {
        Org org = shiroConstUtils.getOrg();
        long roleId = vo.getRoleId();
        List<RoleUserRelation>  relationList = roleUserRelationMapper.selectList(new QueryWrapper<RoleUserRelation>()
                .eq("role_id",roleId));
        QueryWrapper<User> qw = new QueryWrapper<>();
        com.entity.Role role = shiroConstUtils.getRole();
        if( !role.getRoleCode().equals("admin") ){
            qw.eq("tg_build_doorplate", shiroConstUtils.getTgBuildDoorplate());
            qw.eq("area_id",shiroConstUtils.getAreaId());
        }

        if(null != vo.getName() && !("").equals(vo.getName())){
            qw.like("name",vo.getName());
        }

        qw.eq("org_id",org.getOrgId());

        List<Long> userIds = new ArrayList<>();
        for (RoleUserRelation roleUserRelation : relationList) {
            long userId = roleUserRelation.getUserId();
            userIds.add(userId);
        }

        qw.in("id",userIds);

        Page<User> page = new Page<>(vo.getPage(),vo.getLimit());
        page = mapper.selectPage(page,qw);
        Page<UserVo> page1 = new Page<>(vo.getPage(),vo.getLimit());
        page1.setTotal(page.getTotal());
        page1.setSize(page.getSize());
        page1.setCurrent(page.getCurrent());
        page1.setPages(page.getPages());
        List<UserVo> voList = new ArrayList<>();
        for(User user1 : page.getRecords()){
            UserVo vo1 = new UserVo();
            BeanUtils.copyProperties(user1,vo1);
            vo1.setRoleId(roleId);
            Grade grade = gradeMapper.selectById(user1.getAreaId());
            String areaName =grade.getAreaName();
            if(user1.getTgBuildDoorplate().equals("")){
                vo1.setBdName("");
            }else{
                BDGrade bdGrade = bdGradeMapper.selectById(user1.getTgBuildDoorplate());
                String bdName = bdGrade.getBdName();
                vo1.setBdName(bdName);
            }
            vo1.setAreaName(areaName);
            voList.add(vo1);
        }
        page1.setRecords(voList);

        return page1;
    }
}
