package com.dto.equipment;

import com.common.PageConstant;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2023/4/14
 */
@Data
public class MeterDTO extends PageConstant {
    private String id;//表具ID
    private String meterAddress;//表地址
    private String instLoc;//安装位置
    private String areaId;//区域ID
    private String areaName;//区域名称
    private String termId;//关联集中器Id（有线表特属）
    private String tgBuildDoorplate;//房门ID
    private String bdName;//房门名称
    private String meterType;//表具类型 5 NB表 0 冷水水表 4电表
    private String protoCode;//协议类型（NB表特属）
    private String imei;//imei号（NB表特属）
    private String Date;//安装时间
    private String name;//表居名称
    private String orgId;//组织区域Id
    private String modelType;//集中器型号

    private String protocol;//有线表（04）通信协议
    private String uartbps;//有线表（04）串口波特率
    private String channel;//有线表（04）硬件通道
}
