package aep.nbiot.strategy;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 策略实例
 * @date 2021/11/17 8:05
 */
public class AepStrategyContext {

    private IAepStrategy aepStrategy;

    public AepStrategyContext(IAepStrategy aepStrategy) {
        this.aepStrategy = aepStrategy;
    }

    public BaseApiResponse invockApi(BaseApiClient client, HashMap<String,Object> params, HashMap<String,Object> body){
        return aepStrategy.invockApi(client,params,body);
    }
}
