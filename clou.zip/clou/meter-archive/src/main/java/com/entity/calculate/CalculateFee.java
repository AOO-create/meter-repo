package com.entity.calculate;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@TableName("calculate_fee")
public class CalculateFee {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tgBuildDoorplate;//所属房间号

    private Integer type;//缴费类型  1、柜台缴费 2、第三方缴费 3、三方代扣缴费

    private String formula;//公式

    private String realFormula;//描述

    private String status;//是否启用

    private String name;//计算方式的名称


    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long createUser;//操作用户id

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
}
