package com.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.constant.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
@Data
public class nbSendCommandVo extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id; //主键

    private String type;//任务类型

    private String meterAddress;//表地址

    private String imei;//IMEI号

    private String frame;//报文

    private String flag;//成功标志

    private String resultMsg;//返回消息

    private String resultData;//返回数据

    private String param;//请求参数

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;//创建时间
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updTime;//更新时间

    private String meterType;//下行命令类型

    private String baseNumber;
    private String coefficient;
    private String status;
    private String dayDataDate;
    private String monthDataDate;
    private String hourDataDate;
    private String cycle;
    private String interval;
    private String startMin;
    private String startHour;
    private String onDate;
    private String offDate;
    private String rustProofScale;
    private String minute;
    private String hour;
    private String date;
    private String statusTwo;
    private String actionTime;
}