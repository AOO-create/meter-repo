package aep.nbiot.dto.param.devicemanage.lwm2m;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wufanghao
 * @version 1.0
 * @description: LWM2M协议创建设备参数对象
 * @date 2021/12/13 8:19
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OtherLWM2M {

    /**
     * 0.自动订阅 1.取消自动订阅，必填;
     */
    private Integer autoObserver = 0;

    /**
     * 总长度不超过15位，使用0~9的数字，String类型,选填
     */
    private String imsi;

    /**
     * 由大小写字母加0-9数字组成的16位字符串,选填
     */
    private String pskValue;
}
