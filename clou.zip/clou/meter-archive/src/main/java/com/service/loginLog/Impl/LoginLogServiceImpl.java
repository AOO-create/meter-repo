package com.service.loginLog.Impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.log.LoginLog;
import com.mapper.systemLog.LoginLogMapper;
import com.service.loginLog.LoginLogService;
import com.vo.SystemLogVo.LoginLogVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liuwei
 * @description
 * @date 2023/10/26 
 */
@Service
public class LoginLogServiceImpl implements LoginLogService {

    @Autowired
    private LoginLogMapper mapper;

    @Override
    public Page<LoginLog> getPageLoginLog(LoginLogVo log) {
        QueryWrapper<LoginLog> qw = new QueryWrapper<>();
        if(!"".equals(log.getIp())){
            qw.like("ip","%"+log.getIp()+"%");
        }

        if(!"".equals(log.getUsername())){
            qw.like("username","%"+log.getUsername()+"%");
        }

        if(!"".equals(log.getDescription())){
            qw.eq("description",log.getDescription());
        }

        qw.orderByDesc(true,"time");
        Page<LoginLog> page = new Page<>(log.getPage(),log.getLimit());

        page = mapper.selectPage(page,qw);
        return page;
    }
}
