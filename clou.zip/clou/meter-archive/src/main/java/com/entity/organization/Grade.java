package com.entity.organization;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/4/28
 */
@Data
@TableName("o_area_grade")
public class Grade {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;

    private String areaNo;

    private String areaName;

    private String orgId;

    private Long parentId;

    private String email;

    private String remark;

    private Date   updTime;
}
