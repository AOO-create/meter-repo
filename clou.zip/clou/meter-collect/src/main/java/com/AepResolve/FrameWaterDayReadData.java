package com.AepResolve;

public class FrameWaterDayReadData {

    private Integer startcode;
    private Integer type;
    private String address;
    private String contolCode;
    private Integer byteLength;

    private String dataLogo;
    private String serialId;
    private String totalNmbel;
    private String currentFrmId;
    private Integer ticurrentFrmNuber;//本帧条数

    private String reportTime;
    private Integer collGay;//采集间隔

    private String currentIntegreFlow;//当前累积流量
    private Integer instantFlow;// 瞬时流量
    private Integer thwStrenthA;
    private Integer thwStrenthB;
    private Integer retain;

    private Integer cellVolt;//电池电压
    private Integer signalPoint;//信号指示
    private Integer signalStrenth;
    private Integer signalQual;//信号质量
    private Integer signalNoise;

    private Integer coverGrade;//覆盖等级
    private Integer pciId;
    private String imei;//
    private String imsi;//
    private Integer loginedNumber;//累计上线成功次数

    private Integer FailedNumber;//累计上线失败次数
    private String sendTime;//发送的实时时间
    /***
     * 水表阀门状态
     */
    private Integer waterMeterStatus0;//水表状态
    private Integer waterMeterStatus1;
    private Integer alarm;

    private Integer hardware;//硬件版本号
    private Integer software;//软件版本号
    private String checkCode;//校验码
    private Integer endCode;//结束码


    public Integer getStartcode() {
        return startcode;
    }

    public void setStartcode(Integer startcode) {
        this.startcode = startcode;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContolCode() {
        return contolCode;
    }

    public void setContolCode(String contolCode) {
        this.contolCode = contolCode;
    }

    public Integer getByteLength() {
        return byteLength;
    }

    public void setByteLength(Integer byteLength) {
        this.byteLength = byteLength;
    }

    public String getDataLogo() {
        return dataLogo;
    }

    public void setDataLogo(String dataLogo) {
        this.dataLogo = dataLogo;
    }

    public String getSerialId() {
        return serialId;
    }

    public void setSerialId(String serialId) {
        this.serialId = serialId;
    }

    public String getTotalNmbel() {
        return totalNmbel;
    }

    public void setTotalNmbel(String totalNmbel) {
        this.totalNmbel = totalNmbel;
    }

    public String getCurrentFrmId() {
        return currentFrmId;
    }

    public void setCurrentFrmId(String currentFrmId) {
        this.currentFrmId = currentFrmId;
    }

    public Integer getTicurrentFrmNuber() {
        return ticurrentFrmNuber;
    }

    public void setTicurrentFrmNuber(Integer ticurrentFrmNuber) {
        this.ticurrentFrmNuber = ticurrentFrmNuber;
    }

    public String getReportTime() {
        return reportTime;
    }

    public void setReportTime(String reportTime) {
        this.reportTime = reportTime;
    }

    public Integer getCollGay() {
        return collGay;
    }

    public void setCollGay(Integer collGay) {
        this.collGay = collGay;
    }

    public String getCurrentIntegreFlow() {
        return currentIntegreFlow;
    }

    public void setCurrentIntegreFlow(String currentIntegreFlow) {
        this.currentIntegreFlow = currentIntegreFlow;
    }

    public Integer getInstantFlow() {
        return instantFlow;
    }

    public void setInstantFlow(Integer instantFlow) {
        this.instantFlow = instantFlow;
    }

    public Integer getThwStrenthA() {
        return thwStrenthA;
    }

    public void setThwStrenthA(Integer thwStrenthA) {
        this.thwStrenthA = thwStrenthA;
    }

    public Integer getThwStrenthB() {
        return thwStrenthB;
    }

    public void setThwStrenthB(Integer thwStrenthB) {
        this.thwStrenthB = thwStrenthB;
    }

    public Integer getRetain() {
        return retain;
    }

    public void setRetain(Integer retain) {
        this.retain = retain;
    }

    public Integer getCellVolt() {
        return cellVolt;
    }

    public void setCellVolt(Integer cellVolt) {
        this.cellVolt = cellVolt;
    }

    public Integer getSignalPoint() {
        return signalPoint;
    }

    public void setSignalPoint(Integer signalPoint) {
        this.signalPoint = signalPoint;
    }

    public Integer getSignalStrenth() {
        return signalStrenth;
    }

    public void setSignalStrenth(Integer signalStrenth) {
        this.signalStrenth = signalStrenth;
    }

    public Integer getSignalQual() {
        return signalQual;
    }

    public void setSignalQual(Integer signalQual) {
        this.signalQual = signalQual;
    }

    public Integer getSignalNoise() {
        return signalNoise;
    }

    public void setSignalNoise(Integer signalNoise) {
        this.signalNoise = signalNoise;
    }

    public Integer getCoverGrade() {
        return coverGrade;
    }

    public void setCoverGrade(Integer coverGrade) {
        this.coverGrade = coverGrade;
    }

    public Integer getPciId() {
        return pciId;
    }

    public void setPciId(Integer pciId) {
        this.pciId = pciId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public Integer getLoginedNumber() {
        return loginedNumber;
    }

    public void setLoginedNumber(Integer loginedNumber) {
        this.loginedNumber = loginedNumber;
    }

    public Integer getFailedNumber() {
        return FailedNumber;
    }

    public void setFailedNumber(Integer failedNumber) {
        FailedNumber = failedNumber;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

    public Integer getWaterMeterStatus1() {
        return waterMeterStatus1;
    }

    public void setWaterMeterStatus1(Integer waterMeterStatus1) {
        this.waterMeterStatus1 = waterMeterStatus1;
    }

    public Integer getWaterMeterStatus0() {
        return waterMeterStatus0;
    }

    public void setWaterMeterStatus0(Integer waterMeterStatus0) {
        this.waterMeterStatus0 = waterMeterStatus0;
    }

    public Integer getAlarm() {
        return alarm;
    }

    public void setAlarm(Integer alarm) {
        this.alarm = alarm;
    }

    public Integer getHardware() {
        return hardware;
    }

    public void setHardware(Integer hardware) {
        this.hardware = hardware;
    }

    public Integer getSoftware() {
        return software;
    }

    public void setSoftware(Integer software) {
        this.software = software;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public Integer getEndCode() {
        return endCode;
    }

    public void setEndCode(Integer endCode) {
        this.endCode = endCode;
    }
}
