package aep.nbiot.propertie;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author wufanghao
 * @version 1.0
 * @description: NB-IOT配置类
 * appKey，appSecret信息从AEP控制台-菜单：应用管理，查找自己应用向里面获取
 * @date 2021/11/17 8:46
 */
@ConfigurationProperties("aepiot")
    public class AepIotProperties {

    /**
     * 应用appKey
     */
    private String appKey;

    /**
     * 应用appSecret
     */
    private String appSecret;

    private AepMqProperties mq;

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public AepMqProperties getMq() {
        return mq;
    }

    public void setMq(AepMqProperties mq) {
        this.mq = mq;
    }
}

