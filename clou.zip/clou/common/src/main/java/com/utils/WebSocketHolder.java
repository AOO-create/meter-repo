//package com.utils;
//
//import com.websocket.entity.WebSocketClient;
//import io.netty.channel.socket.nio.NioSocketChannel;
//
//import java.util.Map;
//import java.util.concurrent.ConcurrentHashMap;
//
///**
// * @author wufanghao
// * @version 1.0
// * @description: netty
// * @date 2022/05/17 10:19
// */
//
////因为是咋不同的项目中，所以导致生成的class文件也不同，不是共享的文件类型
//public class WebSocketHolder {
//
//    private static final   ConcurrentHashMap<String, WebSocketClient> MAP = new ConcurrentHashMap<>();
//
//    public static void put(String id, WebSocketClient socketChannel) {
//        MAP.put(id, socketChannel);
//    }
//
//    public static WebSocketClient get(String id) {
//        return MAP.get(id);
//    }
//
//    public static Map<String, WebSocketClient> getMAP() {
//        return MAP;
//    }
//
//    public static void remove(String username) {
//        MAP.entrySet().stream().filter(entry -> entry.getKey() == username).forEach(entry -> MAP.remove(entry.getKey()));
//    }
//
//    public static boolean containsKey(String userName) {
//        return  WebSocketHolder.containsKey(userName);
//    }
//}
