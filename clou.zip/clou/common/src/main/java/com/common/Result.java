package com.common;

/**
 * 通用返回
 */
public class Result {

    private Integer code;
    private String msg;
    private Object data;

    public Result() {
    }

    public Result(ResultCodeEnum resultCodeEnum, Object data) {
        this.code = resultCodeEnum.getCode();
        this.msg = resultCodeEnum.getMessage();
        this.data = data;
    }

    public Result(ApiException apiException) {
        this.code = apiException.getCode();
        this.msg = apiException.getMessage();
        this.data = null;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }


    public static Result OK(Object data) {
        return new Result(ResultCodeEnum.SUCCESS, data);
    }

    public static Result OK() {
        return OK(null);
    }

    public static Result OK(ResultCodeEnum resultCodeEnum, Object data) {
        return new Result(resultCodeEnum, data);
    }

    public static Result ERROR(ResultCodeEnum resultCodeEnum) {
        return new Result(resultCodeEnum, null);
    }

    public static Result ERROR(ApiException apiException) {
        return new Result(apiException);
    }
}
