package com.service.systemSetup.Impl;

import com.entity.systemSetup.Menu;
import com.entity.systemSetup.RoleMenuRelation;
import com.mapper.systemSetup.MenuMangerMapper;
import com.mapper.systemSetup.RoleMenuRelationMapper;
import com.service.systemSetup.RoleMenuRelationService;
import com.vo.systemSetUpVo.RoleMenuRelationVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.ApiException;
import com.common.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoleMenuRelationServiceImpl extends ServiceImpl<RoleMenuRelationMapper, RoleMenuRelation> implements RoleMenuRelationService {

    @Autowired
    private RoleMenuRelationMapper mapper;

    @Autowired
    private MenuMangerMapper menuMangerMapper;

    @Override
    public Page<RoleMenuRelationVo> flagList(RoleMenuRelationVo vo) {
        QueryWrapper<RoleMenuRelation> qw = new QueryWrapper<>();

        if(null != vo.getMenuName() && !vo.getMenuName().equals("")){
            List<Menu> menu = menuMangerMapper.selectList(new QueryWrapper<Menu>().like("menu_name",vo.getMenuName()));
            List<String> menuId = new ArrayList<>();
            for(Menu m : menu){
                menuId.add(m.getMenuId());
            }
            qw.in("menu_id",menuId);
        }

        qw.eq("role_id",vo.getRoleId());

        Page<RoleMenuRelation>  page = new Page<>(vo.getPage(),vo.getLimit());
        page = mapper.selectPage(page,qw);

        Page<RoleMenuRelationVo> voPage = new Page<>(vo.getPage(),vo.getLimit());
        List<RoleMenuRelationVo> list = new ArrayList<>();
        for(RoleMenuRelation relation : page.getRecords()){
            RoleMenuRelationVo roleMenuRelationVo = new RoleMenuRelationVo();
            roleMenuRelationVo.setRoleId(relation.getRoleId());
            roleMenuRelationVo.setMenuId(relation.getMenuId());
            Menu menu = menuMangerMapper.selectOne(new QueryWrapper<Menu>().eq("menu_id",relation.getMenuId()));
            if(null !=menu.getParentMenuId() && !menu.getParentMenuId().equals("")){
                Menu parentMenu = menuMangerMapper.selectOne(new QueryWrapper<Menu>().eq("menu_id",menu.getParentMenuId()));
                roleMenuRelationVo.setMenuParentName(parentMenu.getMenuName());
            }
            roleMenuRelationVo.setMenuName(menu.getMenuName());
            roleMenuRelationVo.setAddFlag(relation.getAddFlag());
            roleMenuRelationVo.setUpdateFlag(relation.getUpdateFlag());
            roleMenuRelationVo.setDeleteFlag(relation.getDeleteFlag());
            list.add(roleMenuRelationVo);
        }
        voPage.setRecords(list);
        voPage.setPages(page.getPages());
        voPage.setCurrent(page.getCurrent());
        voPage.setSize(page.getSize());
        voPage.setTotal(page.getTotal());
        return voPage;
    }


    @Override
    public Boolean updateMenuPremitByType(RoleMenuRelationVo vo) {
        Long roleId = vo.getRoleId();
        Integer type = vo.getPremitType();
        //找出所有的所属本角色下的菜单关系
        List<RoleMenuRelation> list = mapper.selectList(new QueryWrapper<RoleMenuRelation>().eq("role_id",vo.getRoleId()));
        int count = 0;
        switch (vo.getPremitType()){
            case 1:{
                for(RoleMenuRelation relation:list){
                    relation.setAddFlag(true);
                    relation.setDeleteFlag(true);
                    relation.setUpdateFlag(true);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 2:{
                for(RoleMenuRelation relation:list){
                    relation.setAddFlag(false);
                    relation.setDeleteFlag(false);
                    relation.setUpdateFlag(false);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 3:{
                for(RoleMenuRelation relation:list){
                    relation.setAddFlag(true);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 4:{
                for(RoleMenuRelation relation:list){
                    relation.setAddFlag(false);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 5:{
                for(RoleMenuRelation relation:list){
                    relation.setUpdateFlag(true);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 6:{
                for(RoleMenuRelation relation:list){
                    relation.setUpdateFlag(false);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 7:{
                for(RoleMenuRelation relation:list){
                    relation.setDeleteFlag(true);
                    count = mapper.updateById(relation);
                }
                break;
            }
            case 8:{
                for(RoleMenuRelation relation:list){
                    relation.setDeleteFlag(false);
                    count = mapper.updateById(relation);
                }
                break;
            }
        }
        if(count <= 0){
            throw new ApiException(ResultCodeEnum.BATCH_UPDATE_ROLE_MENU_PREMIT_ERROR);
        }
        return true;
    }

    @Override
    public Boolean updateMenuPremit(List<RoleMenuRelationVo> voList) {
        for(RoleMenuRelationVo vo : voList){
            RoleMenuRelation relation = new RoleMenuRelation();
            relation.setUpdateFlag(vo.getUpdateFlag());
            relation.setDeleteFlag(vo.getDeleteFlag());
            relation.setAddFlag(vo.getAddFlag());
            relation.setMenuId(vo.getMenuId());
            relation.setRoleId(vo.getRoleId());
            int count = mapper.updateFlag(relation);
            if(count <= 0){
                throw new ApiException(ResultCodeEnum.UPDATE_ROLE_MENU_PREMIT_ERROR);
            }
        }
        return true;
    }
}
