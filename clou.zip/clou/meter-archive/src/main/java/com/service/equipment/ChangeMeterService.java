package com.service.equipment;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.equipment.MeterDTO;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface ChangeMeterService {
    Page<MeterDTO> getMeterByBuild(MeterDTO dto);

    boolean unBindMeter(MeterDTO dto);

    boolean toChangeMeter(MeterDTO dto);
}
