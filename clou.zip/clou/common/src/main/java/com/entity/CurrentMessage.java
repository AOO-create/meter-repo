package com.entity;

import lombok.Data;

import java.util.List;

@Data
public class CurrentMessage {
    String assetNo;
    List<String> meterAddress;
    String userName;
}
