package com.service.systemSetup.Impl;

import com.entity.systemSetup.Menu;
import com.entity.Role;
import com.entity.systemSetup.RoleMenuRelation;
import com.mapper.systemSetup.MenuMangerMapper;
import com.mapper.systemSetup.RoleMenuRelationMapper;
import com.mapper.systemSetup.RoleUserRelationMapper;
import com.service.systemSetup.MenuManagerService;
import com.util.ShiroConstUtils;
import com.vo.systemSetUpVo.MenuVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/21
 */
@Service
public class MenuManagerServiceImpl implements MenuManagerService {

    @Autowired
    private MenuMangerMapper mapper;

    @Autowired
    private RoleUserRelationMapper roleUserRelationMapper;

    @Autowired
    private RoleMenuRelationMapper roleMenuRelationMapper;

    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public List<Menu> getParentMenu() {
        QueryWrapper<Menu> qw = new QueryWrapper<>();
        qw.eq("has_third",1).eq("deleted",0).isNull("parent_menu_id").orderByAsc("menu_index");

        Role role = shiroConstUtils.getRole();
        if(role.getRoleCode().equals("admin")){
            return mapper.selectList(qw);
        }else{
            List<RoleMenuRelation> list = roleMenuRelationMapper.selectList(new QueryWrapper<RoleMenuRelation>().eq("role_id",role.getId()));
            List<Menu> menuList = new ArrayList<>();
            for (RoleMenuRelation relation : list) {
                Menu menu = mapper.selectOne(new QueryWrapper<Menu>()
                        .eq("menu_id",relation.getMenuId())
                        .eq("has_third",1)
                        .isNull("parent_menu_id")
                        .orderByAsc("menu_index"));
                if(menu != null){
                    menuList.add(menu);
                }
            }
            return menuList;
        }
    }

    @Override
    public MenuVo getSubMenuByIndex(String index) {
        QueryWrapper<Menu> qw = new QueryWrapper<>();
        qw.eq("has_third",1).isNull("parent_menu_id").eq("menu_index",index).eq("deleted",0);
        Menu menu = mapper.selectOne(qw);
        MenuVo vo = menuToMenuVo(menu);

        List<MenuVo> childList = reGetChildList(vo.getMenuId());
        vo.setChildList(childList);
        return vo;
    }

    @Override
    public MenuVo getAllMenu(com.entity.systemSetup.Role role) {
        MenuVo rootVo = new MenuVo();
        //获取所有上方菜单
        List<Menu> list = getParentMenu();
        //每一个上方菜单去对照一个MenuVo
        List<MenuVo> menuVos = new ArrayList<>();   

//        Role role = shiroConstUtils.getRole();
        if(role.getRoleCode().equals("admin")){
            for(Menu menu : list) {
                MenuVo vo = getSubMenuByIndex(String.valueOf(menu.getMenuIndex()));
                menuVos.add(vo);
            }
        }else{
            //非管理员角色通过查询确定
            menuVos = new ArrayList<>();
            List<String> list1 = getCurrentUserMenu();
            for(String menuId : list1){
                Menu menu = mapper.selectOne(new QueryWrapper<Menu>().eq("menu_id",menuId).eq("deleted",0));
                MenuVo menuVo = new MenuVo();
                BeanUtils.copyProperties(menu,menuVo);
                menuVos.add(menuVo);
            }
            //拼接成树warningDayData状的菜单
            List<MenuVo> finalMenuVos = new ArrayList<>(menuVos);
            for (MenuVo menu : menuVos) {
                for(MenuVo m : menuVos){
                    if(m.getParentMenuId()!=null && m.getParentMenuId().equals(menu.getMenuId())){
                        menu.getChildList().add(m);
                    }
                }
            }
            //删除构造树中多余的元素
            for(MenuVo menuVo : finalMenuVos){
                if(menuVo.getParentMenuId()!=null){
                    menuVos.remove(menuVo);
                }
            }
        }
        //为子节点赋值上标志
        for(MenuVo menuVo : menuVos){
            List<MenuVo> childs = menuVo.getChildList();
            menuVo.setChildList(reGetFlag(childs));
        }
        rootVo.setChildList(menuVos);
        return rootVo;
    }

    //递归遍历为叶子节点赋值标志
    public List<MenuVo> reGetFlag(List<MenuVo> childs){
        for(MenuVo vo : childs){
            if(vo.getHasThird() == 1){
                reGetFlag(vo.getChildList());
            }else{
                com.entity.Role role = shiroConstUtils.getRole();
                RoleMenuRelation relation = roleMenuRelationMapper.selectOne(new QueryWrapper<RoleMenuRelation>()
                        .eq("menu_id",vo.getMenuId())
                        .eq("role_id",role.getId()));
                if(null != relation){
                    vo.setAddFlag(relation.getAddFlag());
                    vo.setDeleteFlag(relation.getDeleteFlag());
                    vo.setUpdateFlag(relation.getUpdateFlag());
                }else{
                    vo.setAddFlag(false);
                    vo.setUpdateFlag(false);
                    vo.setDeleteFlag(false);
                }

            }
        }

        return childs;
    }

    //递归遍历
    public List<MenuVo> reGetChildList(String parentId){
        List<Menu> menus = mapper.selectList(new QueryWrapper<Menu>().eq("parent_menu_id",parentId).eq("deleted",0)
                .orderByAsc("menu_index"));
        List<MenuVo> menuVos = new ArrayList<>();
        for(Menu menu : menus){
            MenuVo vo = menuToMenuVo(menu);
            menuVos.add(vo);
        }
        //查询所有该menuId下面的子节点
        for (MenuVo menu1 : menuVos) {
            parentId = menu1.getMenuId();
            //自己调用自己
            List<MenuVo> childMenus = reGetChildList(parentId);
            //跳出递归
            if (childMenus.isEmpty()) {
                continue;
            }
            menu1.setChildList(childMenus);
        }
        return menuVos;
    }

    @Override
    public List<String> getCurrentUserMenu() {
        com.entity.Role role = shiroConstUtils.getRole();
        List<String> list = new ArrayList<>();
        List<RoleMenuRelation>  roleMenuRelationList = new ArrayList<>();
        if(role.getRoleCode().equals("admin")){
            roleMenuRelationList = roleMenuRelationMapper.selectList(null);

        }else{
            roleMenuRelationList  = roleMenuRelationMapper.selectList(new QueryWrapper<RoleMenuRelation>()
                    .eq("role_id",role.getId()));
        }
        roleMenuRelationList.forEach(roleMenuRelation -> {
            list.add(""+roleMenuRelation.getMenuId());
        });
        return list;
    }

    public MenuVo menuToMenuVo(Menu menu){
        MenuVo vo = new MenuVo();
        vo.setHasThird(menu.getHasThird());
        vo.setIcon(menu.getIcon());
        vo.setId(menu.getId());
        vo.setMenuId(menu.getMenuId());
        vo.setMenuName(menu.getMenuName());
        vo.setMenuIndex(menu.getMenuIndex());
        vo.setUrl(menu.getUrl());
        vo.setParentMenuId(menu.getParentMenuId());
        vo.setChildList(null);
        return vo;
    }
}
