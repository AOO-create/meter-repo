package com.dto;

import lombok.Data;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/10/19 
 */
@Data
public class UserAndTenantDTO {

    private List<String> userIds;
    private List<String> tenantIds;
    private String  id;
    private String type;
    private String name;
    private String areaName;

}
