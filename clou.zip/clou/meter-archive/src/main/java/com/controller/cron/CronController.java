package com.controller.cron;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.config.DynamicDataSource;
import com.entity.cron.Cron;
import com.service.cron.CronService;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/7
 */
@RestController
@RequestMapping("/archive/Cron")
public class CronController {
    @Autowired
    private CronService service;

    @Secured({"ROLE_ADMIN","ROLE_FOURTH"})
    @RequestMapping("/findCron")
    @ResponseBody
    public Page<Cron> findCron(){
        return service.findCron();
    }

    @Secured({"ROLE_ADMIN","ROLE_FOURTH"})
    @RequestMapping("/updateCron")
    @ResponseBody
    public void updateCron(@RequestBody Cron cron){
         service.updateCron(cron);
    }

    @Secured({"ROLE_ADMIN","ROLE_FOURTH"})
    @RequestMapping("/statusOpen")
    public void statusOpen(@RequestBody Cron cron){
        service.statusOpen(cron);
    }
}
