package com.AepResolve;

import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.mq.MqDataReport;
import aep.nbiot.service.AepApiService;
import cn.hutool.json.JSONUtil;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.config.ProductProperties;
import com.constant.ProtoConstant;
import com.constant.Seroalid;
import com.entity.equipment.WNB;
import com.mapper.equipment.NBmeterMapper;
import com.utils.AepUtils;
import com.utils.BCDCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;


@Service
public class ProtoResolveService {

    @Autowired
    AepCompanyAoteman aepCompanyAoteman;
    @Autowired
    AepCompanyChuanren aepCompanyChuanren;
    @Autowired
    AepCompanyNew aepCompanyNew;
    @Autowired
    private AepApiService aepApiService;
    @Autowired
    private ProductProperties productProperties;
    @Autowired
    private NBmeterMapper nBmeterMapper;
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    /***
     * 组装离线应答帧
     */
    public static String makeOfflineFrame(FrameWaterDayReadData data, String isRespon) {

        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(isRespon)
                .append(ProtoConstant.FarmeCode.OffineLength)
                .append(data.getDataLogo())
                .append(data.getSerialId()).append(data.getTotalNmbel())
                .append(data.getCurrentFrmId());
        String checkCode = makeChecksum(stringBuilder.toString());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    /***
     * 开关阀
     * @param data
     * @param status
     * @return
     */
    public static String makeValveFrame(FrameWaterDayReadData data, String status) {
        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(ProtoConstant.FarmeCode.ValveContol)
                .append(ProtoConstant.FarmeCode.ValveLength)
                .append(ProtoConstant.FarmeLogo.ValveLogo)
                .append(Seroalid.createSerialId())
                .append(status);
        String checkCode = makeChecksum(stringBuilder.toString());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    /***
     * 组装数据同步帧
     */
    public static String makeSyncFrame(FrameWaterDayReadData data, String currentIntegreFlow) {
        String length;
        String logo;
        if (ProtoConstant.FarmeLogo.OffineLogoA.equals(data.getDataLogo())) {
            length = ProtoConstant.FarmeCode.SyncLengthA;
            logo = ProtoConstant.FarmeLogo.SyncLogoA;
        } else {
            length = ProtoConstant.FarmeCode.SyncLengthB;
            logo = ProtoConstant.FarmeLogo.SyncLogoB;
        }

        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(ProtoConstant.FarmeCode.SyncContol)
                .append(length).append(logo)
                .append(Seroalid.createSerialId())
                .append(currentIntegreFlow)
                .append(ProtoConstant.FarmeType.Unit);
        String checkCode = makeChecksum(stringBuilder.toString());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    public static StringBuilder makeFrame(FrameWaterDayReadData data) {
        StringBuilder stringBuilder = new StringBuilder(30);
        stringBuilder.append(ProtoConstant.FarmeCode.StartCode)
                .append(data.getType())
                .append(data.getAddress());
        return stringBuilder;
    }

    public static String join(List<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String s : list) {
            stringBuilder.append(s);
        }
        return stringBuilder.toString();
    }

    public static String makeChecksum(String data) {
        if (data == null || data.equals("")) {
            return "";
        }
        if (data.length() % 2 != 0) {
            System.out.println("字符串不是一个完整的16进制的字符串");
            return "";
        }
        int total = 0;
        int len = data.length();
        int num = 0;
        while (num < len) {
            String s = data.substring(num, num + 2);
            total += Integer.parseInt(s, 16);
            num = num + 2;
        }
        /**
         * 用256求余最大是255，即16进制的FF
         */
        int mod = total % 256;
        String hex = Integer.toHexString(mod);
        len = hex.length();
        // 如果不够校验位的长度，补0,这里用的是两位校验
        if (len < 2) {
            hex = "0" + hex;
        }
        return hex;
    }

    public String handleFrame(String payload) {
        MqDataReport mqDataReport = JSONUtil.toBean(payload, MqDataReport.class);
        MqDataReport.PayloadDTO payloadDTO = mqDataReport.getPayload();
        String deviceId = mqDataReport.getDeviceId();

        if (payloadDTO == null) {
            return null;
        }
        String frame = payloadDTO.getAPPdata();
        //根据deviceId查找对应的协议号
        WNB wnb = nBmeterMapper.selectOne(new QueryWrapper<WNB>().eq("device_id", deviceId));
        if (null == wnb) {
            return "";
        }
        String protoCode = wnb.getProtoCode();
//        String start = frame.substring(0, 2);
        String result = null;
        switch (protoCode) {
            case AepCompanyFrameEnum.AOTEMAN: {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("device", deviceId);
                jsonObject.put("frame", frame);
                String value = jsonObject.toJSONString();
                //从 2.5 版开始，您可以使用 aKafkaSendCallback而不是 ListenableFutureCallback，从而更容易提取 failed ProducerRecord，避免需要强制转换Throwable
                kafkaTemplate.send("AOTEMN_TOPIC", value);
                break;
            }
            case AepCompanyFrameEnum.CHUANGREN: {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("device", deviceId);
                jsonObject.put("frame", frame);
                String value = jsonObject.toJSONString();
                //从 2.5 版开始，您可以使用 aKafkaSendCallback而不是 ListenableFutureCallback，从而更容易提取 failed ProducerRecord，避免需要强制转换Throwable
                kafkaTemplate.send("CHUANGREN_TOPIC", value);
                break;
            }
//                result =aepCompanyChuanren.handleFrame(deviceId,frame);
//                break;
            case AepCompanyFrameEnum.NEWPROTO: {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("device", deviceId);
                jsonObject.put("frame", frame);
                String value = jsonObject.toJSONString();

                String dataLogo = BCDCode.StringBcdToInt(AepUtils.join(AepUtils.stringToArray(frame).subList(13, 15))).toUpperCase();
                if (!dataLogo.equals("E001")) {
                    kafkaTemplate.send("NEW_TOPIC_ONE", value);
                    break;
                } else {
                    kafkaTemplate.send("NEW_TOPIC_TWO", value);
                    break;
                }
            }
            default:
                System.out.println("未找到该设备所属的传输协议");
                return null;
        }
        return result;
    }

    /***
     * 解析主动上报帧
     * @param frameWaterData
     * @param frameArray
     * @param mqDataReport
     *
     * @return
     */
    public FrameWaterDayReadData resolveReadFrame(FrameWaterDayReadData frameWaterData, List<String> frameArray, MqDataReport mqDataReport) {
        int startNode;
        frameWaterData.setTotalNmbel(join(frameArray.subList(15, 17)));
        frameWaterData.setCurrentFrmId(join(frameArray.subList(17, 19)));
        frameWaterData.setTicurrentFrmNuber(Integer.parseInt(frameArray.get(19), 16));
        String logo = ProtoConstant.FarmeLogo.OffineLogoA;
        if (logo.equals(frameWaterData.getDataLogo())) {
            startNode = 26 + frameWaterData.getTicurrentFrmNuber() * 4;
            frameWaterData.setCurrentIntegreFlow(join(frameArray.subList(startNode, startNode + 4)));
            frameWaterData.setImei(join(frameArray.subList(startNode + 22, startNode + 30)));
            frameWaterData.setImsi(join(frameArray.subList(startNode + 30, startNode + 38)));
        } else {
            startNode = 26 + frameWaterData.getTicurrentFrmNuber() * 5;
            frameWaterData.setCurrentIntegreFlow(join(frameArray.subList(startNode, startNode + 5)));
            frameWaterData.setImei(join(frameArray.subList(startNode + 24, startNode + 32)));
            frameWaterData.setImsi(join(frameArray.subList(startNode + 32, startNode + 40)));
        }
        String onlineFrame = makeOfflineFrame(frameWaterData, ProtoConstant.ResponStatus.Online);
        String valveFrame = makeValveFrame(frameWaterData, ProtoConstant.ValveStatus.Close);
        String syncFrameB = makeSyncFrame(frameWaterData, "0017078000");
        String syncFrame = makeSyncFrame(frameWaterData, "95000000");//实例32018000 95 00 00 00
        //发送确认帧 ,下达指令
//        createCommand(productProperties.getMasterKey(), mqDataReport.getDeviceId(), mqDataReport.getProductId(), productProperties.getOperator(), onlineFrame);
//        createCommand(productProperties.getMasterKey(), mqDataReport.getDeviceId(), mqDataReport.getProductId(), productProperties.getOperator(), valveFrame);
        createCommand(productProperties.getMasterKey(), mqDataReport.getDeviceId(), mqDataReport.getProductId(), productProperties.getOperator(), syncFrame);
        //存储到数据库
//      System.out.println("存储到数据库success");
//      System.out.println("下发的离线帧数据为："+onlineFrame);
        System.out.println("下发的阀门帧数据为：" + syncFrame);
        ;
//        打开阀门收到的报文：681029000011215022840500a017 01 80 010716
//        关闭阀门收到的报文：681029000011215022840500a017 01 81 010816
        return frameWaterData;
    }

    public FrameWaterDayReadData resolveValveFrame(FrameWaterDayReadData frameWaterData, List<String> frameArray, MqDataReport mqDataReport) {
        frameWaterData.setWaterMeterStatus0(Integer.parseInt(frameArray.get(15)));
        //需要校验帧数据是否正确
        String makeValveFrame = makeValveFrame(frameWaterData, ProtoConstant.ValveStatus.Open);
        //发送确认帧 ,下达指令
        //createCommand(masterKey, deviceId, productId, operator, makeValveFrame);
        //存储到数据库
        System.out.println("打开阀门开关success并存储记录");
        System.out.println(makeValveFrame);
        return frameWaterData;
    }

    /****
     * 下达指令
     * @param masterKey
     * @param deviceId
     * @param productId
     * @param operator
     * @param payload
     */
    public void createCommand(String masterKey, String deviceId, String productId, String operator, String payload) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("MasterKey", masterKey);
        HashMap<String, Object> body = new HashMap<>();
        body.put("deviceId", deviceId);
        body.put("operator", operator);
        body.put("productId", productId);
        body.put("ttl", 864000);
        //body.put("deviceGroupId",)
        //body.put("level",)
        HashMap<String, Object> content = new HashMap<>();
        content.put("dataType", "2");
        content.put("payload", payload);
        body.put("content", content);
        String relust = aepApiService.invockApi(AepDeviceCommandEnum.CreateCommand, params, body);
        System.out.println("执行命令返回结果为：" + relust);
    }

}
