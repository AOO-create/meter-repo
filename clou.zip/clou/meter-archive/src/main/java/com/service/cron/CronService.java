package com.service.cron;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.cron.Cron;

public interface CronService {

	void startCron(Cron cron);

	void stopCron(Cron cron);

	void changeCron(Cron cron);

	void updateCron(Cron cron);

	Page<Cron> findCron();

	void statusOpen(Cron cron);
}
