package com.service.organization.impl;

import com.config.DynamicDataSource;
import com.dto.organization.BuildDTO;
import com.dto.organization.GradeDTO;
import com.entity.systemSetup.Role;
import com.entity.systemSetup.User;
import com.mapper.equipment.TermManagerMapper;
import com.mapper.organization.BDGradeMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.organization.OrgMapper;
import com.entity.TreeData;
import com.entity.equipment.Term;
import com.entity.organization.BDGrade;
import com.entity.organization.Grade;
import com.entity.organization.Org;
import com.service.organization.GradeService;
import com.util.ShiroConstUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import sun.reflect.generics.tree.Tree;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Stack;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@Service
public class GradeServiceImpl implements GradeService {

    @Autowired
    private GradeMapper mapper;

    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;
    @Autowired
    private ShiroConstUtils shiroConstUtils;

    @Autowired
    private TermManagerMapper termManagerMapper;

    @Override
    public Page<GradeDTO> findGrade(GradeDTO dto) {
        //获得orgId
        com.entity.Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());
        com.entity.Role role = shiroConstUtils.getRole();
        if(!role.getRoleCode().equals("admin")){
            dto.setId(shiroConstUtils.getAreaId());
        }
        Page<GradeDTO> page = new Page<>();

        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }

        List<GradeDTO> list = mapper.getAllGradeIdByOrgId(dto);

        int number = mapper.getGradeNumber(dto);
        if(null != list && list.size() != 0 ){
            page.setRecords(list);
            page.setTotal(number);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Override
    public boolean saveOrUpdateGrade(BuildDTO dto) {
        int result = -1;
        com.entity.Org org = shiroConstUtils.getOrg();
        if(null == dto.getId() || "".equals(dto.getId())){
            //新增
            if(null == dto.getParentId() || "".equals(dto.getParentId())){
                //新增组织区域
                Grade grade = new Grade();
                grade.setOrgId(org.getOrgId());
                grade.setAreaNo(dto.getNo());
                grade.setAreaName(dto.getName());
                grade.setEmail(dto.getEmail());
                grade.setRemark(dto.getRemark());
                grade.setUpdTime(new Date());
                result = mapper.insert(grade);
            }else{
                //插入楼栋单元
                BDGrade bdGrade = new BDGrade();
                bdGrade.setBdNo(dto.getNo());
                bdGrade.setRemark(dto.getRemark());
                BDGrade bdGrade1 = bdGradeMapper.selectById(dto.getParentId());
                String areaId = "";
                if(bdGrade1 == null){
                    //是顶级楼栋单元时无父亲节点
                    Grade grade = mapper.selectById(dto.getParentId());
                    areaId = grade.getId() + "";
                    bdGrade.setParentId(null);
                }else{
                    bdGrade.setParentId(Long.valueOf(dto.getParentId()));
                    areaId = bdGrade1.getAreaId();
                }
                bdGrade.setAreaId(areaId);
                bdGrade.setOrgId(org.getOrgId());
                bdGrade.setUpdTime(new Date());
                bdGrade.setBdName(dto.getName());
                result = bdGradeMapper.insert(bdGrade);
            }
        }else{
            //修改
            if(dto.getId().equals(dto.getAreaId())){
                //修改的是组织区域
                Grade grade = mapper.selectById(dto.getId());
                grade.setAreaNo(dto.getNo());
                grade.setAreaName(dto.getName());
                grade.setEmail(dto.getEmail());
                grade.setRemark(dto.getRemark());
                grade.setUpdTime(new Date());
                result = mapper.updateById(grade);
            }else{
                //修改楼栋单元
                BDGrade bdGrade = bdGradeMapper.selectById(dto.getId());
                bdGrade.setBdNo(dto.getNo());
                bdGrade.setBdName(dto.getName());
                bdGrade.setRemark(dto.getRemark());
                result = bdGradeMapper.updateById(bdGrade);
            }
        }
        return result > 0;
    }

    @Override
    public boolean deleteGrade(BuildDTO dto) {
        int count = -1;
        if(dto.getAreaId().equals(dto.getId())){
            //删除组织区域
            count = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>().eq("area_id",dto.getId()));
            if(count > 0){
                //存在楼栋单元时无法进行删除
                return false;
            }
            return mapper.deleteById(dto.getId()) > 0;
        }else{
            //删除楼栋单元
            count = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>().eq("parent_id",dto.getId()));
            if(count > 0){
                //楼栋单元存在房门号时无法进行删除
                return false;
            }
            return bdGradeMapper.deleteById(dto.getId()) > 0;
        }
    }

    @Override
    public boolean deleteAll(List<BuildDTO> list) {
        int count = -1;
        int count1 = 0;
        int count2 = 0;
        List<String> ids = new ArrayList<>();
        List<String> ids2 = new ArrayList<>();
        for(BuildDTO dto : list){
            if(dto.getAreaId().equals(dto.getId())){
                //是组织区域有楼栋单元
                count = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>().eq("area_id",dto.getId()));
                ids2.add(dto.getId());
            }else{
                //是楼栋单元有孩子节点
                count = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>().eq("parent_id",dto.getId()));
                ids.add(dto.getId());
            }
            if(count > 0){
                //存在孩子节点时无法进行删除
                return false;
            }
        }
        if(ids2.size() !=0 ){
            count1 = mapper.deleteBatchIds(ids2);
        }
        if(ids.size() !=0){
            count2 = bdGradeMapper.deleteBatchIds(ids);
        }
        return (count1+count2) > 0;
    }

    @Override
    public List<GradeDTO> getGradeToSel(String id) {
        com.entity.Org org = shiroConstUtils.getOrg();
        GradeDTO dto = new GradeDTO();
        dto.setOrgId(org.getOrgId());
        com.entity.Role role =  shiroConstUtils.getRole();
        if(!role.getRoleCode().equals("admin")){
            id = shiroConstUtils.getAreaId();
        }
        List<GradeDTO> list = mapper.getGradeToSel(dto,id);

        return list;
    }

    /**
       * 查看有无该功能单位
       * @author liuwei
       * @date  2022/6/23
       * @param
       * @return
     */
    @Override
    public boolean isHaveGrade(String account) {
        return mapper.isHaveGrade(account) > 0;
    }

    //获取全部组织区域节点的树
    @Override
    public List<TreeData> getTreeData() {
        String roleCode = shiroConstUtils.getRole().getRoleCode();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String areaId = shiroConstUtils.getAreaId();
        String tgBuildDoorplate = shiroConstUtils.getTgBuildDoorplate();
        List<TreeData> treeList = new ArrayList<>();
        //查出所有该下面的组织区域且为顶级区域
        List<Grade> topGrade = new ArrayList<>();
        if(roleCode.equals("admin")){
            topGrade = mapper.selectList(new QueryWrapper<Grade>().eq("org_id",orgId).isNull("parent_id"));
        }else if(null  == tgBuildDoorplate  || "".equals(tgBuildDoorplate)){
            //该用户建立在组织区域上，查看该组织区域下一级门栋单元或房门号用户
            topGrade = mapper.selectList(new QueryWrapper<Grade>().
                    eq("org_id",orgId)
                    .isNull("parent_id")
                    .eq("id",areaId));
        }else {
            //建立在门栋 或者房间号
            List<BDGrade> bdList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                    .eq("area_id", areaId)
                    .eq("id",tgBuildDoorplate));
            List<TreeData> treeData1 = new ArrayList<>();
            TreeData treeDataArea = new TreeData();
            treeDataArea.setId(Long.parseLong(areaId));
            Grade grade = mapper.selectById(areaId);
            treeDataArea.setName(grade.getAreaName());
            List<TreeData> treeData = new ArrayList<>();
            for (BDGrade dto : bdList) {
                TreeData tempTree = new TreeData();
                tempTree.setId(dto.getId());
                tempTree.setName(dto.getBdName());
                //开始递归赋值
                tempTree.setChildren(getBDChildren(dto.getId()));
                treeData.add(tempTree);
            }
            treeDataArea.setChildren(treeData);
            treeData1.add(treeDataArea);
            return treeData1;
        }
        if(topGrade.size() <= 0){;
            return null;
        }
        //循环放入children中
        for(Grade grade : topGrade){
            TreeData tempTree = new TreeData();
            tempTree.setId(grade.getId());
            tempTree.setName(grade.getAreaName());
            tempTree.setChildren(getChildren(""+grade.getId()));
            treeList.add(tempTree);
        }
        return treeList;
    }

    private List<TreeData> getChildren(String areaId){
        List<TreeData> treeData = new ArrayList<>();
        //获取顶级楼栋组织
        List<BDGrade> bdList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                .eq("area_id", areaId).isNull("parent_id"));
        for (BDGrade dto : bdList) {
            TreeData tempTree = new TreeData();
            tempTree.setId(dto.getId());
            tempTree.setName(dto.getBdName());
            //开始递归赋值
            tempTree.setChildren(getBDChildren(dto.getId()));
            treeData.add(tempTree);
        }
        return treeData;
    }

    //递归查找单元楼栋门牌的信息
    private List<TreeData> getBDChildren(Long id) {
        List<TreeData> treeData = new ArrayList<>();

        List<BDGrade> bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                .eq("parent_id", id));

        for(BDGrade bdGrade : bdGradeList){
            TreeData tempTree = new TreeData();
            tempTree.setId(bdGrade.getId());
            tempTree.setName(bdGrade.getBdName());
            List<BDGrade> list = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                    .eq("parent_id", bdGrade.getId()));
            if(list.size() == 0){
                //该节点无子节点为叶子节点
                tempTree.setChildren(null);
            }else{
                tempTree.setChildren(getBDChildren(bdGrade.getId()));
            }
            treeData.add(tempTree);
        }
        return treeData;
    }

    @Override
    public List<TreeData> getAllArea() {
        List<TreeData> treeList = new ArrayList<>();
        com.entity.Org org = shiroConstUtils.getOrg();
        com.entity.Role role = shiroConstUtils.getRole();
        List<Grade> topGrade = new ArrayList<>();
        String currentAreaId = shiroConstUtils.getAreaId();
        if(role.getRoleCode().equals("admin")){
            topGrade = mapper.selectList(new QueryWrapper<Grade>().
                    eq("org_id",org.getOrgId()).
                    isNull("parent_id"));
        }else{
            topGrade = mapper.selectList(new QueryWrapper<Grade>().
                    eq("org_id",org.getOrgId()).eq("id",currentAreaId).
                    isNull("parent_id"));
        }

        if(topGrade.size() <= 0){;
            return null;
        }
        //循环放入children中
        for(Grade grade : topGrade){
            TreeData tempTree = new TreeData();
            tempTree.setId(grade.getId());
            tempTree.setName(grade.getAreaName());
            int count = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>().eq("area_id",grade.getId()));
            if(count == 0){
               tempTree.setChildren(null);
            }else{
                TreeData treeData = new TreeData();
                treeData.setId(1l);
                List<TreeData> list = new ArrayList<>();
                list.add(treeData);
                tempTree.setChildren(list);
            }
            treeList.add(tempTree);
        }
        return treeList;
    }

    @Override
    public List<TreeData> findBdGradeByAreaId(String areaId) {
        List<TreeData> treeData = new ArrayList<>();
        com.entity.Org org = shiroConstUtils.getOrg();
        String currentAreaId = shiroConstUtils.getAreaId();
        String tgBuildDoorplate = shiroConstUtils.getTgBuildDoorplate();
        List<BDGrade> bdGradeList = new ArrayList<>();

        if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
            //点击组织区域
            bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                    .eq("org_id",org.getOrgId())
                    .eq("area_id",areaId)
                    .isNull("parent_id"));
        } else if(tgBuildDoorplate == null || tgBuildDoorplate.equals("")){
            //点击组织区域
            bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                    .eq("org_id",org.getOrgId())
                    .eq("area_id",areaId)
                    .isNull("parent_id"));
        }else {
            //点击门栋单元或房间号
            bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                    .eq("org_id",org.getOrgId())
                    .isNull("parent_id")
                    .eq("id",tgBuildDoorplate)
                    );
        }


        if(bdGradeList.size() == 0){
            return null;
        }

        for(BDGrade bdGrade : bdGradeList){
            TreeData treeData1 = new TreeData();
            treeData1.setId(bdGrade.getId());
            treeData1.setName(bdGrade.getBdName());
            int cout = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>()
                    .eq("org_id",org.getOrgId())
                    .eq("parent_id",bdGrade.getId()));
            if(cout == 0){
                treeData1.setChildren(null);
            }else{
                TreeData t = new TreeData();
                t.setId(1l);
                List<TreeData> list = new ArrayList<>();
                list.add(t);
                treeData1.setChildren(list);
            }
            treeData.add(treeData1);
        }
        return treeData;
    }


    //getDoorById
    @Override
    public List<TreeData> findBdGradeByBdId(String bdId) {
        List<TreeData> treeData = new ArrayList<>();
        com.entity.Org org = shiroConstUtils.getOrg();

        List<BDGrade> bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                .eq("org_id",org.getOrgId())
                .eq("parent_id",bdId));
        if(bdGradeList.size() == 0){
            return null;
        }

        for(BDGrade bdGrade : bdGradeList){
            TreeData treeData1 = new TreeData();
            treeData1.setId(bdGrade.getId());
            treeData1.setName(bdGrade.getBdName());
            int cout = bdGradeMapper.selectCount(new QueryWrapper<BDGrade>()
                    .eq("org_id",org.getOrgId())
                    .eq("parent_id",bdGrade.getId()));
            if(cout == 0){
                treeData1.setChildren(null);
            }else{
                TreeData t = new TreeData();
                t.setId(1l);
                List<TreeData> list = new ArrayList<>();
                list.add(t);
                treeData1.setChildren(list);
            }
            treeData.add(treeData1);
        }
        return treeData;
    }

    @Override
    public List<TreeData> getTreeByTermId(String termId) {
        Term term = termManagerMapper.selectOne(new QueryWrapper<Term>().eq("address",termId));
        if(null == term){
            return null;
        }
        String areaId = term.getAreaId();
        return findBdGradeByAreaId(areaId);
    }

    @Override
    public List<String> reGetChildGradeId(String areaId, String orgId, List<String> tempList) {
        tempList.add(areaId);

        List<String> gradeList = new ArrayList<>();
        gradeList = mapper.findIdByOrgId(areaId,orgId);

        for(String gradeId:gradeList){
            reGetChildGradeId(gradeId,orgId,tempList);
        }

        return tempList;
    }


    public List<String> reGetChildBDGradeId(String tgBuildDoorplate,String orgId,List<String> tempList){
        tempList.add(tgBuildDoorplate);

        List<String> gradeList = new ArrayList<>();
        List<BDGrade> bdGradeList = bdGradeMapper.selectList(new QueryWrapper<BDGrade>()
                .eq("org_id",orgId)
                .eq("parent_id",tgBuildDoorplate));
        bdGradeList.forEach(bdGrade -> {
            String id = bdGrade.getId() + "";
            gradeList.add(id);
        });

        for(String gradeId:gradeList){
            reGetChildGradeId(gradeId,orgId,tempList);
        }

        return tempList;
    }

    @Override
    public String getAreaIdByName(String areaName) {
        Grade grade = mapper.selectOne(new QueryWrapper<Grade>().eq("area_name",areaName));
        return grade.getId()+"";
    }

    @Override
    public Page<BuildDTO> getSonBuild(BuildDTO dto) {
        com.entity.Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());
        //全部无的话，查org下面的area
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        if(("".equals(dto.getTgBuildDoorplate() )&&"".equals(dto.getAreaId()))||
            null == dto.getTgBuildDoorplate() && null == dto.getAreaId()){
            //初次进入页面
            if( !"admin".equals( shiroConstUtils.getRole().getRoleCode()) ){
                dto.setAreaId(shiroConstUtils.getAreaId());
                //不是管理员查自己,树也只能看到自己的节点
                BuildDTO grade = mapper.getGrade(dto);
                Page<BuildDTO> page = new Page<>(dto.getPage(),dto.getLimit());
                List<BuildDTO> list = new ArrayList<BuildDTO>();
                list.add(grade);
                page.setRecords(list);
                page.setTotal(1);
                return page;
            }else{
                //为管理员身份查询该org下所有的area
                List<BuildDTO> list = mapper.getGradeList(dto);
                Page<BuildDTO> page = new Page<>(dto.getPage(),dto.getLimit());
                page.setRecords(list);
                int number = mapper.getGradeListCount(dto);
                page.setTotal(number);
                return page;
            }
        }else{
            //点击了节点
            List<BuildDTO> list = new ArrayList<>();
            Page<BuildDTO> page = new Page<>(dto.getPage(),dto.getLimit());
            if( !dto.getAreaId().equals("")){
                if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
                    //是管理员查全部不添加条件

                }else {
                    //如果是areaId，查询本身和子节点，不是管理员查自身单位唯一一个
                    dto.setTgBuildDoorplate(shiroConstUtils.getTgBuildDoorplate());
                }
                list = mapper.getAreaList(dto);
                page.setRecords(list);
                int number = mapper.getAreaListCount(dto);
                page.setTotal(number);
            }else {
                //查询tg表，本身节点和子节点
                list = mapper.getTgList(dto);
                page.setRecords(list);
                int number = mapper.getTgListCount(dto);
                page.setTotal(number);
            }
            return page;
        }
    }

    @Override
    public String getGradeNameById(String id) {
        return mapper.selectById(id).getAreaName();
    }


    public List<String> getBDGradeId(List<String> ids) {

        QueryWrapper<BDGrade> qw = new QueryWrapper<>();
        qw.in("area_id",ids);
        List<BDGrade> bdGradeList  = bdGradeMapper.selectList(qw);
        List<String> bdIds = new ArrayList<>();
        bdGradeList.forEach(val ->{
            bdIds.add(String.valueOf(val.getId()));
        });
        return bdIds;
    }
}
