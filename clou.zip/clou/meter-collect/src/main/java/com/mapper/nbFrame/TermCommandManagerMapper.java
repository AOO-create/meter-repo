package com.mapper.nbFrame;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.nbFrame.TermSendCommand;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
public interface TermCommandManagerMapper extends BaseMapper<TermSendCommand> {
}
