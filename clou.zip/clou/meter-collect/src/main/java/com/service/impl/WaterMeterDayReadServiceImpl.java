package com.service.impl;


import com.AepResolve.AepCompanyFrameEnum;
import com.AepResolve.MeterFrameDataChuangren;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.entity.equipment.WaterMeterDayRead;
import com.mapper.equipment.WaterMeterDayReadMapper;
import com.service.WaterMeterDayReadService;
import com.utils.BCDCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


@Slf4j
@Service
public class WaterMeterDayReadServiceImpl implements WaterMeterDayReadService {

    @Autowired
    private WaterMeterDayReadMapper waterMeterDayReadMapper;


    public void add2()  {
        log.info("项目启动");
    }
    @Override
    public boolean add(MeterFrameDataChuangren chuangren)  {
        if(chuangren==null){return false;}
        WaterMeterDayRead waterMeterDayRead = new WaterMeterDayRead();
        if(AepCompanyFrameEnum.NOW.equals(chuangren.getDataType())){
            SimpleDateFormat format = new SimpleDateFormat("yyMMddHHmmss");
            try {
                waterMeterDayRead.setCollTime(format.parse(chuangren.getTimeStampColl()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            waterMeterDayRead.setDeviceId(chuangren.getImei());
            BigDecimal flower = new BigDecimal(BCDCode.bigToInt(chuangren.getCurrentFlower()) * 0.001);
            double math = flower.setScale(3,BigDecimal.ROUND_HALF_UP).doubleValue();
            waterMeterDayRead.setRealSumFlow(BigDecimal.valueOf(math));
            waterMeterDayRead.setDataDate(new Date());
            String string = new SimpleDateFormat("yyyy-MM-dd").format(waterMeterDayRead.getDataDate()).toString();
            WaterMeterDayRead meterDayRead = waterMeterDayReadMapper
                    .selectOne(new LambdaQueryWrapper<WaterMeterDayRead>()
                            .eq(WaterMeterDayRead::getDataDate,string)
                            .eq(WaterMeterDayRead::getDeviceId,waterMeterDayRead.getDeviceId()));
            if(meterDayRead==null){
                Integer integer = waterMeterDayReadMapper.insert(waterMeterDayRead);
                if (integer == 1) {
                return true;
                }
            }else {
                return false;
            }
        }
        return false;
    }

    @Override
    public boolean add(WaterMeterDayRead waterMeterDayRead) {
        String string = new SimpleDateFormat("yyyy-MM-dd").format(waterMeterDayRead.getDataDate()).toString();
        WaterMeterDayRead meterDayRead = waterMeterDayReadMapper
                .selectOne(new LambdaQueryWrapper<WaterMeterDayRead>()
                        .eq(WaterMeterDayRead::getDataDate,string)
                        .eq(WaterMeterDayRead::getDeviceId,waterMeterDayRead.getDeviceId()));
        if(meterDayRead==null){
            int re= waterMeterDayReadMapper.insert(waterMeterDayRead);
            if (re==1){return true;}else {return false;}
        }else {
            return false;
        }
    }

    @Override
    public boolean addNewProtol(WaterMeterDayRead waterMeterDayRead) {
//        String string = new SimpleDateFormat("yyyy-MM-dd").format(waterMeterDayRead.getDataDate()).toString();
//        WaterMeterDayRead meterDayRead = waterMeterDayReadMapper
//                .selectOne(new LambdaQueryWrapper<WaterMeterDayRead>()
//                        .eq(WaterMeterDayRead::getDataDate,string)
//                        .eq(WaterMeterDayRead::getDeviceId,waterMeterDayRead.getDeviceId()));
//        if(meterDayRead == null){
        int count = waterMeterDayReadMapper.insert(waterMeterDayRead);
//        }
//        Integer i =  waterMeterDayReadMapper.update(waterMeterDayRead,new LambdaQueryWrapper<WaterMeterDayRead>()
//                .eq(WaterMeterDayRead::getDataDate,string)
//                .eq(WaterMeterDayRead::getDeviceId,waterMeterDayRead.getDeviceId()));
//        if (i==1){return true;}else {return false;}
        return count > 0;
    }

}
