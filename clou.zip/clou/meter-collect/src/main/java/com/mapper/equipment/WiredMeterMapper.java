package com.mapper.equipment;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.equipment.WiredMeter;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface WiredMeterMapper extends BaseMapper<WiredMeter> {
    
}
