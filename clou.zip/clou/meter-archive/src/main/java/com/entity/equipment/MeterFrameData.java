package com.entity.equipment;

public abstract class MeterFrameData {


    private String imei;//这个属性不需要
    private String imsi;
    private String collTime;//上报时间
    private Double currentIntegreFlow;//当前采样纪录值
    private String checkCode;//校验码

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getCollTime() {
        return collTime;
    }

    public void setCollTime(String collTime) {
        this.collTime = collTime;
    }

    public Double getCurrentIntegreFlow() {
        return currentIntegreFlow;
    }

    public void setCurrentIntegreFlow(Double currentIntegreFlow) {
        this.currentIntegreFlow = currentIntegreFlow;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }
}
