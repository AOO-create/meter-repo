package com.AepResolve;



import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.service.AepApiService;
import com.config.ProductProperties;
import com.constant.Seroalid;
import com.service.WaterMeterDayReadService;
import com.utils.AESKit;
import com.utils.AepUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

@Component
public class AepCompanyChuanren  {

    @Autowired
    private AepApiService aepApiService;

    @Autowired
    private ProductProperties productProperties;

    @Autowired
    private WaterMeterDayReadService waterMeterDayReadService;


    public String handleFrame(String deviceId,String frame) {

        MeterFrameDataChuangren chuangren = resolveWtm(frame);
        waterMeterDayReadService.add(chuangren);
        String result = createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), responseHeart(chuangren));
        return result;
    }

    public MeterFrameDataChuangren resolveWtm(String payload) {
        MeterFrameDataChuangren chuangren = new MeterFrameDataChuangren();
        List<String> frameArray = AepUtils.stringToArray(payload);
        chuangren.setFrameStart(AepUtils.join(frameArray.subList(0, 4)));
        chuangren.setIsEncry(AepUtils.join(frameArray.subList(5, 6)));
        chuangren.setFrameLength(AepUtils.join(frameArray.subList(6, 8)));
        chuangren.setFrameNumber(AepUtils.join(frameArray.subList(8, 10)));
        chuangren.setImei(AepUtils.join(frameArray.subList(10, 18)).replaceAll("^(0+)", ""));
        chuangren.setTimeStampReport(AepUtils.join(frameArray.subList(18, 24)));
        List<String> commandPackage ;
        //判断命令包是否加密
        if(AepCompanyFrameEnum.ENCRY.equals(chuangren.getIsEncry())){
            String  command= AESKit.decrypt(AepUtils.join(frameArray.subList(24, frameArray.size())));
            if(command==null){return null;}
            commandPackage = AepUtils.stringToArray(command);
        }else {
            commandPackage = frameArray.subList(24, frameArray.size()-1);
        }
        //功能码类型
        chuangren.setCommandType(AepUtils.join(commandPackage.subList(0, 1)));
        chuangren.setCommandCode(AepUtils.join(commandPackage.subList(1, 2)));
        chuangren.setCheckCode((frameArray.get(frameArray.size() - 1)));
        switch (chuangren.getCommandCode()) {
            case AepCompanyFrameEnum.REPORT:
                return setReport(chuangren, commandPackage);
            default:
                return chuangren;
        }
    }

    /***
     * 平台回复给水表有4种情况：
     * : 0 -> 周期采样记录，1 -> 日冻结记录，2 -> 月冻结记录，3 -> 密集采样记录， 4 -> 当前采样记录。
     * @param frameDataChuangren
     * @param commandPage
     */
    private  MeterFrameDataChuangren setReport(MeterFrameDataChuangren frameDataChuangren, List<String> commandPage) {
        frameDataChuangren.setPower(AepUtils.join(commandPage.subList(5, 7)));
        frameDataChuangren.setDataType((commandPage.get(4)));
        if (AepCompanyFrameEnum.NOW.equals(frameDataChuangren.getDataType())) {
            frameDataChuangren.setTimeStampColl(AepUtils.join(commandPage.subList(7, 13)));
            frameDataChuangren.setCurrentFlower(AepUtils.join(commandPage.subList(13, 17)));
        }
       return frameDataChuangren;
    }


    /***
     * 回复设备应答帧
     */
    public  String responseHeart(MeterFrameDataChuangren chuangren) {

        String command = "";
        switch (chuangren.getCommandCode()) {
            case AepCompanyFrameEnum.HEART:
                command =AepCompanyFrameEnum.REPORT_COMMAND;
                break;
            case AepCompanyFrameEnum.REPORT:
                command =AepCompanyFrameEnum.HEARTBEAT_COMMAND;
                break;
            case AepCompanyFrameEnum.REGISTER:
                command =AepCompanyFrameEnum.REGISTER_COMMAND;
                break;
        }
        if(AepCompanyFrameEnum.ENCRY.equals(chuangren.getIsEncry())){
            command = AESKit.encrypt(command);
        }
        while (chuangren.getImei().length()<16){
          chuangren.setImei(AepCompanyFrameEnum.ZERO+chuangren.getImei());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(AepCompanyFrameEnum.HEAD)
                .append(AepCompanyFrameEnum.CONTENT)
                .append(Seroalid.createSerialId())
                .append(chuangren.getImei())
                .append(AepUtils.getTimeMills())
                .append(command);
        String heartChecksum = AepUtils.makeChecksum(stringBuilder.toString());
        stringBuilder.append(heartChecksum);
        return  stringBuilder.toString();
    }

    /****
     * 下达指令
     * @param masterKey
     * @param deviceId
     * @param productId
     * @param operator
     * @param payload
     */
    public String createCommand(String masterKey, String deviceId, String productId, String operator, String payload) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("MasterKey", masterKey);
        HashMap<String, Object> body = new HashMap<>();
        body.put("deviceId", deviceId);
        body.put("operator", operator);
        body.put("productId", productId);
        body.put("ttl", 864000);
        //body.put("deviceGroupId",)
        //body.put("level",)
        HashMap<String, Object> content = new HashMap<>();
        content.put("dataType", "2");
        content.put("payload", payload);
        body.put("content", content);
        String result = aepApiService.invockApi(AepDeviceCommandEnum.CreateCommand, params, body);
        System.out.println("执行命令返回结果为：" + result);
        return  result;
    }

}
