package com.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.area.GradeDTO;
import com.dto.equipment.CollectRateDTO;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.StatisticsDataDTO;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
public interface DayDataManagerService {
    Map<String, Page<MeterDayDataDTO>> getAllDayData(MeterDayDataDTO dto) throws ParseException;

    void ExcelDayDataIn(List<MeterDayDataDTO> list,String meterType);

    Page<MeterDayDataDTO> getDataByDay(MeterDayDataDTO dto);

    Page<MeterDayDataDTO> getDataByMonth(MeterDayDataDTO dto);

    Page<StatisticsDataDTO> statisticsSum(GradeDTO dto) throws ParseException;

    Page<MeterDayDataDTO> getDayData(MeterDayDataDTO dto) throws ParseException;

    List<CollectRateDTO> getCollRateByTimeArea(CollectRateDTO dto) throws ParseException;

    List<CollectRateDTO> getCollectMeter(CollectRateDTO dto);
}
