package com.fegin.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "archive-provider", url = "${service-url.archive-provider}")
public interface ArchiveClient {

    @RequestMapping("/archive/ToCollect/websocket")
    public void sendMessage(@RequestParam(value = "userName") String userName ,@RequestParam(value = "message") String message);

}
