package com.vo.exportExcelVo;

import com.common.PageConstant;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/6/20
 */
@Data
public class ExportExcelParamsVo extends PageConstant {

    private String orgId;
    private String areaId;
    private String meterType;
    private String meterAddress;
    private String dataDate;
    private String termAddress;
    private String type;
}
