package com.service.equipment.impl;


import com.aop.annotation.ChangeTermAopAnnotation;
import com.common.ApiException;
import com.common.Const;
import com.common.Result;
import com.common.ResultCodeEnum;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.log.ChangeTermLog;
import com.entity.equipment.Term;
import com.entity.Org;
import com.entity.organization.Grade;
import com.mapper.equipment.TermManagerMapper;
import com.mapper.organization.GradeMapper;
import com.mapper.systemLog.ChangeTermLogMapper;
import com.service.equipment.TermManagerService;
import com.service.organization.impl.GradeServiceImpl;
import com.util.ShiroConstUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
@Service
@RequiredArgsConstructor
@Slf4j //开启Log4j日志
public class TermManagerServiceImpl implements TermManagerService {

    @Autowired
    private TermManagerMapper termManagerMapper;

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private ChangeTermLogMapper changeTermLogMapper;

    @Autowired
    private NBmeterServiceImpl service;

    @Autowired
    private GradeServiceImpl gradeService;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public List<Term> getTermData(String areaId) {
        Org org = shiroConstUtils.getOrg();

        List<String> idList = new ArrayList<>();
        //获得所有选择的组织区域下的areaId
        List<String> tempList = new ArrayList<>();
        //递归循环遍历areaId下所有子孙节点,如果为空查询该org下所有gradeId
        idList = gradeService.reGetChildGradeId(areaId,org.getOrgId(),tempList);

        List<Term> termList = termManagerMapper.selectList(new QueryWrapper<Term>().eq("org_id",org.getOrgId())
                .in("area_id",idList)
                .eq("status","0")
                .orderByDesc("upd_time"));
//                termManagerMapper.getTermData(org.getOrgId(),idList);
        return termList;
    }

    @Transactional
    @Override
    public String termSave(TermDTO dto) {

        Term term = new Term();
        BeanUtils.copyProperties(dto, term);
        term.setStatus("0");
        Org org = shiroConstUtils.getOrg();
        term.setOrgId(org.getOrgId());
        Term term2 = termManagerMapper.selectOne(new LambdaQueryWrapper<Term>()
                .eq(Term::getTerminalId,term.getTerminalId()).eq(Term::getStatus,"0"));
        int  result = 0;
        if(term2==null){
             result =termManagerMapper.insert(term);
        }else {
            result = termManagerMapper.updateById(term);
        }
        if(result==1){
            return "新增集中器档案成功！";
        }else {
            return "新增集中器档案失败，请查找原因" ;
        }
    }

    @Override
    public Page<TermDTO> getTerm(TermDTO dto) {
        Org org = shiroConstUtils.getOrg();
//        org =new Org();
//        org.setOrgId("1215180414822383616");
        dto.setOrgId(org.getOrgId());
        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
            //管理员查看全部
        }else {
            //非管理员查看本组织区域下的
            dto.setAreaId(shiroConstUtils.getAreaId());
        }

        List<TermDTO> nblist = termManagerMapper.getTerm(dto);
        int count = termManagerMapper.getCount(dto);
        Page<TermDTO> page = new Page<>();
        if(nblist.size() !=0 && nblist !=null){
            page.setRecords(nblist);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Override
    public Page<WiredMeterDTO> getMeter(WiredMeterDTO dto) {
        Org org = shiroConstUtils.getOrg();
        dto.setOrgId(org.getOrgId());

        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        List<WiredMeterDTO> wiredMeterDTOList = termManagerMapper.getMeterOnTerm(dto);
        int count = termManagerMapper.getReadCount(dto);
        Page<WiredMeterDTO> page = new Page<>();
        if(wiredMeterDTOList.size() !=0 && wiredMeterDTOList !=null){
            page.setRecords(wiredMeterDTOList);
            page.setTotal(count);
        }else{
            page.setRecords(null);
            page.setTotal(0);
        }
        return page;
    }

    @Override
    public boolean validAddress(TermDTO dto) {
        List<TermDTO> result = termManagerMapper.validAddress(dto.getAddress());
        if(null == result || result.size() == 0){
            return true;
        }
        TermDTO t = result.get(0);
        return t.getTerminalId().equals(dto.getTerminalId());
    }

    @Override
    public List<TermDTO> getTermByAreaId(String areaId) {
        Org org = shiroConstUtils.getOrg();
        List<String> idList = new ArrayList<>();

        if(areaId == null || areaId.equals("")){
            if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
                //为空时查询该org下所有组织区域
                idList = null;
            }else {
                idList.add(shiroConstUtils.getAreaId());
            }

        }else {
            //获得所有选择的组织区域下的areaId
            List<String> tempList = new ArrayList<>();
            //获得该组织区域下所有的子组织区域（包含自己）
            idList = gradeService.reGetChildGradeId(areaId, org.getOrgId(), tempList);
        }

        return termManagerMapper.getTermByAreaId(org.getOrgId(),idList);
    }

    @Transactional
    @Override
    public Result ExcelTermIn(List<TermDTO> list) {
        Result result = new Result();
        List<TermDTO> dtoList = list;
        String orgId = shiroConstUtils.getOrg().getOrgId();
        String errorAddress = "";
        for(TermDTO dto : dtoList){
            String address = dto.getAddress();
            if( termManagerMapper.validAddress(address) == null ){
                list.remove(dto);
                errorAddress = errorAddress + address + ";";
            }
        }

        for(TermDTO dto : list){
            dto.setInstallDate(new Date());
            dto.setOrgId(orgId);
            Grade grade = gradeMapper.selectOne(new QueryWrapper<Grade>().eq("area_name",dto.getAreaName()));
            if(grade == null ){
                //无该组织区域,新增该组织区域
                dto.setInstallAddr(dto.getAreaName());
                Grade insertGrade = new Grade();
                insertGrade.setUpdTime(new Date());
                insertGrade.setAreaName(dto.getAreaName());
                insertGrade.setOrgId(orgId);
                insertGrade.setAreaNo(dto.getAreaName());
                gradeMapper.insert(insertGrade);
                String areaId = gradeMapper.selectOne(new QueryWrapper<Grade>().eq("area_name",dto.getAreaName())).getId() +"";
                dto.setAreaId(areaId);
            }else{
                dto.setAreaId(grade.getId()+"");
            }

            if(dto.getModelType().equals("CL6610")){
                dto.setModelType("0");
            }else if(dto.getModelType().equals("CL818")){
                dto.setModelType("1");
            }
        }

        if(!errorAddress.equals("")){
            log.info("导入集中器档案，其中失败的有：" + errorAddress);
            result.setCode(500);
            result.setMsg("导入集中器档案，其中失败的有：" + errorAddress);
        }

        termManagerMapper.batchInsert(list);

        return result;
    }

    @Transactional
    @Override
    public Result deleteTerm(String terminalId) {
        //判断其下是否存在表具，
        int count = termManagerMapper.getMeterByTermId(terminalId);
        if(count > 0){
            return Result.ERROR(new ApiException(ResultCodeEnum.DELETE_TERM_ERROR));
        }
        termManagerMapper.deleteTerm(terminalId);
        return Result.OK();
    }

    @Override
    public Result batchDeleteTerm(List<String> idList) {

        int count = termManagerMapper.getMeterByTermIdList(idList);
        if(count > 0){
            return Result.ERROR(new ApiException(ResultCodeEnum.DELETE_TERM_ERROR));
        }

        termManagerMapper.batchDeleteTerm(idList);
        return Result.OK();
    }

    @Override
    public String getAreaIdByTermId(String id) {
        String areaId = "" + termManagerMapper.selectOne(new QueryWrapper<Term>().eq("address",id)).getAreaId();
        return areaId;
    }

    @Override
    public Result changeTermStatus(String terminalId) {
        Term term = termManagerMapper.selectById(terminalId);
        term.setStatus("0");
        List<Term> list = termManagerMapper.selectList(new QueryWrapper<Term>().eq("address",term.getAddress()).eq("status","0"));
        if(null != list && list.size() > 0){
            return Result.ERROR(new ApiException(500,"已存在地址为"+term.getAddress()+"的集中器正在使用，启用失败！"));
        }
        int count = termManagerMapper.updateById(term);
        if(count <= 0){
            return Result.ERROR(new ApiException(500,"启用过程出现问题，启用失败！"));
        }
        return Result.OK("启用成功");
    }

    @Transactional
    @Override
    @ChangeTermAopAnnotation
    public Result changeTerm(TermDTO dto) {
        List<TermDTO> list =termManagerMapper.validAddress(dto.getAddress());
        if(null != list && list.size() > 0){
            return Result.ERROR(new ApiException(500,"已存在地址为"+dto.getAddress()+"的集中器正在使用，更换失败！"));
        }

        Term term = termManagerMapper.selectById(dto.getOldTerminalId());
        dto.setOrgId(term.getOrgId());
        term.setStatus("1");
        //旧集中器更改状态为未使用
        int count = termManagerMapper.updateById(term);
        if(count <=0 ){
            return Result.ERROR(new ApiException(500,"更改旧集中器"+dto.getOldAddress()+"使用状态失败,更换失败"));
        }
        //插入新集中器
        Term newTerm = new Term();
        BeanUtils.copyProperties(dto,newTerm);
        newTerm.setStatus("0");
        newTerm.setOrgId(term.getOrgId());
        count = termManagerMapper.insert(newTerm);
        if(count <= 0){
            return Result.ERROR(new ApiException(500,"新增集中器"+dto.getAddress()+"失败,更换失败"));
        }
        //修改有线表具中的集中器编号
        count = termManagerMapper.updateWiredTermAddress(dto);
        if(count <= 0){
            return Result.ERROR(new ApiException(500,"修改有线表具关联集中器地址失败,更换失败"));
        }

        return Result.OK("集中器"+dto.getOldAddress()+"成功更换为"+dto.getAddress()+",更换成功");
    }

    @Override
    public Result getChangeTermLog(ChangeTermLog log) {
        Page<ChangeTermLog> page = new Page<>();

        Org org = shiroConstUtils.getOrg();
        log.setOrgId(org.getOrgId());
        log.setCurrentPos((log.getPage() - 1) * log.getLimit());
        if(shiroConstUtils.getTgBuildDoorplate() == null ||shiroConstUtils.getTgBuildDoorplate().equals("")){
            log.setAreaId(shiroConstUtils.getAreaId());
        }else{
            log.setOpUser(Const.userId);
        }
        List<ChangeTermLog> list = termManagerMapper.getChangeTermLog(log);
        int count = termManagerMapper.getChangeTermLogCount(log);

        if (list.size() != 0 && list != null) {
            page.setRecords(list);
            page.setTotal(count);
        } else {
            page.setRecords(null);
            page.setTotal(0);
        }
        return Result.OK(page);
    }

}
