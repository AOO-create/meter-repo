package com.service.equipment;

import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.WiredMeterDTO;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import com.vo.exportExcelVo.ExportExcelParamsVo;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
public interface WiredMeterService {
    Page<WiredMeterDTO> getMeter(WiredMeterDTO dto);

    Page<MeterDayDataDTO> getWiredDayData(MeterDayDataDTO dto, String date);

    Result  ExcelWiredIn(List<WiredMeterDTO> list) throws Exception;

    List<MeterDayDataDTO> getExportData(ExportExcelParamsVo exportExcelParams);

    Result deleteMeter(String id);

    Result update(WiredMeterDTO dto);

    Result save(WiredMeterDTO dto);

    Boolean validMeterAddress(String meterAddress);

    Result batchDeleteWired(List<String> ids);
}
