package com.controller;

import com.fegin.client.CollectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientController {
    @Qualifier("collectHysitx")
    @Autowired
    private CollectService collectService;

    @GetMapping("/listen")
    public Object startListenOrgin() {
        return collectService.startListenOrgin();
    }
}
