package com.dto.organization;

import com.entity.systemSetup.User;
import lombok.Data;

import java.io.Serializable;

/**
 * @author liuwei
 * @description
 * @date 2022/5/11
 */
@Data
public class UserDTO extends User implements Serializable {
    private String orgAccount;

    private String token;
}
