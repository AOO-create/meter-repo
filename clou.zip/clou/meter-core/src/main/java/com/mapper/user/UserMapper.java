package com.mapper.user;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pojo.User;

/**
 * @author liuwei
 * @description
 * @date 2022/5/11
 */
public interface UserMapper extends BaseMapper<User>{
}
