package aep.nbiot.dto.param.devicemanage.create.batch;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 批量增加NB设备
 * @date 2021/12/13 8:43
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BatchCreateNBDeviceParam {

    /**
     * 产品ID，必填
     */
    private Integer productId;

    /**
     * 操作者，必填
     */
    private String operator;

    /**
     * 最多一次可以添加100个设备。
     */
    private List<NBDevice> devices;

}
