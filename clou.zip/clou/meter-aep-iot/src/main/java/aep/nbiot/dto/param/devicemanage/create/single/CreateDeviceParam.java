package aep.nbiot.dto.param.devicemanage.create.single;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 增加设备(单个)
 * @date 2021/12/13 8:13
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateDeviceParam {

    /**
     * 设备名称，必填
     */
    private String deviceName;

    /**
     * 设备编号，MQTT,T_Link,TCP,HTTP,JT/T808，南向云协议必填
     */
    private String deviceSn;

    /**
     * imei号，LWM2M,NB网关协议必填
     */
    private String imei;

    /**
     * 操作者，必填
     */
    private String operator;

    /**
     * LWM2M协议必填参数,其他协议不填
     */
    private Object other;

    /**
     * 产品ID，必填
     */
    private Integer productId;
}
