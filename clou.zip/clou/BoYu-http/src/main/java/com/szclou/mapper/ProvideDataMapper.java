package com.szclou.mapper;

import com.szclou.entity.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface ProvideDataMapper {
    List<Term> getAllTerm();

    Term getTerm(@Param("address") String address);

    List<Wmtr> getWmtr(@Param("termId") String terminalId,@Param("currentPos") int currentPos,@Param("size") int size);

    MeterPara getParaByWmtrId(@Param("id") String id);

    MeterPara getParaByMeterId(@Param("id") String id);

    Caliber getCaliber(@Param("id") String caliberId);

    BDGrade getBDGrade(@Param("id") String tgBuildDoorplate);

    List<Meter> getMeter(@Param("termId") String terminalId,@Param("currentPos") int currentPos,@Param("size") int size);

}
