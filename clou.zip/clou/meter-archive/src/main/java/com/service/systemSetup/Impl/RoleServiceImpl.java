package com.service.systemSetup.Impl;

import com.common.Result;
import com.entity.Org;
import com.entity.systemSetup.*;
import com.mapper.systemSetup.MenuMangerMapper;
import com.mapper.systemSetup.RoleMapper;
import com.mapper.systemSetup.RoleMenuRelationMapper;
import com.mapper.systemSetup.RoleUserRelationMapper;
import com.service.systemSetup.MenuManagerService;
import com.service.systemSetup.RoleService;
import com.util.ShiroConstUtils;
import com.vo.systemSetUpVo.MenuVo;
import com.vo.systemSetUpVo.RoleVo;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.ApiException;
import com.common.ResultCodeEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private MenuMangerMapper menuMangerMapper;

    @Autowired
    private MenuManagerService managerService;

    @Autowired
    private RoleUserRelationMapper roleUserRelationMapper;

    @Autowired
    private RoleMenuRelationMapper roleMenuRelationMapper;
    @Autowired
    private ShiroConstUtils shiroConstUtils;
    @Override
    public IPage<Role> selectRole(RoleVo roleVo) {
        Map<String, Object> where = roleVo.getWhere();
        long pageSize = new Long(roleVo.getLimit());
        long pageNum = new Long(roleVo.getPage());
        where.remove("pageNum");
        where.remove("pageSize");
        QueryWrapper<Role> conditions = new QueryWrapper<Role>();
        if(null != roleVo.getDescr() && !roleVo.getDescr().equals("")){
            conditions.like("describe",roleVo.getDescr());
        }
        if(null != roleVo.getRoleCode() && !roleVo.getRoleCode().equals("")){
            conditions.like("role_code",roleVo.getRoleCode());
        }
        com.entity.Role role = shiroConstUtils.getRole();
        if(!role.getRoleCode().equals("admin")){
            conditions.ne("role_code","admin");
        }

        return roleMapper.selectMyPage(new Page<>(pageNum, pageSize), conditions);
    }

    @Override
    public List<Menu> selectMenuByRole(Role role) {
        List<RoleMenuRelation> roleMenuRelations = roleMenuRelationMapper.selectList(new LambdaQueryWrapper<RoleMenuRelation>().eq(RoleMenuRelation::getRoleId, role.getId()));
        List<Menu> list = new ArrayList<Menu>();
        for (RoleMenuRelation roleMenu : roleMenuRelations) {
            Menu menu = menuMangerMapper.selectOne(new LambdaQueryWrapper<Menu>().eq(Menu::getId, roleMenu.getMenuId()));
            list.add(menu);
        }
        return list;
    }

    @Override
    public List<String> findCurrentNode(String roleId) {
        List<RoleMenuRelation>  relationList = roleMenuRelationMapper.selectList(new QueryWrapper<RoleMenuRelation>().eq("role_id",roleId));
        List<String> list = new ArrayList<>();
        for(RoleMenuRelation relation :relationList){
            list.add(relation.getMenuId() + "");
        }
        return list;
    }

    public Boolean addRole2(RoleVo roleVo) throws Exception {
        Role role = new Role();
        BeanUtils.copyProperties(roleVo, role);
        Integer roleResult = roleMapper.insert(role);
        if (roleResult == 0) {
            throw new ApiException(ResultCodeEnum.ADD_ROLE_ERROR);
        }return true;
    }
    @Override
    @Transactional
    public Boolean addRole(RoleVo roleVo) throws Exception {
        Role role = new Role();
        List<MenuVo> list = roleVo.getList();
        Org org = shiroConstUtils.getOrg();
        role.setRoleCode(roleVo.getRoleCode());
        role.setDescr(roleVo.getDescr());
        role.setName(roleVo.getName());
        role.setOrgId(org.getOrgId());
        role.setCreateName(shiroConstUtils.getUser().getName());
        role.setUpdTime(new Date());
        int  roleResult = roleMapper.insert(role);
        if (roleResult == 0) {
            throw new ApiException(ResultCodeEnum.ADD_ROLE_ERROR);
        }
        List<MenuVo> menuVos = new ArrayList<>();
        //插入关系表中
        for (MenuVo menuVo : list) {
            RoleMenuRelation relation = new RoleMenuRelation();
//            if (menuVo.getHasThird() != 1) {
//                relation.setAddFlag(menuVo.getAddFlag());
//                relation.setDeleteFlag(menuVo.getDeleteFlag());
//                relation.setUpdateFlag(menuVo.getUpdateFlag());
//            }
            relation.setMenuId(Long.parseLong(menuVo.getMenuId()));
            relation.setRoleId(role.getId());
            int  roleResult2 = roleMenuRelationMapper.insert(relation);
            if (roleResult2 == 0) {
                throw new ApiException(ResultCodeEnum.ADD_ROLE_ERROR);
            }
        }
        return true;
    }

    @Transactional
    @Override
    public Boolean updateRole(RoleVo roleVo) {
        Role role = new Role();
        BeanUtils.copyProperties(roleVo, role);
        List<MenuVo> list = roleVo.getList();
        role.setCreateName(shiroConstUtils.getUser().getName());
        role.setUpdTime(new Date());
        int roleResult = roleMapper.update(role, new LambdaQueryWrapper<Role>().eq(Role::getId, roleVo.getId()));
        if (roleResult == 0) {
            throw new ApiException(ResultCodeEnum.ADD_ROLE_ERROR);
        }
        QueryWrapper<RoleMenuRelation> qw = new QueryWrapper<RoleMenuRelation>().eq("role_id",role.getId());
        //查到所有保存起来为增删改标志位赋值
        List<RoleMenuRelation> relationList = roleMenuRelationMapper.selectList(qw);
        int deleteRoleResult = roleMenuRelationMapper.delete(qw);
        if(deleteRoleResult <= 0){
            System.out.println("该角色无任何菜单选择起始的时候");
        }

        for (MenuVo menuVo : list) {
            RoleMenuRelation relation = new RoleMenuRelation();
            relation.setMenuId(Long.parseLong(menuVo.getMenuId()));
            relation.setRoleId(role.getId());
            for(RoleMenuRelation r : relationList){
                if(r.getRoleId().equals(relation.getRoleId()) && r.getMenuId().equals(relation.getMenuId())){
                    relation.setAddFlag(r.getAddFlag());
                    relation.setUpdateFlag(r.getUpdateFlag());
                    relation.setDeleteFlag(r.getDeleteFlag());
                }
            }


            //无法获取到关系表中的ID值只能先删除在进行新增来表示更新
            int updateRoleResult = roleMenuRelationMapper.insert(relation);
            if (updateRoleResult == 0) {
                throw new ApiException(ResultCodeEnum.ADD_ROLE_ERROR);
            }
        }
        return true;
    }

    @Transactional
    @Override
    public Result delRole(Role role) {
        List<RoleUserRelation> roleUserRelationList = roleUserRelationMapper.selectList(new QueryWrapper<RoleUserRelation>().eq("role_id",role.getId()));
        if(null != roleUserRelationList && roleUserRelationList.size() > 0){
            return Result.ERROR(new ApiException(500,"本角色下存在用户，删除角色失败"));
        }
        Integer roleResult = roleMapper.delete(new LambdaQueryWrapper<Role>().eq(Role::getId, role.getId()));
        Integer roleResult2 = roleMenuRelationMapper.delete(new LambdaQueryWrapper<RoleMenuRelation>().eq(RoleMenuRelation::getRoleId,role.getId()));
//        Integer roleResult3 = roleUserRelationMapper.delete(new LambdaQueryWrapper<RoleUserRelation>().eq(RoleUserRelation::getRoleId,role.getId()));
        if (roleResult == 1) {
            return Result.OK("成功删除");
        } else {
            return Result.ERROR(new ApiException(500,"删除角色失败！"));
        }
    }


}
