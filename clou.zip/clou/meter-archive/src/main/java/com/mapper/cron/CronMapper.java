package com.mapper.cron;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.cron.Cron;

public interface CronMapper extends BaseMapper<Cron> {
}