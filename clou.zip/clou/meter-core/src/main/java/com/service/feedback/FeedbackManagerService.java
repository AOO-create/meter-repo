package com.service.feedback;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import com.dto.FeedbackDTO;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2023/10/28
 */
public interface FeedbackManagerService {

    Result getFeedbackByUser(String id);

    Result getFeedback(FeedbackDTO feedback);

    Result replay(FeedbackDTO dto);

    Result getFeedbackAnalysisData();
}
