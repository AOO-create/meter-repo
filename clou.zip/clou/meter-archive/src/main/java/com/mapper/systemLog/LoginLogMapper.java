package com.mapper.systemLog;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.log.LoginLog;

/**
 * @author liuwei
 * @description
 * @date 2023/10/26 
 */
public interface LoginLogMapper extends BaseMapper<LoginLog> {
}
