package com.util;


import com.dto.equipment.MeterDayDataDTO;
import com.entity.equipment.MeterFrameDataFourthGeneration;
import com.utils.AepUtils;
import com.utils.BCDCode;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/8/17
 */
public class FrameUtil {


    /**
       * 读表计报文发送组帧
       * @author liuwei
       * @date  2022/8/17
       * @param  表地址meterAddress
       * @return  String帧字符串
     */
    public static String makeSendFrameReport(String meterAddress){
        meterAddress = BCDCode.StringBcdToInt(meterAddress);
        StringBuilder frame = new StringBuilder();
        frame.append("68").append("10").append(meterAddress).append("01") .append("03").append("901F").append("00");
        String checkCode = AepUtils.makeChecksum(frame.toString());
        frame.append(checkCode);
        frame.append("16");
        return String.valueOf(frame);
    }

    /**
       * 日数据报文解析
       * @author liuwei
       * @date  2022/8/17
       * @param String frame
       * @return MeterDayDataDto
     */
    //6810623408220000008116901F00000900002C000000002C000000000000000200E116
    public static MeterDayDataDTO getDayData(String frame) throws ParseException {
        System.out.println("收到的4G抄表数据报文如下所示：" + frame);
        List<String> frameArray = AepUtils.stringToArray(frame);
        MeterFrameDataFourthGeneration meterData = new MeterFrameDataFourthGeneration();
        meterData.setStartcode(Integer.parseInt(frameArray.get(0)));
        meterData.setType(Integer.parseInt(frameArray.get(1)));
        meterData.setAddress(AepUtils.join(frameArray.subList(2, 9)));
        meterData.setContolCode((frameArray.get(9)));
        meterData.setByteLength(AepUtils.bigEndian(Collections.singletonList(frameArray.get(10))));
        meterData.setDataLogo(AepUtils.join(frameArray.subList(11, 13)));
        meterData.setSerialId((frameArray.get(13)));
        String realSumFlow = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(14,18)));
        realSumFlow = realSumFlow.substring(0,6)+"."+realSumFlow.substring(6);
        Double realData = Double.valueOf(realSumFlow);
        meterData.setCurrentIntegreFlow(realData);
        meterData.setUnitSum(frameArray.get(18));

        String dayData = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(19,23)));
        dayData = dayData.substring(0,6)+"."+dayData.substring(6);
        Double realDayData = Double.valueOf(dayData);
        meterData.setCurrentIntegreFlow(realDayData);
        meterData.setUnitDay(frameArray.get(23));
        String collTime = AepUtils.join(frameArray.subList(24,31));
        collTime = BCDCode.StringBcdToInt(collTime);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        //开关阀装填
        String status = AepUtils.join(frameArray.subList(31,33));
        meterData.setCheckCode((frameArray.get(frameArray.size() - 2)));
        //收到报文需要校验帧数据是否正确
        if ("".equals(meterData.getCheckCode()) ||meterData.getCheckCode()==null|| !meterData.getCheckCode().equalsIgnoreCase(AepUtils.makeChecksum(frame.substring(0,frame.length()-4)))) {
            System.out.println("收到的数据帧校验错误，丢弃，打印错误日志");
            return null;
        }

        if(status.equals("0000")){
            status = "1";
        }else if(status.equals("0200")){
            status = "2";
        }
        String meterAddress = BCDCode.StringBcdToInt(meterData.getAddress());
        //处理报文返回要插入的数据 （也提前解析了相应报文。）
        MeterDayDataDTO meterDayDataDTO = new MeterDayDataDTO();
        meterDayDataDTO.setRealSumFlow(realSumFlow);
        meterDayDataDTO.setMeterAddress(meterAddress);
        meterDayDataDTO.setCollTime(dateFormat.parse(collTime));
        meterDayDataDTO.setDataDate(new Date());
        meterDayDataDTO.setStatus(status);
        return meterDayDataDTO;
    }

    /**
       * 组装开关阀控制报文
       * @author liuwei
       * @date  2022/8/17
       * @param String meterAddress表地址 String tyoe 开关阀类型
       * @return 开关阀控制报文String frame
     */
    public static String makeStatusFrame(String meterAddress,String type){
        meterAddress = BCDCode.StringBcdToInt(meterAddress);
        StringBuilder frame = new StringBuilder();
        frame.append("68").append("10").append(meterAddress).append("2A") .append("04").append("A017").append("00");
        if(type.equals("1")){
            frame.append("55");
        }else{
            frame.append("99");
        }
        String checkCode = AepUtils.makeChecksum(frame.toString());
        frame.append(checkCode);
        frame.append("16");
        return String.valueOf(frame);
    }



    /**
       * 解析开关阀返回报文信息
       * @author liuwei
       * @date  2022/8/17
       * @param  String frame纳帕纹
       * @return  返回成功失败
     */
    public static String getStatus(String frame){
        System.out.println("收到的4G开关阀报文如下所示：" + frame);
        List<String> frameArray = AepUtils.stringToArray(frame);
        String type = AepUtils.join(frameArray.subList(13,15));
        String checkCode = frameArray.get(15);
        if(!checkCode.equals("39")&&!checkCode.equals("37")){
            return "开关阀控制失败，校验码异常";
        }
        if(type.equals("00FF")){
            return "开阀控制成功！";
        }
        return "关阀控制成功！";
    }

    public static void main(String[] args) throws ParseException {
        String aep = "22000000000000";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        Date date = dateFormat.parse(aep);
        SimpleDateFormat  format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str = format.format(date);
        System.out.println(str);
    }
}
