package aep.nbiot.dto.param.devicemanage.delete.batch;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 批量删除设备Post方法
 * @date 2021/12/13 8:57
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BatchDeleteDeviceParam {

    private Integer productId;

    private List<String> deviceIdList;
}
