package com.mapper.calculate;

import com.entity.calculate.CalculateFee;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */
public interface CalculateFeeMapper extends BaseMapper<CalculateFee> {
}
