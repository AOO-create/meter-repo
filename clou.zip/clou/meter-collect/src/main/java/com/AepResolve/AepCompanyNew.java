package com.AepResolve;


import aep.nbiot.command.AepDeviceCommandEnum;
import aep.nbiot.service.AepApiService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.config.ProductProperties;
import com.constant.Const;
import com.constant.ProtoConstant;
import com.entity.equipment.WaterMeterDayRead;
import com.entity.nbFrame.nbSendCommand;
import com.mapper.nbFrame.CommandManagerMapper;
import com.service.WaterMeterDayReadService;
import com.utils.AepUtils;
import com.utils.BCDCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class AepCompanyNew {

    @Autowired
    private ProductProperties productProperties;

    @Autowired
    private AepApiService aepApiService;

    @Autowired
    private WaterMeterDayReadService waterMeterDayReadService;

    @Autowired
    private CommandManagerMapper commandManagerMapper;

    public static MeterFrameDataNew resolveWtm(String frame) {
        System.out.println("收到的上报的报文信息如下：" + frame);
        List<String> frameArray = AepUtils.stringToArray(frame);
//        String frameType = ProtoConstant.FarmeType.ReadType;
        MeterFrameDataNew frameWaterData = new MeterFrameDataNew();
        frameWaterData.setStartcode(Integer.parseInt(frameArray.get(0)));
        frameWaterData.setType(Integer.parseInt(frameArray.get(1)));
        frameWaterData.setAddress(AepUtils.join(frameArray.subList(2, 10)));
        frameWaterData.setContolCode((frameArray.get(10)));
        frameWaterData.setByteLength(AepUtils.bigEndian(frameArray.subList(11, 13)));
        frameWaterData.setDataLogo(AepUtils.join(frameArray.subList(13, 15)));
        frameWaterData.setSerialId((frameArray.get(15)));
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        frameWaterData.setReportTime(format.format(new Date()));
        frameWaterData.setCheckCode((frameArray.get(frameArray.size() - 2)));

        return resolveReadFrame(frameWaterData, frameArray);
    }

    /***
     * 解析主动上报帧
     * @param frameWaterData
     * @param frameArray
     *
     * @return
     */
    public static MeterFrameDataNew resolveReadFrame(MeterFrameDataNew frameWaterData, List<String> frameArray) {
        int startNode = 16;

        //取出S0-S5
        String[] snArray = new String[6];
        for(int j=0; j<6;j++){
            snArray[j] = frameArray.get(startNode + j);
        }
        //第一步需要解析S1-S5看下到底数据项包含了哪些，
        String S0 = AepUtils.hexString2binaryString(snArray[0]);
        if(!S0.endsWith("1")){
            System.out.println("收到的数据帧无上报累计流量，数据帧存在问题，丢失数据帧，打印日志");
            return null;
        }

        //第二步根据包含的定位去获取上报总量和imei号，求两个数据项的起始位置即可
        //实时累计流量
        double realSumFlower = Double.parseDouble(BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(23,28)))) * 0.001;
        String str = new BigDecimal(Double.toString(realSumFlower)).toPlainString();

        frameWaterData.setCurrentIntegreFlow(str);//累计流量
        //imei号
        int count = 28;
        int imeiCount = 0;
        int imsiCount = 0;
        int csqCount = 0;
        int rsrpCount = 0;
        int snrCount = 0;
        int eclCount = 0;
        int currentDateCount = 0;
        int statusCount = 0;
//        imeiCount = count + 6 +8;
//        imsiCount = imeiCount + 8;

        //循环遍历标志位，判断偏移量的值
        for(int i=0 ; i<snArray.length;i++){
            char[] newStr = AepUtils.hexString2binaryString(snArray[i]).toCharArray();
            switch (i){
                case 0:{ //S0信号位判断  添加偏移量
                    if(newStr[6] == '1'){ //累计反向用水量
                        count = count + 5;
                    }
                    if(newStr[5] == '1'){//最近一次日冻结数据
                        count = count + 9;
                    }
                    if(newStr[4] == '1'){//最近一次月冻结数据
                        count = count + 8;
                    }
                    if(newStr[3] == '1'){//最近一天小时冻结数据
                        count = count + 123;
                    }
                    break;
                }
                case 1:{//S1信号位判断 添加偏移量
                    for(int s = 0; s< newStr.length;s++){
                        if(s == 6 && newStr[s] == '1'){ //脉冲当量
                            count = count + 2;
                        }else if(newStr[s] == '1'){//其他参数
                            count = count + 1;
                        }
                    }
                    break;
                }
                case 2:{
                    if(newStr[7] == '1'){//长时间未上报阈值
                        count = count + 1;
                    }
                    if(newStr[6] == '1'){//长时间未用水阈值
                        count = count + 1;
                    }
                    if(newStr[5] == '1'){//远端通讯超时时间
                        count = count + 2;
                    }
                    break;
                }
                case 3:{
                    if(newStr[7] == '1'){//
                        count = count + 2;
                    }
                    if(newStr[6] == '1'){
                        csqCount = count;
                        count = count + 1;
                    }
                    if(newStr[5] == '1'){
                        rsrpCount = count;
                        count = count + 2;
                    }
                    if(newStr[4] == '1'){
                        snrCount = count;
                        count = count + 2;
                    }
                    if(newStr[3] == '1'){
                        eclCount = count;
                        count = count + 1;
                    }
                    if(newStr[2] == '1'){
                        count = count + 2;
                    }
                    if(newStr[1] == '1'){
                        count = count + 2;
                    }
                    if(newStr[0] == '1'){
                        count = count + 5;
                    }
                    break;
                }
                case 4:{
                    if(newStr[7] == '1'){
                        count = count + 2;
                    }
                    if(newStr[6] == '1'){
                        count = count + 2;
                    }
                    if(newStr[5] == '1'){
                        count = count + 5;
                    }
                    if(newStr[4] == '1'){
                        currentDateCount = count;
                        count = count + 6;
                    }
                    if(newStr[3] == '1'){
                        statusCount = count;
                        count = count + 2;
                    }
                    break;
                }
                case 5:{
                    imeiCount = count;
                    if(newStr[6] == '1'){
                        imsiCount = count + 8;
                    }
                    break;
                }
            }
        }
        if(imeiCount == 0 || rsrpCount == 0 || csqCount == 0 || snrCount ==0 ||eclCount == 0 || currentDateCount == 0 || statusCount ==0){
            System.out.println("数据帧缺失，丢弃数据帧，打印日志");
            return null;
        }
        //赋值实体
        String str232 = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(imeiCount,imeiCount+8))).replaceAll("^(0+)","");
        frameWaterData.setImei(str232);
        String csqStr = AepUtils.join(frameArray.subList(csqCount,csqCount + 1));
        String rsrpStr = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(rsrpCount,rsrpCount+2)));
        String snrStr = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(snrCount,snrCount+2)));
        String eclStr = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(eclCount,eclCount+1)));
        String currentDateStr = "20" + AepUtils.join(frameArray.subList(currentDateCount+5,currentDateCount+6)) + '-'
                + AepUtils.join(frameArray.subList(currentDateCount+4,currentDateCount+5)) + "-"
                + AepUtils.join(frameArray.subList(currentDateCount+3,currentDateCount+4)) + " "
                + AepUtils.join(frameArray.subList(currentDateCount+2,currentDateCount+3)) + ":"
                + AepUtils.join(frameArray.subList(currentDateCount+1,currentDateCount+2)) + ":"
                + AepUtils.join(frameArray.subList(currentDateCount,currentDateCount+1));
        String statusStr = AepUtils.join(frameArray.subList(statusCount,statusCount+2));

        frameWaterData.setCsq(csqStr);
        frameWaterData.setRsrp(rsrpStr);
        frameWaterData.setSnr(snrStr);
        frameWaterData.setEcl(eclStr);
        frameWaterData.setWaterCurrentDate(currentDateStr);
        frameWaterData.setRunStatus(statusStr);
        if(imsiCount != 0){
            frameWaterData.setImsi(BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(imsiCount,imsiCount + 8))).replaceAll("^(0+)",""));
        }
        return frameWaterData;
    }

    public static StringBuilder makeFrame(MeterFrameDataNew data) {
        StringBuilder stringBuilder = new StringBuilder(30);
        stringBuilder.append(ProtoConstant.FarmeCode.StartCode)
                .append(data.getType())
                .append(data.getAddress());
        return stringBuilder;
    }

    /***
     * 组装离线应答帧
     */
    public static String makeOfflineFrame(MeterFrameDataNew data, String rightCode) {

        SimpleDateFormat format = new SimpleDateFormat("ssmmHHddMMyy");
        String dateStr = format.format(new Date());
        StringBuilder stringBuilder = makeFrame(data);
        stringBuilder.append(rightCode)
                .append(ProtoConstant.ReponseDataLength.reponseDataLength)
//                .append(data.getByteLength())
                .append(data.getDataLogo())
                .append(data.getSerialId())
                .append(dateStr);
        String checkCode = AepUtils.makeChecksum(stringBuilder.toString());
//                .append(ProtoConstant.FarmeCode.OffineLength)
//                .append(data.getDataLogo())
//                .append(data.getSerialId()).append(data.getTotalNmbel())
//                .append(data.getCurrentFrmId());
        stringBuilder.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
        return stringBuilder.toString();
    }

    public void handleResponseFrame(String deviceId, String frame) {
        String dataLogo = BCDCode.StringBcdToInt(AepUtils.join(AepUtils.stringToArray(frame).subList(13,15))).toUpperCase();
        String meterAddress = BCDCode.StringBcdToInt(AepUtils.join(AepUtils.stringToArray(frame).subList(2, 10)));
        //下行命令响应帧比对数据库修改状态  (对比未完成的所有下行命令)
        List<nbSendCommand> commandList = commandManagerMapper.selectList(new QueryWrapper<nbSendCommand>()
                .eq("meter_address",meterAddress)
                .in("flag","0","1"));
        nbSendCommand cc = new nbSendCommand();
        for(nbSendCommand command : commandList){
            //获取数据库报文的数据标识
            String logo = BCDCode.StringBcdToInt(AepUtils.join(AepUtils.stringToArray(command.getFrame()).subList(13,15))).toUpperCase();
            if(dataLogo.equals(logo)){
                //修改状态。
                setResultData(frame,command);
                cc = command;
            }
        }

        commandList.remove(cc);

        for(nbSendCommand command : commandList){
            createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), command.getFrame());
            command.setFlag("1");
            commandManagerMapper.updateById(command);
            return ;
        }

    }

    public void handleFrame(String deviceId, String frame)  {
        String result = "";
        //主动上报帧
        MeterFrameDataNew dataNew = resolveWtm(frame);
        List<nbSendCommand> commandList = new ArrayList<>();
        String onlineFrame = "";
        if (dataNew != null) {
            WaterMeterDayRead waterMeterDayRead = new WaterMeterDayRead();
            //插入数据库
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                waterMeterDayRead.setCollTime(format.parse(dataNew.getReportTime()));
                waterMeterDayRead.setWaterCurrentDate(format.parse(dataNew.getWaterCurrentDate()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            waterMeterDayRead.setCsq(dataNew.getCsq());
            waterMeterDayRead.setRsrp(dataNew.getRsrp());
            waterMeterDayRead.setSnr(dataNew.getSnr());
            waterMeterDayRead.setEcl(dataNew.getEcl());
            waterMeterDayRead.setRunStatus(dataNew.getRunStatus());
            waterMeterDayRead.setImsi(dataNew.getImsi());
            waterMeterDayRead.setDeviceId(dataNew.getImei());
            waterMeterDayRead.setRealSumFlow(BigDecimal.valueOf(Double.parseDouble(dataNew.getCurrentIntegreFlow())));
            waterMeterDayRead.setDataDate(new Date());
            waterMeterDayReadService.addNewProtol(waterMeterDayRead);
            commandList = commandManagerMapper.selectList(new QueryWrapper<nbSendCommand>()
                    .eq("meter_address", BCDCode.StringBcdToInt(dataNew.getAddress()))
                    .in("flag", "0","1"));
        }
        //下达指令回复上报报文帧
        if (commandList.size() == 0) {
            //没有下行命令发送
            onlineFrame = makeOfflineFrame(dataNew, ProtoConstant.ResponControCode.rightCode);
            //发送上报报文回复帧
            result = createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), onlineFrame);
        } else {
            //需要发送下行命令
            onlineFrame = makeOfflineFrame(dataNew, ProtoConstant.ResponControCode.waitCode);
            //发送上报报文回复帧
            result = createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), onlineFrame);
            //发送下行命令帧
            for (nbSendCommand command : commandList) {
                String sendframe = command.getFrame();
                int count = 0;
                //发送下行命令帧
                createCommand(productProperties.getMasterKey(), deviceId, productProperties.getProductId(), productProperties.getOperator(), sendframe);
                command.setFlag("1");
                return;
//                while (true) {
//                    //yitiao
//                    try {
//                        Thread.sleep(3 * 1000);
//                        count++;
//                        System.out.println("循环查询命令表是否接受信息：第" + count + "次了");
//                        String flag = commandManagerMapper.selectById(command.getId()).getFlag();
//                        if (flag.equals("1")) {
//                            break;
//                        }
//                        if (count == 3) {
//                            //响应超时 9 S内没响应
//                            command.setResultData("下行命令异常；响应等待时间9秒已超时未响应");
//                            commandManagerMapper.updateById(command);
//                            return result;
//                        }
//
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
            }
        }
    }

    /***
       * 功能描述  根据下行命令回复帧报文设置返回数据，更新至数据库中
       * @author liuwei
       * @date  2022/7/11
       * @param responFrame, command]
       * @return com.aep.AepResolve.MeterFrameDataNew
     */
    private void setResultData(String responFrame, nbSendCommand command) {
        String type = command.getType();
        command.setFlag("2");
        command.setUpdTime(new Date());

        if(type.equals(Const.TO_SEND_FRAME_FOUR) || type.equals(Const.TO_SEND_FRAME_FIVE)){
            List<String> frameArray = AepUtils.stringToArray(responFrame);
            String zero = frameArray.get(16);
            String readData = BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(17,22))).replaceAll("^(0+)","");
            if(zero.equals("01")){
                command.setResultData("-"+readData);
            }
            String dataLogo = BCDCode.StringBcdToInt(AepUtils.join(AepUtils.stringToArray(responFrame).subList(13,15))).toUpperCase();
            if(dataLogo.equals("C1")){
                readData = "尚无冻结数据";
            }
            command.setResultData(readData);
        }else if(type.equals(Const.TO_SEND_FRAME_SIX)){
            List<String> frameArray = AepUtils.stringToArray(responFrame);
            String resultData =  "";
            //分为24个小时的冻结数据
            for(int i=0 ; i<24 ; i++ ){
                resultData = resultData + (i) +"时："
                        + BCDCode.StringBcdToInt(AepUtils.join(frameArray.subList(16+i*5,16+5+i*5))).replaceAll("^(0+)","") + "m³  ;";
            }
            command.setResultData(resultData);
        }else{
            command.setResultData("下行命令成功!");
        }
        commandManagerMapper.updateById(command);
    }

    /****
     * 下达指令
     * @param masterKey
     * @param deviceId
     * @param productId
     * @param operator
     * @param payload
     */
    public String createCommand(String masterKey, String deviceId, String productId, String operator, String payload) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("MasterKey", masterKey);
        HashMap<String, Object> body = new HashMap<>();
        body.put("deviceId", deviceId);
        body.put("operator", operator);
        body.put("productId", productId);
        body.put("ttl", 864000);
        //body.put("deviceGroupId",)
        //body.put("level",)
        HashMap<String, Object> content = new HashMap<>();
        content.put("dataType", "2");
        content.put("payload", payload);
        body.put("content", content);
        String relust = aepApiService.invockApi(AepDeviceCommandEnum.CreateCommand, params, body);
        System.out.println("执行命令返回结果为：" + relust);
        return  relust;
    }




}
