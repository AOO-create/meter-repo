package com.dto.equipment;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class MeterDayVo  {

    private String meterAddress;

    private String name;

    private String instLoc;

    private Date instTime;
    private Integer sevenDay;
    /****
     * 表具类型 0：冷水水表 1：生活热水水表 2：直饮水水表 3：中水水表 4：电表
     */
    private String meterType;

    private String channel;

    private String uartbps;

    private String termId;
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    private String protocol;

    //串口波特率代号 0：2400bps 1：9600bps 2：1200bps 3：4800bps

    //物理层硬件通道代号 0：RS485 1：MBUS1 2：MBUS2 3.载波

    private String orgId;
    //    组织区域ID
    private String areaId;
    //    小区楼栋ID
    private String tgBuildDoorplate;
    private Integer pn;

    private String dataDate;

    private String sortOrder;
    private String bdName;
    private Integer page;
    private Integer limit;
    private Date collTime;
    private String termAddress;
    private BigDecimal fee1;
    private BigDecimal fee2;
    private BigDecimal fee3;
    private BigDecimal fee4;
    private BigDecimal realSumFlow;
    private BigDecimal incFlow;
    private BigDecimal flow;
}
