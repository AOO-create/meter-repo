package com.service.equipment;

import com.common.Result;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.entity.equipment.Protocol;
import com.entity.equipment.WNB;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.vo.exportExcelVo.ExportExcelParamsVo;

import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface NBmeterService {
    Page<NBDTO> findMeterToConsIsnull(NBDTO dto);

    String updateNB(NBDTO nBdto);

    String addNB(NBDTO nBdto) throws Exception;

    boolean deleteNB(String wmtrId) throws Exception;

    boolean batchDeleteNB(List<String> ids) throws Exception;

    boolean validWmtrNo(String wmtrNo);

    Page<NBDTO> getDataDay(NBDTO dto);

    List<MeterDayDataDTO> getExportData(ExportExcelParamsVo exportExcelParams);

    Result ExcelNBIn(List<NBDTO> list) throws Exception;

    Result ExcelNBProductIn(List<NBDTO> list) throws Exception;

    boolean validImei(String imei);

    List<Protocol> getProtocol();

    List<WNB> findNewProtoMeter();

    Map<String,Object> warningDayData();
}
