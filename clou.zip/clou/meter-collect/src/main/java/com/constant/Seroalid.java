package com.constant;

public class Seroalid {

    private static Integer serialId = 0;

    public static String createSerialId() {
        Integer a;
        String hex = "";
        a = serialId % 255 +1;
        //if(a<16){b="0"+b;}
        hex = Integer.toHexString(a);
        serialId++;
        int len = hex.length();
        // 如果不够校验位的长度，补0,这里用的是两位校验
        if (len < 2) {
            hex = "0" + hex;
        }
        return hex;
    }
}
