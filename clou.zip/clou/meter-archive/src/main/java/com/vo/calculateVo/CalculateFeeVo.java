package com.vo.calculateVo;

import com.common.PageConstant;
import com.entity.calculate.CalculateParam;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */
@Data
public class CalculateFeeVo extends PageConstant {

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long tgBuildDoorplate;//所属房间号

    private Integer type;//缴费类型  1、柜台缴费 2、第三方缴费 3、三方代扣缴费

    private String formula;//公式

    private String status;//是否启用

    private String name;//计算方式的名称

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long createUser;//操作用户id

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long areaId;

    private String method;

    private List<CalculateParam> paramList;

    private Double price;//统一水价

    private String bdName;

    private String userName;

    private String realFormula;//备注

}
