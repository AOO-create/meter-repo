package com.service.message;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dto.MessageDTO;
import com.dto.UserAndTenantDTO;

import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @description
 * @date 2022/9/30
 */
public interface MessageManagerService {
    Page<MessageDTO> findMessage(MessageDTO vo);

    boolean addMessage(MessageDTO vo);

    Map<String,String> userIdentity();

    Integer getMsCountBelongSelf();

    List<MessageDTO> getMessageReadNo();

    boolean readMessage(String id);

    List<MessageDTO> getMessageByUser(String id);

    List<UserAndTenantDTO> getUserAndTenant(String id);
}
