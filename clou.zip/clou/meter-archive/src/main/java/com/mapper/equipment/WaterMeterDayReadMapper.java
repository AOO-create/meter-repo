package com.mapper.equipment;

import com.entity.equipment.WaterMeterDayRead;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface WaterMeterDayReadMapper extends BaseMapper<WaterMeterDayRead> {

}
