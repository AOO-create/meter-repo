package com.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fegin.client.ArchiveClient;
import com.common.Const;
import com.entity.area.Org;
import com.mapper.log.MeterOperateLogMapper;
import com.service.MeterOperateLogService;
import com.vo.SystemLogVo.OperateMeterLogVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/9
 */
@Service
public class MeterOperateLogServiceImpl implements MeterOperateLogService {

    @Autowired
    private MeterOperateLogMapper mapper;

    @Autowired
    private ArchiveClient archiveClient;

    @Override
    public Page<OperateMeterLogVO> getLog(OperateMeterLogVO dto) {
        Page<OperateMeterLogVO> operateMeterLogVOPage = new Page<>();

        Org org = archiveClient.getOrg();
        dto.setOrgId(org.getOrgId());
        dto.setCurrentPos((dto.getPage() - 1) * dto.getLimit());
        if(archiveClient.getTgId() == null ||archiveClient.getTgId().equals("")){
            dto.setAreaId(archiveClient.getAreaId());
        }else{
            dto.setOpUser(Const.userId);
        }

        List<OperateMeterLogVO> list = mapper.getLog(dto);
        int count = mapper.getLogCount(dto);

        if (list.size() != 0 && list != null) {
            operateMeterLogVOPage.setRecords(list);
            operateMeterLogVOPage.setTotal(count);
        } else {
            operateMeterLogVOPage.setRecords(null);
            operateMeterLogVOPage.setTotal(0);
        }
        return operateMeterLogVOPage;
    }

}
