package com.entity.tenant;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/***
 * 插入租户表的时候，并且插入关系表
 */
@Data
public class TenantUserRela {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;

    private Long UserId;  //房东id

    private Long TenantId; //租户id

}
