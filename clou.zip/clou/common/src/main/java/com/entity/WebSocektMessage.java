package com.entity;

import lombok.Data;

@Data
public class WebSocektMessage {
    String code;
    Object object;
    String userId;
}
