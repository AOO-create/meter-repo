package com.service.equipment.impl;

import com.alibaba.fastjson.JSONObject;
import com.aop.annotation.ChangeMeterAopAnnotation;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Const;
import com.dto.equipment.MeterDTO;
import com.dto.equipment.NBDTO;
import com.entity.Org;
import com.entity.equipment.WNB;
import com.entity.equipment.WiredMeter;
import com.mapper.equipment.ChangeMeterMapper;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.service.equipment.ChangeMeterService;
import com.service.organization.impl.GradeServiceImpl;
import com.util.ShiroConstUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/5/30
 */
@Service
public class ChangeMeterServiceImpl implements ChangeMeterService {

    @Autowired
    private ShiroConstUtils shiroConstUtils;

    @Autowired
    private ChangeMeterMapper changeMeterMapper;

    @Autowired
    private NBmeterServiceImpl nBmeterService;

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired
    private GradeServiceImpl gradeService;

    @Override
    public Page<MeterDTO> getMeterByBuild(MeterDTO dto) {
        String areaId = dto.getAreaId();
        String tgId = dto.getTgBuildDoorplate();
        String orgId = shiroConstUtils.getOrg().getOrgId();
        List<MeterDTO> list = new ArrayList<>();
        int count = 0;
        dto.setOrgId(orgId);
        List<String> ids = new ArrayList<>();

        if(dto.getPage() != null){
            dto.setCurrentPos((dto.getPage() - 1)*dto.getLimit());
        }
        Page<MeterDTO>  page = new Page<>(dto.getPage(),dto.getLimit());
        if((areaId == null && tgId == null) || (areaId.equals("") && tgId.equals(""))){
            //初次进入页面
            //根据组织区域查询所有表具
            if(shiroConstUtils.getRole().getRoleCode().equals("admin")){
                orgId = shiroConstUtils.getOrg().getOrgId();
                dto.setOrgId(orgId);
                dto.setAreaId("");
            }else if(shiroConstUtils.getTgBuildDoorplate() == null || shiroConstUtils.getTgBuildDoorplate().equals("")){
                //不是管理员，该用户下所有表具areaId
                areaId = shiroConstUtils.getAreaId();
                dto.setAreaId(areaId);
                dto.setOrgId("");
            }else {
                ids = gradeService.reGetChildBDGradeId(shiroConstUtils.getTgBuildDoorplate(),orgId,new ArrayList<>());
            }
        }else if(areaId !=null || !areaId.equals("")){
            //点击节点
            if(shiroConstUtils.getRole().getRoleCode().equals("admin")){

            }else if(tgId ==null || tgId.equals("")){
                dto.setAreaId(areaId);
            }else{
                ids = gradeService.reGetChildBDGradeId(tgId,orgId,new ArrayList<>());
            }
        }
        if(dto.getMeterType().equals("5")){
            //NB表
            list = changeMeterMapper.getAllMeterByOrgIdNB(dto,ids);
            count = changeMeterMapper.getAllMeterCountByOrgIdNB(dto,ids);
        }else if(dto.getMeterType().equals("0") ||dto.getMeterType().equals("4")){
            //有线表  \电表
            list = changeMeterMapper.getAllMeterByOrgIdWire(dto,ids);
            count = changeMeterMapper.getAllMeterCountByOrgIdWire(dto,ids);
        }
        page.setRecords(list);
        page.setTotal(count);
        return page;
    }

    @Transactional
    @ChangeMeterAopAnnotation(changeType = Const.unbind_meter)
    @Override
    public boolean unBindMeter(MeterDTO dto) {
        int count = -1;
        if(dto.getMeterType().equals("5")){
//            ①删除电信关联调用电信删除接口，等更新NB表具能调用接口时再使用
//            WNB wnb = nBmeterMapper.selectById(dto.getId());
//            JSONObject jsonObject = JSONObject.parseObject(nBmeterService.telecomDeletedNB(wnb).toString());
//            String code =jsonObject.get("code") + "";
//            if(!code.equals("0")){
//                return false;
//            }
//            ②解绑NB表具，删除inst_loc + tgId + deviceId
            count = changeMeterMapper.unBindMeterNB(dto);

        }else if(dto.getMeterType().equals("0") || dto.getMeterType().equals("4")){
            //更新有线表具,置空inst_loc + tgId + termId
            count = changeMeterMapper.unBindMeterWire(dto);
        }

        return count > 0;
    }

    @Transactional
    @ChangeMeterAopAnnotation(changeType = Const.change_meter)
    @Override
    public boolean toChangeMeter(MeterDTO dto) {
        String meterType = dto.getMeterType();
        Org org = shiroConstUtils.getOrg();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(meterType.equals("5")){
            //NB表具更换 ①新增 ②修改删除
            WNB wnb = new WNB();
            wnb.setInstDate(format.format(new Date()));
            BeanUtils.copyProperties(dto,wnb);
            wnb.setWmtrId(null);
            wnb.setOrgId(org.getOrgId());
            wnb.setUpdTime(format.format(new Date()));
            NBDTO nbdto = new NBDTO();
            BeanUtils.copyProperties(wnb,nbdto);
            //调用电信接口插入
            JSONObject jsonObject = JSONObject.parseObject(nBmeterService.telecomInsertNB(nbdto).toString());
            String code =jsonObject.get("code") + "";
            if(!code.equals("0")){
               return false;
            }
            JSONObject resultStr = JSONObject.parseObject(jsonObject.getString("result"));
            String deviceId = (String) resultStr.get("deviceId");
            wnb.setDeviceId(deviceId);
            //Object返回deviceId 自己需要填写协议是哪一种
            //新增NB表具
            int result = nBmeterMapper.insert(wnb);
            if(result <=0 ){
                return false;
            }
        }else{
            WiredMeter wiredMeter = new WiredMeter();
            BeanUtils.copyProperties(dto,wiredMeter);
            wiredMeter.setId(null);
            wiredMeter.setOrgId(org.getOrgId());
            wiredMeter.setMeterType(dto.getMeterType());
            wiredMeter.setInstTime(new Date());
            int count = wiredMeterMapper.insert(wiredMeter);
            if(count <= 0){
                return false;
            }
        }
        unBindMeter(dto);
        return true;
    }
}
