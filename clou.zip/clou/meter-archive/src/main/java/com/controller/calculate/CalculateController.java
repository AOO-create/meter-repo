package com.controller.calculate;

import com.service.calculate.CalculateService;
import com.vo.calculateVo.CalculateFeeVo;
import com.common.Result;
import com.common.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */

@RestController
@RequestMapping("/archive/calculateManage")
public class CalculateController {

    @Autowired
    private CalculateService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getAllCalculate")
    @ResponseBody
    public Result getAllCalculate(@RequestBody CalculateFeeVo calculateVo){
        return Result.OK(service.getAllCalculate(calculateVo));
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("createCalculateOneType")
    @ResponseBody
    public Result createCalculateOneType(@RequestBody CalculateFeeVo calculateFeeVo) throws Exception {
        boolean flag = service.createCalculateOneType(calculateFeeVo);
        if(flag){
            return Result.OK();
        }
        return Result.ERROR(ResultCodeEnum.CALCULATE_ADD_ERROR);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("createCalculateTwoType")
    @ResponseBody
    public Result createCalculateTwoType(@RequestBody CalculateFeeVo calculateFeeVo) throws Exception {
        boolean flag = service.createCalculateTwoType(calculateFeeVo);
        if(flag){
            return Result.OK();
        }
        return Result.ERROR(ResultCodeEnum.CALCULATE_ADD_ERROR);
    }


}
