package com.service.dataView;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dto.dataView.CommonMapDTO;
import com.dto.dataView.MeterPapR;
import com.dto.equipment.MeterHourVo;
import com.dto.equipment.MeterDayVo;
import com.dto.equipment.MeterMonthVo;

import java.text.ParseException;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
public interface DataViewService {
    List<Double[]> getTitleNumber();

    List<CommonMapDTO> getAreaTenantNumber();

    List<Double> getCollectRate();

    List<int[]> getRecordOperate();

    List<CommonMapDTO> getAreaMeter();

    List<CommonMapDTO> getReportRate();

    CommonMapDTO getRateData();

    CommonMapDTO getDosage() ;

    List<MeterDayVo> searchData(MeterDayVo dto);

    List<MeterDayVo> searchHourData(MeterDayVo dto);

    IPage<MeterDayVo> getDataByDay(MeterDayVo dto);
    IPage<MeterDayVo> selectSumHourByAreaId(MeterDayVo dto);
    IPage<MeterDayVo> getIncDataByDay(MeterDayVo dto);

    IPage<MeterHourVo> getDataByHour(MeterDayVo meterDayVo);
    IPage<MeterHourVo> getTfourByHour(MeterDayVo meterDayVo);

    IPage<MeterMonthVo> getDataByMonth(MeterMonthVo dto) ;

    IPage<MeterDayVo> getSevenDataByDay(MeterDayVo meterDayVo);
}
