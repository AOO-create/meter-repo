package com.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author liuwei
 * @description
 * @date 2022/9/30
 */
@Data
@TableName("message")
public class Message {

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;//主键ID

    private String status;//阅读状态 1:已读 2：未读

    private String title;//标题

    private String content;//内容

    private String filename;//附件

    private String type;//消息类型，1：系统消息 2：用户消息

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;//创建时间

    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long createUser;//创建人

    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端\
    private Long recieveUser;//接收人
}
