package com.mapper.calculate;

/**
 * @author liuwei
 * @description
 * @date 2022/7/29
 */
public interface CalculateMapper {
}
