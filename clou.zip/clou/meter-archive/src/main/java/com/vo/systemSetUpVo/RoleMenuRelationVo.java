package com.vo.systemSetUpVo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.common.PageConstant;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/6/28
 */
@Data
public class RoleMenuRelationVo extends PageConstant {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long menuId;

    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long roleId;

    private String menuName;

    private String menuParentName;

    private Boolean addFlag;

    private Boolean updateFlag;

    private Boolean deleteFlag;

    private Integer premitType;
}
