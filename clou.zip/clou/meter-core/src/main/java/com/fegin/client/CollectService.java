package com.fegin.client;

import org.springframework.web.bind.annotation.GetMapping;

//@FeignClient(name = "collect-provider", url = "${service-url.collect-provider}")
public interface CollectService {
    @GetMapping("/nbMeter/listen")
    public Object startListenOrgin();

}
