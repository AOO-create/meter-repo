package com.service.excel;



import com.vo.excelOpVo.ExportExcelParamsVo;

import javax.servlet.http.HttpServletResponse;

/**
 * @author liuwei
 * @description
 * @date 2022/5/31
 */
public interface ExcelManagerService {

    void OutExcel(HttpServletResponse response, ExportExcelParamsVo exportExcelParams) throws Exception;

    void downloadModel(HttpServletResponse response,String type);
}
