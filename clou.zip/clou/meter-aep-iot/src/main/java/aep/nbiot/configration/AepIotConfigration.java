package aep.nbiot.configration;

import aep.nbiot.propertie.AepIotProperties;
import aep.nbiot.service.AepApiService;
import aep.nbiot.service.AepMqService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 自动配置类
 * @date 2021/11/17 8:51
 */
@Configuration
@EnableConfigurationProperties(AepIotProperties.class)
@ConditionalOnClass(AepApiService.class)//只有AepApiService实例化了才注册到sprinboot里面
public class AepIotConfigration {

    /**
     * Aep插件配置对象
     */
    @Autowired
    AepIotProperties aepIotProperties;

    /**
     * Aep API调用服务
     */
    @Bean
    public AepApiService aepIotService(){
        return new AepApiService(aepIotProperties);
    }

    /**
     * Aep MQ监听服务
     */
    @Bean
    public AepMqService aepMqService(){
        return new AepMqService(aepIotProperties);
    }
}
