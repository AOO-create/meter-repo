package aep.nbiot.strategy.aepdevicecommand;

import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.util.ParamsUtil;
import com.ctg.ag.sdk.biz.AepDeviceCommandClient;
import com.ctg.ag.sdk.biz.aep_device_command.CancelCommandRequest;
import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 取消指令
 * @date 2021/11/17 16:07
 */
public class CancelCommandStrategy implements IAepStrategy {

    @Override
    public BaseApiResponse invockApi(BaseApiClient _client, HashMap<String,Object> params, HashMap<String,Object> body) {
        try {
            ParamsUtil paramsUtil = new ParamsUtil(new CancelCommandRequest());
            CancelCommandRequest request = (CancelCommandRequest) paramsUtil.addParams(params,body);
            AepDeviceCommandClient client = (AepDeviceCommandClient)_client;
            return client.CancelCommand(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
