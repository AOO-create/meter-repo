package com.sso.utils;




/**
 * @program: springboot-security-sso
 * @description:
 * @author: 吴方豪
 * @create: 2022-11-02 14:57
 **/
public class RsaUtilsTest {
    private String publicFile = "D:\\auth_key\\rsa_key.pub";
    private String privateFile = "D:\\auth_key\\rsa_key";
    private String secret = "CaoChenLeiSecret";


    public void generateKey() throws Exception {
        RsaUtils.generateKey(publicFile, privateFile, secret, 2048);
    }
}
