package com.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

/**
 * Copyright © 2021 FL All rights reserved.
 * 描述
 */
@Configuration
public class FeignRequestConfiguration{

    @Autowired
    public FeignRequestInterceptor feignRequestInterceptor(){
        return new FeignRequestInterceptor();
    }

}