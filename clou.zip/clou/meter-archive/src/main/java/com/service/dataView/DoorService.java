package com.service.dataView;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.entity.organization.BDGrade;
import com.mapper.organization.BDGradeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoorService {

    @Autowired
    private BDGradeMapper bdGradeMapper;


    //根据房间号来获得 子的房间号   BDGrade
    public List<BDGrade> getDoorById(List<BDGrade> list, Long buildId) {

        List<BDGrade> list2 = bdGradeMapper.selectList(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getParentId, buildId));

        if (list2.isEmpty()) {
            BDGrade bdGrade = bdGradeMapper.selectOne(new LambdaQueryWrapper<BDGrade>().eq(BDGrade::getId, buildId));
            list.add(bdGrade);
            return list;
        } else {

            for (BDGrade g: list2){
                getDoorById(list,g.getId());
            }
            return list;
        }

    }
}
