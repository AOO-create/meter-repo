package aep.nbiot.command;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 指令下发
 * @date 2021/11/17 8:05
 */
public enum AepDeviceCommandEnum implements AepCommandEnum {

    CancelCommand("CancelCommand","取消指令"),
    CreateCommand("CreateCommand","统一合并指令下发"),
    QueryCommand("QueryCommand","查询单个指令详情"),
    QueryCommandList("QueryCommandList","批量查询指令详情"),
    CreateCommandLwm2mProfile("CreateCommandLwm2mProfile","lwm2m协议有profile指令下发接口"),
    ;
    /**
     * 命令KEY
     */
    private String commandKey;

    /**
     * 命令名称
     */
    private String commandName;

    AepDeviceCommandEnum(String commandKey, String commandName) {
        this.commandKey = commandKey;
        this.commandName = commandName;
    }

}
