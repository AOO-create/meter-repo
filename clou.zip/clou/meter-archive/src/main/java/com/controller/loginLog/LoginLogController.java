package com.controller.loginLog;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.entity.log.LoginLog;
import com.service.loginLog.LoginLogService;
import com.vo.SystemLogVo.LoginLogVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuwei
 * @description
 * @date 2023/10/26 
 */

@RestController
@RequestMapping("/archive/loginLog")
public class LoginLogController {

    @Autowired
    private LoginLogService service;

    @RequestMapping("/getPageLoginLog")
    public Page<LoginLog> getPageLoginLog(@RequestBody LoginLogVo log){
        return service.getPageLoginLog(log);
    }


}
