package aep.nbiot.dto.param.devicemanage.update;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 更新设备
 * @date 2021/12/13 9:02
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateDeviceParam {

    /**
     * 设备名称，必填
     */
    private String deviceName;

    /**
     * 操作者，必填
     */
    private String operator;

    /**
     * LWM2M协议必填参数,其他协议不填
     */
    private Object other;

    /**
     * 产品ID，必填
     */
    private Integer productId;

}
