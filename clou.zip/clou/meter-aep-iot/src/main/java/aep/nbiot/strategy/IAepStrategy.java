package aep.nbiot.strategy;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @description: AEP调用策略
 * @author lanccj
 * @date 2021年11月17日07:59:46
 * @version 1.0
 */
public interface IAepStrategy {

    /**
     * 调用电信AEP平台某个API
     * @param client 连接客户端
     * @return 请求返回信息
     */
    BaseApiResponse invockApi(BaseApiClient client, HashMap<String,Object> params, HashMap<String,Object> body);

}
