package com.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dto.equipment.NBDTO;
import com.entity.equipment.Protocol;
import com.entity.equipment.WNB;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
public interface NBmeterMapper extends BaseMapper<WNB> {
}
