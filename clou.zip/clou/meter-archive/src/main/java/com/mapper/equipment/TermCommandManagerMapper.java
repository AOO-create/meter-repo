package com.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.command.TermSendCommand;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
public interface TermCommandManagerMapper extends BaseMapper<TermSendCommand> {
}
