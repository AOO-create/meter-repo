package com.entity.systemSetup;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;


@Data
@TableName("O_USER")
public class User implements Serializable {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long id;
    private String username;        //用户名
    private String password;        //密码
    private String orgId;             //供能单位ID
    private String staffNo;         //工号
    private String name;            //姓名
    private String mobile;          //手机号码
    private String email;          //邮箱
    private String deptId;  //部门
    private double reductionUp;     //减免上限

    private String remark; //备注
    private Date lastLoginTime;     //最后一次登录时间
    private Date updTime;           //更新时间
    private Integer statusCode;          //状态CODE  1 可用，0 不可用
    private String wxAccount; //微信号
    private String areaId;//组织区域ID
    private String tgBuildDoorplate; //单元楼栋ID

}
