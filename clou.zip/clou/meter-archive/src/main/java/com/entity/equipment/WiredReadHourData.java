package com.entity.equipment;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class WiredReadHourData {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    private Long meterId;
    private String meterAddress;
    private String termAddress;
    private Date collTime;
    private Date dataDate;
    private BigDecimal papr_1;
    private BigDecimal papr_2;
    private BigDecimal papr_3;
    private BigDecimal papr_4;
    private BigDecimal papr_5;
    private BigDecimal papr_6;
    private BigDecimal papr_7;
    private BigDecimal papr_8;
    private BigDecimal papr_9;
    private BigDecimal papr_10;
    private BigDecimal papr_11;
    private BigDecimal papr_12;
    private BigDecimal papr_13;
    private BigDecimal papr_14;
    private BigDecimal papr_15;
    private BigDecimal papr_16;
    private BigDecimal papr_17;
    private BigDecimal papr_18;
    private BigDecimal papr_19;
    private BigDecimal papr_20;
    private BigDecimal papr_21;
    private BigDecimal papr_22;
    private BigDecimal papr_23;
    private BigDecimal papr_24;
}
