package aep.nbiot.mq;

import cn.hutool.core.codec.Base64;
import org.apache.commons.codec.binary.Hex;

import java.io.Serializable;

/**
 * @author wufanghao
 * @version 1.0
 * @description: MQ消息-数据上报
 * @date 2021/12/28 13:18
 */
public class MqDataReport extends MqReport implements Serializable {

    private Integer upPacketSN;
    private Integer upDataSN;
    private String topic;
    private Long timestamp;
    private String tenantId;
    private String serviceId;
    private String protocol;
    private String productId;
    private PayloadDTO payload;
    private String messageType;
    private String deviceType;
    private String deviceId;
    private String assocAssetId;
    private String IMSI;
    private String IMEI;

    public Integer getUpPacketSN() {
        return upPacketSN;
    }

    public void setUpPacketSN(Integer upPacketSN) {
        this.upPacketSN = upPacketSN;
    }

    public Integer getUpDataSN() {
        return upDataSN;
    }

    public void setUpDataSN(Integer upDataSN) {
        this.upDataSN = upDataSN;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public PayloadDTO getPayload() {
        return payload;
    }

    public void setPayload(PayloadDTO payload) {
        this.payload = payload;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getAssocAssetId() {
        return assocAssetId;
    }

    public void setAssocAssetId(String assocAssetId) {
        this.assocAssetId = assocAssetId;
    }

    public String getIMSI() {
        return IMSI;
    }

    public void setIMSI(String IMSI) {
        this.IMSI = IMSI;
    }

    public String getIMEI() {
        return IMEI;
    }

    public void setIMEI(String IMEI) {
        this.IMEI = IMEI;
    }

    public static class PayloadDTO implements Serializable {
        private String APPdata;

        public String getAPPdata() {
            return APPdata;
        }

        public void setAPPdata(String APPdata) {
            this.APPdata = APPdata;
            try {
                if(false){//字符串解密，CTWING提供解析后的字符串信息
                    this.APPdata = Base64.decodeStr(APPdata);
                }else{//解密转16进制字符串
                    byte[] x= java.util.Base64.getDecoder().decode(APPdata);
                    this.APPdata = Hex.encodeHexString(x);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
