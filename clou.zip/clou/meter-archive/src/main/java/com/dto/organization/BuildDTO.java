package com.dto.organization;

import com.common.PageConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/4/28
 */
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
public class BuildDTO extends PageConstant {
    private String id;
    private String areaId;
    private String tgBuildDoorplate;
    private String no;
    private String name;
    private String orgId;
    private String orgName;
    private String areaName;
    private String parentId;
    private String parentName;
    private String email;
    private String remark;

}
