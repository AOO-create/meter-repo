package com.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("product")
public class ProductProperties {
    /**
     * 应用masterKey
     */
    private String masterKey;

    /**
     * 应用productId
     */
    private String productId;

    /**
     * 应用operator
     */
    private String operator;

    public String getMasterKey() {
        return masterKey;
    }

    public void setMasterKey(String masterKey) {
        this.masterKey = masterKey;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
