package com.szclou.entity;

import java.util.Date;

/**
 * 说明：水表口径
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-1-21
 */
public class Caliber {

    private String caliberId;
    private int mtrCaliber;//水表口径
    private String measUnit;//计量单位
    private double stdFlow;//标准流量
    private double maxFlow;//最大流量
    private double dayAlrUp;//日报警下限
    private double dayAlrLow;//日报警上限
    private int verifYears;//强捡年限
    private String remark;//备注
    private Date updTime;
    private String orgId;

    public String getCaliberId() {
        return caliberId;
    }

    public void setCaliberId(String caliberId) {
        this.caliberId = caliberId;
    }

    public int getMtrCaliber() {
        return mtrCaliber;
    }

    public void setMtrCaliber(int mtrCaliber) {
        this.mtrCaliber = mtrCaliber;
    }

    public String getMeasUnit() {
        return measUnit;
    }

    public void setMeasUnit(String measUnit) {
        this.measUnit = measUnit;
    }

    public double getStdFlow() {
        return stdFlow;
    }

    public void setStdFlow(double stdFlow) {
        this.stdFlow = stdFlow;
    }

    public double getMaxFlow() {
        return maxFlow;
    }

    public void setMaxFlow(double maxFlow) {
        this.maxFlow = maxFlow;
    }

    public double getDayAlrUp() {
        return dayAlrUp;
    }

    public void setDayAlrUp(double dayAlrUp) {
        this.dayAlrUp = dayAlrUp;
    }

    public double getDayAlrLow() {
        return dayAlrLow;
    }

    public void setDayAlrLow(double dayAlrLow) {
        this.dayAlrLow = dayAlrLow;
    }

    public int getVerifYears() {
        return verifYears;
    }

    public void setVerifYears(int verifYears) {
        this.verifYears = verifYears;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }
}
