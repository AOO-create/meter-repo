package com.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BCDCode {
    /**
     * @功能:测试用例
     * @参数: 参数
     */
//    public static void main(String[] args) {
//        String a ="00010000";
//        int ab = Integer.parseInt(StringBcdToInt(a));
//    }

    /**
     * @功能: BCD码转为10进制串(阿拉伯数据)
     * @参数: BCD码
     * @结果: 10进制串
     */


    public static String StringBcdToInt(String str) {
        int m = str.length() / 2;
        if (m * 2 < str.length()) m++;
        List<String> strs = new ArrayList<>();
        int j = 0;
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {

            if (i % 2 == 0) {//每隔两个
                stringBuilder.append(str.charAt(i));
            } else {
                strs.add((stringBuilder.append(str.charAt(i)).toString()));
                j++;
                stringBuilder.delete(0, stringBuilder.length());
            }

        }
        Collections.reverse(strs);

        return AepUtils.join(strs);
    }


    /**
     * 转换byte数组为int（大端）
     * @return
     * @note 数组长度至少为4，按小端方式转换，即传入的bytes是大端的，按这个规律组织成int
     */
    public static int bigToInt(String data) {
        byte[] b =getbytes(data);
        int mask = 0xff;
        int temp = 0;
        int res = 0;
        for(int i=0;i<4;i++)
        {
            res<<=8;
            temp = b[i]&mask;
            res |= temp;
        }
        return res;
    }


    /**
     * 转换byte数组为int（小端）
     * @return
     * @note 数组长度至少为4，按小端方式转换,即传入的bytes是小端的，按这个规律组织成int
     */

    public static String intToStringSmall(Integer integer){
        String s = String.format("%04x", integer);
        StringBuilder stringBuilder =new StringBuilder();
        stringBuilder.append(s.substring(2,4)).append(s.substring(0,2));
        return stringBuilder.toString();
    }
    public static Integer stringSmallToInt(String string){
        StringBuilder stringBuilder =new StringBuilder();
        stringBuilder.append(string.substring(2,4)).append(string.substring(0,2));
        Integer put_Vlue = Integer.parseInt(stringBuilder.toString(), 16);
        return put_Vlue;
    }

    public static String smallToaddress(String address) {
        StringBuffer  stringBuffer = new StringBuffer();
        stringBuffer.append(address.substring(2,4))
                .append(address.substring(0,2))
                .append(address.substring(6,8))
                .append(address.substring(4,6));
        return  stringBuffer.toString();
    }

    public static String addressToSmall(String address) {
        StringBuffer  stringBuffer = new StringBuffer();
//        " 64 01 39 05 21 20 00 00";000020
        stringBuffer.append(address.substring(2,4))
                .append(address.substring(0,2))
                .append(address.substring(6,8))
                .append(address.substring(4,6));
        return  stringBuffer.toString();
    }
    public static String meterToSmall(String meter) {
        List<String> list = AepUtils.stringToBufferArray(meter,2);
        Collections.reverse(list);
        String join = StringUtils.join(list,"");
        return join;
    }

    // 16进制字符串转byte[]
    public static byte[] getbytes(String data) {

        int len = data.length();

        byte[] ba = new byte[len / 2];

        int i = 0, j = 0, c;

        while (i < len) {

            c = Character.digit(data.charAt(i++), 16) << 4;

            c = c + Character.digit(data.charAt(i++), 16);

            ba[j++] = (byte) c;

        }

        return ba;

    }


    /**
     * @功能: 10进制串转为BCD码
     * @参数: 10进制串
     * @结果: BCD码
     */
    public static byte[] str2Bcd(String asc) {
        int len = asc.length();
        int mod = len % 2;
        if (mod != 0) {
            asc = "0" + asc;
            len = asc.length();
        }
        byte abt[] = new byte[len];
        if (len >= 2) {
            len = len / 2;
        }
        byte bbt[] = new byte[len];
        abt = asc.getBytes();
        int j, k;
        for (int p = 0; p < asc.length() / 2; p++) {
            if ((abt[2 * p] >= '0') && (abt[2 * p] <= '9')) {
                j = abt[2 * p] - '0';
            } else if ((abt[2 * p] >= 'a') && (abt[2 * p] <= 'z')) {
                j = abt[2 * p] - 'a' + 0x0a;
            } else {
                j = abt[2 * p] - 'A' + 0x0a;
            }
            if ((abt[2 * p + 1] >= '0') && (abt[2 * p + 1] <= '9')) {
                k = abt[2 * p + 1] - '0';
            } else if ((abt[2 * p + 1] >= 'a') && (abt[2 * p + 1] <= 'z')) {
                k = abt[2 * p + 1] - 'a' + 0x0a;
            } else {
                k = abt[2 * p + 1] - 'A' + 0x0a;
            }
            int a = (j << 4) + k;
            byte b = (byte) a;
            bbt[p] = b;
        }
        return bbt;
    }

    public static void main(String[] args) {
        String ss = "123";
        System.out.println(str2Bcd(ss).toString());
    }
}