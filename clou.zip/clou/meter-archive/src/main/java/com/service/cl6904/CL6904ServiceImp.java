package com.service.cl6904;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.config.DynamicDataSource;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.WiredMeterDTO;
import com.entity.equipment.Term;
import com.entity.equipment.WiredMeter;
import com.mapper.cl6904.CL6904Mapper;
import com.mapper.dataView.DataViewMapper;
import com.mapper.equipment.TermManagerMapper;
import com.mapper.equipment.WiredMeterMapper;
import com.mapper.organization.BDGradeMapper;
import com.vo.equipment.CollectMeterVo;
import org.apache.http.impl.conn.Wire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CL6904ServiceImp implements CL6904Service{

    @Autowired
    private DataViewMapper dataViewMapper;

    @Autowired
    private TermManagerMapper termManagerMapper;

    @Autowired
    private WiredMeterMapper wiredMeterMapper;

    @Autowired
    private BDGradeMapper bdGradeMapper;

    @Autowired
    private CL6904Mapper mapper;
    @Override
    public List<WiredMeterDTO> getCL6904PapR(String id, String date, String pos, String limit) {
        List<String> ids = new ArrayList<>();
        ids.add(id);
        DynamicDataSource.name.set("r");
        String meterId = dataViewMapper.getMeterId(ids).get(0);
        DynamicDataSource.name.set("w");
        List<WiredMeterDTO> papRList = mapper.getMonthElecData(meterId,date,Integer.parseInt(pos), Integer.parseInt(limit));
        DynamicDataSource.name.set("r");
        return papRList;
    }

    /***
       * 根据组织区域ID或门栋ID集合和日期查询上报的818集中器下电表
       * @author liuwei
       * @date  2023/12/15
       * @params [date, id, bdIds]
       * @return int
     */
    @Override
    public int getReportCl6904(String date, String id, List<String> bdIds) {
        int count = 0;
        List<String> meterId = new ArrayList<>();
        if(null == id || id.equals("") ){
            id = bdGradeMapper.selectById(bdIds.get(0)).getAreaId();
            List<Term> terms =termManagerMapper.selectList(new QueryWrapper<Term>().eq("area_id",id).eq("model_type","1"));
            if(terms != null && terms.size()>0){
                List<String> addressList = new ArrayList<>();
                terms.forEach(val-> addressList.add(val.getAddress()));
                List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                        .in("term_id",addressList).in("tg_build_doorplate",bdIds));
                if(wiredMeterList != null && wiredMeterList.size() >0){
                    List<String> ids = new ArrayList<>();
                    wiredMeterList.forEach(val -> ids.add(val.getId()+""));
                    meterId = dataViewMapper.getMeterId(ids);
                }
            }
        }else if(null == bdIds || bdIds.size() == 0){
            List<Term> terms =termManagerMapper.selectList(new QueryWrapper<Term>().eq("area_id",id).eq("model_type","1"));
            if(terms != null && terms.size()>0){
                List<String> addressList = new ArrayList<>();
                terms.forEach(val-> addressList.add(val.getAddress()));
                List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>().in("term_id",addressList));
                if(wiredMeterList != null && wiredMeterList.size() >0){
                    List<String> ids = new ArrayList<>();
                    wiredMeterList.forEach(val -> ids.add(val.getId()+""));
                    meterId = dataViewMapper.getMeterId(ids);
                }
            }
        }
        if(meterId.size()>0){
            DynamicDataSource.name.set("w");
            count = dataViewMapper.getOioElecReport(meterId,date);
            DynamicDataSource.name.set("r");
        }
        return count;
    }

    /***
       * 根据6610集中器下电表ID和日期获取818表具的日冻结数据
       * @author liuwei
       * @date  2023/12/15
       * @params [id, date]
       * @return com.dto.equipment.MeterDayDataDTO
     */
    @Override
    public MeterDayDataDTO getPapR(String id, String date) {
        List<String> ids = new ArrayList<>();
        ids.add(id);
        DynamicDataSource.name.set("r");
        String meterId = dataViewMapper.getMeterId(ids).get(0);
        DynamicDataSource.name.set("w");
        MeterDayDataDTO  papR = mapper.getPapR(meterId,date);
        DynamicDataSource.name.set("r");
        return papR;
    }

    @Override
    public List<CollectMeterVo> getCL6904NoReport(MeterDayDataDTO dayDataDTO) {
        String areaId =  dayDataDTO.getAreaId();
        List<String> tgIds = dayDataDTO.getTgIds();
        String date = dayDataDTO.getDate();
        List<CollectMeterVo> result = new ArrayList<>();
        List<String> meterId = new ArrayList<>();

        if(null == areaId || areaId.equals("")){
            areaId = bdGradeMapper.selectById(tgIds.get(0)).getAreaId();
            List<Term> terms =termManagerMapper.selectList(new QueryWrapper<Term>().eq("area_id",areaId).eq("model_type","1"));
            if(terms != null && terms.size()>0){
                List<String> addressList = new ArrayList<>();
                terms.forEach(val-> addressList.add(val.getAddress()));
                List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>()
                        .in("term_id",addressList).in("tg_build_doorplate",tgIds));
                if(wiredMeterList != null && wiredMeterList.size() >0){
                    List<String> ids = new ArrayList<>();
                    wiredMeterList.forEach(val -> ids.add(val.getId()+""));
                    meterId = dataViewMapper.getMeterId(ids);
                }
            }
        }else{
            List<Term> terms =termManagerMapper.selectList(new QueryWrapper<Term>().eq("area_id",areaId).eq("model_type","1"));
            if(terms != null && terms.size()>0){
                List<String> addressList = new ArrayList<>();
                terms.forEach(val-> addressList.add(val.getAddress()));
                List<WiredMeter> wiredMeterList = wiredMeterMapper.selectList(new QueryWrapper<WiredMeter>().in("term_id",addressList));
                if(wiredMeterList != null && wiredMeterList.size() >0){
                    List<String> ids = new ArrayList<>();
                    wiredMeterList.forEach(val -> ids.add(val.getId()+""));
                    meterId = dataViewMapper.getMeterId(ids);
                }
            }
        }
        List<String> temp = new ArrayList<>(meterId);
        if(temp.size()>0){
            DynamicDataSource.name.set("w");
            //上报的MeterId集合
            List<String> ss= mapper.getNoReport818(meterId,date);
            meterId.removeAll(ss);
            DynamicDataSource.name.set("r");
            if(meterId.size()>0){
                result = mapper.getCollMeterList(meterId);
            }
        }
        return result;
    }
}
