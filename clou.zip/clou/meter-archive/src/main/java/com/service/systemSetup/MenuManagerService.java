package com.service.systemSetup;


import com.entity.systemSetup.Menu;
import com.entity.systemSetup.Role;
import com.vo.systemSetUpVo.MenuVo;

import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/6/21
 */
public interface MenuManagerService {
    List<Menu> getParentMenu();

    MenuVo getSubMenuByIndex(String index);

    MenuVo getAllMenu(Role role);

    List<MenuVo> reGetChildList(String parentId);

    List<String> getCurrentUserMenu();
}
