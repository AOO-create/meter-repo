package com.mapper.message;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pojo.Message;
import org.apache.ibatis.annotations.Param;

/**
 * @author liuwei
 * @description
 * @date 2022/9/30
 */
public interface MessageManagerMapper extends BaseMapper<Message> {
    int readMessage(@Param("id") String id);
}
