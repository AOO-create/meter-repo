package com.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @author liuwei
 * @description
 * @date 2022/6/23
 */
@Data
@TableName("w_nb")
public class WNB {
    @TableId(type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)//转化成string传到前端
    private Long wmtrId;

    private String meterAddress;

    private String orgId ;

    private String instLoc;

    private String areaId ;

    private String instDate;

    private String updTime;

    private String tgBuildDoorplate;

    private String name;

    private String wmtrType;

    private String productId;

    private String imei;

    private String deviceId;

    private String protoCode;
}
