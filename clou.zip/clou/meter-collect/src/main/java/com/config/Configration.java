package com.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 自动配置类
 * @date 2021/11/17 8:51
 */
@Configuration
@EnableConfigurationProperties(ProductProperties.class)
//@ConditionalOnClass(Test.class)
public class Configration {

    /**
     * 配置对象
     */
    @Autowired
    ProductProperties productProperties;

    }
