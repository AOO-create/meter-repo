package com.mapper.organization;

import com.entity.organization.Org;
import org.apache.ibatis.annotations.Param;
import java.util.List;
/**
 * 说明：单位mapper
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-12-30
 */
public interface OrgMapper {

    Org getOrg(@Param("orgId") String orgId);

    Org getOrgByAccount(@Param("orgAccount") String orgAccount);
}
