package com.fegin.server;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import com.config.DynamicDataSource;
import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.NBDTO;
import com.dto.equipment.TermDTO;
import com.dto.equipment.WiredMeterDTO;
import com.dto.organization.GradeDTO;
import com.entity.Org;
import com.entity.Role;
import com.entity.User;
import com.mapper.organization.OrgMapper;
import com.service.cl6904.CL6904Service;
import com.service.equipment.DayDataManagerService;
import com.service.equipment.NBmeterService;
import com.service.equipment.TermManagerService;
import com.service.equipment.WiredMeterService;
import com.service.organization.BDGradeService;
import com.service.organization.GradeService;
import com.util.ShiroConstUtils;
import com.vo.equipment.CollectMeterVo;
import com.vo.exportExcelVo.ExportExcelParamsVo;
import com.websocket.service.WebSocketService;
import io.micrometer.core.instrument.Meter;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/archive/ToCollect")
public class ArchiveServer {

    @Autowired
    private ShiroConstUtils shiro;

    @Autowired
    private DayDataManagerService dayDataManagerService;

    @Autowired
    private TermManagerService termManagerService;

    @Autowired
    private WiredMeterService wiredMeterService;

    @Autowired
    private NBmeterService nBmeterService;

    @Autowired
    private GradeService gradeService;

    @Autowired
    private BDGradeService bdGradeService;

    @Autowired
    private CL6904Service cl6904Service;

    @RequestMapping("/getOrg")
    public Org getOrg(){
        return shiro.getOrg();
    }

    @RequestMapping("/getUser")
    public User getUser(){
        return shiro.getUser();
    }

    @RequestMapping("/getRole")
    public Role getRole(){
        return shiro.getRole();
    }

    @RequestMapping("/getTgId")
    public String getTgId(){
        return shiro.getTgBuildDoorplate();
    }

    @RequestMapping("/getAreaId")
    public String getAreaId(){
        return shiro.getAreaId();
    }

    @RequestMapping("/websocket")
    public void sendMessage(@RequestParam("userName") String userName ,@RequestParam("message") String message){
        WebSocketService.sendMessage(userName,message);
    }

    @RequestMapping("ExcelDayDataIn")
    public void ExcelDayDataIn(@RequestBody Map<String,Object> map){
        List<MeterDayDataDTO> list = (List<MeterDayDataDTO>) map.get("list");
        String meterType = (String) map.get("meterType");
        dayDataManagerService.ExcelDayDataIn(list,meterType);
    }

    @RequestMapping("ExcelTermIn")
    public Result ExcelTermIn(@RequestBody List<TermDTO> list) throws Exception{
        return termManagerService.ExcelTermIn(list);
    }

    @RequestMapping("ExcelWiredIn")
    Result  ExcelWiredIn(@RequestBody List<WiredMeterDTO> list) throws Exception{
        return wiredMeterService.ExcelWiredIn(list);
    }

    @RequestMapping("ExcelNBIn")
    public Result ExcelNBIn(@RequestBody List<NBDTO> list) throws Exception{
        return nBmeterService.ExcelNBIn(list);
    }

    @RequestMapping("ExcelNBProductIn")
    public Result ExcelNBProductIn(@RequestBody List<NBDTO> list) throws Exception{
        return nBmeterService.ExcelNBProductIn(list);
    }

    @RequestMapping("getWiredExportData")
    List<MeterDayDataDTO> getWiredExportData(@RequestBody ExportExcelParamsVo exportExcelParams){
        return wiredMeterService.getExportData(exportExcelParams);
    }

    @RequestMapping("findGrade")
    public Page<GradeDTO> findGrade(@RequestBody GradeDTO dto){
        return gradeService.findGrade(dto);
    }

    @RequestMapping("getAreaIdByName")
    public String getAreaIdByName(@RequestBody MeterDayDataDTO dto){
        return gradeService.getAreaIdByName(dto.getTermName());
    }

    @RequestMapping("/getAllDayData")
    public Map<String, Page<MeterDayDataDTO>> getAllDayData(@RequestBody MeterDayDataDTO dto) throws ParseException {
        return dayDataManagerService.getAllDayData(dto);
    }

    @PostMapping("/getMeter")
    public Page<WiredMeterDTO> getMeter(@RequestBody WiredMeterDTO dto){
        return wiredMeterService.getMeter(dto);
    }

    @RequestMapping("/ternalfileList")
    @ResponseBody
    public Page<TermDTO> getTerm(@RequestBody TermDTO dto) {
        return termManagerService.getTerm(dto);
    }

    @RequestMapping("/getGradeNameById")
    public String getGradeNameById(@RequestParam("id") String id ){
        return gradeService.getGradeNameById(id);
    }

    @RequestMapping("/getBDGradeNameById")
    public String getBDGradeNameById(@RequestParam("id") String id ){
        return bdGradeService.getBDGradeNameById(id);
    }

    @RequestMapping("/getCL6904PapR")
    public List<WiredMeterDTO> getCL6904PapR(@RequestParam("id") String id ,@RequestParam("date") String date
            ,@RequestParam(value = "currentPos") String currentPos, @RequestParam(value = "limit") String limit){
        return cl6904Service.getCL6904PapR(id,date,currentPos,limit);
    }

    @RequestMapping("/getReportCl6904")
    public int getReportCl6904(@RequestBody MeterDayDataDTO dto){
        return cl6904Service.getReportCl6904(dto.getDate(),dto.getAreaId(),dto.getTgIds());
    }

    @RequestMapping("/getPapR")
    MeterDayDataDTO getPapR(@RequestParam("id") String id, @RequestParam("date") String date){
        return cl6904Service.getPapR(id,date);
    }

    @RequestMapping("/getCL6904NoReport")
    List<CollectMeterVo> getCL6904NoReport(@RequestBody MeterDayDataDTO dayDataDTO){
        return cl6904Service.getCL6904NoReport(dayDataDTO);
    }
}
