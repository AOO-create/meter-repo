package com.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.constant.Const;
import com.constant.ProtoConstant;
import com.entity.aotemanCommand.AotemanSendCommand;
import com.entity.equipment.Term;
import com.entity.equipment.WNB;
import com.entity.nbFrame.TermSendCommand;
import com.entity.nbFrame.nbSendCommand;
import com.fegin.client.ArchiveClient;
import com.mapper.aotemanCommand.AotemanCommandMapper;
import com.mapper.equipment.NBmeterMapper;
import com.mapper.equipment.TermMapper;
import com.mapper.nbFrame.CommandManagerMapper;
import com.mapper.nbFrame.TermCommandManagerMapper;
import com.service.CommandManagerService;
import com.utils.AepUtils;
import com.utils.BCDCode;
import com.vo.nbSendCommandVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @description
 * @date 2022/7/7
 */
@Service
public class CommandManagerServiceImpl implements CommandManagerService {

    @Resource
    private CommandManagerMapper commandManagerMapper;

    @Autowired
    private TermCommandManagerMapper termCommandManagerMapper;

    @Autowired
    private NBmeterMapper nBmeterMapper;

    @Autowired
    private AotemanCommandMapper aotemanCommandMapper;

    @Autowired
    private ArchiveClient archiveClient;

    @Autowired
    private TermMapper termMapper;

    private static String toTen(String baseNumber) {
        char[] chars = baseNumber.toCharArray();
        int length = chars.length;
        StringBuilder baseNumberBuilder = new StringBuilder(baseNumber);
        for(int i = 0; i< 10-length; i++){
            baseNumberBuilder.insert(0, "0");
        }
        baseNumber = baseNumberBuilder.toString();
        return baseNumber;
    }

    private static String addZero(String str){
        if(str.toCharArray().length % 2 != 0){
            str = "0" + str;
        }
        return str;
    }

    @Override
    public Page<nbSendCommand> findAll(nbSendCommandVo vo) {
        QueryWrapper qw = new QueryWrapper();
        if(vo.getMeterType().equals("0")){
            qw = new QueryWrapper<nbSendCommand>();
            if (!vo.getType().equals("") && vo.getType() != null) {
                qw.eq("type", vo.getType());
            }
        }else if(vo.getMeterType().equals("1")){
            qw = new QueryWrapper<TermSendCommand>();
            if (!vo.getType().equals("") && vo.getType() != null) {
                qw.eq("type", vo.getType());
            }
        }else{
            qw = new QueryWrapper<AotemanSendCommand>();
        }
        if (!vo.getMeterAddress().equals("") && vo.getMeterAddress() != null) {
            qw.like("meter_address",'%'  + vo.getMeterAddress() + "%");
        }

        if(vo.getCreateTime()!=null){
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String startDate = dateFormat.format(vo.getCreateTime());

            Calendar c = Calendar.getInstance();
            Date date = null;
            try {
                date = dateFormat.parse(startDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            c.setTime(date);
            int day = c.get(Calendar.DATE);
            c.set(Calendar.DATE, day + 1);

            String dayAfter = new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
            qw.between("create_time", startDate, dayAfter);
        }

        Page  page = new Page();
        String areaId = archiveClient.getAreaId();
        String tgId = archiveClient.getTgId();
        String roleCode = archiveClient.getRole().getRoleCode();
        String orgId= archiveClient.getOrg().getOrgId();

        if(roleCode.equals("admin")){
            //管理员查看所有 不加限制
        }else if(null == tgId || "".equals(tgId)){
            //是组织区域用户登录
            List<String> ids = new ArrayList<>();
            if(vo.getMeterType().equals("0") || vo.getMeterType().equals("2")){
                List<WNB> wnbList = nBmeterMapper.selectList(new QueryWrapper<WNB>().eq("area_id",areaId));
                for (WNB wnb : wnbList) {
                    ids.add(wnb.getMeterAddress());
                }
                qw.in("meter_address",ids);
            }else if(vo.getMeterType().equals("1")){
                List<Term> termList = termMapper.selectList(new QueryWrapper<Term>().eq("area_id",areaId));
                for(Term term :termList){
                    ids.add(term.getAddress());
                }
                qw.in("address",ids);
            }
        }else {
            //门栋单元或屋室
            List<String> bdIds = archiveClient.reGetChildBDGradeId(tgId,orgId);
            List<String> ids = new ArrayList<>();
            if(vo.getMeterType().equals("0") || vo.getMeterType().equals("2")){
                List<WNB> wnbList = nBmeterMapper.selectList(new QueryWrapper<WNB>().in("tg_build_doorplate",bdIds));
                for (WNB wnb : wnbList) {
                    ids.add(wnb.getMeterAddress());
                }
                qw.in("meter_address",ids);
            }else if(vo.getMeterType().equals("1")){
                List<Term> termList = termMapper.selectList(new QueryWrapper<Term>().eq("area_id",areaId));
                for(Term term :termList){
                    ids.add(term.getAddress());
                }
                qw.in("address",ids);
            }
        }

        if(vo.getMeterType().equals("0")){
            page = new Page<nbSendCommand>(vo.getPage(), vo.getLimit());
            page = commandManagerMapper.selectPage(page, qw);
        }else if(vo.getMeterType().equals("1")){
            page = new Page<TermSendCommand>(vo.getPage(), vo.getLimit());
            page = termCommandManagerMapper.selectPage(page,qw);
        }else{
            page = new Page<AotemanSendCommand>(vo.getPage(), vo.getLimit());
            page = aotemanCommandMapper.selectPage(page,qw);
        }
//        page.setTotal(page.getRecords().size());
        if(page.getRecords().size() == 0){
            page.setTotal(0);
        }
        return page;
    }

    @Override
    public boolean saveCommand(nbSendCommandVo command) {
        nbSendCommand sendCommand = new nbSendCommand();
        sendCommand.setMeterAddress(command.getMeterAddress());
        sendCommand.setType(command.getType());
        sendCommand.setCreateTime(new Date());
        sendCommand.setUpdTime(new Date());
        sendCommand.setFlag("0");
        //调用方法设置参数
        sendCommand.setParam(toGiveParam(command.getType(),command));

        //根据类型设置报文信息报文信息
        sendCommand.setFrame(makeFrame(sendCommand));
        WNB wnb = nBmeterMapper.selectOne(new QueryWrapper<WNB>().eq("meter_address",command.getMeterAddress()));
        sendCommand.setImei(wnb.getImei());
        //工具方法赋值参数
        int count = commandManagerMapper.insert(sendCommand);
        return count > 0;
    }

    @Override
    public boolean updateCommand(nbSendCommandVo command) {
        nbSendCommand sendCommand = new nbSendCommand();
        sendCommand.setId(command.getId());
        sendCommand.setMeterAddress(command.getMeterAddress());
        sendCommand.setType(command.getType());
        sendCommand.setUpdTime(new Date());
        sendCommand.setFlag(command.getFlag());
        //调用方法设置参数
        sendCommand.setParam(toGiveParam(command.getType(),command));
        sendCommand.setImei(command.getImei());
        //根据类型设置报文信息报文信息
        sendCommand.setFrame(makeFrame(sendCommand));
        int count = commandManagerMapper.updateById(sendCommand);
        return count > 0;
    }

    @Override
    public boolean deleteCommand(String id) {
        int count = commandManagerMapper.deleteById(id);
        return count > 0;
    }

    @Override
    public boolean batchDeleteCommand(List<String> ids) {
        int count = commandManagerMapper.deleteBatchIds(ids);
        return count == ids.size();
    }

    @Override
    public nbSendCommandVo getParam(nbSendCommand command) {
        nbSendCommandVo vo = new nbSendCommandVo();
        JSONObject jsonObject = (JSONObject) JSONObject.parse(command.getParam());
        switch (command.getType()){
            case Const.TO_SEND_FRAME_ONE:{
                String baseNumber = jsonObject.getString("baseNumber");
                vo.setBaseNumber(baseNumber);
                break;
            }
            case Const.TO_SEND_FRAME_TWO:{
                String coefficient = jsonObject.getString("coefficient");
                vo.setCoefficient(coefficient);
                break;
            }
            case Const.TO_SEND_FRAME_THREE:{
                String status = jsonObject.getString("status");
                vo.setStatus(status);
                break;
            }
            case Const.TO_SEND_FRAME_FOUR:{
                String dayDataDate = jsonObject.getString("dayDataDate");
                vo.setDayDataDate(dayDataDate);
                break;
            }
            case Const.TO_SEND_FRAME_FIVE:{
                String monthDataDate = jsonObject.getString("monthDataDate");
                vo.setMonthDataDate(monthDataDate);
                break;
            }
            case Const.TO_SEND_FRAME_SIX:{
                String hourDataDate = jsonObject.getString("hourDataDate");
                vo.setHourDataDate(hourDataDate);
                break;
            }
            case Const.TO_SEND_FRAME_SEVEN:{
                String cycle = jsonObject.getString("cycle");
                String interval = jsonObject.getString("interval");
                String startMin = jsonObject.getString("startMin");
                String startHour = jsonObject.getString("startHour");
                vo.setInterval(interval);
                vo.setStartHour(startHour);
                vo.setStartMin(startMin);
                vo.setCycle(cycle);
                break;
            }
            case Const.TO_SEND_FRAME_EIGHT:{
                String onDate = jsonObject.getString("onDate");
                String offDate = jsonObject.getString("offDate");
                String rustProofScale = jsonObject.getString("rustProofScale");
                String minute = jsonObject.getString("minute");
                String hour = jsonObject.getString("hour");
                String date = jsonObject.getString("date");
                vo.setOnDate(onDate);
                vo.setOffDate(offDate);
                vo.setRustProofScale(rustProofScale);
                vo.setMinute(minute);
                vo.setHour(hour);
                vo.setDate(date);
                break;
            }
            case Const.TO_SEND_FRAME_NINE:{
                String statusTwo = jsonObject.getString("statusTwo");
                String actionTime = jsonObject.getString("actionTime");
                vo.setStatusTwo(statusTwo);
                vo.setActionTime(actionTime);
                break;
            }
            default: break;
        }
        return vo;
    }

    private String toGiveParam(String type,nbSendCommandVo vo){
        String param = "";
        switch (type){
            case Const.TO_SEND_FRAME_ONE:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("baseNumber",vo.getBaseNumber());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_TWO:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("coefficient",vo.getCoefficient());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_THREE:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("status",vo.getStatus());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_FOUR:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("dayDataDate",vo.getDayDataDate());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_FIVE:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("monthDataDate",vo.getMonthDataDate());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_SIX:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("hourDataDate",vo.getHourDataDate());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_SEVEN:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("cycle",vo.getCycle());
                jsonObject.put("interval",vo.getInterval());
                jsonObject.put("startMin",vo.getStartMin());
                jsonObject.put("startHour",vo.getStartHour());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_EIGHT:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("onDate",vo.getOnDate());
                jsonObject.put("offDate",vo.getOffDate());
                jsonObject.put("rustProofScale",vo.getRustProofScale());
                jsonObject.put("minute",vo.getMinute());
                jsonObject.put("hour",vo.getHour());
                jsonObject.put("date",vo.getDate());
                param = jsonObject.toJSONString();
                break;
            }
            case Const.TO_SEND_FRAME_NINE:{
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("statusTwo",vo.getStatusTwo());
                jsonObject.put("actionTime",vo.getActionTime());
                param = jsonObject.toJSONString();
                break;
            }
            default: break;
        }
        return param;
    }

    private String makeFrame(nbSendCommand vo){
        StringBuilder frame = new StringBuilder(30);
        String type = vo.getType();
        String param = vo.getParam();
        switch (type){
            case Const.TO_SEND_FRAME_ONE:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("04" )  //控制码
                        .append("0900")  // 数据长度 （固定值）
                        .append("00C000") //数据标识 序列号
                        .append("00");  //正负标志，永为正
                //拼接参数--表底数   123 ->0000002301
                String baseNumber = BCDCode.StringBcdToInt(toTen(jsonObject.getString("baseNumber")));//转换成BCD并补齐10位
                frame.append(baseNumber);
                //拼接校和位和结束符
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_TWO:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("04" )  //控制码
                        .append("0400")  // 数据长度 （固定值）
                        .append("08C000"); //数据标识 序列号
                //拼接参数错峰系数  需要转换为16进制数字
                String coefficient = jsonObject.getString("coefficient");
                String ten_coefficient = addZero(Integer.parseInt(coefficient,16) + "");
                frame.append(ten_coefficient);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_THREE:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("04" )  //控制码
                        .append("0400")  // 数据长度 （固定值）
                        .append("10C000"); //数据标识 序列号
                //拼接参数开关阀门状态
                String status = jsonObject.getString("status");
                frame.append(status);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_FOUR:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("01" )  //控制码
                        .append("0600")  // 数据长度 （固定值）
                        .append("2DC000"); //数据标识 序列号
                //拼接参数 日期
                String dayDataDate = BCDCode.StringBcdToInt(jsonObject.getString("dayDataDate"));
                frame.append(dayDataDate);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_FIVE:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("01" )  //控制码
                        .append("0500")  // 数据长度 （固定值）
                        .append("2FC000"); //数据标识 序列号
                //拼接参数 月日期
                String monthDataDate = BCDCode.StringBcdToInt(jsonObject.getString("monthDataDate"));
                frame.append(monthDataDate);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_SIX:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("01" )  //控制码
                        .append("0600")  // 数据长度 （固定值）
                        .append("31C000"); //数据标识 序列号
                //拼接参数 小时日期
                String hourDataDate = BCDCode.StringBcdToInt(jsonObject.getString("hourDataDate"));
                frame.append(hourDataDate);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_SEVEN:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("04" )  //控制码
                        .append("0700")  // 数据长度 （固定值）
                        .append("06C000"); //数据标识 序列号
                String cycle = jsonObject.getString("cycle");
                String interval = addZero(jsonObject.getString("interval"));
                String startMin = addZero(jsonObject.getString("startMin"));
                String startHour = addZero(jsonObject.getString("startHour"));
                frame.append(cycle).append(interval).append(startMin).append(startHour);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_EIGHT:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("04" )  //控制码
                        .append("0900")  // 数据长度 （固定值）
                        .append("34C000"); //数据标识 序列号
                //拼接参数开阀时间、关阀时间、防锈垢时间、分钟、小时、日期
                String onDate = addZero(jsonObject.getString("onDate"));
                String offDate = addZero(jsonObject.getString("offDate"));
                String rustProofScale = addZero(jsonObject.getString("rustProofScale"));
                String minute = addZero(jsonObject.getString("minute"));
                String hour = addZero(jsonObject.getString("hour"));
                String date = addZero(jsonObject.getString("date"));
                frame.append(onDate).append(offDate).append(rustProofScale)
                     .append(minute).append(hour).append(date);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            case Const.TO_SEND_FRAME_NINE:{
                JSONObject jsonObject = (JSONObject) JSONObject.parse(param);
                frame.append(ProtoConstant.FarmeCode.StartCode)
                        .append("10")  //设备类型
                        .append(BCDCode.StringBcdToInt(toSix(vo.getMeterAddress())))
                        .append("04" )  //控制码
                        .append("0500")  // 数据长度 （固定值）
                        .append("38C000"); //数据标识 序列号
                String statusTwo = jsonObject.getString("statusTwo");
                String actionTime = addZero(jsonObject.getString("actionTime"));
                frame.append(statusTwo).append(actionTime);
                String checkCode = AepUtils.makeChecksum(frame.toString());
                frame.append(checkCode).append(ProtoConstant.FarmeCode.EndCode);
                break;
            }
            default: break;
        }
        return frame.toString();
    }

    private String toSix(String meterAddress) {
        char[] chars = meterAddress.toCharArray();
        int length = chars.length;
        StringBuilder baseNumberBuilder = new StringBuilder(meterAddress);
        for(int i = 0; i< 16-length; i++){
            baseNumberBuilder.insert(0, "0");
        }
        meterAddress = baseNumberBuilder.toString();
        return meterAddress;
    }
}
