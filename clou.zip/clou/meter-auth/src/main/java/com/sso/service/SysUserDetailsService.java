package com.sso.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface SysUserDetailsService extends UserDetailsService {
}
