package com.szclou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 说明：
 * 作者：钟明星/CL19803
 * 版本：v1.0
 * 时间：2016-08-06
 */
@Data
public class Term {
    private String terminalId;

    private String assetNo;//资产编号

    private String madeNo;//出厂编号

    private String cpId;//采集点编号（目前没有用到）

    private int statusCode;//终端运行状态

    private String orgId ;//供能单位


    private String terminalAddr;//终端地址码

    private String districtCode;//终端行政区码

    private String masterIp;//主站ip地址

    private Integer masterPort;//端口

    private int collMode;//通信方式

    private int terminalTypeCode;//终端类型

    private String productId;//终端型号（暂时不用，保留）


    private String protocolCode;//采用通讯规约
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date runDate;//投运日期
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date installDate;//安装日期

    private String installStaff;//安装人员

    private String installAddr;//安装地址

    private String installEnv;//安装环境

    private String remark;

    private Date updTime;



    private String ipPort;//不存数据库

    private int online;//不存数据库

    private String areaId;

    private String searchType;

    private int page;

    private int size;
    private String modelType;//集中器型号

}
