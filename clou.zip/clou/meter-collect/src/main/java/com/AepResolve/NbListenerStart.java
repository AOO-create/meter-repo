package com.AepResolve;


import aep.nbiot.callback.AepMqOrginCallback;
import aep.nbiot.service.AepMqService;
import com.service.WaterMeterDayReadService;
import com.service.impl.WaterMeterDayReadServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class NbListenerStart implements ApplicationListener<ApplicationStartedEvent> {


    @Autowired
    private WaterMeterDayReadService waterMeterDayReadService;

    @Autowired
    private AepMqService aepMqService;
    @Autowired
    private ProtoResolveService protoResolveService;

    @Override
    public void onApplicationEvent(ApplicationStartedEvent event) {
        aepMqService.listenerOrign(null,new AepMqOrginCallback() {
            @Override
            public void listener(String msg) {
                String result =protoResolveService.handleFrame(msg);
                System.out.println("原始msg打印消息：" +msg);
                System.out.println("处理结果为:"+ result);
            }
        });
    }
}
