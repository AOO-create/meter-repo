package aep.nbiot.strategy.aepdevicemanage;

import aep.nbiot.strategy.IAepStrategy;
import aep.nbiot.util.ParamsUtil;
import com.ctg.ag.sdk.biz.AepDeviceManagementClient;
import com.ctg.ag.sdk.biz.aep_device_management.DeleteDeviceRequest;
import com.ctg.ag.sdk.biz.aep_device_management.DeleteDeviceResponse;
import com.ctg.ag.sdk.biz.aep_device_management.QueryDeviceListRequest;
import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

import java.util.HashMap;

/**
 * @author wufanghao
 * @version 1.0
 * @description: 删除设备
 * @date 2021/11/17 8:03
 */
public class DeleteDeviceStrategy implements IAepStrategy {

    @Override
    public BaseApiResponse invockApi(BaseApiClient _client, HashMap<String,Object> params, HashMap<String,Object> body) {
        try {
//          ParamsUtil paramsUtil = new ParamsUtil(new DeleteDeviceRequest());
//          DeleteDeviceRequest request = (DeleteDeviceRequest) paramsUtil.addParams(params,body);
            AepDeviceManagementClient client = AepDeviceManagementClient.newClient()
                    .appKey("vNRFeVsRtI6").appSecret("h1Kmx4Gui0")
                    .build();

            DeleteDeviceRequest request = new DeleteDeviceRequest();

            request.setParamMasterKey("2c52ccffa22340958d3886007f6b1480");	// single value
            request.setParamProductId(15118798);	// single value
            request.setParamDeviceIds(params.get("deviceIds"));	// single value
            DeleteDeviceResponse response = client.DeleteDevice(request);
            System.out.println(client.DeleteDevice(request));
            return response;
//          AepDeviceManagementClient client = (AepDeviceManagementClient)_client;
//          return client.DeleteDevice(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
