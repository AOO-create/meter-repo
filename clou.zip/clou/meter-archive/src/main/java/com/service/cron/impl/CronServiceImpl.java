package com.service.cron.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fegin.client.NettyClient;
import com.entity.cron.Cron;
import com.entity.equipment.FourthGenerationMeter;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mapper.cron.CronMapper;
import com.mapper.equipment.FourthGenerationMapper;
import com.service.cron.CronService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;

@Service
public class CronServiceImpl implements CronService {

	private Logger log = LoggerFactory.getLogger(getClass());


	@Autowired
	private ThreadPoolTaskScheduler threadPoolTaskScheduler;

	@Autowired
	private FourthGenerationMapper fourthGenerationMapper;

	@Autowired
	private NettyClient heartBeatHandle;

	@Autowired
	private CronMapper mapper;

	private Map<Long, ScheduledFuture<?>> futureMap = new HashMap<>();

	@Bean
	public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
		return new ThreadPoolTaskScheduler();
	}

	@Override
	public void startCron(Cron cron) {
		if (futureMap.containsKey(cron.getId())) {
			log.warn("已经存在重复任务，任务id:{}，任务标题：{}，任务提醒时刻：{}，任务开始时间：{}，任务截止时间：{}",
					cron.getId(), cron.getTitle(), cron.getExecuteTime(), cron.getStartTime(), cron.getDeadTime());
			return;
		}
		if (new Date().equals(cron.getStartTime()) || new Date().equals(cron.getDeadTime()) ||
				(new Date().after(cron.getStartTime()) && new Date().before(cron.getDeadTime()))) {
			String cronExp = cron.getExecuteTime();
			ScheduledFuture<?> future = threadPoolTaskScheduler.schedule(new MyRunnable(cron), new CronTrigger(cronExp));
			futureMap.put(cron.getId(), future);
			log.info("启动定时任务成功，任务id:{}，任务标题：{}，任务提醒时刻：{}，任务开始时间：{}，任务截止时间：{}",
					cron.getId(), cron.getTitle(), cron.getExecuteTime(), cron.getStartTime(), cron.getDeadTime());
		}
	}

	@Override
	public void stopCron(Cron cron) {
		ScheduledFuture<?> future = futureMap.get(cron.getId());
		if (future != null) {
			future.cancel(true);
			futureMap.remove(cron.getId());
			log.info("关闭定时任务成功，任务id:{}，任务标题：{}，任务提醒时刻：{}，任务开始时间：{}，任务截止时间：{}",
			cron.getId(), cron.getTitle(), cron.getExecuteTime(), cron.getStartTime(), cron.getDeadTime());
		}
	}

	@Override
	public void changeCron(Cron cron) {
		stopCron(cron);// 先停止，在开启.
		startCron(cron);
	}

	@Override
	public void updateCron(Cron cron) {
		mapper.updateById(cron);
		changeCron(cron);
	}

	@Override
	public Page<Cron> findCron() {
		Page<Cron> page = new Page<>(1,10);
		page = mapper.selectPage(page,null);
		return page;
	}

	@Override
	public void statusOpen(Cron cron){
		Cron cron1 = mapper.selectById(cron.getId());
		if(cron.getStatus().equals("1")){
			cron1.setStatus("1");
			mapper.updateById(cron1);
			startCron(cron);
		}else {
			cron1.setStatus("2");
			mapper.updateById(cron1);
			stopCron(cron);
		}
	}

	//暂停使用，定时任务功能模块
//	@Scheduled(cron = "0 0 2 * * ?")
	public void cronManage() {
		List<Cron> list = mapper.selectList(new QueryWrapper<Cron>().eq("status","1"));
		list.forEach(c -> {
			if (new Date().after(c.getDeadTime())) {
				stopCron(c);
				mapper.deleteById(c.getId());
				log.info("删除过期定时任务成功，任务id:{}，任务标题：{}，任务提醒时刻：{}，任务开始时间：{}，任务截止时间：{}",
						c.getId(), c.getTitle(), c.getExecuteTime(), c.getStartTime(), c.getDeadTime());
			} else {
				log.info("尝试启动尚未start的定时任务，任务id:{}，任务标题：{}，任务提醒时刻：{}，任务开始时间：{}，任务截止时间：{}",
						c.getId(), c.getTitle(), c.getExecuteTime(), c.getStartTime(), c.getDeadTime());
				startCron(c);
			}
		});
	}

	private class MyRunnable implements Runnable {

		private Cron cron;

		public MyRunnable(Cron cron) {
			this.cron = cron;
		}

		@Override
		public void run() {
			// 定义任务要做的事，完成任务逻辑
			List<FourthGenerationMeter>  meterList = fourthGenerationMapper.selectList(null);
			if(cron.getType().equals("1")){
				for(FourthGenerationMeter meter:meterList){
					String collId = meter.getCollId()+"";
					heartBeatHandle.fourthReadFlow(meter.getMeterAddress(),collId);
				}
			}else if(cron.getType().equals("2")){
				//定时开阀
				for(FourthGenerationMeter meter:meterList){
					if(meter.getMeterAddress().equals(cron.getMeterAddress())){
						String collId = meter.getCollId()+"";
						heartBeatHandle.statusControll(meter.getMeterAddress(),"1",collId);
					}
				}
			}else if(cron.getType().equals("3")){
				//定时关阀
				for(FourthGenerationMeter meter:meterList){
					if(meter.getMeterAddress().equals(cron.getMeterAddress())){
						String collId = meter.getCollId()+"";
						heartBeatHandle.statusControll(meter.getMeterAddress(),"2",collId);
					}
				}
			}
		}
	}

}
