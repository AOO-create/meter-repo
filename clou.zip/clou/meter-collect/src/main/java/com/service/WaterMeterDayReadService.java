package com.service;


import com.AepResolve.MeterFrameDataChuangren;
import com.entity.equipment.WaterMeterDayRead;

public interface WaterMeterDayReadService {
    /**
     * 添加日记录
     */
    boolean add (MeterFrameDataChuangren waterMeterDayRead);

    boolean add (   WaterMeterDayRead waterMeterDayRead );

    boolean addNewProtol(WaterMeterDayRead waterMeterDayRead);
}
