package com.aop.annotation;

import java.lang.annotation.*;

/**
 * @author liuwei
 * @description  表具操作记录注解
 * @date 2022/6/9
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Documented
public @interface ChangeMeterAopAnnotation {
    int changeType() ;
}
