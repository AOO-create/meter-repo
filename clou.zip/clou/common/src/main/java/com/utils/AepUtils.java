package com.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class AepUtils {
    public static String join(List<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String s : list) {
            stringBuilder.append(s);
        }
        return stringBuilder.toString();
    }

    public static String makeChecksum(String data) {
        if (data == null || data.equals("")) {
            return "";
        }
        if (data.length() % 2 != 0) {
            System.out.println("字符串不是一个完整的16进制的字符串");
            return "";
        }
        int total = 0;
        int len = data.length();
        int num = 0;
        while (num < len) {
            String s = data.substring(num, num + 2);
            total += Integer.parseInt(s, 16);
            num = num + 2;
        }
        /**
         * 用256求余最大是255，即16进制的FF
         */
        int mod = total % 256;
        String hex = Integer.toHexString(mod);
        len = hex.length();
        // 如果不够校验位的长度，补0,这里用的是两位校验
        if (len < 2) {
            hex = "0" + hex;
        }
        return hex;
    }

    public static Integer bigEndian(List<String> list) {
        Collections.reverse(list);
        StringBuilder stringBuilder = new StringBuilder();
        for (String s : list) {
            stringBuilder = stringBuilder.append(s);
        }
        return Integer.parseInt(stringBuilder.toString(), 16);
    }


    public static List<String> stringToArray(String str) {
        int m = str.length() / 2;
        if (m * 2 < str.length()) m++;
        List<String> strs = new ArrayList<>();
        int j = 0;
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {

            if (i % 2 == 0) {//每隔两个
                stringBuilder.append(str.charAt(i));
            } else {
                strs.add((stringBuilder.append(str.charAt(i)).toString()));
                j++;
                stringBuilder.delete(0, stringBuilder.length());
            }

        }
        return strs;
    }

    /***
     * 获取精确到秒的时间
     * @return
     */
    public static String getTimeMills() {
        //声明一个当前系统时间
        Date date1=new Date();
        //将时间转化为字符串类型              同样首先声明一个显示格式
        SimpleDateFormat sim1=new SimpleDateFormat("yyyyMMddhhmmss");
        //通过format()方法将时间类型的数据进行格式化
        String time1=sim1.format(date1);
        //转为字符串类型并输出
        System.out.println(time1);
        return time1;
    }

    public static List<String> stringToBufferArray(String str, int num){
        char[] chars = str.toCharArray();
        List<String> stringList = new ArrayList<>();
        for(int i=0;i<chars.length;i = i + num){
            String str1 = chars[i]+"";
            for(int j = 1 ;j< num ;j++){
                if(i+j>=chars.length){
                    break;
                }
                str1 = str1 + chars[i+j];
            }
            stringList.add(str1);
        }
        return stringList;
    }

    public static String hexString2binaryString(String hexString) {

        if (hexString == null || hexString.length() % 2 != 0)

            return null;

        String bString = "", tmp;

        for (int i = 0; i < hexString.length(); i++) {

            tmp = "0000" + Integer.toBinaryString(Integer.parseInt(hexString.substring(i, i + 1), 16));

            bString += tmp.substring(tmp.length() - 4);

        }

        return bString;

    }


    public static String binaryString2hexString(String bString) {

        if (bString == null || bString.equals("") || bString.length() % 8 != 0)

            return null;

        StringBuffer tmp=new StringBuffer();

        int iTmp = 0;

        for (int i = 0; i < bString.length(); i += 4) {

            iTmp = 0;

            for (int j = 0; j < 4; j++) {

                iTmp += Integer.parseInt(bString.substring(i + j, i + j + 1)) << (4 - j - 1);

            }

            tmp.append(Integer.toHexString(iTmp));

        }

        return tmp.toString();

    }

    public static void main(String[] args) {
        AtomicInteger a = new AtomicInteger();
        a.getAndIncrement();
        System.out.println(a.get());
    }

}
