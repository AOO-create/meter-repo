package com.controller.equipment;

import com.dto.equipment.MeterDayDataDTO;
import com.dto.equipment.WiredMeterDTO;
import com.service.equipment.WiredMeterService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.text.SimpleDateFormat;

/**
 * @author liuwei
 * @description
 * @date 2022/4/25
 */
@RestController
@RequestMapping("/archive/equipment/wiredMeter")
public class WiredMeterController {
    @Autowired
    private WiredMeterService service;

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @RequestMapping("/getMeter")
    @ResponseBody
    public Page<WiredMeterDTO> getMeter(@RequestBody WiredMeterDTO dto) {
        return service.getMeter(dto);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("/saveOrUpdateWired")
    @ResponseBody
    public Result saveOrUpdateWired(@RequestBody WiredMeterDTO dto){
        if(!StringUtils.isEmpty(dto.getId())){
            return service.update(dto);
        }else{
            return service.save(dto);
        }
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("getWiredDayData")
    @ResponseBody
    public Page<MeterDayDataDTO> getWiredDayData(@RequestBody MeterDayDataDTO dto){
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        String dateString = formatter.format(dto.getDataDate());
        return service.getWiredDayData(dto,dateString);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("deleteMeter")
    @ResponseBody
    public Result deleteMeter(@RequestParam("id") String id){
        return service.deleteMeter(id);
    }

    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @PostMapping("batchDeleteWired")
    @ResponseBody
    public Result batchDeleteWired(@RequestBody List<String> ids){
        return service.batchDeleteWired(ids);
    }


    @Secured({"ROLE_ADMIN","ROLE_COMMON","ROLE_TEST","ROLE_WATER"})
    @GetMapping("validMeterAddress")
    @ResponseBody
    public Boolean validMeterAddress(@RequestParam("meterAddress") String meterAddress){
        return service.validMeterAddress(meterAddress);
    }


}
