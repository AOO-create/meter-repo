package com.vo.equipment;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.common.PageConstant;
import lombok.Data;
import java.util.List;

/**
 * @author liuwei
 * 区域收集表具分析VO
 * @date 2023/11/6 
 */
@Data
public class CollectMeterVo extends PageConstant {
    private String meterAddress;
    private String name;
    private String instLoc;
    private String dataDate;
    private String imei;
    private String protoCode;
    private String meterType;
    private String termId;
    private String channel;
    private String protocol;
    private String uartbps;
    private String count;
    private String termAddress;
    private String recentDate;
    private String dayCount;
    private String startDate;
    private String sumReportCount;

    private String date;
    private String areaId;
    private String tgBuildDoorplate;
    private String orgId;

    private String reportCount;//采集成功数量
    private String noReportCount;//采集失败数量
    private Page<CollectMeterVo> collectList;
    private List<String> reportRate;//近半年的采集率
    private List<String> halfYearDate;//近半年的日期
    private List<String> collData; //半年收集日冻结数据
    private List<String> predictRate;//根据回归方程计算得出的预测下一个月的采集率
    private List<String> catastropheDate;//突变数据日期
    private List<String> catastropheData;//突变数据值
    private int catastropheDown;
    private int catastropheUp;
    private int catastropheSum;

    private List<String> areaList;//区域名称集合
    private List<String> noReportList;
}
